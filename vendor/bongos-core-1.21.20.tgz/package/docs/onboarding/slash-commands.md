# Slash commands: which are Claude's, which are this project's

*A reference page. Skim it once, come back when a command surprises you.*

When you type `/` in Claude Code you get one list, but the commands in it come from **two different places** and are maintained by two different people. Claude Code ships some of them; this project ships the rest. They look identical in the menu, which is why a few of them trip people up — see [Easy mix-ups](#easy-mix-ups) at the bottom.

## The 10-second rule

| | **Claude Code's own** | **This project's** |
|---|---|---|
| Who ships it | Anthropic, inside the Claude Code app | This repository |
| Where it lives | Inside the app — nothing in this repo | [`.claude/skills/<name>/`](../../.claude/skills/) |
| What it acts on | Your *session* — context, model, config, account | The *build system* — tasks, claims, ships, ideas |
| Works in any repo? | Yes, everywhere | No — only in a folder that holds this code |
| Authoritative list | Type `/help` | The hall's [Commands](https://example.com/builders/commands) page |

**The short version:** if it changes your Claude session, it's Claude's. If it changes project state — a task, a claim, a ship — it's ours. If you can run it in an unrelated repo, it's Claude's.

> This is also why the commands "appear by magic" when you clone: they aren't a plugin or a download, they're files in `.claude/skills/` that Claude Code reads when a session **starts** on the folder. Clone mid-session and they won't show up until you start a fresh session — the wrinkle the [primer](primer.md) calls out in step 3.

## This project's commands

**The full list lives in the Builders Hall, on the [Commands](https://example.com/builders/commands) page** (Docs → Commands in the hall's sidebar). It shows every slash command this project has and every `bongos` terminal command, with what each does, when to reach for it and what it costs, grouped by when you'd reach for them. The page reads the list from the project itself — the `SKILL.md` files a session on this project is actually given, and the CLI's own command table — so it is always current; this file deliberately keeps no second copy that could drift (task 1004473).

The ones you'll use every session are the work loop: `/builder-start` → `/builder-claim N` → the work → `/builder-ship` (or `/builder-release` to give a task back), with `/status` and `/recall` to find things out on the way.

### Typed-only commands

On the Commands page some rows are marked **Type it yourself**. Those are **hidden from Claude's own menu but still work when you type them**. Every listed command's description sits in every session's context whether it is used or not, so the rarely used admin ones carry `disable-model-invocation: true` in their `SKILL.md`: Claude Code leaves them out of what the model sees, and only a person typing `/name` runs them (task 1004471). The catch: plain English will not reach them, and Claude will not start one on its own — type the slash form.

The four steps of `/owner-review` still answer to their old names — `/backlog-review`, `/bug-triage`, `/idea-triage`, `/priority-session` — and `/goal-close` and `/grade-sweep` each bundle two older commands that still work on their own (`/goal-uat` · `/goal-review`, and `/grader-health` · `/grade-audit`).

### Discipline modes — not slash commands any more

The three core crafts no longer have a slash command. `/dev`, `/paint` and `/ideate` were **deleted** when the root instructions split into a role-neutral kernel (`CLAUDE.md`) plus one **role pack** per craft: `docs/packs/engineer.md`, `docs/packs/artist.md`, `docs/packs/ideator.md`. A claimed task's discipline routes you to your pack — the Conductor injects its path into your session on the next prompt, and `claim.js` prints a one-line reminder — and you read it. A module-contributed discipline can still ship a skill, which is how `ui` → `/design` works.

### Commands that come with a module

Some commands ship inside an optional module and only exist on a project that turns it on — the `/otb-*` pixel-art pipeline (the `pixel-art` module) and the design-style skills such as `/impeccable` and `/style` (the `design-styles` module) are off unless the project enables them. The Commands page lists a module's commands only where that module is on, and names the module beside each one.

## Claude Code's own commands

These work in **any** repository — they have nothing to do with this project. `/help` prints the live, authoritative list for your version; the ones below are simply the ones you'll actually meet.

| Command | What it does |
|---|---|
| `/help` | List every command available right now — **the authoritative list** |
| `/clear` · `/compact` | Wipe or condense the conversation context |
| `/model` · `/config` | Switch model; change app settings |
| `/login` · `/logout` | Sign in to your **Anthropic** account |
| `/init` | Write a `CLAUDE.md` for the current codebase |
| `/cost` · `/usage` · `/context` | Token spend, plan usage, context window |
| `/doctor` | Diagnose the **Claude Code install** |
| `/memory` | Edit Claude's memory files |
| `/mcp` · `/agents` · `/hooks` · `/permissions` | Configure MCP servers, subagents, hooks, tool permissions |
| `/export` · `/resume` · `/rewind` | Save the transcript; resume or roll back a session |
| `/review` | Review a GitHub pull request |
| `/status` | **Claude Code's** session/auth status — see the warning below |

## Easy mix-ups

These are the ones that actually cause confusion.

**`/status` — the genuine collision.** Both sides define it. Claude Code's `/status` shows your session and auth state; this project's shows version and criterion progress. Which one wins depends on your Claude Code version and how it resolves the name. If you get the wrong one, say *"what's left for C8"* in plain English, or run `node scripts/gds/status.js` directly.

**`/login` is Anthropic, not us.** It signs you into your Claude account. To sign into a Cloud Bongos instance, use `bongos login <instance-url>`, or `/builder-setup` for a first-time enrolment.

**`/init` writes a `CLAUDE.md`.** It does *not* scaffold a new instance — that's `bongos init`, wrapped by `/new-project`. Running `/init` in this repo would overwrite the project's own `CLAUDE.md`.

**`/doctor` checks Claude Code.** For the build system's health — your session, toolchain, git plumbing, environment — run `node scripts/gds/doctor.js`.

**`/cost` is Claude's token spend.** To record a project cost against your claim, that's `/builder-cost`.

**`/export` vs `/read-session-export`.** Claude's `/export` *writes* a transcript zip; our `/read-session-export` *reads* one back.

**`/review` reviews a GitHub PR.** The project's review commands are `/owner-review`, `/blocker-review`, and `/goal-close` — different jobs entirely.

## Two more things worth knowing

**Every listed command has a plain-English twin.** Each skill lists trigger phrases, so *"what can I work on"* reaches `/builder-start` and *"ship it"* reaches `/builder-ship`. You never have to memorise the slash form — except for the typed-only commands above.

**Same commands, outside Claude.** The work-loop commands are also a terminal CLI: `bongos start`, `bongos claim N`, `bongos ship`. Same actions, same API — usable from any terminal, a Chromebook, or CI. Run `bongos help` for the verb list; the hall's Commands page lists them too.

**Rank gates are real.** Some of this project's commands refuse below a certain rank — that's enforced by the server on every request, not by the presence of the file on your disk. See [`canonical-permissions.md`](../canonical-permissions.md).
