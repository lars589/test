# The weekly red-team patrol

**What it is.** The patrol layer of goal 1000076 (task 1003128): deterministic
scanners that run weekly and file findings into the security-reports
adjudication queue. It complements the two always-on layers — the agent-side
prevent hooks (task 1003125) and the CI merge gates (tasks 1003126/1003127/1003129)
— by covering what those can't: **git history**, **the network** (registry
metadata), and **slow sweeps**.

## Running it

```bash
node scripts/gds/redteam-patrol.js            # dry run — print, file nothing
node scripts/gds/redteam-patrol.js --file     # the weekly cron form — files reports
node scripts/gds/redteam-patrol.js --canary          # self-test detection only
node scripts/gds/redteam-patrol.js --canary --file   # prove the full pipe (files + dispute-closes)
```

## What actually fires it

**[`.github/workflows/redteam-patrol.yml`](../../.github/workflows/redteam-patrol.yml)
— Mondays 06:17 UTC** (task 1003209, ADR 0188). Before that lane the patrol was,
in the follow-up audit's words, a manual script: tracked, documented, wired into
the control manifest, and run zero times.

The routine itself lives at
[`.claude/scheduled-tasks/redteam-weekly/`](../../.claude/scheduled-tasks/redteam-weekly/SKILL.md)
(`mode: deterministic`, `cadence: weekly`, one step, sink `gds`) and the workflow
invokes it through `run-routine.js`, so the SKILL.md's `steps:` stay the single
source of truth for what a run does. Weekly is the cadence because the checks
watch drift measured in days (release-age, new advisories), not minutes.

**The cadence and the cron are checked against each other.** `cadence: weekly` in
the SKILL.md and `cron: '17 6 * * 1'` in the workflow must agree, or
`scripts/gds/routine-schedule.js` (fitness Check 25) fails the merge gate — as it
does if the workflow stops firing the routine, or fires one that no longer
exists. Change one and change the other in the same commit. The odd minute is
deliberate: GitHub queues scheduled workflows and top-of-hour is its worst
congestion window.

**Why CI and not the always-on server.** All three checks read things only the
*repo* has — full git history, `.github/workflows/`, an auditable lockfile. A
deployed instance runs a vendored core out of `node_modules/@bongos/core`, which
has none of them, so an in-process timer would have scanned nothing and reported
clean. ADR 0188 §2.1.

### Filing from CI (optional)

A CI runner has no Bongos session, so by default the scheduled run **reports but
cannot file**: findings go to the Actions job summary and the job exits 2. To let
it file, set the repo secret **`GDS_PATROL_SESSION`** to a Bongos CLI session JSON
(`{"token":…,"api_base":…}`) for a builder holding `security.report.file`; the
workflow writes it to the session path `instance-config` resolves and the patrol
files normally. This is opt-in on purpose — the patrol must not *require* a
long-lived token to be useful.

**Red means a finding was LOST, not that a finding exists.** Findings are
advisory (ADR 0158 §2), so a run that files three of them is a success:

| the run… | exit |
|---|---|
| found nothing | 0 |
| was a dry run | 0 |
| filed its findings | 0 |
| has findings it cannot file | **2** |

Expect a standing `history-secrets` hit until the staging credential in commit
`092e473` is scrubbed from history. That is the patrol working, not the lane
being broken.

## Prerequisites

- **gitleaks** on PATH (`brew install gitleaks`) or `GITLEAKS_BIN=<path>`. The
  history scan degrades LOUDLY (a printed warning, no silent skip) when absent;
  the dependency + pin checks still run. The scheduled lane installs it itself —
  version-pinned and checksum-verified, the same binary and digest the unit gate
  uses, rather than a mutable action tag (the tj-actions lesson).
- A Bongos session (the normal builder token) for `--file`; dry runs need nothing.
  `--file` preflights it, so a sessionless run prints its findings and says it
  could not file them — it never drops into the CLI's interactive re-auth wall,
  which in a cron log is indistinguishable from a crash.
- Network access to the npm registry for the dependency checks — registry
  failures print notes and skip that item (advisory layer: fail-open, loud).

## What a finding means

Reports land at `target: redteam-patrol/<class>` for Archon adjudication in the
red-team dashboard — confirm / dispute / link-fix, exactly like a
`/builder-redteam` filing (they share the pipeline and the bounty table; patrol
reports are machine-filed, so confirming one pays nobody). The fix is always an
ordinary task; the patrol never gates and never self-executes (ADR 0158 §2).

## Design boundaries

Deterministic only — AI review was deliberately deferred (owner decision
2026-08-18, recorded on the goal). One report per finding class per run keeps
the queue at 0–3 rows weekly. Severity mapping: npm's `moderate` files as
`medium` (the bounty table's vocabulary). Caps: 10 itemized findings per report
body, the rest counted.
