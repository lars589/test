# Recipe — private-first npm distribution (the core)

> **This is one leg of three.** For the whole path from a change on core `main` to a live instance — and for when publishing to npm is *not* what moves an instance — start at [the core release pipeline](core-release-pipeline.md).
>
> **⚠️ The private half of this recipe is HISTORY as of 2026-09-13.** `@bongos/core` publishes **public** — [ADR 0283](../adr/0283-the-core-publishes-publicly-because-access-was-never-the-thing-protecting-it.md) ([task 1003872](https://cloudbongos.com/builders#/task/1003872)) supersedes [ADR 0134](../adr/0134-private-first-npm-distribution.md)'s core half. A tokenless `npm install @bongos/core` now works, so **anything below telling you to set `NPM_TOKEN` for a READ is obsolete**; a token is still needed to *publish*. The build, redaction, manifest-pin and no-leak-gate mechanics are unchanged and still accurate. The daily command is `bongos` regardless of package name.
>
> **`@bongos/client` is no longer part of this.** It was published once (2026-07-07, 0.0.2), never updated while the API moved 500+ core versions, and had **zero** consumers the whole time — every consumer vendors a copy instead. The owner removed it from npm on 2026-09-09; ADR 0134's client half is superseded ([task 1003742](https://cloudbongos.com/builders#/task/1003742)). The generated client still exists and still regenerates — it is simply not a package.
>
> **Why private must be scoped:** on npm, *unscoped* names are always public — only *scoped* names (`@bongos/…`) can be private, and only on a paid plan. So the packages publish under the `@bongos` scope, which maps to the paid `bongos` org.

## The pieces

| Package | What it is | Built by |
|---|---|---|
| `@bongos/core` | the platform an instance installs + the `bongos` CLI (`bin`) | `bongos package-core` (`scripts/gds/package-core.js`) — synthesizes the package.json + a pruned lockfile, redacts, and packs a `.tgz` |

`@bongos/core` carries `publishConfig: { access: "public" }`, and `publishArgs` passes `--access public` as well — both, so neither drifting alone can silently take the package back to restricted ([ADR 0283](../adr/0283-the-core-publishes-publicly-because-access-was-never-the-thing-protecting-it.md)). It read `restricted` until 2026-09-13; what protects the artifact is the no-leak gate on the build, not who may fetch it.

The generated typed client (`node scripts/gds/gen-api-client.js` → `clients/bongos-client/`) is deliberately **not** in this table: it is not published, carries no `publishConfig`, and is consumed by vendoring. See its own README.

## One-time owner setup (only the owner can do these)

These involve payment and permanent, account-level actions. They are **not** done inside a build session.

1. **Put the `bongos` npm org on a paid plan.** Private scoped publishing requires it. On npmjs.com → your org → Billing → upgrade to a plan that allows private packages (npm Teams, ~$7/member/month). Add as members only the people who need to publish or install during pre-launch — each is a billed seat.
2. **Register a trusted publisher — do NOT create a token.** The automatic lane publishes with **OIDC trusted publishing** ([ADR 0180](../adr/0180-dependency-intake-and-drift-policy.md) decision 4, [task 1003202](https://cloudbongos.com/builders#/task/1003202)): npmjs.com → the `@bongos/core` package → Settings → Trusted publisher → GitHub Actions, naming this repo and the workflow filename `publish.yml`. The runner mints a short-lived identity token per run; nothing long-lived exists to steal or rotate. **If the workflow is ever renamed, update the trusted-publisher entry in the same change** or every publish starts failing 403.

   A **manual** `package-core.js --publish --live` still needs a human `npm login` (+ 2FA) on that machine — an interactive session, not a stored credential.

   > **No install token, and none can be issued to any purpose.** `@bongos/core` is public ([ADR 0283](../adr/0283-the-core-publishes-publicly-because-access-was-never-the-thing-protecting-it.md)), so nothing needs a credential to *read* it, and [`fcea51ca`](https://github.com/example-owner/cloud-bongos/commit/fcea51ca) deleted the auth plumbing that used to consume one. A read-only `NPM_TOKEN` in an environment here buys nothing and is one more thing to leak — which is exactly how it leaked: the value sat in the droplet's journal in cleartext for a week (blocker 1000118).

## Publish (the real, permanent step — owner)

Always preview with a dry-run first (no upload, no login needed):

```sh
# Core — build the tarball and DRY-RUN the publish:
node scripts/gds/package-core.js --publish
```

Look for `public access` and the `@bongos/core@<version>` line. When it looks right, publish for real (this is **permanent and public** — npm can't delete a name after 72h, and the version is never reusable):

```sh
npm login                                         # once per machine (+ 2FA)
node scripts/gds/package-core.js --publish --live # actually publishes, PUBLIC
```

For the client (note the `./` — without it, npm reads the path as a git package spec, not a folder):

```sh
node scripts/gds/gen-api-client.js                # ensure it's fresh
npm pack ./clients/bongos-client --dry-run        # token-free content preview
npm publish ./clients/bongos-client               # real (publishConfig makes it restricted; needs npm login)
```

## Cutting a core release (the policy — [ADR 0161](../adr/0161-publish-on-merge.md), superseding ADR 0137)

**Publishing is automatic on merge** as of 2026-08-08: the `publish` workflow rides behind the required `unit` check and waits for the `integration` lane's verdict on the commit it releases (task 1004290), auto-bumps a patch when nobody bumped, builds through the fail-closed no-leak gate, publishes, and tags — see the workflow header (`.github/workflows/publish.yml`) and ADR 0161. It ships inert until the owner arms it: repo variable `PUBLISH_ON_MERGE=1`, a **trusted publisher** registered on npmjs.com for `@bongos/core` naming this repo + `publish.yml`, and the secret `RELEASE_PUSH_TOKEN` (contents:write, for the bump commit). There is deliberately **no** `NPM_TOKEN` — the lane authenticates by OIDC, and the workflow sets neither `NPM_TOKEN` nor `NODE_AUTH_TOKEN` because either one would send npm down the legacy token path and skip the OIDC exchange entirely. A **minor/major bump stays a human in-task edit**. The update subscription ([ADR 0136](../adr/0136-update-channel-subscription-policy.md)) consumes whatever is published, on its next sweep.

**Candidates and Release** ([ADR 0361](../adr/0361-merges-publish-as-candidates-release-decides-what-others-are-offered.md), task 1004298). With the repo variable `PUBLISH_AS_CANDIDATE=1`, each merge publishes under the `next` label: the platform hall runs it, and no other project is offered it. **Release** on /deploy runs `publish.yml`'s `release` job (`workflow_dispatch`, input `release_version`), which moves `latest` to that version over the same OIDC trusted publisher. It needs **Allow npm dist-tag** ticked on the `publish.yml` trusted-publisher entry, and the server's GitHub credential needs **Actions: write** to start the job: the `GITHUB_PUSH_TOKEN` access token (what cloudbongos.com uses), or the GitHub App where one is configured. From a terminal the same job runs as `gh workflow run publish.yml -f release_version=<x.y.z>`. The arming order is in the ADR.

The steps below remain as the **manual fallback** (lane disarmed, npm outage, or a deliberate out-of-band release):

1. **Bump `CORE_VERSION`** in [`src/module-api.js`](../../src/module-api.js) (semver; a **patch** for a fix, **minor** for additive surface — a **major** is a deliberate, human-only event) and append an entry to the release ledger [`docs/module-api-changelog.md`](../module-api-changelog.md) in the same commit ([ADR 0203](../adr/0203-doorway-changelog-out-of-module-api.md) moved that ledger out of `module-api.js`). This bump is a normal claimed task, not a release-tool side effect — the version's provenance stays in the git history + ledger.
2. **Publish** (owner, from a clean checkout of the released commit):
   ```sh
   node scripts/gds/package-core.js --publish        # DRY-RUN: runs the fail-closed no-leak gate, previews @bongos/core@<version>
   npm login                                          # once per machine (+ 2FA), or use a granular token with 2FA bypass
   node scripts/gds/package-core.js --publish --live  # permanent; the no-leak gate must pass or nothing is built/uploaded
   ```
   The no-leak / mirror-redact gate is **built into the build** — a leaking artifact is never produced, so `--publish` cannot upload one.
3. **Tag the release** (optional but recommended — the deliberate, auditable marker): `git tag core-v<version> && git push origin core-v<version>`. The tag documents intent; it triggers no CI.
4. **Done.** Subscribed instances on the `patch`/`minor` channel take it automatically on their next routine sweep; `pinned` instances wait for a manual `bongos upgrade`. A stale (un-bumped) version is rejected by npm as a duplicate — a natural guard.

> **Automating this** (a tag-triggered CI publish) is deferred to the managed-fleet epic ([#1948](https://example.com/builders#/task/1948)); revisit when the manual step becomes a real bottleneck. See [ADR 0137](../adr/0137-upstream-publish-policy-manual-owner-gated.md) "When to revisit".

## Install the core (any consumer machine or instance)

```sh
npm install -g @bongos/core   # global → the `bongos` command, then `bongos init`
```

That is the whole step. No `.npmrc`, no token, no org membership — `@bongos/core` is public ([ADR 0283](../adr/0283-the-core-publishes-publicly-because-access-was-never-the-thing-protecting-it.md)). Verify from a clean environment rather than trusting a logged-in shell, which would succeed either way:

```sh
npm pack @bongos/core --userconfig /dev/null      # no credential is read at all
```

(A project that calls the API vendors the generated client instead — it is not installable.)

> **This section used to say the opposite**, and the difference was invisible: a tokenless read of a *restricted* package returns a flat `E404`, indistinguishable from "no such package". That one ambiguity is what killed the nightly auto-upgrade sweep silently for three weeks, reporting `failed=0` the whole time — the sweep's unit passed no `NPM_TOKEN`, the env-fed `.npmrc` expanded to empty, and a skip is not a failure in that script's accounting. Do not reintroduce an install credential here.

## Provisioning: how a new instance gets its core

Provisioning vendors a **tarball** into each new instance repo, and the instance pins it as `file:vendor/bongos-core-<v>.tgz`. `resolveVendorTarball` in [`provision-repo.js`](../../scripts/gds/provision-repo.js) walks a ladder for the freshest correct one: reuse the control plane's own `file:`-pinned tarball → `npm pack` the control plane's registry-installed core ([ADR 0168](../adr/0168-scaffold-packs-installed-core.md)) → rebuild from source. A child is therefore born on the same core its parent is actually running.

**There is no token in any of this, and no opt-in fork either.** An earlier design gated a registry pull behind `PROVISION_CORE_FROM_REGISTRY=1` plus a read-only `NPM_TOKEN`, fail-soft to vendoring when the credential was absent. [`fcea51ca`](https://github.com/example-owner/cloud-bongos/commit/fcea51ca) deleted that whole path along with `scripts/gds/npmrc.js`: two install modes diverging on an environment variable is a defect shape, and the credential they diverged on stopped being necessary the moment the package went public. `bongos init --registry-core` and the env-fed `.npmrc` it used to write are gone with it.

> **Vendoring is not a stale-by-design choice.** It is what keeps twenty co-tenant instances pinned to a local path with no registry channel to follow — going public was necessary to fix that, and is not sufficient ([ADR 0283](../adr/0283-the-core-publishes-publicly-because-access-was-never-the-thing-protecting-it.md)). Moving a co-tenant forward is still the `package-core` → scp → `bongos upgrade` path.

## Going public — DONE 2026-09-13

`@bongos/core` is public ([ADR 0283](../adr/0283-the-core-publishes-publicly-because-access-was-never-the-thing-protecting-it.md), [task 1003872](https://cloudbongos.com/builders#/task/1003872)). `publishConfig.access` is `"public"` and the registry-side status was flipped with the one-time owner step:

```sh
npm access set status=public @bongos/core
```

That registry flip is separate from `--access public` on a publish, which governs only what *that* publish declares and is historically a no-op when re-publishing an already-private package. Verify the flip by a tokenless install from a clean `HOME`, not by the flag's presence. Public installs need no token; the paid private-package seats can be dropped.
- **Also publish the unscoped vanity name** for `npm install -g cloudbongos` — that is [task 2025](https://example.com/builders#/task/2025) (rename in `package-core.js`/`upgrade.js` + docs), done at launch.
