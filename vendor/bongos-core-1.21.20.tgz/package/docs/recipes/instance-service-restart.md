# Recipe — letting `bongos upgrade` restart the instance service unattended

> [ADR 0279](../adr/0279-an-upgrade-is-proven-by-the-served-version-not-the-health-check.md) · [task 1002884](https://cloudbongos.com/builders#/task/1002884). A core bump only counts once the **running process** is the new core, so `bongos upgrade` has to be able to restart the service without a human at a keyboard. This is what to do when it cannot.

## The symptom

```
! restart command failed (exit 1) — restart the service manually.
```

or, in the journal for the unit:

```
Interactive authentication required.
```

Since task 1002884 this **fails the bump and rolls it back** rather than warning and carrying on. That is the fix working: before it, the run went on to health-check the still-running old process, got a 200, and reported `✓ upgrade complete` for a core that was never served.

## Why it happens

A provisioned instance runs under a `User=` systemd unit. `systemctl restart <unit>` from the owning (non-root) user is a privileged action, so systemd asks polkit, and polkit wants to authenticate a human. In an interactive shell you get a password prompt. In the unattended sweep there is no TTY, so polkit refuses outright and `systemctl` exits 1.

## The fix, in order of preference

### 1. Passwordless sudo (what the code already tries)

`upgrade.js` retries a failed `systemctl restart` through `sudo -n systemctl restart <unit>` when it is not running as root — the same escalation `dev.js`, `dev-lib.js` and `provision.js` use. If the service owner has passwordless sudo, **nothing needs configuring** and the bump succeeds on the retry (the log says `✓ restarted <unit> (via sudo -n)`).

Check whether the owner already has it:

```bash
sudo -n -l
```

A `sudo: a password is required` means no. Note the `-n`: without it this command blocks on a prompt, which is exactly the failure being diagnosed.

### 2. Scoped sudoers, if blanket sudo is too much

Grant only the restart, not everything. Write it with `visudo -f` so a syntax error cannot lock the host out:

```bash
sudo visudo -f /etc/sudoers.d/50-<slug>-restart
```

```
<owner> ALL=(root) NOPASSWD: <redacted> restart <slug>.service
```

Then confirm the retry path works, non-interactively:

```bash
sudo -n systemctl restart <slug>.service && echo OK
```

### 3. A polkit rule, for hosts that deliberately withhold sudo

Equivalent outcome, different mechanism — use it when policy forbids a sudoers entry.

```bash
sudo tee /etc/polkit-1/rules.d/50-<slug>-restart.rules >/dev/null <<'RULE'
polkit.addRule(function(action, subject) {
  if (action.id == "org.freedesktop.systemd1.manage-units" &&
      action.lookup("unit") == "<slug>.service" &&
      subject.user == "<owner>") {
    return polkit.Result.YES;
  }
});
RULE
```

No daemon reload is needed; polkit picks up rules files on the next check.

> **This file is not inherited by a rebuilt box.** It lives in `/etc` on one machine. A reprovision restores code, not hand-placed host config — which is precisely why the `sudo -n` retry lives in the core and this page is the fallback rather than the answer. If you reach for this route, record it in the instance's own provisioning notes or the box will re-discover the stall.

## Verifying it actually worked

Do not trust the exit code alone — that is the failure mode this whole page exists because of. Ask the running process what it is:

```bash
curl -s https://<instance>/version
```

`coreVersion` in that response is the live process's core. If it still reads the old version after a "successful" restart, the process did not swap, and `bongos upgrade` will now catch that itself and roll back.

## Related

- [ADR 0279](../adr/0279-an-upgrade-is-proven-by-the-served-version-not-the-health-check.md) — why a health check cannot confirm an upgrade
- [ADR 0136](../adr/0136-update-channel-subscription-policy.md) §3 — the unattended subscription lane's health-gate + auto-rollback policy
- [`docs/recipes/ops-gotchas.md`](ops-gotchas.md) — the wider set of deploy traps
