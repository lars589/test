# Setting up the Autobongos runner on the Windows PC

The runner is a program that claims tasks and spawns Claude Code sessions to work
them, on an always-on machine with nobody at the keyboard. This is how it gets
installed so it survives a reboot, and how you check on it afterwards.

**Design of record:** [ADR 0307](../adr/0307-autobongos-a-deterministic-supervisor-and-agentic-workers.md).
Task [1003905](https://cloudbongos.com/builders#/task/1003905).

> **NOT YET VERIFIED ON THE REAL MACHINE.** Everything below was written and
> reviewed on a Mac; the install, the cold reboot and the crash-restart have not
> been run on the Windows PC, because that machine is not reachable from where
> this was built. The heartbeat half — the part that tells you whether the runner
> is alive — *was* verified end to end against a real database. Treat step 3 as
> the acceptance test, not as a formality.

---

## What you need on the box first

Open PowerShell as your own user and check all three:

```powershell
node --version ; git --version ; claude --version
```

All three must print a version. The installer refuses to proceed otherwise —
a runner that starts without `claude` on its PATH fails every worker and looks
like a mysterious outage in the log rather than a missing program.

You also need, as **your own user** (not a separate administrator account):

- a `git` credential that can fetch the repo,
- a signed-in Claude Code session,
- a Bongos CLI session (`/builder-reauth` if it has expired).

The runner deliberately runs as you, not as SYSTEM: SYSTEM has none of those
credentials, and "as you" is also the smaller blast radius for a process that
spawns workers with blanket permissions.

## 1. Turn the runner on in the hall — *before* installing anything

The kill switch and the goal allowlist live on the server, and both ship **off**.
A runner installed before this step will start, find it is not allowed to do
anything, and idle — which is correct, but looks like a broken install.

1. Open **cloudbongos.com/builders/gate** (you must be the Archon).
2. Under **Autobongos runner**, add the goal(s) it may work.
3. Press **Start the runner**.

Nothing on the PC can change either of those. That is the point: anything the
machine can write, the worker running on it can write too.

## 2. Install the scheduled task

**This step, and only this step, needs an Administrator shell.** Right-click
PowerShell, choose **Run as administrator**, and sign in to the prompt as the
**same user** you checked the prerequisites with — then, from the checkout:

```powershell
powershell -ExecutionPolicy Bypass -File scripts\gds\autobongos-service.ps1 install
powershell -ExecutionPolicy Bypass -File scripts\gds\autobongos-service.ps1 start
```

Why admin, when the runner deliberately is not: two different things happen
here. **Registering** the task needs admin, because it uses the S4U logon type
(run whether or not anyone is signed in), and Windows only lets an elevated
shell register one — from a normal shell `install` stops and says so, rather
than failing with a bare *Access is denied*. **Running** the task does not: it
runs as you, unelevated (`-RunLevel Limited`), which is what lets it use your
git credential and Claude session. Elevating the same account keeps your
username, so the task is still registered to run as you.

Do **not** install it as SYSTEM, or from a different administrator account:
the task would run as that account, which has none of your credentials. If
your own account is not an administrator on this PC, make it one for the
install rather than elevating as someone else.

That registers a task called `Autobongos` that starts **at boot** (not at sign-in
— nobody should have to log in), restarts if it crashes, and never times out.

It is Task Scheduler rather than a real Windows service on purpose: node cannot
speak the service protocol, so every "node as a service" route needs a
third-party wrapper to download, verify and keep updated. Task Scheduler is
already on the machine and does everything needed except appear in the Services
panel.

## 3. The acceptance test — do this, do not skip it

**A cold reboot must bring the runner back with nobody at the keyboard.**

1. Reboot the PC. Do **not** sign in.
2. From any other device, open **cloudbongos.com/builders/gate**.
3. Within a few minutes the runner line should read **Checking in**.

If it does not, sign in on the box and run:

```powershell
powershell -ExecutionPolicy Bypass -File scripts\gds\autobongos-service.ps1 status
```

which prints the task state, the last result, and the tail of the log.

## 4. Watching it from anywhere

The **Gate** page is the remote view. It shows two separate things, and the
difference matters:

| Line | Means |
|---|---|
| **Checking in** | the process is alive and talking to the server |
| **Quiet** | no check-in for a while — normal while a worker builds (they can take 90 minutes) |
| **Not checking in** | nothing for longer than any worker takes: the runner is not running |
| **Allowed to work** / **Stopped** | the kill switch — nothing to do with whether the process is up |

A runner can be **Allowed to work** and **Not checking in** at the same time:
that is a machine that is off, unplugged or wedged, and it is the state worth
noticing.

### Reading the night

The log answers "what happened" only if you are willing to read a log, and the
whole premise is that you are not at the keyboard. One command gives you the
night in five answers instead:

```powershell
powershell -ExecutionPolicy Bypass -File scripts\gds\autobongos-service.ps1 digest
```

or from any checkout: `node scripts/gds/autobongos-digest.js` (add `--since 24h`
for a rolling window, `--all` for everything, `--json` for the structured shape).

It answers: **what shipped**, **what is on hold and why**, **what each worker
decided that its task description did not determine**, **what it cost**, and
**where both limit windows stand**.

The third one is the one to actually read. A worker will not reliably stop and
ask — given an under-specified task it makes the call and writes it into the
file, which is what a good engineer does. So the decisions happen whether or not
anyone sees them, and every line in that section is a sentence the task
description should have contained. The task with the most entries is the thinnest
spec you wrote, and the digest names it.

The full log still lives on the box at `%LOCALAPPDATA%\cloudbongos\autobongos.log`
if you want the raw rows.

## 5. Stopping it

Use the **kill switch in the hall**, not the scheduled task. The switch survives
a reboot and cannot be undone by anything running on the machine; stopping the
task only stops this run, and the next boot starts it again.

`autobongos-service.ps1 stop` exists for maintenance on the box itself. It asks
Task Scheduler to stop the task, then **watches the runner's own process** (the
pid in its heartbeat file) and tells you which of these happened:

| It says | Means |
|---|---|
| `stopped ... has exited` | the process was watched to exit. The next boot starts it again |
| `NOT STOPPED ... still running after Ns` | the process outlived the stop (exit code 1). It runs under a different logon session (S4U) that a normal shell cannot end — `Stop-Process` fails the same way. From an **Administrator** PowerShell run the `taskkill /F /PID <pid>` it prints, or reboot. Until then `start` does nothing, because the task will not launch a second copy over a live one |
| `was not running` | the heartbeat's process had already exited |
| `CANNOT CONFIRM` | there is no heartbeat pid to check; look with `Get-Process node` |

## Keeping the checkout current

`autobongos-service.cmd` runs `git fetch` + `git reset --hard origin/main` before
each start, on the **main checkout only** — worker trees are separate worktrees
and are never touched. A fetch that fails does not stop the runner: being one
commit behind beats not running at all.

Because of that reset, **never leave uncommitted work in the runner's checkout.**
It is the machine's working copy, not a place to edit.

## If something looks wrong

| Symptom | Where to look |
|---|---|
| Runner line says **Not checking in** | is the PC on? `...\autobongos-service.ps1 status` on the box |
| **Checking in** but nothing ever ships | first the Gate page — is a goal allowlisted, and is the switch on? If both are on, the **gauge**: `autobongos-service.ps1 digest`, or `node scripts/gds/autonomy-gauge.js`. A `hold` with `unknown: true` means it cannot read your remaining capacity, and it will wait forever rather than guess |
| The log repeats `hold ... unknown: true` | the gauge has no reading it can vouch for. Open a **terminal** `claude` session on the box once — that writes it. A desktop-app session does not: the writer is a statusLine command, and only a terminal renders one |
| `hold` naming the **usage limit** | working as designed. A worker was cut off by the subscription limit, so the runner sleeps until the reset time and then resumes by itself. There is no fixed task cap (task 1004454) |
| Shipping stopped after a while | the log: the runner backs off after three failures and probes; the reason is in the log |
| It keeps restarting | `status` shows the last result; the `====` banners in the log mark each start |

The runner is built not to stop: three failures in a row drop it to a slow probe
rather than an exit, and it returns to full speed on its own once the cause
clears ([task 1003904](https://cloudbongos.com/builders#/task/1003904)). If the
scheduled task's restart counter is climbing, something is wrong that the
internal backoff should have absorbed — that is worth reading the log over.
