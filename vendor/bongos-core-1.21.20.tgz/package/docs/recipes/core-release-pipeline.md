# Recipe — the core release pipeline: how a change to Cloud Bongos reaches a live instance

> **The map.** Three sibling recipes each cover one leg — [packaging-the-core](packaging-the-core.md) (build the artifact), [private-npm-distribution](private-npm-distribution.md) (publish it), [upgrading-the-core](upgrading-the-core.md) (consume it). This file is the thing that connects them, and it exists to state one fact loudly:
>
> ## **Merging to `main` ships nothing.**
>
> A change that has landed on `main` is running on **zero** instances. It reaches users only after someone bumps `CORE_VERSION`, cuts an artifact, and moves an instance's pin. Those are three separate acts by design ([ADR 0137](../adr/0137-upstream-publish-policy-manual-owner-gated.md)) — and every layer around them reports success in the meantime.

## Why this file exists

Between 2026-07-24 and 2026-08-03, **93 work commits (171 counting merges) — including the entire governance permission system — sat on `main` unreleased for ten days** while the live platform served the previous version. Nothing was broken. `/builder-ship` printed success, the publish-reconciler flipped `confirmed → shipped`, credits paid out. Every signal a builder could see said "delivered"; nothing compared live against `main` (blocker 1000097, task [1002521](https://example.com/builders#/task/1002521)).

A second failure followed from the same gap: a builder filed a careful, well-evidenced "prod has been serving stale code for days" report whose central measurement was taken against **the wrong instance**, and which prescribed the npm `--registry` upgrade path for an instance that pins a **vendored tarball** — where it would have moved nothing at all.

Both were documentation failures, not code failures. This is the missing document.

---

## The three gates

A change crosses three independent gates. **None of them implies the next**, and each has its own actor, action, and proof.

| # | Gate | What it means | Who | Proof it happened |
|---|---|---|---|---|
| **0** | **Included** | your change is inside the publishable subtree at all | the allowlist | `isPublishable('<path>')` → `true` |
| **1** | **Landed** | the commit is on core `main` | any builder, via `/builder-ship` | task status `shipped` |
| **2** | **Released** | a `CORE_VERSION` exists that *contains* the commit, and an artifact was cut from it | a builder bumps + packages; **the owner publishes** | the version is published / a `.tgz` exists |
| **3** | **Deployed** | a specific instance moved its pin to that version | per instance | that instance's `/version` reports the new `coreVersion` |

Bongos vocabulary collides with gate 1 in a way worth naming: **task status `shipped` means "merged to `main`"** — it does not mean released, and it does not mean live. `ship.js` says so in its own comment and, since task 1002521, prints a divergence warning at the end of every ship.

---

## Gate 0 — does your change ship at all?

The core is not "this repo." It is exactly the subtree [`isPublishable()`](../../scripts/gds/publish-manifest.js) selects ([ADR 0098](../adr/0098-public-mirror-publish-manifest.md)) — a **default-deny, two-layer** gate:

```
isPublishable(p)  ==  matchesDeny(p) ? false : matchesAllow(p)
```

A path publishes only if it falls in `PUBLISH_ALLOWLIST` **and** escapes `PUBLISH_DENYLIST`. A new, unclassified top-level surface therefore never leaks by omission — it is simply not published.

**A change under a denied path reaches no instance at any version.** The four denial rationales:

| Rationale | Examples |
|---|---|
| **Topology** — prod infra, deploy machinery, CI, local gate hooks | `infra/`, `scripts/deploy/`, `.github/`, `.claude/hooks/` |
| **Read-sensitive docs** — the security/audit corpus | `docs/security/`, `docs/audits/` |
| **Content / copyright** — the instance's product layer and all art | `modules/game/`, `modules/art-pipeline/`, `public/`, `brand/` |
| **Host-module tests** — tests that statically import an excluded module | see the list in `publish-manifest.js` |

Note the deliberate non-exclusion: the rank / trust-boundary / ship-grade machinery **is published** — it is the open-source methodology ([ADR 0065 §4](../adr/0065-agpl-nonprofit-ai-first-governance.md)). Only the *topology* subset of the protected surfaces is held back.

Check a path before you assume:

```bash
node -e "console.log(require('./scripts/gds/publish-manifest').isPublishable('docs/recipes/core-release-pipeline.md'))"
```

## Gate 1 — land it on `main`

The ordinary claim→ship loop: `/builder-claim N` → build → `/builder-ship`. That chains `completed` → `confirmed` → `shipped`, and credits land at `shipped` ([ADR 0120](../adr/0120-pay-on-land-and-builder-owned-rebase-gate.md)).

Landing is CI-gated (tasks 1002610/1002611/1002619, ADR 0159): every PR runs the **`unit`** check — the DB-free suite plus the fitness gates, via `npm test` — and branch protection **requires** it, so a red suite blocks the merge. PRs touching the hard-floor safety surfaces (`CODEOWNERS` (instance-side)) additionally need the owner's review. The owner kill-switch is `node scripts/gds/gating.js on|off|status` — reversible by construction, snapshot-restored.

**Stop here and nothing happens to any user.** This is the gate that feels like the finish line and is not.

## Gate 2 — cut a release

Three steps. The first two are ordinary claimed work; only the publish (2c) is owner-gated — and 2c is skipped entirely for a vendored-tarball instance.

### 2a. Bump `CORE_VERSION` — the step with no automation behind it

`CORE_VERSION` lives in [`src/module-api.js`](../../src/module-api.js) and is bumped **by hand, inside a claimed task**, with an entry appended to the release ledger [`docs/module-api-changelog.md`](../module-api-changelog.md) in the same commit. (The ledger used to be a comment block inside `module-api.js`; appending to it there on every CI release grew the file past the oversized-file fitness ratchet and broke `unit` on `main` — [ADR 0203](../adr/0203-doorway-changelog-out-of-module-api.md).) The version's provenance stays in git history + ledger ([ADR 0137](../adr/0137-upstream-publish-policy-manual-owner-gated.md) §2).

Semver here is not decoration — it decides **who receives the change automatically** ([ADR 0136](../adr/0136-update-channel-subscription-policy.md)):

| Bump | Reaches `patch` subscribers (the default) | Reaches `minor` subscribers |
|---|---|---|
| **patch** — a fix; the doorway surface is byte-identical | ✅ | ✅ |
| **minor** — an added export / additive surface | ❌ **invisible to them** | ✅ |
| **major** — never automatic for anyone | ❌ | ❌ |

The practical trap: a **MINOR is silently withheld from every patch-only instance**, which is the default channel. If a fix must reach the fleet, it belongs behind a *patch* bump — so an additive export shipped alongside a needed fix will strand that fix. The ledger convention is to justify the level explicitly ("the doorway surface is byte-identical to X, so despite the volume this is → PATCH").

**A bump is mandatory even for a one-file fix.** `bongos upgrade` refuses an equal version, and npm rejects a duplicate — a natural guard, and the reason "carrier bumps" exist to sweep up commits that landed with no bump behind them.

### 2b. Build the artifact

```bash
node scripts/gds/package-core.js --ref main            # → dist/bongos-core-<v>.tgz + .manifest.json
node scripts/gds/package-core.js --ref main --self-verify
```

`package-core` archives the **committed** tree at `--ref`, never your working tree, and stamps the version from `CORE_VERSION` *at that ref*. Full mechanics — the fail-closed no-leak gate, the `tree_sha256` integrity pin, the pruned lockfile — in [packaging-the-core](packaging-the-core.md).

> ⚠️ **Packaging a mid-flight `main` produces a stale version number.** If `CORE_VERSION` at your ref is still the previous value, your tarball is stamped with a version the fleet may already have. `bongos upgrade` refuses the **equal** case (`already on <v>`; `--force` bypasses that) and a target **below** what is installed or pinned (task [#1004009](https://cloudbongos.com/builders#/task/1004009); `--allow-downgrade` is the only way through — `--force` is not). That second refusal lives in the **installed** core, so an instance still on a core that predates it has no such guard: there a lower target proceeds and silently installs older code. Confirm the bump is actually in your ref before packaging.

### 2c. Publish — automatic on merge

**Every merge to `main` publishes** ([ADR 0161](../adr/0161-publish-on-merge.md), superseding ADR 0137's manual gate): once the required `unit` check succeeds on a main push — and the `integration` lane is green on the commit being released, which carries the packaged-core empty-database proof (task 1002863; the wait is task 1004290) — the `publish` workflow auto-bumps a **patch** if nobody bumped (via `scripts/gds/bump-version.js`, which writes the literal AND appends the ledger entry to [`docs/module-api-changelog.md`](../module-api-changelog.md) — ADR 0203; the carrier commit stages both), builds through the fail-closed no-leak gate with `--self-verify`, publishes, and tags `core-v<version>`. A **minor/major is still a human in-task bump** — CI never makes that call, because it decides what patch-channel subscribers receive unattended.

The lane is armed by the owner via the `PUBLISH_ON_MERGE=1` repo variable + two secrets (`NPM_TOKEN`, `RELEASE_PUSH_TOKEN`); while disarmed it no-ops loudly. Manual fallback, same command CI runs:

```bash
node scripts/gds/package-core.js --publish          # DRY-RUN — runs the no-leak gate, previews
node scripts/gds/package-core.js --publish --live   # permanent
```

**A publish is not what moves a vendored-tarball instance** — see gate 3. Chasing an npm publish to move a `file:`-pinned instance is a documented dead end.

## Gate 3 — move the instance's pin

> **There is now a control for this, and it is the owner's** (task 1003159, [ADR 0293](../adr/0293-the-owners-deploy-door-is-an-intent-the-control-plane-drains.md)). Everything below still describes what actually happens on the box, and is what you need when something goes wrong — but the ordinary path no longer requires a shell or an ssh key.
>
> **Hall → Deploy** (`/deploy`) shows the version the box is actually serving, what it could move to, and moves it on an explicit second click. It is gated on the `core.pin.move` atom — archon-floor and `system: true` — and every move lands in the `core_upgrades` ledger with the builder who asked. The web tier never gains a shell: it queues a `core-upgrade` intent and the control-plane runner drains it, driving exactly the `bongos upgrade` invocation documented below, with its health gate and auto-rollback intact.
>
> **One install-time step enables it.** The door needs a `provisioning_instances` row to point at, and the control plane has never had one:
>
> ```bash
> node scripts/gds/enroll-control-plane.js --owner <builderId> --apply
> ```
>
> Until that is run, `/deploy` says so and names this command. The self row carries `hosting_shape='control-plane'`, which every destructive intent action refuses by name — a teardown aimed at it would destroy the platform from inside its own UI, so the guard is an allow-list (`core-upgrade`, `restart`) enforced at `enqueueIntent`, the one place every intent passes.

Each instance decides, independently, when to take a release. **Which mechanism it uses is a per-instance fact you must establish before prescribing anything** — read its `package.json`:

| Pin in `package.json` | Path | How it updates |
|---|---|---|
| `"@bongos/core": "file:vendor/bongos-core-<v>.tgz"` | **vendored tarball** | ship the `.tgz` to the instance and run `bongos upgrade --from <tgz>`; npm's published version is irrelevant |
| `"@bongos/core": "^<v>"` | **npm registry** | `bongos upgrade --to <v> --registry`; requires the version to be published and a token to read it |

The mechanics of the bump itself — pre-flight, pin-verify, migrate, `.claude/` materialize, restart, the mandatory health check, and auto-rollback — are in [upgrading-the-core](upgrading-the-core.md). Two portable traps that bite hardest here:

- **`PGDATABASE` is load-bearing.** `migrate.sh` has a default; on a co-tenant host that default is *someone else's database*. Always set `PGDATABASE=<instance-db>` explicitly or you migrate the wrong DB (the usual outcome is a clean auto-rollback, which then reads as "the upgrade failed").
- **Never hand-edit `package-lock.json`'s `@bongos/core` entry.** Editing `version` + `resolved` while leaving `integrity` at the old tarball's hash makes `npm ci` resolve the *old* content from the content-addressable cache — the deploy reports healthy and runs old code. Run `npm install file:vendor/bongos-core-<v>.tgz` instead, and verify after: `node -e "console.log(require('./node_modules/@bongos/core/package.json').version)"`.

Also: an instance can have **more than one plane to update** (e.g. a web instance plus a control plane that resolves its tooling from its own vendored core). Updating one does not update the other.

**Worked example — cloudbongos.com (task 1002621).** The web instance moved off `file:vendor/...` onto a bare registry pin (`bongos upgrade --to <v> --registry --force`, then commit+push `package.json`/`package-lock.json`/`.npmrc` — no tarball) and is enrolled in `config/update-subscriptions.json` (instance-side) on the `patch` channel, with the `core-update-subscription` routine armed via a dedicated systemd timer on the control-plane box (daily; see [upgrading-the-core](upgrading-the-core.md) for the generic enroll/arm steps). The deploy service's `npm ci` and the routine's `npm view` both authenticate via a root-owned `NPM_TOKEN` env file wired in through each unit's `EnvironmentFile` — a read-only token never committed to any repo. The control plane's own tooling pin is a separate, not-yet-migrated plane (see above).

---

## The pin-bump runbook — cloudbongos.com, one paste per step (task 1002767)

The generic mechanics are [upgrading-the-core](upgrading-the-core.md); this is the **operational sequence for the live mothership** — registry pin, pull-deploy repo at `/home/lars/cloudbongos-instance`, `cloudbongos.service` serving `127.0.0.1:3002`. Every trap below cost a real round trip on the 2026-08-13 (`1.19.91 → 1.19.94`) run; the goal is that the next bump is one paste, not fifteen.

**Cadence: bump once, at session end.** One upgrade covers every release the session landed (publish-on-merge cuts one per merge — you don't chase each). Don't bump per-ship.

### Step 0 — try the one command first (task 1003189)

The whole sequence below is deterministic, so it is also a script. `go-live.js` composes the
same parts this runbook narrates — `deploy-divergence.js` for the gap, the registry for proof a
release exists, and `bongos upgrade --registry --commit-pin` for the bump itself — and reports
once instead of forty times:

```bash
node scripts/gds/go-live.js
```

That is **plan-only and read-only**: it prints live-vs-target, checks the registry actually
carries the target, and names every halt condition it found. Add `--apply` to move the pin.

It **halts rather than guessing** on exactly the things that need judgement — unreleased commits
on `main`, a registry missing the target, a dirty tree on either end, a failed health check, an
uncommitted pin, and an unresolved artist review (see below). When it halts, fall through to the
manual steps below and use your own head; that is what the rest of this section is for.

Two flags worth knowing:

- `--verify-marker <path>=<needle>` refuses a target that does not actually contain your change.
  This is the guard for the trap in Step 1: the carrier sitting on `main` when your fix merged
  was usually cut *before* it, so deploying "the version main was on" is a textbook-clean go-live
  that changes nothing — and every downstream check agrees it worked.
- `--allow-unreleased` downgrades the UNRELEASED halt to a warning. Reach for it only when you
  have already confirmed *why* main is ahead of its last release.

**The one halt that is not about git: `ARTIST_REVIEW_UNRESOLVED`** (task 1003575,
[ADR 0241](../adr/0241-the-artist-gate-is-a-per-project-deploy-gate-that-reads-a-state.md)).
A project running `artist_gate: 'strict'` — the default — may not move its pin while a
cascade-filed **artist review task** is still open. Note what it is and is not: it reads a task
*status*, never an artist's opinion, and it holds **this gate only**. Nothing about a builder's
ship, grade, merge, credit or landing on `main` consults it, which is exactly what lets a gate
that stops work coexist with [ADR 0162](../adr/0162-review-gates-retired-rank-consistent-ci-only.md).

There are three ways past it, and the first two are the ordinary ones:

1. **Resolve or dismiss the reviews.** Shipping one, or abandoning it in triage, is what the
   gate reads — the same board moves as any other task.
2. **Lower the setting.** `PATCH /provisioning/instances/:id/settings` with
   `artist_gate: 'advisory'` keeps the reviews being filed and stops them holding deploys.
   (Raising it back to `strict` is **not retroactive** — reviews filed before the raise never
   hold again.)
3. **Release one.** `POST /tasks/:id/override-request` with a rationale, then the **project
   owner** approves it at `POST /override-requests/:id/decide`. Three things about that, each of
   which is a deliberate narrowing rather than a new mechanism:

   - It is the *same* request flow as the grader bypass — ADR 0241 §3 rules out a second
     authority path — but the **owner alone** may decide this class. An Archon is refused with
     `override_owner_only`, and that is correct, not a bug.
   - Approving it **confirms nothing and pays nothing.** The review stays open on the board;
     what stops is its hold on the pin. (A release is why `POST /tasks/:id/override-request`
     accepts an artist review at `backlog` at all — the completed-only rule still applies to
     every other task.)
   - A **self-release** (owner is also the builder or the artist) is permitted and written to
     the audit log as a self-override. It is the valve that stops a solo project deadlocking,
     not a routine step: the right answer to being gated is to fix the work or fix the grader.

**`bongos upgrade` asks the same gate** (task 1004205): the vendored `upgrade.js --from` run
refuses before the pin moves, with the same halt, the same three ways past it and the same two
unknowns below — it reuses `go-live.js`'s reader. Until then only `go-live.js` asked, and an
instance that moved its pin by hand moved it past open reviews.

`go-live.js` prints the gate's level on every plan, held or not, so "why did nothing stop?" is
answerable without going and looking. Two different unknowns, two different verdicts:

- It cannot *reach* the gate (no CLI session, or an instance too old to serve `/api/bongos/artist-gate`) —
  a **note**, not a halt. We do not know the gate applies, and bricking the pin over that would
  leave no task id to release against.
- The route is there and **errors** — `ARTIST_GATE_UNREADABLE`, a **halt**. The gate applies and
  will not answer, and a broken read must never be a quieter way past it than the owner's own
  override. The fix is in the instance's logs, not on anyone's review queue.

**What `--apply` does, in order** (task 1004306):

1. **Rehearse.** It runs the exact `bongos upgrade` it is about to run, plus `--dry-run`. That
   asks every refusal the bump has (the artist gate, module compatibility, the database
   identity, the downgrade guard) and changes nothing. A refusal stops here: no timer stopped,
   no backup written, and the report says "Nothing changed". Before this, the backup came
   first, so on cloudbongos.com every attempt the artist gate refused had already written a
   65 MB dump: one a day at the daily cadence, a full disk in about three days at every fifteen
   minutes.
2. **Stop the pull-deploy timer and back up** to `backupDir` as
   `pre-<version>-<timestamp>.sql.gz`. A dump that fails now fails the go-live (before, a failed
   `pg_dump` still left a tiny gzip that read as a backup) and the timer is put back.
3. **Prune:** keep the newest **10** of those pre-upgrade dumps, by time, and delete the rest.
   Only that exact name pattern is touched: a dump named by hand (`pre-lane-sweep-…`) and the
   nightly backups (`db-backup-nightly.sh`, `<db>-<timestamp>.sql.gz`, kept 30 days by that
   script) are never pruned here. A
   prune that cannot run is a ⚠ warning, not a failed deploy.
4. **Bump, restart, read back**, as before.

Host topology (ssh alias, box paths, service names, health URL) lives in a host-owned
`config/go-live.json`, never in the core — run `node scripts/gds/go-live.js --help` for the
schema. A core that named one instance's box would not be a core.

**Upgrading a provisioned co-tenant** (task 1003521). A co-tenant under `/srv/<host>/<slug>` is
the same engine with two fields different, because two of this instance's assumptions do not hold
there: it has no pull-deploy timer to stop (only its `<slug>-db-backup.timer`), and its repo of
record is the **customer's** own GitHub repo, so pushing the pin there is both wrong and
uncredentialed. So omit `deployTimer` — the stop and the restart are skipped, and there is no
`reset --hard` to race — and set `"pinMode": "local-commit"`, which commits the pin without
pushing it. (`"leave-dirty"` leaves the bump in the working tree; `"push"` is the default and is
what the platform instance needs.) Everything else — the registry proof, `--verify-marker`, the
`pg_dump`, the health-gated upgrade with auto-rollback, the box-side version read-back — is
unchanged. The co-tenant's own scaffold gap is separate and still open:
[#1003520](https://cloudbongos.com/builders#/task/1003520).

### Step 1 — pick the version (your machine, main checkout)

```bash
git fetch origin --tags
git tag --list 'core-v*' --contains <your-merge-sha> | sort -V | head -1
```

**Failure this prevents — pinning a release that predates your work.** The version your own ship report printed is usually the release cut for the *previous* merge (ADR 0161 publishes *after* each land). The version to pin is the newest tag that **contains** your merge. If no tag contains it, the publish lane hasn't finished (or is disarmed): a green `publish` *check* is not evidence of a publish — read the Publish **step log** for `+ @bongos/core@<version>`. The package is private, so an anonymous `npm view` proves nothing either.

### Step 2 — the bump (the owner runs this line, via `!` in the session)

This paste is the **owner’s**: the permission classifier’s treatment of a mutating `sudo` over ssh **varies by session** — some sessions permit it, others block every ssh including read-only probes and `backup.js --trigger`. Don’t retry into a block; hand the owner the line. The `!` prefix also keeps ssh honest: a bare `ssh host` is non-interactive here — it connects, prints the MOTD, and exits — so the command must ride as an argument.

**Re-read `coreVersion` on `/version` immediately before running — a prepared `--to` goes stale within the hour.** Live moves by other paths (another session's bump, the subscription sweep), so the version you picked in Step 1 may already be behind what is serving:

```
curl -s https://cloudbongos.com/version
```

If live is **at or past** `<VER>`, stop and pick again. On 2026-09-17 a paste prepared against 1.19.838 ran an hour later against 1.19.841, and `--to 1.19.840` took two merged PRs off live while printing `✓ upgrade complete`. `bongos upgrade` now refuses a `--to` older than the installed core (task [#1004009](https://cloudbongos.com/builders#/task/1004009); `--allow-downgrade` is the deliberate way through) — but the refusal only exists once live is on a core that carries it, and it cannot catch a `--to` that is merely *not the newest*. The re-read is still the step.

```
! ssh -i ~/.ssh/otb_builder jaxri@REDACTED_IP "sudo -n bash -c 'set -a; . /etc/cloudbongos/npm.env; set +a; cd /home/lars/cloudbongos-instance && sudo -n -u lars --preserve-env=NPM_TOKEN env PGDATABASE=cloudbongos BONGOS_INSTANCE_ROOT=/home/lars/cloudbongos-instance ./node_modules/.bin/bongos upgrade --to <VER> --registry --commit-pin --restart-cmd \"sudo systemctl restart cloudbongos.service\" --health-url http://127.0.0.1:3002/healthz'"
```

What each piece is for — each guards a failure that actually happened:

- **`BONGOS_INSTANCE_ROOT`, not `CLOUDBONGOS_INSTANCE_ROOT`.** The legacy spelling still works but prints a deprecation warning three times per run and stops being read in core 1.21; the new spelling is verified in this exact line (2026-09-17, twice).
- **The token lives in root-only `/etc/cloudbongos/npm.env`, and is handed DOWN to `lars`.** This is the step that used to be documented wrongly, so read it before improvising. `NPM_TOKEN` is **not** in lars’s environment, **not** in the interactive profile, and **not** in `/home/lars/.npmrc` — all three probed empty (2026-08-17). An earlier version of this runbook grepped `~/.npmrc` and therefore aborted on its own `[ -n "$NPM_TOKEN" ]` guard every time. Worse, it could not have worked even if that file were populated: the project `.npmrc` says `_authToken=<redacted>, which **overrides** lars’s user `~/.npmrc`, so the variable is the only channel. Hence the shape above: `set -a; . /etc/cloudbongos/npm.env; set +a` reads it as **root** (mode 600), and `--preserve-env=NPM_TOKEN` hands it to the unprivileged `lars` — exactly what systemd does for the sweep unit (`User=lars` + `EnvironmentFile=`). Without it npm falls back to the **public** registry, 404s on the private `@bongos/core`, and rolls back cleanly having taught you nothing.
- **Never put the token in the command line — `sudo` logs the full argv (task 1003218).** The shape above is safe *because* the token is read INSIDE the quoted script, so only the `grep` reaches argv. The tempting variant is not:
  ```
  sudo -u lars -H env NPM_TOKEN="<redacted>" … bongos upgrade …     # ← LEAKS
  ```
  Passing "by reference" in the script text is NOT enough; what matters is what argv looks like after expansion. **The command above is the compliant form of exactly this advice** — it uses `--preserve-env=NPM_TOKEN`, so the token travels in the environment and never reaches any argv.
- **`--to <VER>` is required** — `bongos upgrade` refuses to guess a target.
- **Use `--restart-cmd`, NOT `--service` — and `--health-url` is what buys the automatic rollback.** The two restart flags are not interchangeable here. `restartService()` ([`scripts/gds/upgrade.js`](../../scripts/gds/upgrade.js)) runs a **bare** `systemctl restart <svc>` for `--service`, with no `sudo`; the upgrade runs as unprivileged `lars`, who has NOPASSWD sudo for the restart but cannot restart a unit directly — so `--service` fails at the last step, after the core is already swapped in. `--restart-cmd` lets you spell the `sudo` (it overrides `--service` when both are passed). Point the health URL at `http://127.0.0.1:3002/healthz` — **not** `:3000` (that is the port named in CLAUDE.md, not this instance's; read the truth from `systemctl cat cloudbongos.service`) and **not** the public URL, where a pre-launch `basic_auth` on the apex makes a healthy boot look failed and triggers a needless rollback that then misreports "health STILL failing after rollback". The service is fine; the probe was wrong. Health polls ~30s, so an immediate `fetch failed` is not a failure.
- **`--commit-pin` commits AND pushes the pin.** The instance is a pull-deploy repo: the next sync runs `git reset --hard origin/main`, which reverts an uncommitted pin, and `npm ci` then reinstalls the old core. Nothing errors. This is exactly how live sat 13 releases behind (task 1002712). The same applies to any tracked instance-config edit (`config/branding.json`): commit + push or the next deploy tick undoes it. A commit that fails to *push* saves nothing — deploy.sh resets to the remote.
- **`PGDATABASE=cloudbongos` is inline above, and that is what records the `core_upgrades` ledger row.** The migrate step resolves the instance DB itself, but the ledger write reads only the env; a form that omits it still upgrades successfully and just logs `ledger skipped (no DATABASE_URL or PGDATABASE)`. It is also **load-bearing beyond the ledger** — `migrate.sh` defaults to a *different* production DB (`example`), so name it explicitly rather than letting it default.

### Step 3 — verify on the box, not from your browser

```
! ssh -i ~/.ssh/otb_builder jaxri@REDACTED_IP "curl -s http://127.0.0.1:3002/version"
```

`coreVersion` must equal the target. This is the proof; the deploy tool's own output is not.

**Failure this prevents — trusting a stale or gated public view.** The apex may sit behind pre-launch `basic_auth`, and HTML rides the CDN. (The classic *stylesheet* staleness — new HTML styled by a 4-hour-old `cosmos.css` — was fixed by content-hashed asset URLs in task 1002766, so a broken-*looking* page is no longer expected; if you must check publicly, use a cold profile or `fetch(url, {cache:'reload'})`.)

### Step 4 — prove the pin is durable

The `--commit-pin` output already reports commit + push. To prove durability the hard way, force a deploy tick and re-read the version — a reverted pin shows up here and nowhere else:

```
! ssh -i ~/.ssh/otb_builder jaxri@REDACTED_IP "sudo -n systemctl start cloudbongos-deploy.service; sleep 5; curl -s http://127.0.0.1:3002/version"
```

If `coreVersion` regressed: the pin didn't reach `origin/main` — re-run the bump and watch for the `PIN NOT COMMITTED` warning text, or commit+push `package.json` + `package-lock.json` in the instance repo by hand.

---

## Detecting divergence

[`scripts/gds/deploy-divergence.js`](../../scripts/gds/deploy-divergence.js) is the comparison that was missing during the ten-day incident. It runs **warn-only at the end of every ship** and can be run by hand any time:

```bash
node scripts/gds/deploy-divergence.js --url https://<instance-host>
```

It reports the two gaps **separately**, because they have different fixes:

- **UNRELEASED** — commits on `main` past the last `CORE_VERSION` bump. *No instance can take these at any pin* — no version contains them. Fix: bump + land (gate 2a).
- **UNDEPLOYED** — the live instance's `coreVersion` is behind `main`'s. A release exists; this instance has not moved its pin. Fix: gate 3.

Exit codes: `0` aligned, `1` diverged, `2` undetermined.

> ### ⚠️ Do not trust its numbers without checking the anchor
>
> The tool has a **known anchor defect** — reproduced live on 2026-08-08, where it named `1.18.19` as the last bump while printing `origin/main 1.19.0` two lines above, then counted 70 UNRELEASED commits from that wrong anchor.
>
> The mechanism is one compound failure. It locates the bump with `git log <ref> -1 -G"^const CORE_VERSION = "`. `git log` shows no diff for merge commits, so `-G` **cannot match the merge** that lands a bump on `main` — the only candidate is the original commit on the branch, carrying that branch's earlier **commit date**. `-1` then picks the newest *by date*, so a bump authored earlier on a long-lived branch loses to a later-authored one, even when the earlier one is the higher version. Every count downstream inherits the wrong anchor.
>
> Separately and by design, it measures from the last *bump commit*, not from what was actually **packaged** — so work landing between the bump and `package-core` reads as UNRELEASED even though the tarball contains it. Comparing against the `core-v*` release tag would be more accurate.
>
> Treat a divergence warning as **"look closer"**, never as a precise commit count. The direction is reliable; the arithmetic is not.

**Before acting on any "prod is stale" report, establish which instance was measured.** `curl` the `/version` endpoint of each candidate host yourself. Instances that serve different products are pinned at different versions *correctly* — a game-only instance needs no platform release. A report that names the wrong host will read as authoritative regardless of how carefully it was written.

---

## Who can do what

| Act | Gate | Who |
|---|---|---|
| Land a change on `main` | 1 | any builder holding a claim, behind the required `unit` check (protected paths are Metic+; hard-floor paths need owner review per `CODEOWNERS` (instance-side); [canonical-permissions](../canonical-permissions.md)) |
| Bump `CORE_VERSION` | 2a | a builder, inside a claimed task |
| Build the artifact | 2b | any builder — `package-core` is tokenless and network-free |
| Publish to npm | 2c | **automatic on merge** once the owner arms the lane ([ADR 0161](../adr/0161-publish-on-merge.md)); the manual `--publish --live` fallback stays owner-only |
| Move an instance's pin | 3 | whoever operates that instance |

Automating gate 2c (a tag-triggered CI publish) is deliberately deferred until a real fleet makes the manual step a bottleneck — see [ADR 0137](../adr/0137-upstream-publish-policy-manual-owner-gated.md) "When to revisit".

## Where to go next

| You want to… | Read |
|---|---|
| build / verify / inspect the artifact | [packaging-the-core](packaging-the-core.md) |
| publish it, or set up private npm access | [private-npm-distribution](private-npm-distribution.md) |
| move an instance from N → N+1, or subscribe it to updates | [upgrading-the-core](upgrading-the-core.md) |
| know *why* publishing is manual | [ADR 0137](../adr/0137-upstream-publish-policy-manual-owner-gated.md) |
| know *what* an unattended upgrade is allowed to take | [ADR 0136](../adr/0136-update-channel-subscription-policy.md) |
| know what counts as "the core" | [ADR 0098](../adr/0098-public-mirror-publish-manifest.md) · [ADR 0103](../adr/0103-core-first-extraction-cloud-bongos-trunk.md) |
