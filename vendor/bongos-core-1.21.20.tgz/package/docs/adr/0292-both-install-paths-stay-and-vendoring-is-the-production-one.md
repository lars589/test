# ADR 0292 — Both install paths stay, and vendoring turns out to be the production one

- **Status:** accepted
- **Date:** 2026-09-16
- **Task:** [1003879](https://cloudbongos.com/builders#/task/1003879) (goal 1000090, working area 4 — Bongos Core distribution). Public-npm **gate 6**, the decision row deliberately held back from gate 5's mechanical cleanup ([1003878](https://cloudbongos.com/builders#/task/1003878)) because both candidates were large deletions that could as easily be mistakes.
- **Gated on:** [ADR 0283](0283-the-core-publishes-publicly-because-access-was-never-the-thing-protecting-it.md) / [task 1003872](https://cloudbongos.com/builders#/task/1003872) — the flip to a public publish, which is what made this question answerable.
- **Supersedes:** [ADR 0134](0134-private-first-npm-distribution.md)'s **"vendored is the default, until the registry path is proven end-to-end"** clause. The condition is met; the default does not change, and the reason it does not change is the substance of this ADR.
- **Adjacent:** [ADR 0258](0258-the-public-cli-is-a-generated-client-package-not-the-published-core.md) (the CLI package, candidate 2) · [ADR 0161](0161-publish-on-merge.md) (the lane that publishes) · [ADR 0108](0108-instance-composition-configurable-root.md) (core-as-npm-dep).

## Context

Gate 6 asked two questions that the public flip appeared to answer by implication, and deliberately refused to let them be swept out as consequences:

1. Does the **vendored-tarball install path** (~124 references across `upgrade.js`, `init.js`, `provision-repo.js`, `package-core.js`) still earn its keep now that a registry install works for everyone?
2. Does **`@cloudbongos/cli`** ([ADR 0258](0258-the-public-cli-is-a-generated-client-package-not-the-published-core.md)) still earn its keep, given task 1003872 named it as "redundant — that package exists only because the core is private"?

Both were framed as probable deletions. Both are **keeps**, and in the first case the framing was wrong in an instructive way.

## The question the task asked was not the question that decides it

Gate 6 framed vendoring as insurance for hosts that cannot reach the registry: *"does anyone need to stand up an instance with no access to npm — an air-gapped host, a CI runner with no egress, a self-hoster behind a corporate proxy?"*, to be weighed against the AGPL self-host promise. Read that way, the honest answer is "probably nobody, yet" — and vendoring looks like 124 references maintained for a case that never happens.

That is not what the code does with it. From `provision-repo.js`, on the path every project created through the wizard takes:

> Core resolution is vendored (`--vendor-core`): **a tarball built from this checkout**, file:-pinned. init still accepts `--registry-core` for an operator who explicitly wants a published version.

Vendoring is not the fallback. It is the **production provisioning path for every instance this platform creates**, and `--registry-core` is the opt-out. Deleting it does not remove a contingency; it breaks project creation.

The reason is visible in `resolveVendorableCoreTarball`'s three-rung ladder, whose rungs are ordered *freshest-correct first* and whose comments name the bugs each one fixed:

1. a `file:`-pinned control plane reuses its own pinned tarball — rebuilding from source aborts with an empty core set when the runner is itself a consumer instance (task 1002275, which left new repos empty);
2. a registry-pinned control plane **packs the core it has installed**, so the child pins the same, current core the hub runs — this is what ended "the frozen-old-tarball births" (task 1002706);
3. a genuine core source checkout rebuilds fresh via `package-core.js`.

Every rung answers one question: *what is the control plane actually running?* A registry install cannot express that. It can only express *what was most recently published*. Those coincide often and are not the same thing, and the gap between them is precisely where the bugs above lived.

This is the owner's own input, stated more sharply than the task body had it: vendoring is what makes standing up today's code work at all, because a checkout routinely runs ahead of the registry. Worth recording honestly, since the obvious measurement appears to contradict it:

- `main` is **not** durably ahead of the registry any more. Since publish-on-merge was armed, 136 of the last 300 commits on `main` are release bumps, releases land every 9–51 minutes, and `main`'s `CORE_VERSION` and the registry's `latest` were identical (1.19.785) at the moment this was written.
- But provisioning does not provision from `main`. It provisions from **the control plane's own checkout**, which is whatever commit that box is on, and it hands the child a byte-exact tarball of it. An unmerged branch, an uncommitted fix, a box deliberately held at an older pin — none of those exist on the registry at any version, ever.

So the air-gap argument, the one the task put forward, is the weakest of the reasons. The strongest is that vendoring is the only way to say **"this exact core"** instead of **"the newest published one"**.

## Decision

### 1. The vendored-tarball install path STAYS

No removal task follows. It is the default because it is load-bearing, not because the registry path was unproven.

ADR 0134's condition — *"until this registry path is proven end-to-end on a real greenfield standup"* — is **met**, and has been twice over: proven with a token on 2026-07-08 (task 2118 / blocker 71, a real `bongos init --registry-core` scaffold resolving `@bongos/core@1.17.0` and generating a reproducible lockfile), and tokenless since ADR 0283 (`npm pack @bongos/core` from a clean `HOME` with no credentials fetches 25.5 MB at the current version). This ADR closes that clause: the registry path is proven, supported, and reachable via `--registry-core` — and vendoring remains the default anyway, for the reason above rather than for want of proof.

What the public flip **did** retire is one of vendoring's supporting arguments, not its main one. Rung 2's own comment justifies packing the installed core partly "without requiring the child's owner to hold a token for the still-private registry package". That clause is now obsolete. The primary reason in the same sentence — the child pins the same, current core the hub runs — is untouched by the flip.

The costs gate 6 counted are real and are accepted with open eyes: ~124 references, a second install mode every scaffold/upgrade/provision path must keep straight, a Windows-only test failure ([task 1003839](https://cloudbongos.com/builders#/task/1003839)), and the pin-refresh complexity in `refreshStandaloneCorePin`. They buy the ability to provision an instance that matches the platform that provisioned it. That is a fair price.

### 2. `@cloudbongos/cli` STAYS, on a new justification

Task 1003872 was right that the *original* reason is gone: the package was built so a newcomer could reach the board without a private-registry credential, and there is no private registry any more. Keeping it needs a reason of its own, and there is one, measured rather than asserted:

| | files | unpacked | runtime deps |
|---|---|---|---|
| `@cloudbongos/cli` | 32 | 0.5 MB | `undici` |
| `@bongos/core` | 2,611 | 46.4 MB | `express`, `pg`, `pino` |

`npx @cloudbongos/cli` costs a newcomer half a megabyte. Collapsing it into the core would make the same front door a 46 MB download that drags in a web server and a Postgres driver to print a task list. The thin client is the better artifact on merit, independently of why it first existed.

The three-way framing in the task body is also narrower than it looked: **unpublishing is not on the table.** The package is public at 0.1.3 and strangers may have installed it; withdrawing a published name is a different act from deleting private code, and nothing here justifies it.

So: keep it, keep publishing it, and let it depend on the now-public core. [ADR 0258](0258-the-public-cli-is-a-generated-client-package-not-the-published-core.md) stands, with its *rationale* amended — the package is a deliberately small entry point, no longer a workaround for a private core.

## Consequences

- **No code is deleted by this decision.** Gate 6 closes as a keep/keep, which the task explicitly allowed.
- ADR 0134's "vendored until proven" clause is spent. A future reader asking "why is vendoring still the default when the registry works?" is answered here, not there.
- The one genuine piece of rot the flip left behind in this area is rung 2's stale token clause; it is a comment, and it is corrected by this ADR's existence rather than by a migration.
- **What would reopen this:** if provisioning ever stops meaning "match the control plane" — if instances came to be pinned to published versions by policy rather than to the hub's own tree — vendoring's main justification goes with it, and candidate 1 should be re-asked. Nothing on the current roadmap does that.
- The self-host/AGPL argument the task raised is not the reason for the outcome, but it is not contradicted either: a self-hoster behind a proxy keeps a supported path, as a side effect of a decision made for other reasons.
