# ADR 0258 — The public CLI is a generated client-only package, and its file list is proven by running it

- **Status:** accepted
- **Date:** 2026-09-07
- **Task:** [task 1003679](https://cloudbongos.com/builders#/task/1003679) (BONGOS-V1, goal 1000054 — *A newcomer can build without the UI*)
- **Deciders:** Claude, under the Archon's standing scope
- **Related:** [ADR 0083](0083-modular-architecture-strangler-build-plan.md) (a module may import only `src/module-api.js` — the reason a static closure cannot answer this question) · [ADR 0099](0099-delayed-redacted-mirror-export.md) (the lagged, redacted public mirror — still dormant) · [ADR 0108](0108-instance-composition-configurable-root.md) (the core ships as a private versioned dependency) · [ADR 0118](0118-api-contract-source-of-truth-code-first.md) (the generated client this package vendors) · [ADR 0161](0161-publish-on-merge.md) (why the core's version moves many times a day)

---

## Context

The core ships as `@bongos/core`, which is **private**. That is deliberate (ADR 0108), and it
has an unintended consequence at the front door: a newcomer with no credential can install
nothing. There is no terminal path into an instance at all, so the web hall is the only way in.

The owner put it plainly: *"how am I supposed to easily take on tasks as a new builder? I should
be able to do everything without the UI."*

An open task, 1002025, proposed the obvious fix — publish the core to npm. That is the wrong
instrument on two counts. It publishes the **server**: routes, auth middleware, pool, migrations,
provisioning. And it bypasses ADR 0099's redaction pipeline, which is the mechanism that is
supposed to decide what leaves this repo and does not run until ~2026-11. The premise was also
stale (it named `@cloudbongos/core`; the package is `@bongos/core`).

Two refactors landed the night before this decision and are what make a narrower answer possible:
[task 1003676](https://cloudbongos.com/builders#/task/1003676) cut the one edge that dragged the
server into the CLI, and [task 1003677](https://cloudbongos.com/builders#/task/1003677) made
`src/module-api.js` resolve its kernel capabilities on read rather than on import.

## Decision

**Generate a separate, public, client-only package — `@cloudbongos/cli` — from the core, and do
not publish the core.** `scripts/gds/build-cli-package.js` emits it; `tests/cli_package.mjs`
proves it.

Four parts of this are load-bearing.

### 1. The name is scoped because the org already exists

The owner holds the npm org `cloudbongos`. On npm, org names and unscoped package names share one
namespace, so the bare name `cloudbongos` is **not publishable precisely because that org
exists** — npm reports it as invalid, which reads like the name is taken when in fact the owner
owns it. A public scoped package is free and `npx @cloudbongos/cli` is not a worse experience
than `npx cloudbongos`. (Registry checked 2026-09-07: `cloudbongos`, `@cloudbongos/cli` and
`@cloudbongos/core` all 404, search total 0.)

Related and worth writing down because it wasted the owner's time: **a package name cannot be
created or reserved on the npm website.** The name comes into existence on first `npm publish`.
Every field on the org settings pages operates on packages that already exist, which is why
"Add Existing Package" answered `Forbidden` for a package nobody had published.

### 2. The file list is DECLARED, and proven by behaviour — not computed

The tempting approach is to derive the package from a static require-closure of the CLI entry
points. **That instrument does not work here, and cannot be made to.** `src/module-api.js` is the
published module doorway (ADR 0083): a module may import *only* it, so any script that touches a
module file statically reaches the doorway, and the doorway by design *names* every kernel
capability. A static walk therefore sees the whole server — 33 `src/` files from
`scripts/gds/start.js` alone — even though every one of those names is behind a lazy getter that
never resolves. Measured at runtime the same set is **one** `src/bongos/` file
(`api-prefix.js`, which imports nothing).

This is the same trap as task 1003677's original done-when ("zero `src/bongos` in the
require-closure"), which was unsatisfiable for exactly this reason: a getter still *contains* the
require text.

So `FILES` in the build script is an explicit, grouped, auditable list, and the test packs the
tarball, installs it into an empty directory **with no repo present**, and runs every advertised
verb. A verb may fail for want of a session or a network; it may not fail because a file is
missing. That test is the only thing that can prove the list complete, and it earned its keep
immediately — the first build shipped without `clients/bongos-client/index.mjs`, which
`cli-lib.js` reaches by a dynamic `import()` that no `require()`-based reasoning would ever see.
The build now refuses any relative `import()` target the manifest omits, and the generated
`package.json` `files` array is derived from the manifest rather than hand-listed (the hand-listed
one had already dropped `clients/`, producing a tarball that installed cleanly and died on first
use).

### 3. `claim` and `ship` are absent, and the CLI says why

Writing code needs a real checkout and a worktree, so `claim`, `ship`, `dev`, `serve`, `module`,
`upgrade`, `onboard`, `doctor`, `exec` and `package-core` are not in the public CLI. A newcomer
who types one gets the reason and the next step — `bongos shell` opens a terminal on a cloud dev
box that already has the full CLI — rather than `unknown command`. A bare unknown-command error
teaches nothing, which is the precise failure this whole task exists to fix, so it would be
perverse to reintroduce it at the boundary.

The journey the package supports end to end is: `bongos login <instance>` → `bongos start` →
`bongos shell`. Steps one and two are what had no terminal path at all.

`onboard` is excluded for a second reason: it drags ten provisioning files that talk to
DigitalOcean and GitHub. It is owner tooling, and it is the widest redaction surface in the
candidate set.

### 4. A redaction gate runs on every build, and it fails closed

The package is public, so the build scans the emitted tree and **refuses to emit** on a hit:
non-loopback IPv4 (RFC 5737 documentation ranges and link-local exempted — those can never name
real infrastructure, so they are the correct thing to write in an example), GitHub/npm token
shapes, private-key blocks, AWS keys, plus every domain and owner login it can read out of the
instance's own `config/branding.json`.

The needles come from host config rather than a list in the core, so the core carries no instance
identity (the ADR 0062 §7 split). A neutral core has no `config/branding.json`, so that half is
inert there — which is correct: the gate exists to stop someone building this package from an
*instance* checkout. `cloudbongos.com` is allowlisted as public by design, the way
`registry.npmjs.org` is baked into npm.

The generated `package.json` carries **no `repository` field**: the core repo is private, so a
repository URL would 404 for every user *and* put the owner's login into a public artifact for no
benefit. It gains one when ADR 0099's mirror lands.

## Consequences

- 31 files, ~450 KB, 13 verbs, **one** runtime dependency (`undici`). Small enough to audit by
  reading, which was the point.
- The package's version is independent of the core's. The core moves many times a day under
  ADR 0161; a public CLI's contract should not.
- The generated tree is gitignored (`dist/`). It is rebuilt, never committed.
- **Publishing is the owner's action, not a builder's.** It is the owner's npm account, and a
  public package name cannot be un-taken. The build stops at a packed tarball and hands over one
  `npm publish --access public`.
- `@bongos/client` is **vendored** as a single file rather than declared as a dependency — a public
  package that depended on a private one would be uninstallable for everyone. (It was private then;
  since [task 1003742](https://cloudbongos.com/builders#/task/1003742) it is not published at all,
  which makes the vendoring not merely preferable but the only option. Vendoring was the right call
  either way, and this package is one of the two reasons the client had no consumers to lose.)
- Task 1002025 is superseded and should be closed against this ADR rather than done.
- **The journey above is instance-dependent, and 0.1.1 shipped assuming it was not**
  ([task 1003730](https://cloudbongos.com/builders#/task/1003730)). `bongos shell` is the answer
  this package gives to `bongos claim`, but `dev-box` is a **control-plane** module — it
  provisions droplets, so every hosted co-tenant checked (hermeslines-marketing, mercury, demo)
  runs without it while cloudbongos.com has it. On those instances the only route the CLI offered
  to a checkout ended in `HTTP 404: not_found`: a newcomer could list the work and not start it.
  The instance manifest had always said so — `/api/gds/instance` carries `modules.enabled` — and
  no CLI script read it. It now does, **failing open** (a core too old to publish a roster must
  never block a working box), and the dispatcher's checkout-only text presents `bongos shell` as
  conditional rather than promising a box it cannot verify.
- **A surface conversion is only as complete as the paths it is tested on.** Task 1003680 routed
  `start.js` through `surface.js` and pinned exactly that file, so eleven `/builder-*` lines
  shipped in 0.1.1 — including `requireSession()`, the gate every unauthenticated verb passes
  through, which told terminal users to run `/builder-setup`, and `setup.js`'s completion footer,
  which told a newly-registered builder to run two verbs this package does not have. Several also
  named `node scripts/gds/<x>.js`, the checkout this package exists to avoid needing. The test now
  **runs** the guidance printers under both surfaces rather than scanning one file's source.

## Rejected

- **Publishing the core** (task 1002025 as written) — ships the server and bypasses ADR 0099.
- **Deriving the package from a static require-closure** — structurally impossible past the
  module doorway; see §2.
- **Waiting for the ADR 0099 mirror** — it is dormant until ~2026-11 and the front door is broken
  now. The two are independent: this package is a build product, not a source release.
- **An unscoped `cloudbongos` package** — unpublishable while the owner's org of that name exists.
- **Depending on `@bongos/client`** — private, so the public package would not install.
- **Including `claim`/`ship` in a degraded form** — a half-working claim that cannot materialize
  into a checkout is worse than one that explains where to go.
- **Shipping all of `src/`** to make lazy getters safe — reintroduces the server surface and the
  redaction problem the narrow list exists to avoid.
