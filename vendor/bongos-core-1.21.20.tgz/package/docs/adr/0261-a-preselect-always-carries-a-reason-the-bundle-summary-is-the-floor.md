# ADR 0261 — A preselect always carries a reason; the bundle's summary is the floor

**Status:** Accepted · 2026-09-07 · task 1003684
**Supersedes nothing. Resolves a tension between [ADR 0237](0237-a-starter-bundle-is-a-preset-over-the-always-on-core-keyed-by-declared-type.md) and [ADR 0243](0243-a-bundle-adjustment-belongs-to-the-bundle-not-the-advice-about-it.md).**

## Context

Two rules were each right on their own and wrong together.

**ADR 0243** made `bundle.adjustments` a **delta**: a team-shape rule that fires without moving
anything claims nothing. That is correct — a sentence explaining a change that did not happen is
a claim the owner cannot check, and the module contract states it plainly ("a rule that changed
nothing claims nothing").

**ADR 0237** says a preselect the owner cannot see a reason for is one they have to audit, which
is worse than no preselect at all. The wizard's own paint site quotes this.

The two collide whenever a type's bundle **already contains** what a rule would add. The live
case: `game` is `['dev-box','discord']` and the `small-team` rule adds `dev-box`. The rule fires,
moves nothing, and correctly reports `adjustments: []`. Confirmed against live core 1.19.580:

```
GET /provisioning/starter-bundles → bundles[type=game].byTeamShape['small-team']
  {"bundle":["dev-box","discord"],"adjustments":[]}
```

The owner then reached step 4 of the create wizard and saw **two extras switched on and no reason
beside them** — `#modWhy` rendered as an empty, hidden div. Exactly the state ADR 0237 exists to
prevent, produced by ADR 0243 behaving correctly.

This was originally filed as a bug against the recommendation engine (a "dropped adjustment").
It was not: the engine is right. The gap is that the panel had only one voice — the rule's — and
fell silent when the rule had nothing to say.

## Decision

**The why-line has two voices, and the type's is the floor.**

1. When one or more rules **moved** something, their sentences are shown, unchanged. A real
   adjustment still speaks for itself and is never displaced.
2. When no rule moved anything, the **type's own curated `summary`** explains the preselect.
3. When the owner has answered the picker for themselves (`state.modules !== null`), the panel
   says nothing at all — unchanged. Handing back a reason for a toggle they just flipped reads
   as the panel arguing with them.
4. A bundle carrying no summary still says nothing. The floor is a floor, not an invention.

The summary was already authored for this job (`STARTER_BUNDLES[type].summary` in
`modules/provisioning/starter-bundles.js`), already served on every row of
`GET /provisioning/starter-bundles`, and — until this change — **rendered nowhere in the
product**.

## Consequences

- No new copy, no new endpoint, no new field. The change is which existing sentence is rendered
  when the delta is empty.
- `adjustments` keeps its meaning exactly. Nothing about ADR 0243 is weakened: the delta is still
  a delta, and no rule is credited with a change it did not make. What changed is that the
  panel's silence is no longer the *only* alternative to a rule sentence.
- The pin `tests/projects_hub_module_picker.mjs` had a fixture with **no `summary` field**, which
  made four "no adjustment, no sentence" cases pass for the wrong reason. The fixture now carries
  the real summaries and those cases assert the new contract — including, explicitly, that no
  *rule* sentence is invented for a change that did not happen.
- `tests/wizard_preselect_why.mjs` pins the resolver directly across every combination.

## Alternatives rejected

**Make the rule claim a no-op change.** Report `a-team-shares-one-environment` as an adjustment
even when `dev-box` was already in the bundle. Rejected: it re-introduces exactly the unverifiable
claim ADR 0243 removed, and the owner would read "a small team gets one shared environment" beside
a module that was on before they answered.

**Widen the bundles so no rule is ever redundant.** Rejected: it contorts curated per-type presets
to serve an unrelated rendering concern, and the redundancy would return the moment a rule or a
bundle changed.

**Leave it silent.** Rejected by the owner on 2026-09-07 after the trade-off was put to them
directly. The preselect is the wizard's most consequential default, and shipping it unexplained
for the most common answer combination is the failure ADR 0237 names.
