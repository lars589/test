# ADR 0260 — An application IS the consent, and the hub's own echo is the gate: the D7 applicant view

- **Status:** accepted
- **Date:** 2026-09-03
- **Task:** [task 1002972](https://cloudbongos.com/builders#/task/1002972) (PV7, goal 1000045 — criterion C4)
- **Relates to:** `docs/specs/<redacted>.md` **D7** (owner-signed 2026-08-16), [ADR 0215](0215-the-recruiter-sliver-is-a-ceiling-not-a-step.md) (the D3 sliver this reuses), [ADR 0205](0205-federated-checkin-needs-the-hubs-own-signin-witness.md) + security report 1000027 (client credentials name a project, never a person), [ADR 0201](0201-cross-project-application-vouched-row-live-record.md) D1.2/D1.3 (the vouch mark and the statusless echo), [ADR 0171](0171-profile-rollup-join-and-consent.md) D4/D5 (indistinguishable nulls, no-store), [ADR 0016](0016-trust-boundary-server-enforced-permissions.md) (descriptive, never authority), [ADR 0083](0083-modular-architecture-strangler-build-plan.md) (the doorway)

## Context

Spec D7 asks for one thing in one sentence: a reviewer looking at an application
sees **what the applicant's own profile rules would already show them**, plus the
applicant's note, **evaluated live at review time**. Public account → the public
profile view. Private account → the D3 sliver. No new disclosure class.

Two halves of that already existed when this task opened. The applicant's note
reaches the project's queue through the join relay (task 1002330,
`relayApplicationNote`). The D3 projection exists and is proved
([ADR 0215](0215-the-recruiter-sliver-is-a-ceiling-not-a-step.md)). What did not
exist was the **rule** — which of the two views an applicant gets — and the
**path** by which a project's reviewer queue could ask the hub for it.

Three things about that path are not obvious, and each could have been got wrong
in a way that looked like a simplification.

## Decision

### D1 — The rule is one port composing the two EXISTING views, never a third shape

`modules/platform-identity/applicant-profile.js` answers
`null | { view:'public', account, cross_project } | { view:'sliver', sliver }`.

The public branch's rollup half is `getPublicProfileExtras` — the very port the
canonical `/u/<handle>` page calls. The private branch's projection is
`sliverShapeFor`, exported from `recruiter-sliver.js` — the very function the
recruiting route serializes. **Neither branch builds its own object**, because a
third five-key lookalike *is* the new disclosure class D7 forbids: free to drift
from the original field by field, and uncovered by the whitelist proof over it.

`tests/applicant_profile_boundary.mjs` asserts both key sets against the
**modules' own exported lists**, never against copies kept in the test.

### D2 — The APPLICATION is the consent, not the recruiting opt-in

This is the one place the applicant view differs from the recruiter sliver, and
it is the decision most likely to be "tidied" away later.

`getRecruiterSliver` floors on `recruiterSliverVisibleSql` = consent **and
recruiting reach**, because a recruiter browsing a directory was invited by
nobody. An applicant has done something a browsing recruiter has not — spec D7
says it in those words: **"applying is an explicit act"**.

So routing this port through `getRecruiterSliver` would be wrong *in the
direction that looks safe*. `recruiter_discoverable` defaults to **false** for a
private account, so a private builder who deliberately applied would show their
reviewer **nothing at all**, and criterion C4 would be satisfied by an empty box.
The reach opt-out governs the *recruiting surface* — `account-visibility.js` says
exactly that of `scoutingListableSql` — and was never a gate on a door the
account itself knocked on.

**What the swap does NOT relax**, and this is what keeps it from meaning
"applying opts you into everything":

- `accountActiveSql` still floors it — `profile_state='active'` **and**
  `terms_accepted_at IS NOT NULL`. A provisional account and one that never
  accepted the platform terms disclose nothing, applying or not.
- `hide_stats` is untouched in both branches. Applying is consent to be **seen**,
  never consent to be **counted**.
- The existence axis stays off, for ADR 0215 D1's reason: the private account is
  precisely this rule's subject.

The proof asserts the swap **in both directions on the same account** — `PRIVOUT`
gets an applicant view and gets `null` from `getRecruiterSliver` — so the
tempting refactor cannot pass quietly.

### D3 — The gate is the hub's own echo, because client credentials name a project and not a person

`POST /sso/applicant-profile` is authenticated by `client_id` + `client_secret`,
like its two siblings. **That authentication is not sufficient on its own**, and
this is the whole security argument for the route.

[ADR 0205](0205-federated-checkin-needs-the-hubs-own-signin-witness.md) / security
report 1000027 is the lesson `/sso/membership/check-in` and `/sso/activity/rollup`
both had to learn: credentials prove *which project* is calling and say **nothing
about who the `github_id` in the body is**. Without a per-subject witness, this
route is a **bulk disclosure oracle** over every account on the platform —
private ones included, since D7's private branch is exactly the disclosure the
existence axis normally withholds. That is strictly worse than the rollup hole it
would mirror.

The witness is `platform_identity_application_echoes` — the statusless
"you applied to this project on this date" row from
[ADR 0201](0201-cross-project-application-vouched-row-live-record.md) D1.3. It is
the right witness because **the hub writes it itself**, in its own join relay,
only after the project answered the relayed application with a success. A client
cannot assert itself into that table. `applicationBacksProfileRead` is the exact
analogue of `membershipBacksRollup`: a boolean, and the narrowest cross-account
read the table has — the caller must already name both the account and the
project, and there is no listing by `client_id`, so a project learns nothing
about who applied that it was not already told at its own door.

It reuses the **same 30-day window**, and that is load-bearing rather than tidy:
when the echo stops matching, the view stops rendering, because the platform has
stopped vouching for the link between that queue row and that account.

Refusal is **404, never 403** — a 403 would confirm the `github_id` names a real
account. And the gate runs **before any account is read**: the proof asserts that
on the statement log, not on the response, because a gate that refuses *after*
reading has already done the disclosure work.

### D4 — LIVE means nothing is stored, at either end

Nothing about the applicant is written to the `access_requests` row and nothing is
cached on the project. The profile is resolved on **every render**
(`attachApplicantProfiles`), so an applicant who hides their stats, goes private,
or loses their account between applying and being reviewed is answered by the next
read of the queue — criterion C2's "immediately". A snapshot taken at apply time
would keep publishing a consent that had since been withdrawn, for as long as the
request sat in the queue. The hub sends `Cache-Control: no-store`; the project
keeps nothing.

### D5 — The queue keys on the VOUCH, never on `github_login`

`attachApplicantProfiles` resolves only rows carrying `applicant_github_id` — the
hub's own assertion about who filed the request (`core_230`). `POST /access-requests`
is the one **public unauthenticated write** on the GDS, so `github_login` is a
string anybody may type. Resolving a cross-project record against an unvouched
login is precisely the impersonation surface the vouch exists to close: file a
request naming a well-known builder, let the owner read that builder's excellent
record, and walk in. An unvouched row gets `profile: null`, always.

### D6 — The credential stays in core; the module gets a narrow port

The hub call lives in `src/bongos/auth-admission.js` beside the two other calls
that hold the hub client secret, and `loadIdpConfig` stays **off** the doorway —
putting it there would hand every module the credential that speaks for the whole
project. `<redacted>(githubId)` is published instead: one
`github_id` in, one already-bounded view out. The module can neither widen the
request nor re-address it.

## Consequences

- **The path is complete but DORMANT until R09 ([task 1002285](https://cloudbongos.com/builders#/task/1002285)) ships the vouch writer.** Nothing in the tree writes `applicant_github_id` today, so every queue row currently resolves `profile: null` and renders exactly as it did before. This is stated rather than glossed: the feature is wired end to end and proved, and it lights up on the day R09 lands its writer — the sequencing R08's own migration comment predicted. 1002972's declared dependency was PV3 alone; **the real dependency on R09 was missing from the graph.**
- The reviewer queue degrades rather than breaks: a hub outage, a self-hosted instance with no hub, and an applicant with no echo all render a row with its login, note and vouch pill and no profile block.
- `MAX_LIVE_PROFILE_READS = 25` caps per-render hub round-trips against a 200-row queue. It bites on vouched rows in list order, so the rows a reviewer acts on carry the profile. Raising it buys detail and costs latency; it changes nothing about what may be disclosed.
- `recruiter-sliver.js` now has a second first-party reader. The sole-reader guard in `tests/recruiter_sliver_boundary.mjs` was widened with a stated reason **and strengthened**: every listed reader is now checked to not *branch* on a sliver field, so the property the guard protects — descriptive data is never consulted as authority — is enforced rather than trusted.
- **Still not built:** the apply UI's *"your application shares: …"* disclosure line D7 names. There is no apply UI anywhere — `POST /my-projects/join` has no browser caller — so the sentence has no page to live on. It belongs with whichever task builds that surface, and is filed rather than silently dropped.
