# ADR 0297 — A task's creator may retire it, and that is the ownership axis's first route

**Status:** accepted · **Date:** 2026-09-16 · **Task:** [task 1002443](https://cloudbongos.com/builders#/task/1002443) (goal 1000095)

## Context

The owner, 2026-07-25: *"Each task should have a creator, the creator of that task
should be able to abandon that task directly inside of the UI."*

The first half shipped elsewhere and earlier. `migrations/core_227_task_created_by.sql`
([task 1003278](https://cloudbongos.com/builders#/task/1003278), goal 1000072) added
`tasks.created_by` — nullable, no backfill, indexed, with the two `SELECT t.*` views
rebuilt so the column actually reaches the claimable feed — and `createTask` has
threaded the caller through ever since. This ADR is only about the second half, which
had not moved: **retiring a task was a rank power and nothing else.**

`POST /tasks/:id/abandon` gated on `task.abandon`, floor `metic`
([ADR 0152](0152-metic-task-abandonment.md), archon before that under
[ADR 0090](0090-metic-task-authoring.md)). So a builder below Metic could file a
task and then could not withdraw it. They had to ask someone with triage authority to
retire a proposal that was theirs in the first place — the same shape as the goal
membership problem [ADR 0106](0106-goal-owner-manager-authority.md) fixed, and
for the same reason: **the rule is about whose row it is, and a rank cannot say that.**

The permission model had already grown the vocabulary for this and had never used it.
[ADR 0151](0151-governance-permissions-as-atom-ranks-as-roles.md) §3 defines an **ownership axis** —
a key declared `scope: 'own'` is *parameterized by a concrete row*, so holding it
authorizes nothing until a handler that has loaded that row supplies its owner. R100
made `requirePermission` refuse an own-scoped key outright, precisely so `.own` could
never degrade into `.any`, and recorded that **zero call sites passed one**. The
resolver shipped `authorizeOwned` / `authorizeOwnedOrAny`; six keys were declared
own-scoped; not one route decided anything with them. This is that axis's first real
consumer.

## Decision

**Two authorities reach the abandon transition, and only one of them is rank-shaped.**

| key | floor | reaches |
|---|---|---|
| `task.abandon` | `metic` | any task, any creator — triage authority, unchanged from ADR 0152 |
| `task.abandon.own` | `xenos` | a task you created, while it is still `backlog` / `ready` / `blocked` |

The route is therefore `requireBuilder` plus an in-handler decision — the shape
`POST /goals/:id/members`, `PATCH /goals/:id/members/:builderId` and
`PATCH /inbox/:id/body` already use, and the shape `requirePermission` structurally
cannot express. Its rank pin moves `metic+archon` → `any-builder`, whose job becomes
catching an accidental **tightening** back to a rank floor as loudly as it catches a
gate removal.

**The two facts are resolved in two different places, on purpose.** Authority here is a
conjunction drawn from two sources, and folding them together loses one:

- the **rank fact** — does this builder hold the key — is request-scoped, so it resolves
  in the route before the transaction opens: once, uncached, per
  [ADR 0016](0016-trust-boundary-server-enforced-permissions.md);
- the **owner fact** — is this row theirs — is a column that can change under us, so it
  is evaluated *inside* `abandonTask`'s existing `FOR UPDATE` transaction, through a new
  optional `authorize` callback. `created_by` joins the locked `SELECT`, so the predicate
  and the `UPDATE` read the same row version.

Reading `created_by` in the route would be a TOCTOU window — the task can be
re-attributed, claimed or shipped between the check and the write. Resolving permissions
inside the transaction would hold a row lock across a second pool acquire, which under a
saturated pool is a deadlock. Splitting them is what makes the decision both **fresh**
and **race-free**, and it is why the callback is documented as pure and DB-free rather
than merely happening to be.

**The decision itself is a pure module**, `modules/lifecycle/abandon-authz.js`, following
`goal-route-authz.js` and `shouldRefuseSessionClaim`. Every branch is pinned by a
DB-free unit test instead of only through a live route, and the hall's display hint and
the server's verdict are demonstrably reading one rule.

**A creator's window is narrower than a Metic's, and stops at the grader.**
`backlog` / `ready` / `blocked` only. Past that a retire is a correction to the ledger
rather than an author changing their mind, so `completed` and `confirmed` stay with the
cross-owner authority. `active` is excluded here and again by the active-claim guard.
Nothing is subtracted from `task.abandon`: a Metic keeps every status they could reach
before, and a test pins that the new window never becomes a ceiling on the old power.

**`counterpart: ['task.abandon']` is declared, not derived.** Same `act` verb, same
`task` resource, so the cross-owner key genuinely subsumes retiring your own and
`authorizeOwnedOrAny` may admit on it without consulting the owner. The verb is `act`
rather than `manage` deliberately: `manage` is the full-control verb and would silently
dominate every future narrower `task.*.own` key — the verb-blind escalation
[task 1003195](https://cloudbongos.com/builders#/task/1003195) closed, where a
`memory.read.any` grant satisfied a `memory.manage.own` write.

## Consequences

**A null creator belongs to nobody, and that is load-bearing.** Every task filed before
`core_227` (~1,357 of them) plus the seed, restock and Discord-bug vectors carry
`created_by IS NULL`. The owner comparison is the government resolver's own — injected,
never re-implemented, because a duplicated ownership comparison is exactly how one
quietly widens — and it matches `null`, `''`, objects and `NaN` against nothing. Were
that to slip, one xenos-floor grant would open every historical task at once. It is the
single widest failure mode here and has its own test.

**The hall shows the control to a creator, and pre-answers the refusals in words.** A
task's creator sees "Retire this task…" on their own record; outside the window they are
told why rather than shown a button that would 403. The list of statuses is restated in
the browser file because it cannot `require` the server's, and is marked as a display
mirror the server re-decides under a lock.

**Fail-closed at every new branch.** A missing `government` port denies (its absence
means authority cannot be *established*, and admitting there would make disabling a
module a privilege escalation — the inversion ADR 0016 exists to prevent); a throwing
resolver denies; anything that is not an explicit `{ ok: true }` denies; `authorize`
runs *before* the already-abandoned idempotent return and before the shipped and
active-claim guards, so an unauthorized caller cannot probe a row's state through a
200 or distinguish the 409s.

**No guard was removed.** Shipped stays immutable, an active claim still has to be
released first, the re-abandon is still idempotent, `/promote` still restores, and the
audit_log entry is unchanged on both paths.

**What this does not do.** It does not give creators any other power over their own
tasks — editing, promoting and dependency management keep their Metic floor, and
widening those is a separate decision. It does not touch `task.merge`, which reuses
`abandonTask` under the hood but is a triage judgement about duplicates rather than
authorship. And it does not backfill attribution: the control simply does not appear on
tasks that predate `core_227`, which is the honest outcome of that migration's own
refusal to guess.

**Revisit if** a second `task.*.own` key appears (the `act` verb choice is what keeps
that safe, and a wider relation would need a `VERB_DOMINANCE` entry stating why), or if
goal leadership should confer shaping authority — deliberately left conferring nothing
here, as [task 1002858](https://cloudbongos.com/builders#/task/1002858) also left it.
