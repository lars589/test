# ADR 0214 — The canonical profile URL gets one resolver, and it stays dark until the page it names actually resolves

- **Status:** accepted
- **Date:** 2026-08-29
- **Task:** [task 1002804](https://cloudbongos.com/builders#/task/1002804) (P08, goal 1000045 — Public builder profiles, criterion C1)
- **Relates to:** ADR 0171 D1/D2/D8 (link out instead of inlining; `hide_stats` suppresses numbers, never existence; `github_id` is the join key and the handle is presentation), ADR 0202 D4 / ADR 0210 (one shared visibility predicate, never a second variant), ADR 0141 (identity federated, authority local), ADR 0083 (module boundary), ADR 0016 (identity is never authority), `docs/specs/<redacted>.md` Decision 1 + Decision 3, `docs/specs/<redacted>.md` D2 (404, never 403)

## Context

Profile-page spec Decision 1 names one canonical public profile with two render paths: `cloudbongos.com/u/<handle>` is canonical and server-rendered on the hub; `builders.<instance>/profile` stays the LOCAL view and emits `rel=canonical` to it; and the numeric `?id=` form "never dies" as a rename-proof fallback that redirects to the canonical handle URL. ADR 0171 D1 amended that: federated non-hub instances **link out** rather than inlining cross-project numbers, and named this task the owner of the federated render path — the visible link, the `rel=canonical` emission, and the numeric-id redirect.

Four facts about the tree, established before any of this was designed:

1. **`/u/<handle>` does not exist.** No route, no page, no hub search, no sitemap (proved by task 1002806, confirmed by task 1002296). The page is goal 1000048 R14 / [task 1002365](https://cloudbongos.com/builders#/task/1002365), which sits at `backlog`. So does R13 (cross-instance canonical), R12 (robots.txt) and R15 (sitemap). R01 — the ADR that *decides the SEO namespace* — is only `ready`, and R03 in the same goal proposes moving platform pages under `/bongos/…`. **The path string `/u/<handle>` is not merely unbuilt; its shape is not yet settled.**
2. **The READ behind that page already exists.** `GET /profiles/:handle` (`modules/platform-identity/routes/public-profile.js`, R05) resolves current-or-previous handle through `resolveHandle`, which floors on the shared `accountVisibleSql` predicate and answers 404 for unknown / provisional / private alike — never 403.
3. **`GET /builders/:id/profile` whitelists nine core columns and `handle` is not one of them.** Task 1002296 hit this and routed around it: `profile-connections.js` hands the connections API a `github_login` and uses the handle the response echoes back. That workaround has a hole its own header names — the rename window is a **single** `previous_handle` slot, so a builder who has renamed **twice** has a login that matches neither `handle` nor `previous_handle`, the degree call 404s, and the connections section silently never appears.
4. **No served page carries a hub origin.** `clientBranding()` deliberately omits `domains`; `applyBrandTokens()` stamps `{{publicOrigin}}` and `{{buildersOrigin}}` (this instance's own addresses) and nothing else. The only hub origin anywhere at runtime is `loadIdpConfig().origin` in `src/bongos/auth-config.js` — server-side auth wiring, never rendered. ADR 0171 D1 flagged exactly this gap.

## Decision

### D1 — One resolver owns the canonical URL, and it answers `null` while the page does not resolve

`modules/platform-identity/canonical-profile.js` is THE place that answers "what is this builder's canonical profile URL?". Everything that needs the answer — the `rel=canonical` link, the visible link-out, the numeric-id redirect — asks it and renders nothing when it answers `null`. One resolver, three consumers, so the three can never disagree about where a profile lives or about whether it is safe to point there.

`CANONICAL_PROFILE_PAGE_LIVE` is `false`. **Today the resolver answers `null` everywhere and all three surfaces are dark.**

**Why dark, and not "canonical ahead of the page".** Emitting a canonical at a URL that is planned but unbuilt is a normal SEO staging move when the target is imminent and its address is fixed. Neither holds here:

- **The target 404s.** A `rel=canonical` pointing at a 404 does not consolidate anything — a 404 cannot be indexed, so there is no signal to consolidate onto. What it *can* do is cost: the declaring page is the only one that works, and a canonical that names a non-indexable URL is a documented way to have a working page reported as a duplicate of nothing and dropped. We would be spending the one page that ranks to point at a page that does not exist.
- **The address is not settled.** R01 has not been written and R03 proposes relocating platform pages under `/bongos/…`. Baking `/u/<handle>` into every federated instance's served HTML now means every one of them advertises a path that a sibling task may still move — and a canonical is precisely the kind of claim that is expensive to retract, because crawlers cache it and users bookmark what it redirects them to.
- **There is no upside to being early.** Canonical consolidation begins when the target becomes indexable, not before. Emitting now buys nothing and risks the working page.

So the honest answer is: build the machinery, prove it, and **do not point at a 404**. The flip is one boolean in one file, and R14 cannot land the page without noticing it — `tests/canonical_profile_url.mjs` fails if a `/u/` page route appears anywhere in the tree while the flag is still `false`. The flag cannot silently lie in either direction.

**What must be true to flip it** (the checklist R13/R14 inherit, stated once so nobody has to re-derive it): the page is served at the path this file names; R01 has ratified that path; the page 404s (never 403) for absent / provisional / private, matching `GET /profiles/:handle`; and `noindex`-until-first-ship (P09) is in place so flipping the flag does not publish a farm of empty profiles.

### D2 — The hub origin becomes a server-side stamp, delivered as a `<meta>`, not a `<script>`

`applyBrandTokens()` gains `{{hubOrigin}}`. It resolves to the instance's **own** `publicOrigin` when `platform-identity` is enabled (that module *is* the hub flag — `src/platform-server.js`), to `loadIdpConfig().origin` on a federated instance, and to `''` on a vanilla one. This is the "server-side hub-origin stamp token" ADR 0171 D1 asked for, and it is the only way a served page can carry a correct cross-host canonical: `clientBranding()` cannot reach `domains`, and a baked value would make every instance advertise whoever authored the file (the fitness identity gate, task 1002748).

It is stamped as `<meta name="hub-origin" content="{{hubOrigin}}">`, following the `{{instanceBase}}` precedent — a meta attribute, never a script global. **The token is deliberately not written directly into a `href`**: `dropEmptyHrefLinks` only drops an href that is a *bare* origin token, so `href="{{hubOrigin}}/u/x"` on an instance with no hub would silently become the same-host relative URL `/u/x` — a canonical pointing at the instance itself. Reading the meta and refusing an empty value makes that failure impossible rather than merely unlikely.

### D3 — `handle` joins the numeric profile response under the EXISTENCE predicate, not the rollup one

`GET /builders/:id/profile` gains a top-level `handle`, attached only where the `platform-identity.hub` port resolves, sourced from a new port function `getPublicHandle(githubId)` that floors on `isAccountVisible` — the shared predicate, never a variant.

**Why the existence predicate and not the rollup one.** `account-visibility.js` is explicit that `hide_stats` suppresses NUMBERS and never existence, and `resolveHandle` already says the same out loud: hiding removes the rollup, not the page. A builder who hides their stats still has a public profile at `/u/<handle>` — it just carries no numbers. Gating the handle on `rollupVisibleSql` would deny a canonical URL and a connect button to exactly the people who chose a public profile without public numbers.

**This does not create a new inference.** It is true that `handle` present together with `cross_project: null` narrows the four indistinguishable rollup-null cases to "hidden". That pair is **already published, unauthenticated, on `/profiles/:handle`**, which answers `200 { account: { handle }, cross_project: null }` for exactly that account. The change re-presents on the numeric route a pair the handle route already serves; it does not widen what the platform discloses. The three cases ADR 0171 D2 requires to stay merged — no account, provisional, private — all still produce `handle` absent **and** `cross_project` null, byte-identical.

**What this closes today, with the flag still off:** fact 3 above. `profile-connections.js` can take the canonical handle straight from the profile response instead of guessing with a `github_login`, so a twice-renamed builder gets their connections section back.

### D4 — The numeric `?id=` form redirects on the hub and canonicalizes on a federated instance

The spec's two clauses — "the local view stays as-is" and "the numeric form redirects to the canonical URL" — read as a contradiction only until you ask *which instance*:

- **On the hub**, `builders.<apex>/profile?id=N` and `<apex>/u/<handle>` describe the same person from the same database. Two URLs for one page on one host is precisely the duplication Decision 1 exists to end, so the numeric form **redirects**.
- **On a federated instance**, `builders.foo.com/profile?id=N` shows *foo's* local rank, works and achievements. That is genuinely different content, so it **must not** redirect. It stays the local view, emits `rel=canonical`, and shows the visible link-out — ADR 0171 D1's federated render path exactly.
- **On a vanilla instance** nothing changes at all.

A page cannot both redirect to a URL and declare it canonical, and it does not have to: the two behaviours belong to different instances.

The hub redirect is a client-side `location.replace` (it replaces rather than pushes, so Back still leaves the site cleanly) issued after the profile read resolves the handle. It is not a true 301 and does not claim to be: the hall page is served from a boot-time in-memory HTML map with no per-request database access, and giving that path a DB read to serve a redirect is a real cost for a page that is not indexed today (there is no robots.txt yet — R12). **When R14 lands the server-rendered page it should serve the numeric form as a real 301 in its own namespace, using this same resolver**; that is written here so the follow-up is a decision already made rather than one rediscovered.

### D5 — The redirect is not an existence oracle

The hub redirect fires iff the profile response carries a `handle`, which it does iff `isAccountVisible` — the same predicate `/profiles/:handle` already floors on. Three properties make the fallback silent:

1. **The non-redirect branch is a working page, not an error.** No account, provisional, and private all render the ordinary local profile — the same markup, the same status, the same everything. There is no error shape to read a signal off.
2. **The three "no" cases are indistinguishable from each other.** `getPublicHandle` returns `null` for all three; the response omits the key identically. The redirect can only ever separate "publicly visible account" from "not that", never one *reason* from another.
3. **The one bit it does expose is already public.** "This builder has a publicly visible platform account" is exactly what an unauthenticated `GET /profiles/<handle>` answers with 200-vs-404 today. The redirect derives its target from a handle the response already carried; it adds no bit the caller could not already read.

And the redirect target is a handle, never a `github_id` — the join key stays internal, as `<redacted>` already insists.

### D6 — Publishing the handle map puts the numeric profile read under the EXISTING public read ceiling

`GET /builders/:id/profile` answered at line rate. That is structural rather than an oversight: `rateLimitMiddleware` returns early for every non-write method, and the one read limiter is mounted under `/public/*`, which this route is not (ADR 0209's finding, one route over). Tolerable while the route re-presented leaderboard data everyone can already read; not once it also carries `handle`, because an id walk then yields the **builder → canonical-profile-handle map**, one call per builder, for every publicly visible account. `modules/platform-identity/routes/public-profile.js` caps `/profiles/:handle` for exactly that mapping, with exactly that reasoning. Two routes publishing one map get one ceiling.

So the route mounts `publicReadRateLimitMiddleware` — **the shared instance** (120/60s per IP, the `/public/*` posture), not a new budget and not a private copy. ADR 0209's load-bearing point applies verbatim: two limiters configured identically are indistinguishable in a diff and hand an enumerator twice the budget, so the test asserts the shared instance **by object identity**.

**This required strengthening a guard, not weakening one.** `tests/profile_route.mjs` (R06.1) pinned the route as public by requiring the registration line to read `router.get(path, async (req, res) =>` — the handler and nothing else. Its own comment says what it is for: *"a future PR walling this behind `requireBuilder` would break 'another account can see it'"*. That intent is **auth**, and throttling is not authentication — `/public/*` is rate-limited and public. But a line-regex cannot tell the two apart, and it silently missed the more likely bypass anyway: a gate mounted with `router.use`. The guard now reads the **real router stack**, rejects any function exported by `../auth` on that route, rejects any router-level middleware at all, and allows exactly one named handler — the shared limiter — with its reason. Six mutations were run against it; the strengthened form catches all of them, including the two `router.use` forms the old regex let through.

## Consequences

- **Three surfaces ship dark and one ships live.** The canonical link, the link-out and the numeric redirect are all gated on one boolean that is `false`; the widened `handle` on the profile read is live immediately and closes the twice-renamed connect-button hole. A reviewer should expect exactly that asymmetry.
- **R13/R14 inherit a one-line flip and a checklist.** `CANONICAL_PROFILE_PAGE_LIVE` in `modules/platform-identity/canonical-profile.js`, with D1's four preconditions in its doc-comment and a test that fails if a `/u/` page route lands while it is still `false`.
- **A cross-version window exists and is bounded.** A federated instance running a core release where the flag is `true` while its hub is pinned to an older release would link out to a 404. The blast radius is a link and a canonical, not a broken page, and the flag ships in the same release as the page it names.
- **The link-out discloses that a builder has a public platform account** — the same bit D5 analyses, now visible on a federated instance's page rather than only via the handle route. Deliberate: that is what "link out to the canonical record" means.
- **`applyBrandTokens` grows a seventh token.** Its signature is now at seven injectable parameters; a further one should probably move the origins into an object rather than extend the list again.
- **Not decided here:** the sitemap and `noindex` rules (P09 / R15), the served page itself and its caching posture (R14), whether the numeric permalink on the hub should key on the core builder id or a platform-side identifier once the page exists (R14's call, with D5's rule binding either way), and whether federated instances ever inline cross-project numbers — ADR 0171 D1 names the pull-with-cache follow-up and it stays a separate task.
