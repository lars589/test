# ADR 0299 — The nod queue stays scoped to routed filings; the backlog walk is the widening

**Status:** accepted · **Date:** 2026-09-17 · **Task:** [task 1003748](https://cloudbongos.com/builders#/task/1003748) (goal 1000089)

## Context

`listRoutedAwaitingNod` (`modules/ideas/inbox.js`) feeds the "Reported work awaiting a
nod" slice of the Home attention card, and it filters `WHERE l.origin = 'route'`. On
2026-09-08 that read returned 11 rows while 232 tasks sat at `backlog`. The task asked
whether a queue that omits ~95% of the un-nodded backlog is honestly named, or should
grow a second slice for un-routed rows. It noted two things that bound any widening:
dep-gated rows wait on a trigger (migration 163), not a person, so they must not be
shown as needing a nod; and [task 1003746](https://cloudbongos.com/builders#/task/1003746)
(`/backlog-review`) might make the question moot, so decide after that exists.

It exists now. Live numbers on 2026-09-17, from `node scripts/gds/backlog-review.js`:

| Bucket | Rows |
|---|---|
| waiting on a dependency (auto-promotes on ship) | 109 |
| spikes (backlog by convention, migration 020) | 2 |
| stranded (dep abandoned — trigger can never fire) | 1 |
| awaiting a nod (only a human gates it) | 3 |
| **total backlog** | **115** |

`GET /inbox/awaiting-nod` returned `count: 0`. `GET /inbox/rotting` returns 200 (the
route-shadowing bug the task mentioned no longer reproduces), with no rows past the
30-day timer.

## Decision

**Do not widen the nod queue or the card.** `origin='route'` stays the predicate.

1. **The premise that ~220 rows had no path to a human is gone.** Of the rows the card
   omits, 111 are correctly *not* a person's decision (109 dep-gated, 2 spikes). The
   remaining 4 (3 nod + 1 stranded) are exactly what `/backlog-review` walks, goal by
   goal, with the dependency predicate the task said any widening would need
   (`include=deps` → per-edge `satisfied`). The widening the task asked for already
   shipped — as a cadence skill, not a card slice.
2. **The name is honest.** The card says *"Reported work awaiting a nod"* — reported
   is the routed population. It never claimed to be the whole backlog.
3. **A second slice would duplicate a partition.** The four-bucket split lives in
   `backlog-review.js`; a card slice would need a second copy of the
   stranded/dep-gated/spike rules in SQL, free to disagree with the walk. The rot
   card already carries the same kind of warning about its verb list duplicated there.
4. **The card is a push surface for filers.** A routed filing is someone waiting on an
   answer; a planning-seeded backlog row is not. Mixing them dilutes the one signal
   the card exists to carry (task 1003066, owner interview Q3).

## Revisit when

- The *awaiting a nod* bucket of `/backlog-review` (not dep-gated, not spike, not routed)
  grows past what one daily walk clears — then a Home count linking to the walk earns
  its place. Show a **count and link**, not rows, and derive it from the same partition
  the walk uses.
- `/backlog-review` stops being run — then the rot timer is again the only pull, and
  this decision's first reason no longer holds.

## Rejected

- A second "un-routed backlog" slice on the card (duplicates the partition; dilutes the
  filer signal).
- Renaming the queue (the current copy already says *reported*).
- Dropping the origin filter and relying on `has_unshipped_dep` (would pull planning rows
  and spikes into a surface built for filers).
