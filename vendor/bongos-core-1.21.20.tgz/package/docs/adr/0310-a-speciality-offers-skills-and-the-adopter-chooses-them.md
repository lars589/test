# ADR 0310 — A speciality OFFERS skills; the adopter turns them on, one at a time, having been shown what each does

**Status:** accepted · **Date:** 2026-09-19 · **Task:** [#1003978](https://cloudbongos.com/builders#/task/1003978) · **Goal:** 1000095 · **Supersedes nothing; completes [ADR 0296](0296-a-role-speciality-is-data-over-three-existing-surfaces.md)**

## Context

[ADR 0296](0296-a-role-speciality-is-data-over-three-existing-surfaces.md) defines a speciality as *"a named bundle of knowledge, skills and an interaction contract that sits UNDER a craft"*, and names three ingredients over three existing surfaces. **Two of the three shipped.** `contract_md` is the interaction contract; `specialities_documents` + `specialities_learnings` are the knowledge.

The third never existed. There is no skills column, no skills field on the draft, nothing in `validateDraft`, nothing in the routes, nothing in the injected contract. `grep -i skill` across the module's schema, domain and routes returns only the header sentences describing a thing that is not there — in the ADR, in the migration header, in `specialities.js`, and in the module's `CLAUDE.md` table.

That is prose asserting behaviour the code does not have, and it is worse here than usual because it is the feature's own definition. Task 1003978 filed it, and deliberately withheld an implementation: *"Do NOT start by adding a `skills` column. Decide (2) first"* — (2) being whether naming a skill grants anything.

**Why it matters rather than being a doc typo.** The point of a speciality is that an expert's way of working arrives in a session. Two-thirds of that is context and tone; the third is *what the session can DO*. An economics speciality that brings a costing skill is materially different from one that only changes how Claude talks. Without it, a speciality changes framing and never capability.

## The owner's ruling (2026-09-19)

Asked whether specialities should carry skills at all, and if so how:

> *"Specialities should carry skills but these should be user based, giving people edges in the beginning and then eventually being able to share these specialities with others. But also, if say two people are economist ideator specialists, then they decide which skills they want to use and which are relevant to them. It does not become super blanketed."*

Asked whether an adopted speciality's skills should arrive switched on or off:

> *"They should be off, and you should walk through what comes with each, people need to learn the system and understand things instead of preventing learning."*

Two rulings, and the second is the sharper one. It is not a safe default chosen to avoid surprise — it is a **position about learning**. The moment of adoption is the moment a person is most willing to find out what a tool does, and handing them a working toolkit silently spends that moment. Being walked through each skill and choosing it is how the system gets understood.

## Decision

### 1. A speciality DECLARES candidate skills. It grants nothing.

This answers task 1003978's question (2), and the answer is the strong one: **naming a skill can never confer it.** Skills are materialised into a checkout by other machinery (`claude-materialize.js`), and permission is rank-gated server-side with no caching ([ADR 0016](<redacted>.md)). A speciality may say *"in this speciality, reach for `/recall` and `/status` first"*; it may not hand anyone a capability they did not already have.

The task warned that a column *"would imply an authority it must not have"*. It does not, given point 2 — because the declaration is a menu, and a menu is not an entitlement. What makes that safe is not the storage shape but the fact that enabling a skill still passes every existing gate, unchanged.

### 2. The adopter chooses, per person, and starts with nothing on

Two layers, because one layer is the blanket the owner ruled against:

| Layer | Holds | Why there |
|---|---|---|
| `specialities_catalog` | the skills this speciality OFFERS | the speciality is the thing being shared |
| `specialities_adoptions` | the skills THIS builder turned on | already per-builder, already the row an adoption creates |

Two people holding the same economist ideator speciality share its knowledge and its contract, and need not share a single enabled skill. That is the ruling, and the second table is where it becomes true rather than documented.

**Default: nothing enabled.** An adoption begins with an empty set.

### 3. Adoption is a walkthrough, not a toggle list

The consequence of the default that carries the actual intent. Adopting a speciality must **present each offered skill in turn — what it does, when its author reaches for it, what it costs** — and let the person enable it there, then. A settings page with eleven unchecked boxes satisfies the letter of "off by default" and defeats the ruling entirely.

The bar: **a person who has finished adopting a speciality can say what each skill in it does.** If the flow does not produce that, it is not built yet, whatever the schema says.

### 4. Sharing needs no new mechanism

Already shipped in `specialities_catalog`: `owner_kind` (`builder` | `project`), `visibility` (`private` → `project` → `public`), `offered`, `sellable`. The owner's *"edges in the beginning and then eventually being able to share"* is exactly that ladder, and it exists. Skills ride it for free: a speciality shared with its offered set intact is shared whole, and each new adopter still starts from nothing enabled and walks through.

## What this is NOT

- **Not a grant of authority.** Repeated because it is the invariant most likely to erode.
- **Not a way to declare a skill that does not exist.** A speciality may name only skills the instance actually has, or adoption offers a walkthrough of something that will 404 at the moment a person most needs it.
- **Not blanketed by craft.** A speciality's skills belong to the speciality, never to the craft above it.
- **Not authored by us.** [ADR 0296](0296-a-role-speciality-is-data-over-three-existing-surfaces.md): the deliverable is the mechanism, not a catalogue of specialities.

## Consequences

**The four documentation sites stop lying today, and do not start lying differently.** They currently claim a shipped ingredient. Until the build lands they must say *declared, decided, not yet built*, pointing here — the ADR, the migration header, `specialities.js`, and the module `CLAUDE.md`.

**A skill's own description becomes load-bearing.** The walkthrough is only as good as the text it shows, and skill descriptions were written to be *matched* by a model, not *read* by a newcomer. Whoever builds the walkthrough will find this.

**Adoption gets slower, on purpose.** That is the cost the ruling accepts.

## Build order

Deliberately separate tasks, because the middle one is where the ruling lives and it should not be a sub-bullet of a schema change:

1. **Schema + validation** — the offered set on the catalog, the enabled set on the adoption, `validateDraft`, the routes. Refuses a skill the instance does not have. *Built in task 1004072 (`skills` / `enabled_skills`, specialities_003, `modules/specialities/skills.js`).*
2. **The walkthrough** — the adoption flow that presents each skill and takes a decision. The ruling's real deliverable. *Built in task 1004073 (`GET /specialities/:id/skills`, `skills.explainSkill`, the hall settings panel). The consequence above came true: skill descriptions are model-facing, so a SKILL.md may now carry optional people-facing `plain:` / `reach-for:` / `cost:` lines, and the walkthrough says so when it had to derive the words instead.*
3. **Injection** — the enabled set reaches the session through the contract the Conductor already injects; a line naming the skills this builder leans on, per [ADR 0296](0296-a-role-speciality-is-data-over-three-existing-surfaces.md)'s pattern of using surfaces that exist. *Built in task 1004074: `describeForApi` appends one sentence naming the enabled skills — only those still offered and installed — after the provenance fence, since the list is the adopter's choice and not the author's prose. It says it is advice and not permission. Nothing enabled adds nothing. No new mechanism: the port, `GET /me` and the Conductor are unchanged in shape, and the Conductor's craft match scopes the line with the rest of the contract. Pinned end to end by `tests/speciality_session_skills.mjs`.*

Nothing is built by this ADR. It is the decision task 1003978 asked to be made first.
