# ADR 0304 — Routine reads run without a prompt; anything a flag can turn into a write is exact-form

**Status:** accepted · **Date:** 2026-09-17 · **Task:** [task 1003992](https://cloudbongos.com/builders#/task/1003992) (goal 1000095 — BONGOS-V2)

**Related:** [ADR 0104](0104-trust-gds-api-channel-in-auto-mode.md) (the allow-list this extends — it named read wrappers as the next step) · [ADR 0016](0016-trust-boundary-server-enforced-permissions.md) (an allow-rule grants no authority) · [ADR 0043](0043-git-ssh-trust-boundary-and-rank-floor-on-permission-paths.md) (git-guard is the cooperative layer) · [ADR 0302](0302-the-third-identical-failure-stops-the-session-and-asks.md) (same investigation)

## Context

The shipped `.claude/settings.json` pre-allowed six commands. Much of what a session runs to look
around — `gh pr view`, `git fetch origin`, `node scripts/gds/status.js` — stopped and asked the
builder for permission. The 2026-09-17 investigation of a non-technical builder's stalls found
this is a prompt they cannot evaluate: they are asked to approve a command they do not read, many
times an hour, and the only safe answer they have is "yes". A prompt that is always answered yes
protects nothing and teaches the builder to stop reading prompts.

## Decision

Pre-allow the **read-only subset**, in the core's `.claude/settings.json` and — rule for rule, in
verb form — in the starter an instance receives (`STARTER_ALLOW`, task 1003962):

- `git status` as a prefix rule.
- `git branch` and `git fetch` as **exact forms only** (`git branch --list`, `--show-current`,
  `-a`, `-vv`; `git fetch`, `git fetch origin`, `git fetch origin main`).
- `gh pr view | checks | list` and `gh run view | list` as prefix rules.
- The gds CLIs audited read-only under every flag they accept: `start`, `status`, `recall`, `me`,
  `doctor`, `preflight`, `skill-preflight`, `ship-check`, `fitness`, `strand-watch`,
  `stale-worktrees`, `read-session-export`. (`recall` POSTs, but to the search endpoint — a query.
  `ship-check` and `fitness` run the repo's own checks, the same trust as the already-allowed
  `ship.js`: a rule naming a script in the tree trusts the tree.) Audited and left out:
  `backlog-review.js`, whose default walk POSTs promote / abandon, and `key-status.js`, whose
  `--recheck` rewrites the local session file.

**The rule behind the split.** `Bash(x:*)` is a prefix rule: it allows every flag that can follow
`x`. So a command gets a prefix rule only when no flag turns it into a write or an exec.
`git fetch --upload-pack=<cmd>` runs a command, `git fetch origin x:main` moves a local branch, and
`git branch -D` deletes one — so those two subcommands are listed in the exact forms a session
actually uses, and anything else under them still asks.

**`git diff`, `git log` and `git show` get no rule at all.** The task asked for them, the first
cut had them as prefix rules, and review caught what that did — both reproduced on this repo:
`git log -1 --format=<text> --output=<path>` writes chosen content to any path (a
`.git/hooks/pre-push` is code execution), and `git diff --no-index -- /dev/null <path>` prints any
file, including the ones the `Read(...)` deny-list protects. Claude Code already runs the
read-only forms of these commands without a prompt in every permission mode, and checks their
flags when it does; an allow-rule is matched first and switches that check off. So for these three
the rule bought nothing and cost the flag check. By this ADR's own test they fail it.

**git-guard stays the backstop, and the lists are pinned.** A PreToolUse hook runs whether or not
a command is pre-allowed, so git-guard still blocks its four shapes. `tests/box_ship_permissions.mjs`
goes further: no allow-rule may *cover* a command git-guard blocks (blocked samples per guard rule;
a new guard rule fails the suite until it has one); no allow-rule may cover a write dressed as a
read (`--output`, `--no-index`, `--upload-pack`, a refspec); and the whole allow-list is pinned —
every rule is a named gds script or one of the thirteen git/gh strings in the test — so
widening it is a deliberate, reviewed edit.

## Consequences

- A session on a laptop or a box in auto mode reads PR and CI state, fetches, and runs the
  read-only gds CLIs without interrupting the builder. `bypassPermissions` boxes are unaffected
  (the rules are a no-op there).
- An allow-rule matches the command text, not the program: it is a convenience, never a security
  boundary. That is why the dangerous cases are handled by *not writing the rule* rather than by an
  `ask` or `deny` pattern for `--output` — Claude Code's own docs note such argument patterns are
  evaded by quoting (`--out''put`).
- Rules were `Bash` only at first — the evidence was a hosted Linux box. The `PowerShell(...)`
  twins landed in [task 1004014](https://cloudbongos.com/builders#/task/1004014), once
  [task 1003999](https://cloudbongos.com/builders#/task/1003999) had put that tool behind the same
  guards; allowing first and guarding second was the wrong order. See the amendment below.
- An instance that already has a `.claude/settings.json` keeps its own; only a fresh starter carries
  the new rules (the never-clobber rule of task 1003962).

## Amendment — 2026-09-17: every rule has a `PowerShell(...)` twin ([task 1004014](https://cloudbongos.com/builders#/task/1004014))

On a Windows laptop Claude Code's shell tool is `PowerShell`, and a `Bash(...)` rule says nothing
about a PowerShell command, so those sessions still met the prompt on every routine read.

**Decision.** One list of commands, carried by every shell tool the guards see
(`.claude/hooks/shell-tools.js`): 31 commands × `Bash`, `PowerShell`. The twins are the *same*
commands in the *same* forms — prefix where the Bash rule is a prefix, exact where it is exact,
and still no `git diff | log | show`. **The six blessed writers are twinned too.** ADR 0104's
argument is tool-independent (the server decides per request from live rank; the rule grants
nothing), and twinning only the reads would let a Windows session look around freely and then
dead-end on `ship.js` — the #1027 failure, moved to a different machine.

**What made it safe to mirror rather than re-derive.** Documented by Claude Code: PowerShell rules
have the same shape as Bash rules; `|`, `;`, `&&`, `||` split a command and *every* part must
match, so `gh pr view 1 | Set-Content <path>` and `git status; Remove-Item …` still ask.

Not documented — redirection, `$(…)`, `$env:` assignments — so the installed client (2.1.274) was
read instead: a string probe of the binary, down to its PowerShell permission function. In order,
it (1) applies deny rules; (2) collects a list of decisions, where each of these is an **ask**:
a `$(…)` subexpression, an expandable string, splatting, `--%`, a .NET member call, a script block,
a command that modifies `$env:`, a write into `.git/`, a `cd` compounded with `git`, and **any
real file redirection** ("could write to arbitrary paths" — in-tree or not, `$null` and `2>&1`
excepted); (3) returns the first deny, **else the first ask, and only then an allow**. Prefix
allow-rules are consulted after all of that, one pipeline element at a time, and a statement that
is not a command — an assignment — is never "allowed". So `$env:NODE_OPTIONS='…'; node
scripts/gds/status.js`, `git status $(…)` and `gh pr view 1 > scripts/gds/status.js` all still ask.

That is a reading of one version's minified code, not a contract — so **the repo does not lean on
it.** The grader's objection to the first cut was exact: nothing here enforced that ordering, and
nothing would turn red if a release changed it. `.claude/hooks/allow-rule-guard.js` now does, through
the one part of the contract that IS documented: a PreToolUse hook may answer
`permissionDecision: "ask"`, the most restrictive hook answer applies, and hooks "can tighten
restrictions but not loosen them". On the PowerShell tool, a command that names anything this
project pre-allows is put in front of a person **unless it is plain**: command names, bare-word
arguments from a fixed alphabet, `$name` reads, literal strings, the separators `; | && ||`, and
`2>&1` / `> $null`. It never blocks, fails open, and stays silent for commands nobody pre-allowed —
or every `>` on a Windows laptop would prompt and the prompts this task removed would be back.
`tests/allow_rule_guard.mjs` runs every PowerShell allow-rule through it, so a new rule cannot
outrun the guard.

**That hook is an allowlist of shape because the denylist version failed — this ADR's own lesson,
relearned.** Its first cut listed dangerous constructs (`$(`, `>`, `{`, `env:` …). A security
review of it found eleven commands that smuggle a write or an exec and still answered "no ask":
a bare `( … )` runs a pipeline in argument mode; a quote inside a `<# comment #>` blinds a quote
scanner; PowerShell reads smart quotes as quotes; `> $null\path` is a file, not a discard; a block
comment can split the command's name. Every one is a disagreement between a pattern and
PowerShell's tokenizer, which is exactly why this ADR refuses an `ask` pattern for `--output`
("evaded by quoting"). Recognising the safe case and asking for everything else has no such list
to keep up with: a `(`, `#`, backtick, `<`, real redirect, lone `&`, newline, smart quote or
assignment is simply not in the grammar. The eleven are kept as test cases.

Chained and piped commands pass the grammar on purpose — `git status; Remove-Item x` is "plain" —
because the split on `|`, `;`, `&&`, `||` with every part needing its own match is the DOCUMENTED
half, and the hook stands in only for the undocumented one.

Today the hook is redundant with the client, which is the point: it pins the behaviour instead of
trusting it. `allowCovers` in `tests/box_ship_permissions.mjs` still models only rule shape,
separators and case folding, and says so. NOT traced in the client: how `git.exe` is canonicalized
before matching — the hook folds case, quotes, backticks, comments, `\` and `.exe` itself, and is
deliberately loose there, since that step only decides whether it has an opinion at all.

**The restrictive list is twinned too.** `permissions.deny` carried `Bash(git stash:*)` alone — a
hard stop on a Linux box and nothing on a Windows laptop. It now has its PowerShell twin, and the
suite fails if any shell rule in `deny` or `ask` exists for one tool and not the other.

**The one PowerShell-specific trap.** Its rules match **case-insensitively**, and git's flags do
not: `-d` and `-D` are different commands. No rule here sits next to such a pair — `git branch`
appears only as four exact read forms — and `tests/box_ship_permissions.mjs` now runs every check
once per tool with the matcher's case folding modelled, plus a twin check: the tools must carry
identical lists, and a rule for a tool outside `shell-tools.js` fails the suite.

**Left alone.** A session that writes `node .\scripts\gds\status.js` (backslashes) matches no rule
and asks — fail-safe, and the skills all spell it with forward slashes.

## Rejected

- **`Bash(git:*)` or `Bash(gh:*)`.** One rule instead of thirteen, and it pre-allows `git push`,
  `git reset --hard`, `gh pr merge` and `gh api -X DELETE`.
- **Prefix rules for `git diff | log | show`, with `ask` rules for `--output` and `--no-index`.**
  Evaluated in the order deny → ask → allow, so it works on the text a session normally writes — and
  is evaded by quoting. The harness's built-in handling already covers the safe forms, so the pair
  of rules would add a leaky guard to remove a prompt that does not exist.
- **Prefix rules for `git fetch` / `git branch --list`.** `git branch --list -D x` is covered by the
  prefix and blocked by git-guard — harmless in practice (git refuses the combination) but it makes
  "nothing the guard blocks is allowed" false, and that sentence is worth keeping true.
- **`bypassPermissions` everywhere** (task 1251's box default). It is a mode, not a list: a builder
  who cycles modes or works from a laptop is back to prompts, and it removes the prompt for writes too.
