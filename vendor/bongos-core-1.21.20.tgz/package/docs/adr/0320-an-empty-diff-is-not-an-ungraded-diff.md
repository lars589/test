# ADR 0320 — An empty diff is not an ungraded diff: grade the claim instead

- **Status:** Accepted
- **Date:** 2026-09-20
- **Task:** 1004011 · goal 1000118 · scoped out of task 1003950 (shape 2)
- **Supersedes nothing.** Narrows [ADR 0041](0041-temporary-grader-bypass-killswitch.md)'s reach: the `--allow-empty` close is no longer one of the things `task.confirm.grade_bypass` gates.
- **Drops** task 1004010, the alternative shape (a new permission atom for the same close). Owner decision, 2026-09-20 — see §5.

## 1. Context

`scripts/gds/ship.js --allow-empty` is how a builder closes a task that produced no
committed artifact: the premise turned out to be false, the work was a pure
verification, the change landed directly in the database or on the host.

Until now that flag did two things at once. It set `skipGrade = true` — the subagent
grader never ran — and it therefore routed the close through
`POST /tasks/:id/confirm`, whose gate is `task.confirm.grade_bypass`, one of the four
trust-boundary keys [ADR 0157](0157-archon-is-rank-and-identity-only.md) names. In
practice a Metic could not close an artifact-free task at all without asking an Archon.

Task 1003950 shipped a terminating escalation on that refusal so the builder at least
stopped looping. It deliberately left the underlying shape alone and filed two
alternatives: give the close its own lower-floored permission atom (1004010), or remove
the need for a permission by grading something real (1004011, this one).

## 2. The two things that were wrong

**The permission was the wrong question.** `task.confirm.grade_bypass` means *ratify
this past a grade that FAILED*. That is a genuine trust-boundary act: a verdict exists
and a human is overriding it. An `--allow-empty` close is not that. No verdict exists,
because there was nothing for the grader to read. Charging the same key for "it was
judged and rejected" and "there was nothing to judge" conflates a override with an
absence, and the cost of the conflation was that the cheapest, least scrutinised ship
in the system needed the most powerful key to perform.

**Nothing was being checked.** This is the more serious half. On a no-artifact ship the
grader was skipped *entirely*, so the assertions in the handoff notes — "the premise was
already fixed", "this was a pure ops verification", "the row was updated directly" —
went into the ledger unexamined. The ledger is the complete record of what happened to
the project (CLAUDE.md §8), and on exactly the ships where the record is the *only*
evidence, nothing read it. A permission gate is not a substitute for scrutiny: an Archon
clicking confirm is not the same as someone checking whether the claim is true.

## 3. Decision

**On an `--allow-empty` ship, grade the NOTES (and the value summary) against the task
description, instead of skipping the grade.** The grader's question becomes: *is this
task genuinely artifact-free, and does the evidence given support that?* A pass is a
real passing grade that confirms through the ordinary rank-open path and needs no bypass
permission. A fail is a real fail, and the remedy is better evidence, not a key.

Four sub-decisions carry most of the weight:

**D1 — The rubric axes are re-asked, not replaced.** The gate downstream is
`functional_fidelity >= THRESHOLD AND code_quality >= THRESHOLD AND confidence >= 0.4`,
and `/grade-audit`, the aggregates and the cost model all read those columns. Inventing
a third pair of axis names would have meant teaching every one of them a synonym. So the
axes keep their names and the prompt re-asks them for this species:
`functional_fidelity` → *is this genuinely artifact-free?*; `code_quality` → *is the
evidence specific and checkable, or bare assertion?*. The gate arithmetic is untouched.

**D2 — Two generalist shots, not the four-lens panel.** The panel is Hacker / Quality /
Efficiency / (Reader) — lenses over code. Over three paragraphs of prose they are four
readings of the same short text at four times the cost, so the lenses go, recorded in
`signals.lenses_dropped` rather than left to be inferred from their absence (the
trivial-diff precedent, #513: lighter, never silent).

The panel's unanimous gate, however, was also the cross-check that makes injection
hard — an attacker must fool *every* gating worker. This decision's first implementation
kept a single shot and lost that property; the grader failed the ship on it, correctly
(see D4). So the species runs **two** independent readings of the same prompt, collapsed
by **unanimity, not median**: the worst score on each axis, and a pass only if every shot
passed. Under a median the collapse would be actively harmful — the median of two is
their mean, so a fooled 10 averages with a suspicious 3 into a passing 6.5 and the second
reading launders the first. A split verdict is recorded as `signals.shot_dissent`, since
two readings of the same fenced text disagreeing is itself worth a human's eye.

The collapse covers **all three gate axes, `confidence` included** — a point the second
round of grading caught, because the first fix collapsed only `functional_fidelity` and
`code_quality`. Confidence is easy to miss: it is the one gate axis that lives in
`signals` rather than `rubric_scores`. Leaving it at the median would have reintroduced
the same laundering on the axis where it matters most, since the server's
`validateAndScore` derives `lowConfidence` purely from the submitted value and never sees
the client's `unanimous` boolean — a shot honestly reporting 0.2 ("I cannot judge this
claim", the value that exists to fall through to a human) would average with a confident
0.9 and clear the 0.4 gate at 0.55.

**D4 — Every builder-controlled field is scrubbed and fenced (SR-15 / #995).** The panel
workers have wrapped the diff, title, description and value summary in
`grader-workers/fence.js` since #995, because a builder can embed steering text in their
own artifact. This species carries the same inputs and is the worse case on both sides of
the ledger: the notes are not context around an artifact the model can independently
check, they *are* the evidence; and a successful injection does not merely flip one of
four workers, it closes a task past the scrutiny this ADR introduced to replace the
Archon-only gate. So fencing here is not defence in depth, it is the boundary. The
no-follow rule is also restated *after* the artifact, because the notes may run to 24,000
characters and a rule stated once at the top is a long way behind by the end of an
adversarial payload.

**D3 — The species marker lives in `signals`, not in `grader_kind`.** The server's
`validateAndScore` hardcodes `task_grades.grader_kind` to `'subagent'` for everything
arriving through `POST /tasks/:id/grade`, so the column cannot carry the distinction
without teaching every consumer of that enum a new member. `signals.no_artifact_grade`
is submitted verbatim and stored, so it is the durable discriminator.
`signals.graded_subject = 'notes'` says what was read.

## 4. Consequences

- A Metic can now close a genuinely artifact-free task on the strength of a graded
  claim. `task.confirm.grade_bypass` keeps exactly the meaning ADR 0041 gave it and
  loses a use it never should have had.
- **A second grade species exists in `task_grades`.** Every consumer that averages,
  counts or spot-checks grades must split on `signals.no_artifact_grade` first: a score
  over prose and a score over a 400-line diff are not the same measurement.
  `/grade-audit` is updated with that rule in this change.
- **No-artifact closes get harder, not easier, for the dishonest.** The permission wall
  was indiscriminate — it stopped the honest Metic and waved through any Archon. The
  grade is discriminating: it reads the claim. "Confirmed working" with nothing a reader
  could re-run now fails an axis that previously did not exist.
- **The diff-hash reuse key is deliberately not set** for this species. Hashing the empty
  diff would let the *next* empty-diff ship of the same task reuse this grade — a
  different claim, different notes, silently inheriting a pass it never earned.
- **Below the protected-path floor, nothing changes.** The server's Guard 1b (task
  1002646) fails a passing grade closed when a below-floor builder submits no
  `committed_files`, and a no-artifact grade submits none by definition. That guard is
  correct and untouched: for a sub-floor builder the permission-path check is genuinely
  unprovable. This decision moves the Metic-and-above case, which is the case that was
  filed.
- `--skip-grade` is unchanged and still reaches the Archon gate. The escalation split
  task 1003950 added still decides which refusal prints there.

## 5. Alternatives considered

**Task 1004010 — a new permission atom for the no-artifact close.** The sibling shape,
and the one this drops. It would have added a lower-floored relative of a trust-boundary
key, plus a governance migration and a `system: true` decision of its own. Rejected on
two grounds: it answers "who may skip the check" when the better question is "why is
there no check", and it permanently widens the permission surface — the same class of
change the owner declined three days earlier for `version.create` (task 1003853,
[ADR 0250](0250-strict-versioning-the-version-boundary-is-the-scope-gate.md) §6a).
Solving the problem without a new atom is the consistent call. The row is closed, with
its problem statement kept should this fail to land.

**Keep skipping the grade, lower the floor on the existing key.** Cheapest, and wrong
for the same reason as 1004010: it treats the gate as the point. Nothing would read the
notes.

**Grade the notes with the full panel.** Rejected under D2 — four code lenses over prose
is cost without signal. Note what the rejection had to preserve separately: the panel's
value here was never its lenses, it was the unanimity of its gate, and D2 keeps that with
two shots rather than four lenses.

**A single generalist shot.** This decision's first implementation, and wrong for a
reason that only became visible once the prompt was written: it leaves one reading
between a crafted set of handoff notes and a closed task. Corrected before landing.

**A new pair of rubric axes for prose.** Rejected under D1 — honest about the
measurement, but it moves the gate arithmetic and every consumer of it, for a naming
gain.
