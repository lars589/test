# 0235 — A fix category is `kind='bug'` under a goal, not a new column

- **Status:** Accepted
- **Date:** 2026-09-03
- **Tasks:** [#1003215](https://cloudbongos.com/builders#/task/1003215) (this decision — the structural half
  of idea 1000828), [#1003214](https://cloudbongos.com/builders#/task/1003214) (the advisory's first quiet
  case), [#1003157](https://cloudbongos.com/builders#/task/1003157) (extended the same exemption to the
  criterion-link advisory and the goal detail view)
- **Goal:** [#1000071](https://cloudbongos.com/builders#/goal/1000071) — Idea routing
- **Related:** [ADR 0086](0086-goal-scoped-work-hierarchy.md) (the real work hierarchy this decision keeps
  intact), [ADR 0183](0183-criteria-close-themselves.md) (why a container that never finishes is dangerous
  now), [ADR 0192 "a category orients and authorises nothing"](0192-a-category-orients-and-authorises-nothing.md)
  (the precedent this decision is *not* — see §2)

## 1. The problem

A fix for something that should already work needs a home. Filing it with no
`goal_id` lands it in the version's catch-all — no scope wall, no owner reviewing
it (the `no_goal`/`catch_all` gap `goal-advisory.js` already flags for everything
else). Filing it under a real goal used to trip a second, unrelated nudge: every
goal-bound task with no done-when criterion link reads as unattributed work
(task 1003157). Neither nudge is wrong for a *feature* — but a bug fix is not
delivering toward one of a goal's stated outcomes; it is restoring one. Idea
1000828 named this a missing **first-class grouping**: "a fix for something that
should already work," living *under* an existing goal, without a new goal being
born for it.

## 2. Why this is not a stored category, and not [ADR 0192](0192-a-category-orients-and-authorises-nothing.md)

The obvious-looking answer — add a `category` (or `bucket`) column to `tasks` —
is the wrong shape for two reasons specific to *this* system's schema, not taste:

1. **`tasks` stores no category at all, by decision.** [ADR 0192 "a category
   orients and authorises nothing"](0192-a-category-orients-and-authorises-nothing.md)
   already answered a structurally identical question for *goals* — a human label
   from an owner-named set, advisory only, gating nothing — and its own text is
   explicit that "a task stores no category… it inherits its goal's through
   `tasks.goal_id`; a stored copy would be a second answer to one question." A
   `tasks.fix_category` boolean would be exactly that second answer: `kind='bug'`
   already exists, is already required (`migrations/006_pms_v2.sql`,
   `NOT NULL DEFAULT 'unclassified'`), and already means "this is a fix." Adding
   a column to restate it is duplication, not a new fact.
2. **This decision is a *narrower*, more binding one than [ADR 0192](0192-a-category-orients-and-authorises-nothing.md)'s.**
   Its category is purely a label a human reads — nothing may branch on it.
   "A bug fix needs no criterion link" and "a bug fix in the catch-all is quiet"
   are the OPPOSITE: two decision surfaces (`goal-advisory.js`) DO branch on
   `kind='bug'`, on purpose, because the alternative — nagging every bug fix to
   either name a criterion it doesn't serve or justify a goal it doesn't need —
   is the noise idea 1000828 asked to remove. So this ADR does not extend ADR
   0192's "orients, never authorises" rule to `kind`; `kind` already carries real
   weight elsewhere in this codebase (`task-classifier.js`'s heuristic
   classifier decides it from title/description, and `<redacted>`
   calibrates a task's estimate by it), and this decision adds one more narrow,
   named case to that existing list rather than inventing a second category axis
   beside it.

## 3. Why not a global "Bugs" goal either

Idea 1000828's own reasoning is the load-bearing part, and it survives unchanged
here: a goal carries `scope_modules`, the [ADR 0086](0086-goal-scoped-work-hierarchy.md)
§3 scope wall — a bugs goal spanning every module makes that wall either
everything or nothing, which is not a wall. And a goal carries done-when criteria
and can be marked `achieved`; a bug container never finishes, so making it a goal
manufactures a goal that can never legitimately reach `achieved` — polluting the
exact signal [ADR 0183](0183-criteria-close-themselves.md)'s auto-satisfy now
depends on to cascade a goal to `achieved` the moment every linked task ships. A
category *under* an existing goal keeps that goal's wall, keeps the "things that
should work in THIS area" context, and never claims to be finishable on its own.

## 4. Decision

**A fix category is `kind='bug'` on a task that carries a real `goal_id` — no
schema change, no new column, no new goal type.** The goal is *finishable* as
before; the fix category is a lens over its existing `kind` field, exactly the
way [ADR 0192](0192-a-category-orients-and-authorises-nothing.md)'s goal category
is a lens over `goals.category_id`, just enforced more strictly because two real
gates read it.

**As-built** (task 1003214 first, task 1003157 completing it — both already
shipped on `main` before this ADR was written):

- `adviseGoal()` in [`modules/lifecycle/goal-advisory.js`](../../modules/lifecycle/goal-advisory.js)
  is the single place all three exemptions live, in one pure, DB-free function:
  a `kind='bug'` task is silent for `no_goal` (no goal at all — a fix needs no
  home to be filed correctly), `catch_all` (a fix sitting in the version's
  catch-all bucket is already where it belongs), and `no_criterion_link` (a real
  goal's criteria named, but a bug fix delivers no criterion and needs none). The
  function's own doc comment states the rule this ADR records: *"a fix is the
  goal's 'fix category', not a delivery against one of its stated outcomes."*
- `countTasksWithoutCriterionLink()` in
  [`modules/lifecycle/db-deps-criteria.js`](../../modules/lifecycle/db-deps-criteria.js),
  surfaced on `GET /goals/:id` and rendered on the hall's goal detail view
  (`modules/hall-ui/public/goals-render.js`), excludes `kind='bug'` from its
  count for the identical reason — an intentionally unlinked fix must not read as
  a standing defect on the goal's own page.
- **No hall/status change was needed for grouping.** Verified against the live
  code, not assumed: every task card in a goal's To-do list already renders its
  `kind` as a visible tag (`goals-render.js`, `task__tag`), and the goal detail
  view's Filters disclosure already offers a `Kind` lens with `bug` as a value
  (`goals-page.js`, `f-goal-kind`) — so "the hall groups bugs by kind" was
  already true before this task, via the *same* general-purpose kind facility
  every other kind uses. Building a bug-specific grouping widget beside it would
  be the second-hierarchy mistake [ADR 0192](0192-a-category-orients-and-authorises-nothing.md)
  §2 already named once for goal categories.

## 5. What was deliberately not built

- **No `tasks.category` / `tasks.fix_category` column, no enum, no CHECK
  constraint.** `kind` already answers the question.
- **No global "Bugs" goal**, and no goal-creation shortcut that manufactures one
  — §3 above is why that door stays shut.
- **No bug-specific grouping UI.** The kind tag + Kind filter already exist and
  already work for `bug` the same as every other kind; a second, bug-only lens
  beside a general one would duplicate it for no reader benefit.

## 6. Consequences

- Idea 1000820 and idea 1000788 (the `node_modules/pino` worktree-resolution
  bugs cited as this decision's first real customers) now have somewhere to file
  that advances a goal without inventing one — the mechanism task 1003215 asked
  for was already load-bearing on `main` by the time this ADR was written; this
  document is what makes the decision citable rather than three commit messages.
- The exemption is enforced in exactly one function (`adviseGoal`) and one query
  (`countTasksWithoutCriterionLink`); a third surface that starts branching on
  `kind='bug'` for a similar reason should extend those, not invent a fourth
  definition of "what counts as a fix."
- If a future need ever wants `kind='bug'` to carry MORE weight than an advisory
  exemption — a claim-time gate, a reward multiplier, a dependency rule — that is
  a new, explicit decision needing its own ADR, the same posture
  [ADR 0192](0192-a-category-orients-and-authorises-nothing.md) §5 holds for goal
  categories. This ADR does not pre-authorise that.
