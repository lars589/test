# 0191 — Majority, and an author who may vote but never decide alone

- **Status:** Accepted
- **Date:** 2026-08-25
- **Tasks:** [#1003273](https://cloudbongos.com/builders#/task/1003273). Diagnosis and companion fix: [#1003271](https://cloudbongos.com/builders#/task/1003271) (the summons), [#1003269](https://cloudbongos.com/builders#/task/1003269) (the Government tab order).
- **Supersedes, in part:** [ADR 0175](0175-the-board-room-full-idea-ratification.md) — §3's pass-rule set (`first_ratifier | consent`) and §§7/11's flat anti-self-vote rule. Everything else in 0175 stands, including §8 (Discord is outbound-only, never a ballot), which this decision explicitly re-affirms.

## 1. The report, and why the obvious diagnosis was wrong

On 2026-08-25 the owner reported that "voting seems to be bugged … we have
multiple ideas that need full idea ratification in queue but the voting ability
does not seem to exist at present."

Nothing was broken. Nine items sat open, every one scoring 100 on completeness,
under `pass_rule: first_ratifier` and `membership: rank:archon`. Four archons were
active, so **any one of three non-authors could have ratified any item with a
single click.** Two independent facts made that invisible:

1. **Every open item was authored by the one person looking at them.** ADR 0175's
   anti-self rule refused an author's vote, and the hall honoured it by rendering
   *no ballot at all* — so the Board Room showed nine sittings and no way to vote
   on any of them. From the owner's seat the feature genuinely did not exist.
2. **Nobody else had been told.** The Discord announcer was the only summons, and
   it is best-effort by construction. That half is fixed separately in [#1003271](/builders#/task/1003271).

The lesson worth keeping: **a rule enforced by removing the control is
indistinguishable from a broken feature.** The anti-self rule was correct in
intent and invisible in operation.

## 2. The pass rule becomes `majority`, and majority means more than half of the MEMBERSHIP

The owner's decision: *"voting needs majority or whatever other type of conditions
for passing that a project actually lets into place. So for this project, it should
be majority."*

`majority` did not exist. `PASS_RULES` was `['first_ratifier', 'consent']`, and
neither is a majority:

| Rule | What decides | **What silence means** |
|---|---|---|
| `first_ratifier` | the first vote cast | an unvoted item **passes** |
| `consent` | a reasoned objection returns; anything else passes | an empty window **passes unopposed** |
| `majority` (new) | more than half of the resolved membership votes yes | an item that never reaches a majority **returns** |

The three are **not a ladder of strictness** — they differ on what silence means,
which is the axis that actually matters. That framing is now the comment in
`config.js`, because "which is stricter" is the wrong question to ask of them.

Two sub-decisions, both deliberate:

- **Of the MEMBERSHIP, not of the votes cast.** Two yes votes out of nine members
  is not a majority however unanimous the turnout was. Counting cast votes would
  let low turnout quietly pass things, which is the failure mode the owner's word
  "majority" is reaching for.
- **Strictly more than half, never `>=`.** On the live board of four that is three,
  not two. A tie is not a majority.

`majority` also closes early when the outcome is **already fixed** — carried, or
arithmetically unreachable given that v1 has no vote-changing. That is not
impatience; it is the same reasoning that makes `consent` close on full turnout.

## 3. An author may vote, and may never decide alone

Replacing ADR 0175 §§7/11's flat refusal. The owner's rule: *"authors can vote if
also a voting member"* — and an item *"needs at least one vote from a non-author to
pass."*

**The rule did not get weaker; it moved to where deciding actually happens.**
Refusing the cast was only ever a proxy for "an author must not decide their own
idea", and it was the proxy that produced the deadlock. Enforcement is now at the
two points where something is actually decided:

1. **Closing it** — `shouldCloseAfterVote` requires a vote that is not the
   author's, under *every* rule. Without this an author could still close their own
   item under `first_ratifier`.
2. **Carrying it** — the majority tally requires at least one **non-author yes**.
   A majority made only of the author cannot ratify, on any board, including a
   one-member one.

Three consequences we chose on purpose:

- **The author's yes still counts toward the numerator.** They sit on the board and
  it is a real vote; it simply can never be the whole of a majority. Author + two
  peers = three of four = carried.
- **An author cannot make their own idea worse.** Their `no` is excluded from the
  objection test. Otherwise the safest act available to an author would be silence
  — a strange incentive to build into a board.
- **A self-cast earns no karma.** The +1 rewards reading someone else's idea and
  taking a position on it. Paying it for a self-vote would make an author's own
  ballot a small income stream.

**The amendment carve-out survives, and is now the author rule's *scope* rather
than an exception to it.** ADR 0175 §7 blesses the monarchy act: on a one-Archon
board the proposer must be able to ratify their own amendment or the subject type
is dead on arrival. So the author rule applies to `full_idea` only — an amendment
pays nothing and has no author to wait for. In code that is one predicate
(`authorRuleApplies`), and for an amendment the deciding author is `null`, so the
trigger and tally behave exactly as they did before this change. A test asserts
both sides.

## 4. The clock is a consequence of majority, not an independent fix

[#1003271](/builders#/task/1003271) was originally scoped to add a sitting clock, because nine items with
`window_minutes: null` could never lapse. **Implementing that would have destroyed
the very ideas it was meant to unstick**, and the reason is one line — `tallyOutcome`:

```js
return (votes || []).some((v) => v.direction === 'no') ? 'returned' : 'passed';
```

**Zero votes passes.** Give those sittings a deadline while `first_ratifier` is in
force and the expiry sweep closes all nine as *ratified, unread* — paying author
ratification karma and the stream-3 idea credit on ideas nobody voted on.

So a clock is only safe under a rule where expiry means **return**, which is what
`majority` provides. The two ship together, and `BOARD_DEFAULTS.window_minutes`
stays `null` in the neutral core: a project that wants a clock wants `majority`
first, and the neutral default must not hand every instance an auto-ratifier.

## 5. What this costs, stated plainly

Under majority on a four-member board, **three affirmative votes are needed for
anything to pass.** That is a real bar, and on a quiet board the honest outcome of
an idea nobody engages with is now *returned* rather than silently ratified. That
is the point of the owner's choice — but it means a generous window and a working
summons ([#1003271](/builders#/task/1003271)) are load-bearing, not cosmetic. A majority board with no
summons would return everything.

**A solo instance still cannot ratify its own ideas.** One member who is also the
author has no non-author yes available, so their ideas return. This is inherent in
"never decide alone" and is the correct default for the portable core — an
instance that wants otherwise should widen its board, which is a config change and
not a code change. Worth revisiting only if a real single-owner instance finds it
obstructive; the shape of the fix would be a constitution that names the board
wider, not a bootstrap exception.

## 6. Discord is unchanged

Voting stays hall-only. ADR 0175 §8's argument is untouched by anything here: an
objection must carry a reason and name the section it faults, and a reaction cannot
express that. The owner re-affirmed this on 2026-08-25 when asked directly. [#1003271](/builders#/task/1003271)
improves the *notification* and leaves the ballot where it is.
