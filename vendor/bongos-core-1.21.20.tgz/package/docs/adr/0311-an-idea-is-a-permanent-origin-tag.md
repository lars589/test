# ADR 0311 — An idea is a permanent origin tag, and the payout follows its descent

**Status:** accepted · **Date:** 2026-09-19 · **Task:** [task 1004076](https://cloudbongos.com/builders#/task/1004076) (goal 1000095 — BONGOS-V2)

**Related:** [ADR 0262](0262-a-bug-never-lands-in-the-inbox.md) + the landing matrix it governs (`modules/ideas/routing.js`) · [ADR 0175](0175-the-board-room-full-idea-ratification.md) (the Board Room, unchanged by this) · [ADR 0054](0054-session-token-reward-cost-plus.md) (the credit the payout rides on) · [ADR 0015](0015-task-dependencies-and-auto-promotion.md) (why spikes do not auto-promote) · [ADR 0086](0086-goal-scoped-work-hierarchy.md) (goals, which a Full Idea may now become)

## Context

An idea, today, is a **container for work**. It sits in `idea_inbox` until it names a goal, and then it becomes a task and leaves the ideas world entirely. The better-aimed the thought, the faster it disappears from the person who had it — and the ideas page, which shows only what is left, is named after the leftovers.

This was reported as a small confusion and turned out to be structural. On 2026-09-19 the owner filed a thought from the hall, it routed into a goal as a task, the confirmation line was cleared by the next keystroke, and five minutes later they could not find it. The signal existed; its half-life was about four seconds. The routing decision that caused it was made by a `<select>` nobody notices.

Three facts found while mapping the live mechanism shaped everything below:

- **`karma_log` carries no task key and no idea key**, deliberately (`migrations/040_builder_karma.sql`). "The karma a thought caused" is not a quantity this system can compute.
- **Task parentage is capped at one level and refuses cross-version parents** (`modules/lifecycle/hierarchy.js`), by design — ship rollup and claim safety lean on it.
- **Nothing anywhere records that shipped work was later removed.** `shipped` is terminal, there is no reverted state, and `tasks.merged_into_task_id` is CHECK-constrained to abandoned rows, so it can only describe work cut before it landed.

## The decision

**An idea stops being a container and becomes a permanent origin tag** — never edited, never editing, and the only thing that can answer where a piece of work came from. It may become a task, a criterion or a goal depending on scope; the tag itself never changes.

**The tag survives every fork, and the payout follows it.** The ideator's credit split (`modules/economy/credits.js` `awardIdeaTaskShipCredit`) resolves only the earliest lineage link today, so a task split off later pays nobody. It is extended to follow the whole descent, **decaying with depth** — full share at the direct task, halving each hop, so an infinite descent is worth at most twice the direct task. This is what gives the tag teeth: if it does not survive a fork, *someone does not get paid*. Descendant **work** pays the origin; a separate idea that merely cites the origin does not, or early filers farm the project.

**Size and brightness are two independent channels.** Size is the sum of those payouts and **never falls**; brightness is how much of that work is **still alive**. A thought that caused a great deal of work the project later tore out renders **large and dead**. A single number would have made that indistinguishable from a thought that never mattered, which is the failure the split exists to prevent.

**Karma is rejected as the basis for size** — see Context. Credits are already idea-attributed at ship; karma is not, and is left as it is.

**The task hierarchy is not widened.** Provenance is a different relation from work decomposition and belongs with `ideas_task_lineage`, which is already many-ideas-to-one-task and carries none of the hierarchy's invariants.

**Removal is proposed by the system and confirmed by a person.** `modules/lifecycle/cascade.js` already implements ship-generates-work and declares an empty rule set; the first rule files a **question** when a ship deletes an earlier shipped task's work. A derived-only signal dims the sky for refactors, renames and file moves; a declared-only one rots because nobody remembers. An unanswered proposal rots on the existing clock; confirming sits at the nod's floor on the nod's existing surface.

**A ratified Full Idea becomes the structure, not another point inside it** — a goal, or a criterion inside one. The Full Idea carries a **recommendation** and the board decides which, because scope is the thing you learn last. The five questions are replaced with the owner's set and **versioned**, so ideas already filed keep scoring against the questions they were actually asked. The Board Room flow is unchanged.

**Two settings belong to the project, not the platform**, and share one home: who may ignite a thought directly into claimable work, and the decay rate.

**Existing ideas get their lineage backfilled, not their payouts.** Size for a pre-existing idea is computed from the descent it has, so the picture is meaningful on day one without spending credits twice — and because that number is then not a sum of payouts actually made, it must be **marked as historical** rather than quietly presented as one.

## Consequences

- **The hard part is now load-bearing rather than optional.** Before this, a lineage tag that died at the first fork produced a worse picture. After it, it produces a wrong ledger. That is deliberate: it puts the effort where the value is.
- **Ideator payouts become open-ended in principle**, bounded in practice by the decay. A project that dislikes the shape turns the dial rather than arguing with the platform.
- **The visible record will be dominated by large dead rings in a project that churns.** Accepted: failure is fine, and a record that only ever grows brighter is not a record.
- **Three tasks were dropped** as this direction invalidated them — a text-only ancestry trail ([task 1004054](https://cloudbongos.com/builders#/task/1004054)), a `held` inbox status ([task 1002832](https://cloudbongos.com/builders#/task/1002832)), and backfilled Full Idea answers on old goals ([task 1003678](https://cloudbongos.com/builders#/task/1003678)) — and one was amended ([task 1003852](https://cloudbongos.com/builders#/task/1003852)), whose title asserted the exact exclusivity this reverses.
- **Working area 6 now carries ten criteria.** A consequence of the owner's instruction to add here rather than open a new goal.

## Does not decide

- The **exact decay rate** beyond its default of halving — it is a per-instance dial, and what a given project should set it to is that project's call.
- **What precisely counts as removed** — the shape is propose-then-confirm; the derivation is [task 1004081](https://cloudbongos.com/builders#/task/1004081)'s spike to settle.
- **How provenance edges are physically recorded** — [task 1004080](https://cloudbongos.com/builders#/task/1004080)'s spike, constrained only by "not by widening the task hierarchy".
- **How any of this is drawn.** The agreed visual direction is `docs/design/ideator-surface-direction.md` and the mockups beside it; the criteria deliberately name the *model* — the states, the channels, the rules — and leave the picture free to change.
