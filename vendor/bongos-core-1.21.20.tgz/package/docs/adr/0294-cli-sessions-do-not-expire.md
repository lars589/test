# 0294 — CLI sessions do not expire; revocation is the whole remedy

- **Status:** Accepted
- **Date:** 2026-09-16
- **Deciders:** The owner, who asked for the CLI timeout removed entirely after a three-week gap signed him out, and accepted the stated security consequence.
- **Task:** task 1003956 (goal 1000110 — Working area 2: account creation, management & community)
- **Interacts with:** [ADR 0206](0206-own-scoped-session-revocation-no-absolute-ceiling.md) (the own-scoped revoke this leans on, and the ceiling it declined to build), [ADR 0016](0016-trust-boundary-server-enforced-permissions.md) (a session is resolved fresh per request, never cached), migrations `035_auth_token_hygiene.sql` (introduced the TTL) and `core_243_cli_sessions_never_expire.sql` (clears it).

## Context

A `bongos` sign-in died after 24 hours of not being used. `db-kernel.js createSession` defaulted a null `expiresAt` to `now() + SESSION_TTL_MS`, and `lookupSession` rewrote `expires_at = now() + 24h` on every authenticated request. An actively-used session therefore never lapsed; an idle one did, and the builder came back to `Your Bongos CLI session is no longer valid` blocking every `/builder-*` command until they re-authed through the browser.

This is the third time the number has been argued. V3.R38 (task #259, migration 035) set it to 1 hour. V3.R90 (task 1000400) widened it to 24 hours with the note that 1h "kicked builders out over lunch". Each round shortened the nuisance and left the mechanism alone. The owner hit it again on 2026-09-16 after a three-week gap and asked for the timeout gone rather than widened a fourth time.

The argument for keeping it was always auth-token hygiene (GDS-V3 criterion C9): the token sits in a plaintext file at mode 0600, so a leaked or abandoned copy should not live forever. **That argument does not survive contact with refresh-on-use.** A leaked token is, by definition, a token somebody is using — and every use rolled the expiry forward another 24 hours. The timer could only ever fire on a session that had gone quiet, which is the legitimate holder stepping away, not the thief. The control was aimed at attackers and landed exclusively on users. ADR 0206 had already written down half of this ("a CLI bearer sitting in the session file is, in practice, immortal"); what it did not do is draw the conclusion that a control which cannot reach its target is not worth its cost.

What genuinely bounds a leaked bearer arrived with ADR 0206 itself: `GET /me/sessions`, `POST /me/sessions/revoke`, `POST /me/sessions/revoke-all`, and the hall's "Sign out everywhere" — no rank required, no Archon to find. A person who knows their token leaked gets it dead in one request. That is strictly faster than any TTL, which at best kills it the following day.

## Decision

**CLI sessions carry no expiry. They last until revoked.**

1. `createSession` records `expires_at = NULL` when the caller names no expiry. `lookupSession` already treated NULL as never-expires, so this is a one-line default change rather than new machinery. Every call site that passes `null` is `source: 'cli'` — the CLI device flow, the federated CLI sign-in, the hall's token re-issue, and the dev-box pair.
2. `lookupSession` still bumps `last_used_at` on every request, but rolls `expires_at` forward **only for a row that already has one**:

   ```sql
   expires_at = CASE WHEN expires_at IS NULL THEN NULL
                     ELSE now() + ($2::int * INTERVAL '1 millisecond') END
   ```

   Without the `CASE`, the first request after sign-in would mint the very timeout this removes.
3. Migration `core_243` clears `expires_at` on live, unrevoked `source='cli'` rows, so the change reaches sessions that already exist instead of charging every builder one last forced re-auth on deploy day. This is migration 035's grace inverted, for the same reason 035 gave: do not sign out the people holding sessions when the policy moves.

**Browser sessions are untouched.** They pass an explicit 30-day `expiresAt`, so the new default never reaches them, and `core_243`'s `source = 'cli'` filter leaves their rows alone. `SESSION_TTL_MS` survives as the roll-forward window for rows that have an expiry — it is no longer a default.

### Rejected

- **Widen the TTL again (7 days, 30 days).** The fourth iteration of a mechanism whose first three failed for the same structural reason. Any window loose enough to stop annoying builders is far too loose to bound a leak, and refresh-on-use means it still never fires on the attacker.
- **Keep the TTL and make re-auth cheaper.** Already tried: ADR-era tasks 1000401 and 1000504 built the one-click hall re-issue and `/builder-reauth` precisely to soften this. The friction got smaller and the interruption stayed. Removing the interruption is what was asked for.
- **An absolute ceiling on `created_at`.** ADR 0206 rejected it and its reasoning holds unchanged: a cap signs out every dev box and long-running session on a timer, for a threat the revoke answers faster. Nothing here revives it.
- **Drop `expires_at` from the schema.** The column is load-bearing for web sessions and still honoured by `lookupSession`. Removing it would force browser expiry into some other mechanism for no gain.
- **A blanket `UPDATE builder_sessions SET expires_at = NULL`.** Would hand browser cookies an immortality nobody decided on — and irreversibly, since `lookupSession` only rolls an expiry it can already see, so a web row cleared by mistake stays cleared. The `source = 'cli'` filter is the safety property of that migration.

## Consequences

- A builder signs in once and stays signed in. Coming back after a weekend, a holiday, or three weeks costs nothing.
- **A leaked CLI token is valid until somebody revokes it.** This is the real cost and it was accepted explicitly. In practice it is a smaller change than it sounds: under refresh-on-use a leaked token in active use was already immortal, so what actually changes is the *abandoned* copy — one on a decommissioned laptop or an old dev box — which previously went stale on its own and now does not.
- The remedy is self-serve and immediate (ADR 0206). The compounding half of that decision now carries more weight: the session list shows `created_at` beside `last_used_at`, so a session nobody recognises is something a person can see and kill. That visibility was a nice-to-have beside a timer; it is now the primary control.
- Nothing about rank or deactivation changes. `setBuilderRank` still calls `revokeAllSessionsForBuilder` on every demotion, and `requireBuilder` still refuses a deactivated builder on the hot path regardless of a live token. Neither consults `expires_at` — the TTL was never load-bearing for C7.
- Criterion C9's idle-session hygiene claim is no longer met by a timer, and should be read as met by revocation plus visibility instead.

## When to revisit

- **Sessions start being issued to principals nobody will notice a leak on** — machine identities, CI runners, embedded devices. ADR 0206 flagged this and it is the strongest argument for a cap; such a principal wants a short, non-sliding expiry set explicitly at creation, which the `expiresAt` parameter already supports without changing this default.
- **A compliance or hosting requirement names a maximum session age.** Then it belongs on `created_at` as a true ceiling, per ADR 0206, with the grace treatment `core_243` and 035 both gave.
- **The session list shows long-dead sessions accumulating faster than people prune them.** That is the visibility half failing, and it is now the only half.
