# ADR 0338 — Modules travel through a Bongos-hosted store, and an acquired module keeps working forever

- **Status:** accepted
- **Date:** 2026-09-25
- **Task:** [task 1003782](https://cloudbongos.com/builders#/task/1003782) (goal 1000091 — working area 5, Module distribution & economy)
- **Deciders:** Will (owner of working area 5) chose the transport and the delist semantics; Claude researched the options and wrote the record.
- **Related:** [ADR 0264](0264-the-ten-working-areas.md) (area 5's state) · [ADR 0107](0107-module-upstreaming-contribution-to-core-catalog.md) §6 (modules ship inside core today) · [ADR 0135](0135-module-upstream-submission-interim-queue.md) (the interim submit queue) · [ADR 0138](0138-bundled-module-deps-declared-per-module.md) (module npm deps composed at init) · [ADR 0161](0161-publish-on-merge.md) / [ADR 0283](0283-the-core-publishes-publicly-because-access-was-never-the-thing-protecting-it.md) (how the core itself is distributed) · [ADR 0324](0324-the-public-npm-cli-channel-is-retired.md) (the owner retiring a public npm channel) · [ADR 0098](0098-public-mirror-publish-manifest.md) (`isPublishable()`)

## Context

A module has no way to travel on its own. `bongos module list` enumerates what is on disk,
`bongos module submit` pushes *into* core (ADR 0135), and nothing installs, fetches or
downloads one. A module reaches an instance only by shipping inside the core package
(`default:false`, ADR 0107 §6) or by living in the instance's own repo. A module also has no
version of its own — `module.json` carries only a `coreVersion` range (task 1003781 adds one).

Roughly a third of area 5 hangs off how a module travels: install (task 1003785), update
(task 1003786), upgrade reporting (task 1003787), the registry and entitlement tables
(tasks 1003812, 1003813), release channels (task 1003815) and delist (task 1003797). Whatever
is chosen has to leave room for four things the area's criteria already require:

1. an **entitlement check before install** — a paid module is not handed to someone who has not paid;
2. a **per-version quality score**;
3. a **tester channel** that sees a version before general release;
4. a **delist** that actually stops distribution.

Three transports were weighed:

| | npm packages | Bongos-hosted store | Git refs |
|---|---|---|---|
| Added monthly cost | $0 | ≈ $0 at first (existing control plane + the $5/mo DO Spaces bucket already paid for backups) | $0 |
| Entitlement before install | **No** — a public package is downloadable by anyone; a private one needs a paid npm seat per buyer | **Yes** — the server checks before it serves | Only by per-repo access management |
| Delist stops distribution | **No** — npm restricts unpublish, and published versions persist | **Yes** — the server stops serving | **No** — clones and forks persist |
| Tester channel | dist-tags, awkwardly | native | branches, awkwardly |
| Integrity | built in | reuse the core's `tree_sha256` manifest | weak |
| Upkeep | another public channel (ADR 0324 retired the last one on the owner's judgement) | we run upload/download | low |

npm and git refs both fail requirements 1 and 4 by construction, and those two are the
economy: a store that cannot withhold a paid module or stop distributing a removed one is not
a store. That is the point of this working area, and the owner said so directly.

## Decision

### D1 — The transport is a Bongos-hosted module store

Cloud Bongos hosts the store. An author publishes a packaged module version to it; an
instance acquires a module from it; people pay for modules through it (the money movement
itself is area 8's, per the area-5 criteria — this ADR decides the channel, not the payment).

The shape the implementing tasks build to:

- **Artifact.** A module version is a tarball plus a manifest in the same format
  `package-core.js` already produces for the core: per-file hashes and a
  compression-independent `tree_sha256`, built through the same `isPublishable()`
  default-deny gate (ADR 0098). No second packaging format.
- **Where it lives.** The registry rows (module, version, price, channel, score) are tables on
  the control-plane database (tasks 1003812, 1003814, 1003815). The tarballs live in object
  storage — the DO Spaces bucket the platform already pays for — or on the control plane's
  disk while volume is small. The store is served by the control plane.
- **Acquire = check, then serve.** Download is an authenticated request; the server checks the
  entitlement (task 1003813) and the channel the instance is on before it hands over the
  artifact. A free module still goes through the same path with a zero price, so free and paid
  are one code path (the owner's "assessed identically" rule applies to distribution too).
- **Verify on arrival.** `bongos module install` / `update` (tasks 1003785, 1003786) verify
  the tarball against its manifest hashes before placing it under the loader's discovery root,
  and record the exact version acquired.
- **Modules' own npm dependencies** keep travelling through npm as ADR 0138 already composes
  them. The store carries the module's own code, not its third-party libraries.

**Cost.** This adds no new fixed cost today. If download volume outgrows the Spaces tier's
included transfer, that is the point to revisit, with serving from the control plane's disk as
the cheaper fallback (CLAUDE.md §4).

### D2 — An acquired module keeps working, forever; removal only stops what comes next

When a module is **delisted** by Metic+ (task 1003797), **withdrawn by its author**, or its
store entry is otherwise deleted:

- it **leaves the catalog** and **cannot be newly acquired**;
- **no further versions or updates** are served for it;
- **every instance that already acquired it keeps it, and it keeps working** — the store never
  reaches into an instance to disable, remove or expire an acquired module, and an entitlement
  is never revoked by a delist;
- the instance is **told** — `bongos upgrade` / the module update check (task 1003787) and the
  hall's module view say plainly that this module will receive no more updates.

The artifact an instance acquired is already on that instance, so this costs the store nothing
to honour: it simply never deletes or disables what it has handed over.

The refund path in task 1003789 is the one place an entitlement can end, and it is a separate,
buyer-initiated act — a delist is not a refund.

## Consequences

- **Install, update and upgrade (1003785–1003787) are unblocked** against a concrete target:
  an authenticated control-plane download of a hash-manifested tarball.
- **Delist (1003797) is a catalog and serving change only.** It must not touch installed
  copies; a test should pin that a delisted module still loads on an instance that holds it.
- **Security issues are not a special case under D2.** The owner's rule is "always works; tell
  the user". A module with a vulnerability is delisted and the holder is warned; the store does
  not remotely disable it. If a remote kill switch is ever wanted, that needs a new ADR that
  supersedes D2 — it is not implied here.
- **The store becomes something we run.** Upload, download, storage and its availability are
  now platform responsibilities on the control plane. An outage blocks new installs and
  updates; it never affects an already-installed module, by D2.
- **ADR 0135's per-instance submission queue** remains the path for proposing a module
  *into core*. Publishing to the store is a different act (task scope for the publish command
  is not yet filed and should be, alongside 1003785).
- **No cryptographic signing yet.** Integrity is the manifest hashes, delivered over TLS from
  a server we control. Author signing can be added later without changing the transport.

## Rejected

- **npm packages** — public packages cannot withhold a paid module or be truly withdrawn, and
  the owner has already retired one public npm channel (ADR 0324) on the judgement of what the
  project wants to maintain.
- **Git refs** — cheapest to start, but no integrity story, no ranking hook, and a removal
  cannot stop copies already cloned.
- **Remote disable on delist** — rejected by the owner: getting a module means keeping it.
