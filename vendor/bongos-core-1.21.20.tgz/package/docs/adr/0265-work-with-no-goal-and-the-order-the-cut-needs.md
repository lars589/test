# 0265 — Work with no goal survives a version close, and the order the ten-area cut actually needs

- **Status:** Accepted
- **Date:** 2026-09-08
- **Tasks:** [#1003713](https://cloudbongos.com/builders#/task/1003713) (this record + the fix). Found while re-basing the cutover plan in [#1003711](https://cloudbongos.com/builders#/task/1003711).
- **Goal:** [#1000086](https://cloudbongos.com/builders#/goal/1000086) — Strict versioning, criteria `sv-every-task-has-a-goal` and `sv-cutover-proven-live`.
- **Builds on:** [ADR 0250](0250-strict-versioning-the-version-boundary-is-the-scope-gate.md) (D3, D4, D5), [ADR 0263](0263-how-a-version-closes.md) (§5–§8), [ADR 0264](0264-the-ten-working-areas.md) (the cut this order executes).

## 1. The defect

**A version can close while still holding unfinished work, because the closing
invariant counts goals and not tasks.**

`closeVersion` applies each goal's disposition and then asserts, against
committed in-transaction state, that no non-maintenance goal on the version is
still `open`. That is the whole check. Every task write inside the close is
scoped `WHERE goal_id = $1` — the abandon branch and the roll-forward move both.

So a task belonging to **no** goal is reached by nothing: no disposition touches
it, the goal re-count cannot see it, and the version flips to `shipped` with the
task still stamped with it. It is then permanently non-terminal on a version that
is over, and invisible to every surface that reasons per goal.

[ADR 0250](0250-strict-versioning-the-version-boundary-is-the-scope-gate.md) D3 shut this door one tier down — R10 and R14 made a *goal* refuse to
close while holding unfinished tasks. The version tier never got the same
treatment, and D4 ("every task has a goal") was written as a property of the data
rather than as a gate anything enforced at the boundary.

### It has already happened

Measured on the live instance 2026-09-08: **six non-terminal tasks sit on shipped
versions** — five on GDS-V3 under goal 1000002 and one on GDS-V4 under goal
1000004. Those versions shipped and took the work with them.

The next batch was already queued. **Forty-seven tasks on BONGOS-V1 carry
`goal_id IS NULL`** (measured in task 1003711): R11 made `goal_id` required going
forward but never backfilled the rows that predated it, because every catch-all
lookup matches the exact title `<VERSION> — general` and BONGOS-V1's catch-all is
titled "Work with no goal yet". Closing BONGOS-V1 would have stranded all 47 by
exactly this path, and R30's live proof would have found it *after* the close,
with no way back.

## 2. The decision

**A version refuses to close while any non-terminal task remains on it,** as a
second invariant beside the goal re-count, in the same transaction, against
committed state. It fails with `CLOSE_LEAVES_STRANDED_TASKS` carrying the count
and up to fifty ids, and the route renders that as a 409 naming them — the
caller's only move is to go and home those tasks, and making them run a query to
discover which ones is how forty-seven went unnoticed.

Two exemptions, both forced rather than chosen:

- **The maintenance goal's tasks.** `carryBugsForward` runs in the `onClosed`
  hook, which fires *after* this check and after the flip ([ADR 0263](0263-how-a-version-closes.md) §8), so
  maintenance work is legitimately still on the version at check time. Exempted
  through `maintenanceGoalExemptSql` — the **same** predicate the goal count
  uses, never a second copy. R18 replaced that function's body once already (a
  title comparison became `is_maintenance`, closing a spoofing hole); a
  hand-inlined copy here would have survived that edit and quietly re-opened it.
- **Smoke fixtures**, on the same `__smoke__` terms the abandon and roll-forward
  branches already use. Three doors now decide what "unfinished" means and they
  have to agree — a test fixture that wedges a production close is worse than the
  bug it was pinning.

The probe runs **after** the goal re-count and **before** the flip. Order is part
of the decision: open goals are the bigger and more actionable problem, and
reporting stray tasks first would send a caller chasing rows the goal
dispositions were about to move anyway.

## 3. The consequence: the cut needs roll-forward, *then* fold

Verifying the above surfaced two facts that together determine how
[ADR 0264](0264-the-ten-working-areas.md)'s thirty-eight-goals-to-ten cut can be executed at all:

1. **A task cannot cross a version boundary by hand.** `PATCH /tasks/:id { goal_id }`
   refuses with 409 `goal_version_mismatch` — "a task can only join a goal in its
   own version". The version → goal → task rollup is why: a cross-version link
   drops the task out of its version's totals.
2. **`roll_forward` creates, it does not merge.** It writes a *new* goal on the
   planning version with the predecessor's prose, membership and scope, archives
   the predecessor behind it with `succeeded_by_goal_id`, and moves the unfinished
   tasks' `goal_id` **and** `version_id` together (task 1003710). There is no
   disposition that folds a goal into an existing one.

So neither obvious order works. Closing BONGOS-V1 and rolling its goals forward
would mint roughly thirty-three successor goals on BONGOS-V2 — the same sprawl,
one version later. And homing the tasks into the ten area goals first is refused,
because the area goals live on BONGOS-V2 and the tasks live on BONGOS-V1.

**The order that works, with no new code and no Archon overrides:**

1. **Give every homeless task a goal on its own version.** The 47 null-goal rows
   and the two catch-alls' populations go to any real goal on the version they
   are already on — bugs to that version's maintenance goal ([ADR 0262](0262-a-bug-never-lands-in-the-inbox.md)), the rest
   to whichever existing goal fits. This is the step the new invariant makes
   mandatory rather than optional.
2. **Close the building version, rolling every goal that still holds work
   forward.** Tasks arrive on BONGOS-V2 carrying both `goal_id` and `version_id`.
3. **Fold on BONGOS-V2 while it is still `planning`.** Now each task and its
   destination area goal share a version, so `PATCH /tasks/:id { goal_id }` is
   legal; move the work into the ten areas and archive the emptied successors
   through R14's disposition flow.

Step 3 has to happen before BONGOS-V2 starts building, because D1 closes a
version's goal set the moment it does. That is not an awkward constraint — it is
the rule doing its job: the fold *is* scoping, and scoping belongs in `planning`.

## 4. Alternatives rejected

- **Add a `fold_into` disposition to the close.** It would collapse steps 2 and 3
  into one call, but it puts a scope decision — which area absorbs which goal —
  inside a transaction that also ships a version, and it invents a second way to
  move a task between goals beside the one that already exists. The two-step
  costs one extra pass over the data and keeps folding where a human can see it.
- **Create the six new area goals on BONGOS-V1 using R07's `admit_reason`
  override.** Legal, and it would let the whole fold happen before the close. But
  it spends ten Archon admissions to work around a rule those admissions exist to
  make expensive, and it grows the building version's goal set to forty-three on
  the way to shrinking it. ADR 0250 §3 built the override counter precisely so
  this shape would be visible; using it here would be reading the counter as a
  budget.
- **Backfill the 47 with a migration instead of gating the close.** A backfill
  fixes today's rows and nothing else; the gate is what stops the forty-eighth.
  Both are wanted, but only one of them is a rule.
