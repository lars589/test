# ADR 0358 — A hall wears a look, and its night takes a tint of it

- **Status:** accepted
- **Date:** 2026-09-30
- **Task:** [task 1004421](https://cloudbongos.com/builders#/task/1004421) (BV2.PS06, goal 1000121 — project startup; spec `docs/specs/<redacted>.md` D2 and D8)
- **Amends:** [ADR 0219](0219-a-look-is-a-branding-pack-the-style-library.md) Context §2 and the rejected "dark tier" alternative (a look could not carry a dark ground), and `DESIGN.md`'s "Pure black in dark" rule, for halls only
- **Keeps:** [ADR 0204](0204-the-apex-is-dark-only.md) (the platform's own apex is dark-only, pure black), [ADR 0062 §3](0062-medusa-instance-model-decoupling.md) (the branding contract; still thirteen colours and two faces)
- **Decided with:** the owner, 2026-09-30 — D2 in the planning session (the tint is allowed and on by default), and "a custom look is one accent used in both modes" the same day.

## Context

The project-startup flow lets a founder give a new project a look, so that a builder who works in several projects always knows which hall they are in. ADR 0219 already made a look a branding pack: thirteen colours and two font stacks, laid over the instance's pack. But it left two things out:

1. **Nothing let the platform set a hall's look.** A look was a file an instance owner copied into `config/branding.json` by hand.
2. **Every look's night was the same pure black.** The pack is one-mode, so in dark mode only the accent told one hall from another.

The second is a world rule (`DESIGN.md`: "Pure black in dark"). It exists because the chrome sculpture's rendered plates composite into `#000000` with `lighten` and leave no seam. The owner decided (D2) that a hall may give that up: each look gets a subtle tinted night, on by default, and the founder can switch it off.

## Decision

**D1. The night tint is derived, never authored.** When a hall wears a look with the tint on, its four dark grounds take a small share of the look's own accent:

| token | tinted night |
|---|---|
| `--bg`, `--bg-deep` | `color-mix(in srgb, var(--accent) 6%, #000000)` |
| `--bg-frame` | `color-mix(in srgb, var(--accent) 6%, #08080a)` |
| `--bg-card` | `color-mix(in srgb, var(--accent) 5%, #101012)` |

The card's share is the smaller because the hall's info chip (`--info` on `--info-weak`, both mixed from the card) was the thinnest pair under a tint, and at 8% it fell to 4.37:1; 5% clears every look. No look carries a dark palette and no token is added: the tint is a formula over the thirteen, so the contract stays at fifteen and a custom accent gets its own night for free. The table lives once, in `src/night-tint.js`; `themeMarkup()` emits it after the hall's sheet as the two dark twins the sheet already writes (`html[data-theme="dark"]` and the `prefers-color-scheme` block), at equal specificity, so it wins on order. The inks, the status vocabulary and every derived recipe stay the sheet's.

**D2. The tint is on by default, and only a look turns it on.** A hall that has never chosen a look renders exactly as it does today, pure black included, whatever the tint setting says. The founder's switch puts a looked hall back on pure black.

**D3. The apex and the hub stay pure black.** This decision is about a project's hall. The platform's own surfaces (ADR 0204) keep the world rule, and `DESIGN.md` says so where it states the rule.

**D4. A custom look is one accent, used in both modes, nudged until it reads.** The founder picks one colour. It is laid over the chrome world's palette as `accent`. If it fails any of the pairs the hall paints with it (dark ink on an accent fill; the accent as text on the black and tinted grounds; the light mode's derived accent ink on paper), its lightness moves, the hue staying put, to the nearest value that passes. The preview shows the adjusted colour. There is no separate dark accent and no sixteenth token. The nudge is one algorithm, `lookAdjustAccent`, in `modules/provisioning/look.js`; the create wizard carries a copy that a test pins to it.

**D5. The look travels the settings road.** `look` (the four library looks, `custom`, or `own` = the instance's own pack) and `night_tint` (`on` | `off`) join the provisioning settings vocabulary, so they reach a running hall the way every other policy does: written to `web.env`, applied by a restart (the pack is memoised). The adjusted accent and the logo's address ride as companion variables. `src/branding.js` resolves the look from the style library on the instance itself, so the platform never sends a palette, only a name.

**D6. A logo is an image the platform keeps.** PNG, JPEG or WebP only, at most 256 KB, checked by its magic bytes, never SVG (an SVG is a document that can carry script). The platform stores it and serves it at a content-addressed public address; the hall shows it in its mark and the browser tab uses it as the favicon. Without a logo, a looked hall's favicon is drawn in the look's own colours.

## Consequences

- A founder picks a look, a night and a logo at creation, and an existing project's owner picks the same three on its manage page (D8). Both save through the platform; the hall restarts once to wear it.
- Contrast is measured, not hoped for: `tests/look_night_tint.mjs` runs the hall's own token suite under every look with the tint on, and under custom accents across the hue wheel.
- A hall with a tinted night loses the seamless `lighten` composite for any rendered plate. The hall ships no plate today (`--plate: none`), so nothing shows a seam; a hall that adds one later must switch the tint off or re-shoot it.

## Alternatives considered

- **Each look authors its own dark palette** (the mocks' approach). Rejected: a dark tier in the pack is the contract change ADR 0219 refused, for every sheet and drift test, and a custom accent would have no night.
- **Two custom accents, light and dark** (the canvas). Superseded by the owner: one accent the platform makes readable is less to get wrong.
- **Refuse an unreadable custom accent.** Rejected by the task: adjust, do not refuse.
- **Send the full palette from the platform.** Rejected: thirteen colours and two quoted font stacks in an env file is fragile to quote, and the instance already ships the library.
