# 0289 — An unconsumed contribution is a CI failure, not a boot refusal

**Status:** accepted · 2026-09-16 · [task 1003819](https://cloudbongos.com/builders#/task/1003819) (successor to abandoned task 1002464)

## Context

A module declares what it contributes in `module.json`. Two checks read that block and neither asks the question that matters here:

- `src/module-seams.js` `verifyPortsSatisfied` checks the **opposite** direction — every `consumes` port has exactly one provider among the enabled modules. It says nothing about a `contributes` entry with no consumer.
- `src/module-loader/manifest-schema.js` `validateManifest` checks the **shape** of `contributes` — a closed key set, so a typo'd *key* errors. It does not look at whether the value resolves to anything.

So a module can declare `contributes.pollers: ["ghost"]` with no `modules/<key>/pollers/ghost.js` and boot stays silent. That silence is not a bug in the consumers: `startModulePollers` skips a missing poller file because a real poller may run on the control plane rather than in this process, `hallWidgetScripts` skips a `uiSections` entry with no `hall-widget.js` because a section can be declarative, and `moduleWebSurfaces` skips a surface whose directory was never shipped. Each skip is correct for a genuine declarative-only entry, and **indistinguishable from a typo or a rename that left the manifest behind**.

Verified on `main` 2026-09-16: 84 declared seam entries across 21 modules resolve to a real artifact, and five do not — `dev-box`'s `box-lifecycle` poller and `boxes` uiSection (both genuinely declarative), and three `ui-design` skills that live in the core `.claude/skills/` rather than the module tree, where `moduleSkillSources` silently skips them. Nothing was broken; nothing could tell you that.

## Decision

**A declared `contributes.<seam>` whose consumer's artifact is absent fails CI — `scripts/gds/seam-wiring-guard.js`, fitness Check 33 — and does not affect boot.**

The guard's `SEAM_CONSUMERS` table pairs each seam with **the function that actually reads it** and the artifact that function resolves, so the check asks the same question the consumer asks rather than inventing a second convention that could drift from it. A seam with no reader anywhere (`rooms`, allowed by the schema since the doorway but wired to nothing) carries `consumer: null`, and every declaration of it is reported.

**The exemption is per-entry and lives in the manifest**: `declarativeSeams: { "pollers": ["box-lifecycle"] }`. It is validated in `validateManifest`, against the module's own `contributes`, because that is the one place holding both — so an exemption naming a seam the module does not declare, or an entry it does not list, is an **error**. A typo'd exemption that validated clean would exempt nothing while reading as though it exempted something, which is the failure direction that hides a defect. The guard adds the mirror case: an exemption whose artifact **now exists** is reported as stale, so the list cannot quietly become a lie in either direction.

**The wired set is reported on the pass path**, not only the failure path — 84 wired, 5 declarative-only — because a check that is silent when it passes gives no evidence it ran.

## Consequences

- **The manifest stops being able to describe a feature that isn't there.** A rename that leaves `contributes` behind now reddens the build instead of silently shipping a module one feature short.
- **CI, not boot, and the asymmetry with `verifyEnabledPorts` is deliberate.** That check throws at boot because an unprovided port otherwise surfaces as a `resolve()` throw on a request path, in a process that already reported healthy — refusing early is strictly safer. For every seam but `routes`, an unconsumed contribution is not that shape: the consumer skips it gracefully, nothing crashes later, and the instance runs correctly minus one feature. Adding a production start-up failure for a manifest-hygiene defect would trade a real outage risk for a cosmetic one, and a red build costs nobody uptime.
- **`routes` is the exception, and it argues the same way.** `mountModuleRoutes` `require`s the factory with no try/catch, so a missing route file already takes the boot down today — pre-existing, and not changed here. For that seam the guard is not a new gate: it moves an existing crash from production start-up to the build. Strictly earlier, strictly cheaper. CI therefore covers both shapes — the seams that fail silently get a voice, and the one that fails loudly gets to fail before it reaches a server.
- **A new `contributes` key must be added to `SEAM_CONSUMERS` too**, or it is silently unchecked — the same gap in a new place. A test asserts the guard spans every key `ALLOWED_CONTRIBUTES` permits, so forgetting fails CI rather than going unnoticed.
- **`rooms` is now visibly dead.** The schema has allowed it since the doorway and nothing ever read it. No module declares it, so nothing fails today; the first one that does gets told.
- Rejected — **a boot-time refusal beside `verifyPortsSatisfied`**: see the asymmetry above. Rejected — **a blanket skip for the seams that legitimately allow declarative entries** (`pollers`, `uiSections`): that is how the gap arose, and it would hide the real cases the guard exists to catch. Rejected — **rebasing branch `task-1002464`**: 333 lines, 461 main commits behind its base, against a `loader.js` since rewritten. Its two test files were read for the property checklist; PR [#589](https://github.com/example-owner/cloud-bongos/pull/589) should be closed rather than revived.
