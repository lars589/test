# 0237 — A starter bundle is a preset over the always-on core, keyed by the declared project type

- **Status:** Accepted
- **Date:** 2026-09-03
- **Tasks:** [#1002338](https://cloudbongos.com/builders#/task/1002338) (this decision — BV1.R19)
- **Goal:** [#1000046](https://cloudbongos.com/builders#/goal/1000046) — Project creation: visibility and
  customization, criterion `proj-module-select` ("during setup a default set of modules is pre-selected…")
- **Related:** [ADR 0083](0083-modular-architecture-strangler-build-plan.md) (the one-way import rule that
  keeps this file pure), [ADR 0107](0107-module-upstreaming-contribution-to-core-catalog.md) +
  [ADR 0167](0167-module-catalog-source-vs-provenance.md) (the module catalog a bundle names into),
  [ADR 0182](0182-project-visibility-two-axes.md) D4 (the publish bar a bundle may not join),
  task [#1002772](https://cloudbongos.com/builders#/task/1002772) (the declared project type),
  task [#1002334](https://cloudbongos.com/builders#/task/1002334) (R15, the detail interview)

## 1. The problem

Criterion `proj-module-select` opens with "during setup a default set of modules is
pre-selected." Every Cloud Bongos instance already boots with the same always-on
core — the sixteen `default: true` modules a project cannot sensibly run without —
so "pre-selected" can only mean the **opt-in** modules layered on top. An owner
creating their first project has met none of them, and asking them to read a
twenty-one-row catalog before they have a repo is the version of customization
that gets skipped.

R19 is the data that answers it. R20 ([#1002339](https://cloudbongos.com/builders#/task/1002339))
renders the picker, R21 searches the catalog, R17/R22 recommend from the interview
answers, R23 adds modules later — four consumers, one table underneath.

## 2. Keyed by the DECLARED type, not by anything inferred

The task text (seeded 2026-07-17) names three bundles: *Game / SaaS-Tool /
Community*. That vocabulary was superseded four weeks later. Task
[#1002772](https://cloudbongos.com/builders#/task/1002772) settled the closed
project-type set by owner decision on 2026-08-13 — **`game` · `research` ·
`business` · `non-profit` · `not-sure`** — and it is the live one: a CHECK on
`platform_identity_projects.type`, a matching CHECK on
`provisioning_instances.type`, `PROJECT_TYPES` in both modules, and five buttons in
the create wizard. "Community" survives, but as a **team shape**
(`PROJECT_DETAIL_VOCAB.team_shape ∈ solo | small-team | community`), not a project
type. Bundles key off the shipped vocabulary; the seeded triple is recorded here as
history so the divergence is not read later as an omission.

Two constraints come with that key and neither is negotiable:

- **The arrow runs type → modules, never back.** Task 1002772 explicitly rejected
  deriving a project's type from its enabled module set, because flags flip all
  through setup and a half-configured project would show a confidently wrong type.
- **The interview does not ask a second time.** R15 wrote that into its own
  vocabulary comment: "the module bundle R19 recommends comes off the
  separately-declared `type`, so the interview deliberately does not ask it a
  second time." So R19 adds no key to `PROJECT_DETAIL_VOCAB` and no migration —
  the `detail` jsonb column stays reserved for answers an owner actually gave.

`not-sure` and *undeclared* resolve to the same modules (the core, nothing else)
and are deliberately **not** the same answer: `type` is nullable because every row
predates the field and must never be back-filled with a guess, so `bundleForProjectType(null)`
returns `type: null` with its own copy. A picker can tell "the owner said not sure"
from "nobody asked yet"; conflating them would be the same invention the nullable
column exists to prevent.

## 3. A declaration pinned by a test, not a read of the live catalog

The natural implementation is to resolve bundles against
`src/module-loader/catalog.js` — the one model the hall's Modules tab and
`bongos module list` both build from, so they cannot drift (ADR 0167). A module may
not import it: `src/module-api.js` is the only core file a module may require (ADR
0083's one-way rule) and the doorway exposes no catalog.

So `modules/provisioning/starter-bundles.js` **declares** its module keys and stays
pure — no I/O, no core import, no sibling import — exactly like `onboard-plan.js`
beside it. The link back to the catalog is a test, not a runtime read:
`tests/provisioning_starter_bundles.mjs` reads every `modules/*/module.json` off
disk and fails the build if a bundle names a module that does not exist, if
`ALWAYS_ON_CORE` drifts from the manifests' `default: true` set, if a bundle names
an always-on module (a preselect that toggles nothing but reads to the owner as a
choice), or if it names one of the two hub-only modules. A test is the right
enforcement point here because the failure is a *build-time* fact — the manifests
are in the same commit as the declaration — and buying it at runtime would cost the
purity that lets a script, a route and a test all read the same answer.

## 4. What the bundles are, and why they are short

| type | bundle (opt-in additions) |
|---|---|
| `game` | `dev-box`, `discord` |
| `research` | `agents` |
| `business` | `agents`, `dev-box` |
| `non-profit` | `discord` |
| `not-sure` | — |

Today's opt-in catalog is genuinely three modules wide (`agents`, `dev-box`,
`discord`; `platform-identity` and `provisioning` are the control plane's own and
are refused by construction). That is why this is a **declaration and not a rule
engine** — a bundle grows as the catalog does, and R17/R22 own the layer that
reasons. A preselect an owner has to audit is worse than none.

`dev-box` is preselected on two types despite costing money to *use*: enabling the
module opens the door, it provisions nothing and bills nothing until a builder asks
for a box, and the picker toggles it off in one click.

## 5. The read surface

`GET /provisioning/starter-bundles` returns `{ core, bundles }` — the always-on
floor once, then every type resolved as
`{ type, label, summary, core, bundle, modules }`. The whole table in one read,
because the picker re-preselects as the owner flips the type question and must not
refetch to do it, and because R17's recommendations and R20's preselect reading the
same shape is what stops them naming different modules.

`rank: public`, the same (absent) gate as `GET /provisioning/onboard-plan` — the
signed-out wizard reads it while choosing a type, it writes nothing, and the module
catalog it names into is already public at `GET /public/modules`.

## 6. Consequences

- **A bundle is never a publish precondition.** [ADR 0182](0182-project-visibility-two-axes.md)
  D4 fixes the bar at identity alone — a name and a description, "not tagline, art,
  modules, governance, or a completed interview." Taking or declining a bundle
  cannot move a project's dark-matter state.
- **Nothing is stored yet.** R19 defines and serves; where a chosen selection lands
  is R20's decision, and there is still no module-selection column on any table.
- **Adding a module to the catalog is now a two-file change** if it belongs in a
  bundle — the manifest and this declaration — and the integrity test says so out
  loud when a manifest flips its `default`.

## 7. Rejected

- **Resolving against the live catalog at runtime** — costs the purity and breaks
  the one-way rule for a fact that is fixed at build time.
- **A `bundle` key in `PROJECT_DETAIL_VOCAB`** — R15 already ruled the interview
  must not re-ask what `type` declares.
- **Inferring the bundle from the free-text description** — that is the deferred
  AI/semantic layer ([#1003500](https://cloudbongos.com/builders#/task/1003500)), and
  the goal's own text pins the near term as rule-based.
- **Naming the seeded Game / SaaS-Tool / Community triple** — three of those five
  live types would then have no bundle, and two of the three names match nothing an
  owner can pick.
