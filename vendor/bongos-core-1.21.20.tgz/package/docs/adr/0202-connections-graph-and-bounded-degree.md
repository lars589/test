# ADR 0202 — A connection is one directed row on the platform account, and every degree label is computed over the graph the viewer is allowed to see

- **Status:** accepted
- **Date:** 2026-08-28
- **Task:** [task 1002294](https://cloudbongos.com/builders#/task/1002294) (goal 1000045 — Public builder profiles, criterion C6)
- **Relates to:** ADR 0141 (identity federated, authority local — the cross-project data plane), ADR 0171 (the rollup join, fail-closed consent, `hide_stats` and the leak-by-subtraction ban), ADR 0182 (a predicate written once as JS and as a SQL fragment), ADR 0192 / ADR 0194 (fail closed to the narrower door; one reader, never re-derived), ADR 0083 (module-owned, namespaced migrations), `docs/specs/<redacted>.md` (D1 flags, D2 matrix, D4 invite lifecycle), `docs/specs/<redacted>.md` (page section 6 is reserved for this)

> ADR **0201** is reserved by a sibling session in flight at the time of writing; this ADR takes 0202 rather than race it. The gap is deliberate (the ADR 0199 precedent).

## Context

Criterion C6 asks for LinkedIn-shaped connections: request / accept / decline / remove, connections on the profile with 1st/2nd/3rd-degree labels, and "builders you may know" from platform-native signals. Four facts found while reading the tree shape every decision below.

1. **The data plane already exists and it is account-global, not per-instance.** `platform_identity_accounts` is the stable cross-project account (keyed on `github_id`); `<redacted>` and `platform_identity_builder_project_activity` hang off it. Core `builders` rows are per-instance and cannot express "these two people know each other across projects". So a connection is **account↔account on the hub**, and it belongs to `modules/platform-identity/`.
2. **An analogous lifecycle is already written.** `goal_membership_requests` (migration `core_188`) runs `pending → accepted | rejected | cancelled` with a **partial unique index on the pending row only**, resolved rows kept as the audit trail, and an atomic resolve-and-act statement so an accepted row can never exist without its membership. Its vocabulary and its shape carry over almost unchanged; where this ADR diverges it says so.
3. **Privacy here is not one flag but a matrix, and it is owner-signed.** `profile_state` (`provisional|active`), `account_visibility` (`public|private`, [task 1002966](https://cloudbongos.com/builders#/task/1002966)), `hide_stats`, and the nullable `recruiter_discoverable` whose effective value is `COALESCE(recruiter_discoverable, account_visibility = 'public')`. The two rules the matrix encodes — `hide_stats` beats everything, and public responses stay viewer-independent — are the ones a graph feature is most likely to break.
4. **ADR 0171 D4 already bans the exact bug a graph invites**: *"no partial numbers; a count plus a hidden total is a leak by subtraction."* A mutual-connection count, a connection count, and a degree label are all counts computed over a set that privacy filters — the three places that rule has to be applied by construction rather than by memory.

Nothing in this feature may confer authority. A connection grants no rank, no credits, no admission, and no access to any project (ADR 0016 / ADR 0141).

## Decision

### D1 — One directed row per relationship, made unordered by a generated pair key

**We store the request, not the edge — one row, directed, with the unordered pair generated from it as the uniqueness key.** `requester_github_id` and `addressee_github_id` are kept because the inbox, the cancel path and the decline rule all need to know who asked; `pair_lo` / `pair_hi` are `GENERATED ALWAYS … STORED` from `LEAST`/`GREATEST` of the two, and a **partial unique index on `(pair_lo, pair_hi)` over the open statuses** is what makes a duplicate *and* a simultaneous reciprocal request impossible in the database rather than in a route. Reads are symmetric: one helper unions both directions, and no caller writes a direction-aware `WHERE` of its own.

Migration sketch — `modules/platform-identity/migrations/<redacted>.sql`, additive and `platform_identity_`-namespaced (ADR 0083 §5), authored by [task 1002295](https://cloudbongos.com/builders#/task/1002295), not here:

```sql
CREATE TABLE IF NOT EXISTS platform_identity_connections (
  id                   bigserial PRIMARY KEY,
  requester_github_id  bigint NOT NULL,
  addressee_github_id  bigint NOT NULL,
  -- The unordered pair, derived — never written by a caller, so A→B and B→A
  -- collide on the index instead of both being accepted.
  pair_lo bigint GENERATED ALWAYS AS (LEAST(requester_github_id, addressee_github_id)) STORED,
  pair_hi bigint GENERATED ALWAYS AS (GREATEST(requester_github_id, addressee_github_id)) STORED,
  status  text NOT NULL DEFAULT 'pending'
            CHECK (status IN ('pending', 'accepted', 'rejected', 'cancelled', 'expired')),
  note        text,
  seen_at     timestamptz,
  created_at  timestamptz NOT NULL DEFAULT now(),
  resolved_at timestamptz,
  updated_at  timestamptz NOT NULL DEFAULT now(),
  CHECK (requester_github_id <> addressee_github_id)
);

-- At most ONE open relationship per pair. Resolved rows stay as the audit trail
-- and never block a later ask (the goal_membership_requests precedent).
CREATE UNIQUE INDEX IF NOT EXISTS uniq_platform_identity_connections_open
  ON platform_identity_connections (pair_lo, pair_hi)
  WHERE status IN ('pending', 'accepted');

-- The three reads: my inbox, my outbox, and the 1-hop neighbourhood both
-- traversal and suggestions expand from.
CREATE INDEX IF NOT EXISTS platform_identity_connections_addressee
  ON platform_identity_connections (addressee_github_id, status);
CREATE INDEX IF NOT EXISTS platform_identity_connections_requester
  ON platform_identity_connections (requester_github_id, status);
CREATE INDEX IF NOT EXISTS platform_identity_connections_pair_accepted
  ON platform_identity_connections (pair_lo, pair_hi) WHERE status = 'accepted';
```

**Rejected.** *Two mirrored rows written on accept* — the LinkedIn-on-paper model: it doubles every write, and the two halves can drift under a partial failure, which is the class of bug the goal-invite ADR fixed by making resolve-and-add one statement. *A pure symmetric edge with no requester* — cheap to read and impossible to build an inbox on: cancel, decline and the cooldown all need to know which side asked. *A core table beside `builders`* — connections are account-global; a core table would exist on every self-hosted instance with nothing to put in it and would breach the module boundary.

### D2 — Lifecycle: the goal-invite vocabulary, three deliberate divergences, remove is a delete

`pending → accepted` (the addressee accepts) `| rejected` (the addressee declines) `| cancelled` (the requester withdraws) `| expired`. The accept path resolves the row and returns the new connection in **one statement**, so an `accepted` row can never exist without being readable as a connection. Divergences from `goal_membership_requests`, each on purpose:

1. **A decline is silent.** The requester is never told. The row leaves their outbox as "no longer pending" and no notification is emitted. A goal invite's decline is inbox cleanup between two people who already build together; a connection decline is a social judgement, and telling someone they were refused turns a cheap ask into an event and manufactures a retaliation surface.
2. **A decline closes the door for 90 days, and re-asking inside that window is answered as if it worked.** `rejected` is load-bearing state, not just audit: a new request from the same requester inside `resolved_at + 90 days` is **swallowed** — nothing is written, and the endpoint returns the same body it returns for a request that was genuinely created. This is ADR 0194 D3's rule applied to a person instead of a project: the response must reveal nothing about the addressee's prior decision, and a 409 saying "declined" would disclose exactly the thing decision 1 keeps quiet. After 90 days the door reopens; people change. Decline is **not** a block and does not hide the requester anywhere (see Deferred).
3. **Expiry is 30 days, read-time, no sweeper** — the constant and the mechanism the privacy spec D4 already chose for recruit invites (`created_at + 30 days`, computed in every queue view). An expired request is absent from both inboxes. Because `now()` cannot live in an index predicate, the write path **resolves any expired row of the pair to `'expired'` in the same statement that inserts the new request** — so a stale `pending` row can never keep the partial unique index locked against a legitimate re-ask.

**Remove hard-deletes the row.** An accepted connection is consensual data about *two* people; when either withdraws, a tombstone saying "A removed B" is data neither consented to keep and that no read path uses. The partial unique index covers only `pending|accepted`, so the deleted row blocks nothing. The asymmetry with `rejected` — which is kept — is exactly that `rejected` still does work (the cooldown) and a removal row would not. `seen_at` is stamped on first inbox render, the D4 parity item, for a "delivered/seen" affordance later.

### D3 — Degree is bounded expansion from the viewer, capped, and it degrades rather than guesses

**A recursive CTE seeded at the viewer, hard-capped at depth 3 with a per-level fan-out cap and a deterministic frontier order.** There is no closure table and no cached graph. Two shapes cover every product question, and both are bounded *from the viewer*:

- **The label V→T** (profile section 6). 1st = one index hit on the accepted-pair index. 2nd = `EXISTS` on the intersection of two index-ranged neighbour sets — which yields the mutual list for free. 3rd = V's 1-hop materialised (cap `FANOUT_1 = 500`) expanded to a 2-hop frontier (cap `FANOUT_2 = 5000`), intersected with T's 1-hop.
- **The 2nd-degree frontier** (suggestions, D5) — the same expansion, one level, ranked, `LIMIT 20`.

**Past the caps, or past depth 3, the label is `null` — "out of network" — never a number the query did not actually establish.** The frontier is ordered by `github_id` so a truncation is reproducible rather than a different answer each call. `DEGREE_MAX = 3`, `FANOUT_1`, `FANOUT_2` are named constants exported beside the query, not literals inside it.

**Honest envelope.** Cost is `O(d)` for 1st, `O(d)` for 2nd (two index range scans and a hash intersect), and `O(min(d², FANOUT_2))` for 3rd. At the hub's present scale — order 10² active accounts — every one of these is a few index scans and single-digit milliseconds. The caps begin to bite around 10⁴ accounts with a heavy-tailed degree distribution, and they bite in the right direction: a hub-heavy account with 400 connections has a 3-hop neighbourhood in the millions, and the cap converts that from a slow query into a *missing* 3rd-degree label on a page that still renders. The revisit trigger is a measured p95, not a guess.

**Rejected.** *A materialised closure or adjacency table* `(a, b, degree)` — it is `O(N·d²)` rows, every accept and every remove invalidates an unbounded slice of it, and worse, it would have to be privacy-filtered *at write time*, freezing a visibility decision into stored data, which is precisely what ADR 0171 D2 forbids ("every surface reads through the module's filtered functions at render time, never from a stored copy"). *An in-process graph cache* — one Node process makes it tempting, and the no-store privacy model makes it wrong: a hide or a private-flip must beat the cache. *A graph database or a second store* — a whole new dependency and monthly cost for a workload that fits in three index scans (CLAUDE.md §4).

### D4 — One shared effective-visibility predicate; the count is the length of the list you may see

**Connections get no privacy predicate of their own.** They consume the single effective-visibility reader [task 1002967](https://cloudbongos.com/builders#/task/1002967) establishes, published in both forms the ADR 0182 precedent requires — a JS function and a SQL fragment (`accountVisibleSql(alias)`, beside `publishableSql`) — so a route and a query cannot drift. Adding a second, connections-flavoured predicate is the drift ADR 0194 D7 exists to prevent.

1. **`profile_state = 'active'` is the floor for the entire feature.** A provisional account cannot send, cannot receive, and never appears in a list, a frontier or a suggestion. Fail closed: an account row that cannot be read is treated as invisible, never as visible (ADR 0192 §6 / ADR 0194 §2).
2. **A private account is not addressable, so a stranger cannot send it a request** — the connect button does not render and `POST /connections` answers **404, not 403**; a 403 confirms the handle exists (the profile-page spec's rule). A private account may still *send* requests and hold real connections; those appear in its own-scope list and in the counterparty's own-scope list, and **never in any public connection list**, because rendering a private account inside someone else's public page is the 404 bypass wearing a different hat.
3. **`hide_stats` does not suppress the edge; it suppresses the numbers beside it.** A connection is not rollup-derived, so hiding stats does not hide that you know someone. Anything rendered *alongside* a connection row that comes from `platform_identity_builder_project_activity` — credits, ships, karma, the disciplines union, `last_active` — is suppressed exactly as everywhere else. Stating this here is the point: without it, [task 1002296](https://cloudbongos.com/builders#/task/1002296) has to guess.
4. **Degree is an own-scope read, never a public one.** `GET /profiles/:handle` carries no degree label; the page composes one from a second authenticated call about the caller. This is how a viewer-relative number coexists with ADR 0171 D4's viewer-independent public responses — the same page-shell composition the privacy spec D2 uses to render an owner their own private page from a public endpoint that 404s.

**The leak-by-subtraction rule, in one sentence: every count is the length of the array the viewer is allowed to see.** Never a raw count beside a filtered list. Three sites it binds:

- **Mutual connections.** "You and Ada have 4 mutuals" over a list of 3 names discloses the fourth by subtraction — ADR 0171 D4's ban, exactly. The count is computed over the filtered set or it is not shown.
- **The connection count on a profile.** Same rule; filtered accounts are not counted, and there is no "+N hidden".
- **The degree label.** If every path from V to T runs through a node V may not see, the label is `null`, not "3rd". A degree label is a property of *the viewer's visible subgraph*, not a global fact, and two viewers legitimately seeing different labels for the same target is the model working, not a bug.

### D5 — "Builders you may know": three native signals, one explainable score, and three refusals

Every suggestion carries the reason that produced it, because an unexplainable suggestion on a page about who you know is worse than none.

| Signal | Source | Weight |
|---|---|---|
| Mutual connections | the accepted-edge set, filtered per D4 | `3 × min(mutuals, 10)` |
| Shared projects | co-membership on the same `client_id` in `<redacted>` / `platform_identity_builder_project_activity` | `2 × shared_projects` |
| Recency | `max(last_active)` inside the last 30 days | `1` |

Ties break on `last_active`, then `github_id` so the list is stable. A hand-tuned linear sum, deliberately — the requirement is a sentence a human reads ("you both build on Foo"), not accuracy. **A named project appears in a reason only where its catalogue row is publicly listed**; otherwise the reason reads "a project you both build on" and the name is withheld — ADR 0171 D6's rule that the aggregate is not the leak, the name is.

**Three refusals, named rather than quietly skipped.**

- **Shared goals are not a signal.** `goal_members` is instance-local; the hub has no goal table and reading one would mean a per-instance fetch on a page render. Out.
- **Shared guilds are a slot, not a feature.** C7's guilds do not exist yet ([task 1002300](https://cloudbongos.com/builders#/task/1002300)). The scorer reserves the term and ships it at zero rather than pre-building a signal against a schema nobody has written.
- **Discord is refused outright.** Discord is a one-way mirror outside the trust boundary, and `platform_identity_accounts` stores no Discord identity. Using Discord co-membership would mean importing an identity link the account never gave the hub — the opposite of the fail-closed consent ADR 0171 D3 built. Likewise refused: the GitHub follower graph, email, and any address-book import. The suggester uses only what the account handed the platform by building here.

Suppressed suggestions are suppressed silently — no "N more" counter, which would be leak-by-subtraction with a friendlier label. Anyone the viewer already has a `pending`, `accepted`, or in-cooldown `rejected` row with is simply absent, which also keeps D2's silence intact.

## What this unblocks

| Task | Depends on |
|---|---|
| [task 1002295](https://cloudbongos.com/builders#/task/1002295) — Connections API: request / accept / decline / remove / list + degree queries | D1 (the migration + the uniqueness constraint), D2 (the five statuses, the atomic resolve-then-insert, the swallowed re-ask, read-time expiry), D3 (the capped CTE and its constants), D4 (`accountVisibleSql` on every read) |
| [task 1002296](https://cloudbongos.com/builders#/task/1002296) — Connections on the profile + connect button | D4 §2 (404 not 403, private accounts absent from public lists), §3 (the edge shows, the numbers do not), §4 (degree comes from a second authenticated call, not from `GET /profiles/:handle`), and the filtered-count rule |
| [task 1002297](https://cloudbongos.com/builders#/task/1002297) — "Builders you may know" | D5 entire — the three signals, the score, the reason string, and the three refusals |
| [task 1002298](https://cloudbongos.com/builders#/task/1002298) — PROOF: two builders connect; each sees the other + a 2nd-degree suggestion | D2 (the happy path), D3 (a real 2nd-degree label), D5 (a mutual-derived suggestion). The proof should also assert one negative: a private third party is absent from the public list *and* from the mutual count |

**What the guild and orb-physics wave gets** ([task 1002309](https://cloudbongos.com/builders#/task/1002309) – [task 1002313](https://cloudbongos.com/builders#/task/1002313)), and what it does not. Exposed: `neighbours(githubId)` (the visible 1-hop set), `degreeBetween(viewer, target)` → `1|2|3|null`, and `mutualCount(viewer, target)` over the visible set. **Not exposed: a connection strength scalar.** V1 has one edge type and it is unweighted. If R33 wants strength it must *derive* it from mutuals, shared projects and recency at read time — a stored strength column would need re-filtering per viewer and would be a cached privacy decision, the thing D3 rejected the closure table for.

## Consequences

- The hub gains one table, three indexes and one uniqueness constraint. A duplicate connection, a self-connection and a simultaneous reciprocal request all become database errors rather than route bugs.
- Every connection read joins the same effective-visibility predicate as every other public read on the hub, so a future privacy flag lands in one place and reaches this feature for free — and a new connections read that forgets the join is a visible omission in review rather than a silent leak.
- Degree labels are honest but not always complete: a viewer can see `null` where a global oracle would say "3rd", either because a bridge is private or because the fan-out cap truncated. This is a deliberate trade of completeness for both privacy and a bounded query, and the UI copy must say "out of network", never "not connected".
- A declined request is invisible to the person declined, including on re-ask. The cost is that a builder can send the same request twice a year and never learn why nothing happens; the benefit is that declining stays cheap enough that people actually do it instead of leaving requests pending forever.
- Nothing here is authority. No connection table is read by `requireRank`, `requirePermission`, or any admission gate, and accepting a connection changes no one's rank, credits, or access to any project.

## Deferred (named, not silently dropped)

- **A connections-specific visibility toggle** ("hide my connections list"). The three flags plus one consent state were owner-signed as a set; a fourth forks the D2 matrix and needs the owner, not a builder. `account_visibility` already answers the question for the whole page.
- **Blocking.** Decline closes a door for 90 days; it does not hide the requester from search, suggestions or the graph. A real block is a different feature with its own matrix row and should not be smuggled in as a decline side-effect.
- **What an accepted connection unlocks on a private account.** V1's rule is minimal and deliberate: an accepted connection grants exactly what a name in a list needs — handle, display name, avatar — and the private account's `/u/<handle>` still 404s. The wider rule (a connection unlocks the full profile) is defensible and is how LinkedIn behaves, but it is an owner decision about the privacy matrix, not a builder's.
- **Notifications.** Connection requests ride the existing attention-card inbox pattern (privacy spec D5, no parallel inbox); an SSE nudge and email stay deferred for the same reason they are deferred there.
