# ADR 0201 — An application is the project's own `access_requests` row, vouched for by a hub-signed assertion carried in a header; the record it carries is resolved live and never stored

- **Status:** accepted
- **Date:** 2026-08-28
- **Task:** [task 1002283](https://cloudbongos.com/builders#/task/1002283) (R07, goal 1000045 — public builder profiles; criteria C3/C4)
- **Relates to:** ADR 0141 (federated hub IdP — identity federated, authority local; §1 the signed assertion, §3 the join relay), ADR 0171 (the profile↔rollup join, `hide_stats`, `profile_state`, `no-store`), ADR 0194 (the joinability door the public POST answers first), ADR 0192 (a gated project's member door), ADR 0016 (the DB enforces), ADR 0116 (the error envelope), ADR 0157 (`access_request.review` is *identity* and stays archon), [`docs/specs/<redacted>.md`](../specs/<redacted>.md) D3/D4/D7 (spike 1002785), [`docs/specs/<redacted>.md`](../specs/<redacted>.md) D1/D2/D3 (spike 1002786)

## Context

C3 says a builder browsing the orbs page applies to a project **through the existing join path**, and C4 says the application **carries the applicant's cross-project record** so the receiving project sees a track record, not a name — with the owner able to approve or decline. The goal's own hard constraint (ADR 0016 / 0141) is that those numbers are descriptive analytics, never authority.

Every piece already exists, and none of them are joined up:

- **The relay** ([`modules/platform-identity/routes/my-projects.js`](../../modules/platform-identity/routes/my-projects.js)) — `POST /my-projects/join { origin, note }` resolves the origin against the hub's own `sso_clients` registry (the SSRF guard: never the caller's raw string), then makes a **plain, unauthenticated** `POST ${client.origin}/api/gds/access-requests` carrying `{ github_login, display_name, note }`. `joinRelayOutcome` translates the answer into one of five hub-authored sentences. The applicant's note already rides it (task 1002330); the privacy spec's claim that the note is hardcoded is stale.
- **The row** (`migrations/060_access_requests.sql`, untouched since) — `pending → invited | dismissed`, terminal rows kept as the audit trail, one open row per login (a partial unique index on `lower(github_login)`).
- **The gate** — `hasInvitedAccessRequest` in [`src/bongos/db-kernel.js`](../../src/bongos/db-kernel.js) reads `status='invited'` directly, and `firstTimeAdmissionBlocked` is the single decision all four sign-in paths call. `invited` is not a queue label; it *is* the admission verdict.
- **The record** — `getPublicProfileExtras(githubId)` returns `null` unless `profile_state='active' AND NOT hide_stats`, and `GET /profiles/:handle` already serves it publicly, CORS-enabled (`corsPublicGet`), `Cache-Control: no-store` (ADR 0171 D5), rate-limited per IP.

Two facts found in this spike shape everything below.

**The relayed request is indistinguishable from a stranger's.** The target's `POST /access-requests` is the one public unauthenticated write on the GDS, and the relay presents nothing the applicant could not have typed into the project's own landing page. Attaching a cross-project record to a `github_login` that nobody vouched for turns the queue into an impersonation surface: anyone can file a request naming a well-known builder, the owner reads that builder's excellent record beside it, approves — and the person who actually signs in is whoever holds *that* GitHub account. The record is exactly the thing that makes the unauthenticated write dangerous, so C4 cannot be built without closing it.

**`validateOrRespond` is strict by default** ([`src/bongos/routes/_helpers.js`](../../src/bongos/routes/_helpers.js)) — an unknown body field is rejected `validation_failed` 400. The public POST validates strictly (`modules/onboarding/routes/access-requests.js`). A 400 is not one of `joinRelayOutcome`'s five cases, so it returns `null` and the hub answers "the project could not be reached" (502). Adding a body field to the relay would therefore break applications to **every project pinned to a core older than the change** — which, since projects pin their own core, is most of them, indefinitely.

## Decision

### D1 — The application is an `access_requests` row on the target project. No cross-project applications table, on either side.

1. **Extend `access_requests`; do not add a table.** `status='invited'` is what `hasInvitedAccessRequest` reads, so a parallel record would need its own branch wired into `firstTimeAdmissionBlocked` — a second place where admission is decided, which is precisely the drift that decision exists as one function to prevent. It would also need its own queue, its own audit trail and its own reconciliation with the row the same person may already hold. The console wave (spike 1002786 D2) reached the same conclusion for invites; two waves inventing two tables for one door is the outcome to avoid.

2. **The migration adds exactly what a vouch needs: `applicant_github_id text` and `vouched_at timestamptz`, both nullable.** `text`, not `bigint`, because core `builders.github_id` is `text` (`migrations/003_pms.sql`) and the hub's numeric cast is the module's own concern (ADR 0171 D2 already handles non-numeric principals there). `applicant_github_id IS NOT NULL` **is** the vouch mark — no `source` enum, because a second column would let the two disagree. The console wave's `kind` / `created_by` columns (spike 1002786 R2) are a **separate** additive migration; the two waves must not both add `kind`, and either order works.

3. **Nothing about the application is stored on the hub except when it was filed.** A hub-held row saying a project has a pending application would be a hub-held admission fact — authority on the wrong side of the boundary, and stale the moment the owner acts. So the hub keeps an **echo** for one purpose only: so the applicant's own surfaces (My Projects, the orbs card) can say *"you applied on <date>"* without asking every project on every render. The echo carries `(github_id, client_id, applied_at)` and **never a status** — it is not allowed to claim what the project decided. An approval becomes visible the way membership always becomes visible: the check-in (ADR 0141 §3) creates the membership row and the card flips to *member*. The echo ages out of the applicant's view after **30 days**, the same read-time constant the privacy spec D4 chose, so a declined application does not read as "applied" forever.

4. **Re-applying is not an error.** The partial unique index already makes one open row per login the invariant; the endpoint answers `requested` for an application that is already open rather than a 409, so a double-clicked Apply button never tells the applicant they failed. A dismissal does **not** bar the door — resolved rows do not occupy the index, and a project that wants a permanent bar has `invite_only` (ADR 0194).

### D2 — The hub vouches for the applicant's identity in a **header**; the record itself is resolved **live**, in the reviewer's browser, and is never snapshotted.

1. **The relay carries a hub-signed, audience-scoped assertion in `<redacted>`.** It reuses `mintHubAssertion` ([`modules/platform-identity/hub-keys.js`](../../modules/platform-identity/hub-keys.js)) with a `purpose: 'application'` marker — the discriminator `mintHubLogoutToken` already established, so a captured device-login assertion cannot be replayed as an application vouch or the reverse. The target verifies it **offline** with the existing `verifyHubAssertion` ([`src/bongos/auth-idp.js`](../../src/bongos/auth-idp.js)) against the `<PREFIX>_HUB_PUBLIC_KEY` every federated instance is already provisioned with (ADR 0141 §4): signature, issuer, `aud === this instance's client_id`, unexpired. No new secret, no new key, no instance→hub call at apply time.

2. **A header, not a body field — and that is the whole compatibility story.** Per Context, a body field would 400 on every older pin and the hub would report the project unreachable. A header is invisible to the strict validator, so a project on any pin keeps taking applications unchanged, and a project that upgrades starts vouching with no coordination at all. (The CLI's `POST /auth/device/exchange` carries its assertion in the body; it could, because that route was new. This one is not.)

3. **An absent or invalid assertion writes the row anyway — unvouched.** It is never a refusal. Refusing would lock out applicants from an older hub, and would hand an attacker a way to make applications fail by sending garbage. Unvouched is simply the row the project has always had: a name and a note, with no record beside it.

4. **The record is never copied. The row stores an identity; the record is fetched at render.** C2 requires the hide to be honored *live everywhere, including pending applications* — the goal's own text says hiding after applying re-hides it on the owner's view. A stored snapshot is a copy the builder can no longer withdraw: honoring a later hide would mean a purge sweep across every instance that ever received one, and any instance missed is a permanent leak. Privacy spec D7 already decided "live at review time, never a stored snapshot"; this ADR ratifies it and adds the vouch (D2.1) that makes the live render *safe* rather than an impersonation surface.

5. **The fetch is made by the reviewer's browser against the hub's already-public `GET /profiles/:handle`, not by the instance's server.** It is CORS-enabled, `no-store`, and `getPublicProfileExtras` applies `profile_state='active' AND NOT hide_stats` inside the module — so C2 is honored by construction, at the instant of render, with no cache to outlive a toggle. Doing it server-side instead would extend ADR 0141's always-on hub dependency from sign-in onto the console's own request path, and would need the client-authenticated read plus timeout/retry/cache that ADR 0171 D1 rejected for exactly this reason and named as a deliberate separate task. It would also meter the per-IP read limit against the *instance* rather than each reviewer. A hub outage degrades to "the platform record isn't available right now" beside a queue that still works — the degrade-don't-500 rule.

6. **The vouch carries the `handle` as well as the `github_id`, and a handle-less account shows no record.** `GET /profiles/:handle` is addressed by handle; `github_id` is the stable join key but has no public read. The handle at apply time is stored on the row, and the previous-handle 301 window (ADR 0171 D8) covers a rename. An account with no handle yet, or a `provisional` one (404 by design, ADR 0171 D3), renders as an application with a note and no record — which is honest, not broken.

7. **A private account's application carries name, handle and note, and nothing else — in V1.** The D3 recruiter sliver is gated on `project.recruit`, an *instance* permission the hub cannot check from a cross-origin browser read, and inventing a fourth authorization plane to carry it is not this goal's job. The apply UI states exactly what the application shares (privacy spec D7's rule). The sliver half is already sequenced behind the recruiter port — task 1002972 depends on task 1002968 — and lands there, not here.

### D3 — "Project owner" is the project's own archon. There is no cross-project owner authority, and none is created.

1. **The registrant is whoever the instance seated as its first Archon** (`maybeSeatFirstAdmin`) — for a platform-provisioned project, the founder who filled the create wizard. **Delegates are whoever that Archon grants on that instance**, through the governance UI that already exists: promote to archon, lower a permission's floor, or a custom role. Because the instance *is* the project (ADR 0108; console spec D1), per-project scoping dissolves — the instance is the scope, so the governance grant needs no resource column and the per-project-scoped-permission problem never arises.

2. **The check is the atom that already guards this act: `access_request.review`, floor archon** (`modules/government/catalog.js`), which pins `GET /access-requests`, `PATCH /access-requests/:id` and `POST /access-requests/invite`. **This goal mints no new permission.** Widening the queue's *read* half to metics is the console wave's `project.recruit` (spike 1002786 R3); until it lands, the owner view ships on `access_request.review` alone and moves over when it does. Adding a third atom for the same door would be the drift.

3. **`platform_identity_projects.owner_github_id` stays advisory attribution and is never read as a gate** — its own comment says so, and `project-stats.js` already declines to read it, taking the project's own archon off its own leaderboard instead (ADR 0170). A hub-held owner list consulted before an admission would be the hub deciding who may admit on someone else's box: the exact inversion ADR 0141 exists to prevent. The hub's role here is unchanged from §3 — relay, echo, and a link to the project's own console.

4. **So the owner's pending-applications view is a page on the project's own instance**, and the hub links to it. It absorbs the Watch page's access-requests section on the same terms the console spec set (one queue, one home).

### D4 — The lifecycle keeps three states; approval is a door, not a membership.

1. **No new status values.** `invited` means approved — the door opens and **the acceptance act is signing in** (console spec D2), whose authoritative record is the `builders` row plus the membership check-in. An `accepted` state would be a second place membership is asserted, free to drift from the one that actually admits. `dismissed` means declined. Both are terminal and the row stays as the audit trail.

2. **Rescind is `invited → dismissed`, and the PATCH must learn to accept it.** Today it resolves only from `pending`. An approval given by mistake, before the applicant has ever signed in, must be revocable: `hasInvitedAccessRequest` stops matching and the door re-locks. After they have signed in the row is history and offboarding is the instance's own act (`/builder-exit`) — this route must never pretend to remove a member. The reverse correction (`dismissed → invited`) needs no new path: `POST /access-requests/invite` already resolves or inserts an `invited` row for any login.

3. **Approval expires read-time at 30 days, whatever created it.** The privacy spec D4 set that constant for recruit invites; an `invited` row produced by approving an application is the same open admission door, and one rule for `status='invited'` is the only version of this that cannot rot into two. An **application** carries no expiry — a stale `pending` row admits nobody, and the owner dismissing it is the whole mechanism.

4. **Approve and decline are idempotent on the value they already hold** (a PATCH to the current terminal state returns the row, not a 409), so a double-clicked button in the queue is safe. Every refusal names the state that blocked it and the action available there, in the ADR 0116 envelope.

## What this unblocks

| Task | Depends on |
|---|---|
| [task 1002284](https://cloudbongos.com/builders#/task/1002284) — R08, the application API (apply / list-pending / approve / decline) | D1 (the migration + the row), D4 (the statuses, the rescind gap, idempotency), D3.2 (the atom it pins) |
| [task 1002285](https://cloudbongos.com/builders#/task/1002285) — R09, the application carries the cross-project record (+ note) | D2 wholesale — the assertion, the header, the live browser read, the handle |
| [task 1002286](https://cloudbongos.com/builders#/task/1002286) — R10, "Apply" on the in-core browse surface | D1.3 (the echo is where *applied* comes from), D1.4 (a re-apply is not an error) |
| [task 1002287](https://cloudbongos.com/builders#/task/1002287) — R11, the owner pending-applications view | D3 (who may see it, and that the page lives on the project), D2.5 (the record is fetched from the page) |
| [task 1002288](https://cloudbongos.com/builders#/task/1002288) — R12, "Apply" on the orbs front door | D1.3, D1.4 — the same state and the same idempotency, from the separate static site |
| [task 1002289](https://cloudbongos.com/builders#/task/1002289) — R13, PROOF: apply → owner sees record → approves → applicant joins | all four; the proof must also pin the unvouched case (no record rendered) and a hide toggled between two renders |
| [task 1002972](https://cloudbongos.com/builders#/task/1002972) — applications carry the applicant profile: note through the relay, live render in the queue | D2.4 (live, never a snapshot) and D2.7 (the private-account sliver is its half, behind [task 1002968](https://cloudbongos.com/builders#/task/1002968)) |

Two things R08 should not rediscover: the relay's applicant note already exists (task 1002330), and `PATCH /access-requests/:id` resolving only from `pending` is a real gap D4.2 asks it to close.

## Consequences

- A project running any core pin keeps taking applications exactly as it does today; upgrading is what turns the vouch on. A vanilla or standalone instance holds no hub public key, verifies nothing, and degrades to the local queue it already has — which is the goal spec's stated degrade for non-federated instances.
- The queue gains a two-class row: vouched (a platform account, a record beside it) and unvouched (a name and a note). The owner must be able to see which is which — an unvouched row that *looked* vouched is the whole vulnerability, so the distinction is UI-load-bearing, not decoration.
- `GET /profiles/:handle` picks up a second class of caller. Its per-IP limit meters each reviewer separately (D2.5), and its `no-store` is now doing double duty: it is what makes a hide land on the owner's next queue render.
- The hub can say *when* someone applied and never *what came of it*. A card that wants to say "declined" is asking for a fact the hub is not allowed to hold; the honest reading is membership appearing, or not.
- The echo is the one new hub table this goal adds, and it is deliberately statusless so it can never be mistaken for the application.

## Rejected

- **A cross-project `applications` table on the hub.** It would hold an admission fact about someone else's project, need its own path into `firstTimeAdmissionBlocked` to mean anything, and be stale from the moment the owner acted. C3 asks for the existing join path precisely to avoid this.
- **A separate `project_applications` table on the instance**, beside `access_requests`. Two queues for one door, two audit trails, and the same person able to hold a row in each.
- **A profile snapshot stored on the application row.** Fails C2's live hide, and honoring a later hide would mean sweeping every instance that ever received a copy.
- **Adding the assertion to the relay body.** 400s on every older pin under strict validation, which `joinRelayOutcome` reads as unreachable — breaking applications to most projects, for good.
- **Refusing an application whose assertion is missing or invalid.** Locks out an older hub and hands an attacker a denial vector; unvouched is the row the project has always had.
- **An instance→hub server-side pull for the record.** Extends the always-on hub dependency onto the console's request path and needs the client-authenticated read with timeout/retry/cache that ADR 0171 D1 rejected and named as its own task.
- **Reading `owner_github_id` as an authorization.** The hub deciding who may admit on someone else's instance — the inversion ADR 0141 exists to prevent — and the column's own comment already says it is advisory.
- **A new "project owner" permission atom.** `access_request.review` already guards this exact act at the right floor; widening its read half is the console wave's `project.recruit`, and a third atom for one door is drift.
- **An `accepted` status.** Membership is asserted by the sign-in and the check-in; a second assertion is free to disagree with the one that admits.

## Deferred (named, not dropped)

- **The private-account sliver in the queue** — needs `project.recruit` gating the hub can see; task 1002972 behind task 1002968.
- **The console page absorbing the Watch section, and the `kind` / `created_by` columns** — spike 1002786's wave, whose migration must not collide with D1.2.
- **A hub-side aggregate of every project's queue** ("all my projects' applications in one view") — needs the push-model federation `project-stats.js` describes; the console spec already records it as the eventual shape.
- **Guild applications (C8)** — spike R23; a guild applying is a different applicant class and this ADR decides nothing for it.
