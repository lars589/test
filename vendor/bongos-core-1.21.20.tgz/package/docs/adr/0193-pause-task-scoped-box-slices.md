# 0193 — Pause task-scoped box slices: a box serves its rank scope (the full repo for Metic+)

- **Status:** Superseded by [ADR 0346](0346-dev-boxes-are-retired.md) — the dev box was removed (goal 1000120). Was: Accepted
- **Date:** 2026-08-25
- **Tasks:** [#1003285](https://cloudbongos.com/builders#/task/1003285) (the pause), from the owner's 2026-08-25 dev-box efficiency review; the review's other findings are [#1003286](https://cloudbongos.com/builders#/task/1003286)–[#1003291](https://cloudbongos.com/builders#/task/1003291) and shipped [#1003253](https://cloudbongos.com/builders#/task/1003253).
- **Pauses, does not repeal:** [ADR 0148](0148-task-scoped-box-source-access.md) / goal 1000051 — the claim-driven slice. The machinery stays; the default flips.

## 1. The decision

The owner reviewed the live dev-box experience and decided: **pause the serving
of a task-scoped slice and serve the entire repo instead.** A box now gets its
**rank scope** — the full repo for Metic+, the starter sparse surface below —
regardless of what the builder has claimed.

Implementation is a pause, not a deletion: `routes/box.js` skips the
lifecycle-port `scopeKeys` resolution unless `BOX_TASK_SCOPE=on` is set in the
web process env. With `scopeKeys` absent, `decideSourceAccess` takes its
documented pre-ADR-0148 rank fallback — a path that has existed, unit-tested,
since the feature shipped. `GET /box/scope` reports `task_scoping_paused` so the
hall and the desktop app can say why `task_scope` is false.

## 2. Why

The slice was defense-in-depth, never a hard wall — ADR 0031 §6 records the
honest limit: any read credential for the repo can read all of it, and
sparse-checkout is client-side. What the 2026-08-25 review found is that the
narrowing's *costs* were real while that benefit was notional:

- **Sessions on a box misdiagnose.** A Claude session that cannot see a module
  (or its nested CLAUDE.md) concludes the code is missing or itself stuck, and
  burns the session repairing context instead of doing the task.
- **The scope machinery multiplied the moving parts** that already failed in the
  field: the base-slice collapse (task 1002729, 247 of 248 grants), the empty
  `modules/` cone, and per-claim re-sync churn on every claim change.
- **Every live box user is Metic+ anyway** — the rank fallback grants them full;
  the slice was narrowing trusted builders while newcomers were already gated by
  rank.

## 3. What does NOT change

- **Allow/deny is untouched.** The live-rank + status check per request (ADR
  0016), the provision floor, and the clawback on demotion all stand.
- **The credential posture is untouched.** The box still holds no permanent
  credential; the per-request credential is read-only and `git push` still 403s
  (ADR 0055; re-verified on hardware 2026-08-25, task 1003253).
- **Sub-Metic boxes still get the starter surface.** The rank scope IS the
  boundary that carries the trust posture; it was never the claim slice.

## 4. Revert

Set `BOX_TASK_SCOPE=on` in the web env and restart — the ADR 0148 behavior
returns exactly as shipped. If the pause becomes permanent, delete the
lifecycle-port resolution in `routes/box.js` and retire this flag with a
follow-up ADR.

## 5. Known staleness while paused

The desktop app's task-picker copy ("your box is now scoped to `<modules>` —
and nothing else", BV1.R100) overstates while paused; it can read
`task_scoping_paused` from `GET /box/scope`. Cosmetic, not gating.
