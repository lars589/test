# 0206 — A leaked bearer's remedy is the account holder's own revoke, not an absolute session ceiling

- **Status:** Accepted
- **Date:** 2026-08-29
- **Deciders:** Claude, building the own-scoped half of the session self-service. The ceiling question is the one the task named as "worth a decision either way".
- **Task:** task 1003341 (goal 1000045 — public builder profiles + account security, criterion `i-control-my-own-access-and-exposure`)
- **Interacts with:** [ADR 0016](0016-trust-boundary-server-enforced-permissions.md) (the DB enforces; a session is checked fresh per request, never cached), [ADR 0053](0053-scoped-dev-box-session.md) / [ADR 0151](0151-governance-permissions-as-atom-ranks-as-roles.md) §3 (the session-scope registry — scope is capability on the token, orthogonal to rank), migration `035_auth_token_hygiene.sql` (the 24h TTL + refresh-on-use it introduced, and the deliberate backfill grace that came with it).

> **Amended by [ADR 0294](0294-cli-sessions-do-not-expire.md) (2026-09-16).** This ADR declined to add an absolute ceiling *on top of* the 24h sliding TTL, and that judgement stands unchanged. What changed afterwards is the sliding TTL itself: ADR 0294 removed it from CLI sessions entirely, on the same reasoning this file states below — refresh-on-use meant the timer only ever fired on the legitimate holder, never on a leak. So where the text below says an idle session expires after 24h, read: CLI sessions do not expire at all, and the own-scoped revoke shipped here is now the only bound on a leaked bearer rather than the faster of two.

## Context

`db-kernel.js lookupSession` rewrites `expires_at = now() + 24h` on every authenticated request. That is refresh-on-use, and for a session in daily use it means the TTL never arrives: a CLI bearer sitting in `~/.config/otb/gds-session.json` is, in practice, immortal. If it leaks — committed to a repo, left on a shared dev box, copied off a stolen laptop — the holder keeps it alive simply by using it.

Until this task the account holder had no remedy of their own. `POST /auth/logout` revokes only the token presented on that same request, which is useless when the token you want dead is the one you no longer hold. The two endpoints that can kill somebody else's session — `POST /auth/revoke` and `POST /auth/revoke-all` — are gated on the admin `auth.session.revoke` atom, so the victim had to find an Archon and ask. On a self-hosted single-owner instance there may be no second Archon at all, which makes the remedy not merely slow but absent.

Two different fixes were on the table, and it matters that they are not the same fix:

1. **Give the holder the remedy.** List your own live sessions, kill one, or sign out everywhere — no rank, no permission, no intermediary.
2. **Cap the sliding window.** Stop `expires_at` at some absolute distance from `created_at`, so every session dies eventually whether anybody notices or not.

## Decision

**Ship (1). Do not ship (2) — for now, and for stated reasons rather than by omission.**

The own-scoped routes land as `GET /me/sessions`, `POST /me/sessions/revoke` and `POST /me/sessions/revoke-all`, in their own file (`src/bongos/routes/my-sessions.js`), gated on `requireBuilder` alone. Every statement they issue carries `builder_id = <the caller's own id>`, taken from the session the caller presented and never from the query string, the body or the path. `revoke-all` deliberately includes the session making the request: this is the button somebody presses when they believe a token has leaked, and a sweep that spared one session would leave them wondering which. The token value is never selected, never logged and never returned.

**Why no absolute ceiling.** A ceiling and a revoke are aimed at different things, and only one of them was the gap:

- A ceiling is **unconditional**: it signs out every builder, every dev box, every long-running autonomous session on a timer, whether or not anything has gone wrong. Migration 035 already met this problem once, in the small — it backfilled a 24h grace *specifically* so the migration would not kill the session running it — and a ceiling reintroduces that class of breakage permanently rather than once.
- A ceiling is **slow where it matters**: any cap loose enough not to be a daily nuisance (30 days, 90 days) leaves a leaked token live for weeks. The victim who knows their token leaked does not want it to expire eventually; they want it dead now. That is exactly what (1) gives them, in one request.
- A ceiling has **no owner-visible upside** once (1) exists. Its remaining value is against a leak nobody ever notices — real, but strictly weaker than the visibility this task also ships: the list surfaces `created_at` beside `last_used_at`, so a session that has been alive for three months is now something a person can *see* and act on, which is the compounding half of the fix.
- Rank changes already do the sweeping a ceiling would do. `setBuilderRank` calls `revokeAllSessionsForBuilder` on any demotion, and `requireBuilder` denies a deactivated builder on the hot path regardless of a live token, so the authority-drift case a ceiling is often justified by is already closed by other means.

The ceiling stays deliberately unbuilt, not forgotten. What would change the answer is stated below.

### Rejected

- **An absolute `created_at + N` cap now.** Breaks every long-lived box and autonomous session on a timer for a threat the revoke answers faster; and any N large enough to be tolerable is too large to be a remedy.
- **A shorter TTL.** Same objection, worse: it punishes ordinary use continuously and still does nothing the moment a token is in someone else's hands.
- **Three more routes inside `routes/auth.js`.** That file is the largest in `src/bongos/routes/` and its admin pair legitimately reads a caller-named target from the request body. Keeping the own-scoped half separate is what lets `tests/own_session_revoke.mjs` assert the no-caller-named-owner rule over a whole file, with no carve-out for a neighbour to hide behind.
- **A `keep_current` flag on revoke-all.** Configurability nobody asked for: somebody who wants to keep one session revokes the others individually — the list marks which one is current.
- **404 on a session id that is not yours.** It would confirm which ids exist. A miss answers `revoked: 0`, identically to an id that never existed.
- **Lowering the `auth.session.revoke` floor instead.** That widens an admin atom to reach *other people's* sessions, which is the opposite of what a self-serve remedy needs.

## Consequences

- A builder at any rank — `xenos` included — can see and kill their own sessions without an Archon. The cross-builder admin pair is untouched and still permission-gated; this is an addition, not a replacement.
- A session in continuous use still never expires on its own. That is now a *visible* property (the list shows how old each session is) with a one-click remedy, rather than an invisible one with no remedy.
- The three routes are pinned to `any-builder` in `EXPECTED_RANKS`, so both a later rank gate *and* a later widening to public fail the route-rank auditor loudly.
- The hall's Settings page grows an "Active sessions" panel with a per-session revoke and a "Sign out everywhere" button. Signing out everywhere from the browser ends that browser session too, so the page sends the builder back to sign-in.

## When to revisit

Add the ceiling if any of these become true:

- Instances start issuing sessions to principals that cannot be asked to notice a leak (machine identities, embedded devices) — those want a cap, because nobody is watching the list.
- A compliance or hosting requirement names a maximum session age.
- The session list shows, in practice, that long-lived sessions accumulate faster than people prune them — i.e. the visibility half of this decision turns out not to work.

If it is added, it belongs on `created_at` (a true ceiling), not on the TTL, and it needs the same grace treatment migration 035 gave the 24h TTL, or it will sign out the session that deploys it.
