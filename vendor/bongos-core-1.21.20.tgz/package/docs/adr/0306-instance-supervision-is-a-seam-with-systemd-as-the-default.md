# ADR 0306 — Instance supervision is a seam, with systemd as the default

**Status:** accepted · **Date:** 2026-09-17 · **Task:** [task 1003997](https://cloudbongos.com/builders#/task/1003997) (goal 1000106 — BONGOS-V2)

**Related:** [ADR 0111](0111-instance-hosting-provisioning-module.md) (the standup runbook this seam sits inside, and the enqueue-only trust boundary) · [ADR 0128](0128-provisioning-runner-privilege-and-db-auth-model.md) (`PROVISION_SUDO` — the escalation knob this ADR leaves alone) · [ADR 0130](0130-provision-remote-exec-over-ssh.md) (the precedent for adding a dimension to the injected exec seam) · [ADR 0281](0281-an-instance-identity-is-its-own-unix-account-and-pg-role.md) (`User=`/`Group=` is how instance isolation is enforced) · [ADR 0285](0285-a-shared-box-holds-about-twelve-projects-per-gb-and-memory-is-the-wall.md) (every live project is `hosting_shape='standalone'`) · [ADR 0303](0303-provisioning-verifies-the-base-caddyfile-and-never-edits-it.md) (detect-and-refuse rather than auto-edit shared host config)

## Context

`provision-units.js` hardcoded `/etc/systemd/system` in three path functions, and the
runner reached for `systemctl` inline at fifteen call sites across `provision.js` and
`provision-teardown.js`. Supervision was not a choice anywhere — it was a string.

That is fine on the boxes we run today: every live project is `hosting_shape='standalone'`
on a systemd host (ADR 0285). It stops being fine the moment the plane is a container. The
self-host image runs `USER node`, installs no `sudo`, and boots no systemd, so the standup's
service step cannot run there at all.

**A directory knob does not fix this.** Pointing the unit path somewhere writable still
emits `systemctl daemon-reload` into a process namespace where systemd is not PID 1. The
thing that varies is not *where the unit file goes*; it is *what supervises the process*.

**systemd `--user` was considered and rejected.** It addresses an unprivileged VM — a user
session bus, `~/.config/systemd/user/` — but a plain container runs no systemd at all, user
bus included. It would have fixed a shape we do not have while leaving the one we do have
untouched.

## Decision

**Instance supervision is a seam with two implementations, and systemd is the default.**

A process manager answers four questions about an instance's long-running service: install
and enable it, restart it, remove it, and install its nightly backup schedule. Those four
operations move behind `scripts/gds/provision-process.js`; the call sites ask the resolved
manager rather than composing `systemctl` strings.

**Selection is explicit, then probed, then defaulted:**

1. `PROVISION_PROCESS_MANAGER` when set (an unknown value is a loud error, never a silent fallback);
2. otherwise systemd when `/run/systemd/system` exists — the same check `sd_booted(3)` makes, and the one systemd itself documents for "was this host booted under systemd";
3. otherwise supervisord.

**The live box is unchanged by construction.** It boots systemd, so the probe selects
systemd, and the systemd implementation emits byte-identical commands and unit paths to
what the inline strings emitted. The existing composition assertions in `tests/provision.mjs`
are the proof: they pin the exact strings and were not rewritten for this change.

**What the seam deliberately does NOT cover:**

- **Caddy reload.** `systemctl reload caddy` is shared-proxy config, governed by ADR 0303, and the container has no Caddy at all — that is [task 1004017](https://cloudbongos.com/builders#/task/1004017), not this seam.
- **The dedicated-droplet cloud-init path.** A DigitalOcean droplet always boots systemd; baking unit files into cloud-init stays systemd-specific on purpose.
- **Per-instance unix accounts.** `useradd` cannot run under `USER node`, so ADR 0281's isolation has no container equivalent yet — [task 1004018](https://cloudbongos.com/builders#/task/1004018).

## Consequences

- **Isolation must be restated per manager.** systemd enforces ADR 0281 with `User=`/`Group=`; supervisord's equivalent is its `user=` directive, and the supervisord implementation sets it from the same `instanceUser(inst)`. A future third manager has to answer this question explicitly or it silently drops the boundary that stops one instance reading a sibling's `/proc/<pid>/environ`.

- **supervisord has no timers, so the nightly backup is skipped there — loudly.** supervisord supervises processes, not schedules. Rather than re-implement cron badly, the supervisord implementation installs no backup schedule and logs the exact `crontab` line an operator can add instead. A container self-host therefore has no automatic DB backup until that is addressed; the skip is visible in the standup log, not silent.

- **The seam is two implementations wide, not N.** It exists because we have two real planes, not as speculative pluggability. A third manager is a new implementation in one file, but nothing is abstracted further in anticipation of one.

- **This alone does not make container standup work.** It removes one of four blockers. The self-host container still has no ingress (task 1004017), no per-instance identity (task 1004018), and a backup directory owned by a hardcoded `APP_USER = 'lars'` ([task 1002719](https://cloudbongos.com/builders#/task/1002719)). Task 1003997's done-when was narrowed to this seam accordingly, so the ledger does not record a self-host story that is not there yet.
