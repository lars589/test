# 0264 — The ten working areas: one goal per area, held until 5,000 builders

- **Status:** Accepted
- **Date:** 2026-09-07
- **Tasks:** [#1003696](https://cloudbongos.com/builders#/task/1003696) (this record). Executed by BV1.R25 ([#1003612](https://cloudbongos.com/builders#/task/1003612)), R26 ([#1003613](https://cloudbongos.com/builders#/task/1003613)), R27 ([#1003614](https://cloudbongos.com/builders#/task/1003614)), R28 ([#1003615](https://cloudbongos.com/builders#/task/1003615)) and R29 ([#1003617](https://cloudbongos.com/builders#/task/1003617)).
- **Goal:** [#1000086](https://cloudbongos.com/builders#/goal/1000086) — Strict versioning, criterion `sv-cutover-proven-live`.
- **Decided by:** the owner and the full team, in a manual goal review on 2026-09-07.
- **Builds on:** [ADR 0250](0250-strict-versioning-the-version-boundary-is-the-scope-gate.md) (the version boundary is the scope gate — this is the scope that boundary will hold), [ADR 0086](0086-goal-scoped-work-hierarchy.md) (the goal tier).
- **Amended by:** [ADR 0308](0308-an-eleventh-working-area.md) — an **eleventh** area (Autobongos, [goal 1000119](https://cloudbongos.com/builders#/goal/1000119)) was admitted on 2026-09-17. The table in §1 is ten of eleven; read 0308 beside it.

## 1. The decision

**The platform runs on exactly ten goals — one per working area — until it has
5,000 builders.** Each area has a named owner and a description of what "done"
looks like at that scale. Thirty-eight goals are open today; they collapse into
these ten.

| # | Working area | Owner | The 5,000-builder state |
|---|---|---|---|
| 1 | **Project creation** | Rini | Any new user, developer or not, can create a project from an existing folder or code repository whatever it already contains. |
| 2 | **Account creation, management & community** | Rini | — |
| 3 | **Human project management** | Scott | A project-management system with scalable levels of hierarchy — not infinitely configurable. Users edit, scope and manage work without ever prompting Claude. |
| 4 | **Bongos Core distribution** (staging of updates) | Lars / Will | Core updates are offered in every project's UI, and via the update CLI or skill. Approved users decide whether to take an update. A changelog is visible inside the update. |
| 5 | **Module distribution & economy** | Will | Modules are bought with money or credits and update the same way. Bongos assesses and ranks module quality; willing users test before mass deployment; only the best modules are listed, on price and assessed quality. |
| 6 | **Governor / Builder / Artist / Ideator experience** (incl. agents) | Masterqua / Rini | Each role gets a tailored experience that cannot break into the others. Noise is limited at every human interface. Agents are designed to aid all these roles. |
| 7 | **Government** | Will / Masterqua | Fully customizable creation of ranks and what each entails for project access. Recommended base ranks and governments ship for different project types and sizes. |
| 8 | **Platform credit economy** | Scott | Real money reaches users for completed work, without fail. Users hold platform balances, fund projects and pay each other with no fees. Bongos banks project funds and delivers them on cash-out. |
| 9 | **Platform analytics** | Lars | Bongos gathers as much user data as it can to improve itself — session transcripts as an efficiency signal, plus every user action and work delivery across the ecosystem through the Bongos API. |
| 10 | **Security** | all except Nils and Scott | Ranks are enforced. The Bongos server is not hackable by Claude's latest model. Red-teaming is consistent. |
| 11 | **Autobongos** | Lars | *Added 2026-09-17 by [ADR 0308](0308-an-eleventh-working-area.md).* A project owner points idle compute at goals they have allowlisted, and it builds unattended inside their subscription limits — stopping rather than guessing whenever a human is needed, and reporting what it did without being asked. |

## 2. Why ten, and why now

Thirty-eight open goals is not a plan; it is a list of everything anyone has ever
wanted. [ADR 0250](0250-strict-versioning-the-version-boundary-is-the-scope-gate.md) measured what that costs — 523 open tasks, fourteen goals
reporting done while holding thirty-five unfinished tasks — and built the
machinery to stop the drift. But **enforcement alone cannot shrink a scope that
is already too large**: D1 closes the goal set of a *building* version, which
freezes thirty-eight goals in place just as effectively as it would freeze ten.

So the rules and the cut are two halves of one move. This ADR is the cut. Ten is
chosen to be small enough that every area has a single owner who can hold its
whole shape in their head, and the horizon is **5,000 builders** rather than a
date, because the point at which this set stops being the right set is a scale
question, not a calendar one.

## 3. The disposition of all 38 open goals

Nothing on this list is a guess. Every row below the horizontal rule was named in
the review; the three rows above it were not, and are marked as such.

### Not covered by the review — open questions

| Goal | Note |
|---|---|
| [#1000003](https://cloudbongos.com/builders#/goal/1000003) — Work with no goal yet | The per-version catch-all. Already R25's target: drained and archived there. No separate decision needed. |
| [#1000065](https://cloudbongos.com/builders#/goal/1000065) — Community surface | Reads as the community half of area 2 and is treated as such below, but the review did not say so. **Confirm before executing R25.** |
| [#1000088](https://cloudbongos.com/builders#/goal/1000088) — Repo cleanup: everything justifies itself | Genuinely unmentioned, and maps to no area. **Needs an owner decision: fold, keep as an eleventh, or close.** |

### Becomes an area, or folds into one

| Goal | Disposition | Area |
|---|---|---|
| [#1000046](https://cloudbongos.com/builders#/goal/1000046) — Project creation | **becomes the area** (active; Rini building, Lars on the npm package) | 1 |
| [#1000065](https://cloudbongos.com/builders#/goal/1000065) — Community surface | becomes the area *(assumed — see above)* | 2 |
| [#1000045](https://cloudbongos.com/builders#/goal/1000045) — Public builder profiles | fold — relevant, active | 2 |
| [#1000075](https://cloudbongos.com/builders#/goal/1000075) — Collaboration & the social hall | fold — Niels almost done; builder collaboration is refined under community | 2 |
| [#1000085](https://cloudbongos.com/builders#/goal/1000085) — The operable hall | fold | 3 |
| [#1000054](https://cloudbongos.com/builders#/goal/1000054) — Public distribution | fold — Rini and Lars, relevant | 4 |
| [#1000029](https://cloudbongos.com/builders#/goal/1000029) — Module upstreaming & catalog | fold — looped into the module goal | 5 |
| [#1000066](https://cloudbongos.com/builders#/goal/1000066) — Role-composed context | fold — this is the working-area goal | 6 |
| [#1000038](https://cloudbongos.com/builders#/goal/1000038) — Agent framework & registry | fold — stays, needs cleanup from Rini; dedicated agents for specific tasks | 6 |
| [#1000039](https://cloudbongos.com/builders#/goal/1000039) — Agent authoring & first roster | fold into the agents one | 6 |
| [#1000040](https://cloudbongos.com/builders#/goal/1000040) — Agent scheduling & spend limits | fold into the agents one | 6 |
| [#1000025](https://cloudbongos.com/builders#/goal/1000025) — Builder experience | review first, close out solid tasks, then fold | 6 |
| [#1000068](https://cloudbongos.com/builders#/goal/1000068) — Government, not governance | **becomes the area** — Lars blitzes it; bugs and a rename | 7 |
| [#1000057](https://cloudbongos.com/builders#/goal/1000057) — Rank blocker matrix | fold into government | 7 |
| [#1000078](https://cloudbongos.com/builders#/goal/1000078) — Project money out | merge into builder compensation | 8 |
| [#1000067](https://cloudbongos.com/builders#/goal/1000067) — Ideator compensation | merge into builder payout | 8 |
| [#1000084](https://cloudbongos.com/builders#/goal/1000084) — Execution integrity & tenant isolation | bring into the security goal | 10 |
| [#1000070](https://cloudbongos.com/builders#/goal/1000070) — Scan-before-install | fold — Rini does the bug task | 10 |

Areas **3** (human project management), **4** (core distribution), **5** (module
distribution & economy), **8** (credit economy), **9** (platform analytics) and
**10** (security) have no single existing goal to promote and are **created** by
R29, taking the folds listed against them.

### Finish, then close

| Goal | Disposition |
|---|---|
| [#1000086](https://cloudbongos.com/builders#/goal/1000086) — Strict versioning | *"EVERYONE DO THIS NOW."* Finish, then close — it is the enabling work for the cut itself. |
| [#1000073](https://cloudbongos.com/builders#/goal/1000073) — Finish the GDS→Bongos rename | Niels finishes; small. |
| [#1000082](https://cloudbongos.com/builders#/goal/1000082) — Status ledger in the world | Lars deletes the status page, then closes it out. |
| [#1000024](https://cloudbongos.com/builders#/goal/1000024) — Build-pipeline integrity | A pile of bugs — check relevance, then fold or close. |
| [#1000032](https://cloudbongos.com/builders#/goal/1000032) — Instance hosting + domains | Clean out, then close. |
| [#1000058](https://cloudbongos.com/builders#/goal/1000058) — Non-cloudbongos project lifecycle | All bugs — fold into another goal. |

### Deleted

Twelve goals are cut outright:

[#1000037](https://cloudbongos.com/builders#/goal/1000037) Pay-on-land incentive alignment ·
[#1000043](https://cloudbongos.com/builders#/goal/1000043) Platform security: safe multi-tenant hosting ·
[#1000044](https://cloudbongos.com/builders#/goal/1000044) Living project sky ·
[#1000047](https://cloudbongos.com/builders#/goal/1000047) Project pricing & hosting revenue ·
[#1000048](https://cloudbongos.com/builders#/goal/1000048) SEO & public discoverability ·
[#1000049](https://cloudbongos.com/builders#/goal/1000049) Orb Physics ·
[#1000050](https://cloudbongos.com/builders#/goal/1000050) Self-hosted project analytics ·
[#1000052](https://cloudbongos.com/builders#/goal/1000052) First-run onboarding ·
[#1000053](https://cloudbongos.com/builders#/goal/1000053) Sessions start knowing ·
[#1000063](https://cloudbongos.com/builders#/goal/1000063) The front door ·
[#1000064](https://cloudbongos.com/builders#/goal/1000064) The hall as the room ·
[#4](https://cloudbongos.com/builders#/goal/4) CB-V1 — general (the old general bucket).

**"Delete" means `archived`, not a row removal.** `goals.status` is
`open|achieved|archived` (migration 160) and nothing deletes a goal — archiving is
the disposition, and it is reversible via `POST /goals/:id/reopen`. Preserving the
rows is deliberate: shipped tasks under a cut goal keep their attribution and
credit history, which a delete would strand.

## 4. The consequence that reorders the goal: R14 is the keystone

**None of section 3 can be executed today, and the reason is a rule this goal
shipped four tasks ago.**

R10 ([task #1003597](https://cloudbongos.com/builders#/task/1003597)) made
`POST /goals/:id/archive` refuse a goal that still holds unfinished tasks, returning
the tasks and demanding a disposition. That was correct and is exactly ADR 0250 D3.
But **the vector that supplies a disposition is R14** ([task #1003601](https://cloudbongos.com/builders#/task/1003601)), which has not shipped. So right now the
archive door is closed and the key has not been cut.

Every one of the twelve deletes and every fold in section 3 goes through that
door. That makes R14 the **keystone of the entire cut**, not one feature among
thirteen, and it should be built before the rest of the version-close chain
rather than in rank order.

This is worth stating plainly because it looks like a bug and is not: the refusal
is the system working as designed, one task ahead of its own remedy.

## 5. What this does not decide

- **It does not renumber or re-rank the ten areas.** The order in §1 is the review's order, not a priority.
- **It does not set criteria for the six new goals.** R29 scopes them; an area without done-when criteria cannot close, and inventing criteria for someone else's area is how a goal acquires scope its owner never agreed to.
- **It does not move any task.** Rehoming is R25 (the catch-alls) and R26 (the closed goals holding open work).
- **It does not decide the three open questions in §3.** They are surfaced, not guessed.

## 6. What actually executed, 2026-09-08

The cut ran to completion in one pass under [#1003728](https://cloudbongos.com/builders#/task/1003728), in the order [ADR 0265](0265-work-with-no-goal-and-the-order-the-cut-needs.md) §3 requires. **BONGOS-V1 is `shipped`, BONGOS-V2 is `building`, and the board is eleven rows: the ten working areas plus the maintenance goal.** All six strict-versioning invariants hold; 532 non-terminal tasks are homed and none are orphaned.

**The close** dispositioned all 21 open non-maintenance goals — 20 `roll_forward`, and `abandon` for [#1000067](https://cloudbongos.com/builders#/goal/1000067) (Ideator compensation), which held no unfinished work. 391 tasks moved onto BONGOS-V2 with their goals; the maintenance queue's 50 carried into a fresh goal, [#1000118](https://cloudbongos.com/builders#/goal/1000118).

**The fold** then moved every successor's work into its area and archived it. Areas 1, 2 and 7 are the retitled successors of goals 1000046, 1000065 and 1000068; the other seven already existed.

### The four decisions §3 left open, as the owner settled them

| Question | Decision |
|---|---|
| Is [#1000065](https://cloudbongos.com/builders#/goal/1000065) (Community surface) area 2? *(§3 asked this be confirmed)* | **Yes.** Its successor is area 2, and 1000045 folds into it. |
| [#1000088](https://cloudbongos.com/builders#/goal/1000088) — Repo cleanup, mapped to no area | **Folds into area 6.** Repo hygiene is builder-facing. |
| [#1000024](https://cloudbongos.com/builders#/goal/1000024) — Build-pipeline integrity | **Folds into area 4.** §3 called it "a pile of bugs"; by execution time it held **zero** — its 45 bugs had already gone to the maintenance goal, leaving 61 infra/feature/decision tasks. The deploy and release pipeline is how a core update reaches an instance, which is area 4's subject. |
| [#1000082](https://cloudbongos.com/builders#/goal/1000082) — Status ledger | **Closed out**, its 2 tasks abandoned — the disposition §3 already recorded. |

Also folded, where §3 named no destination: [#1000032](https://cloudbongos.com/builders#/goal/1000032) (Instance hosting + domains, 34 tasks) and [#1000058](https://cloudbongos.com/builders#/goal/1000058) (Non-cloudbongos project lifecycle) into **area 1** — provisioning and addressing an instance is the back half of creating a project; and [#1000073](https://cloudbongos.com/builders#/goal/1000073) (the GDS→Bongos rename) into **area 6**.

### Two things §5 said this ADR would not decide, and still doesn't

- **Area 2 has no done-when criterion**, because §1's 5,000-builder column for it is a literal blank and §5 reserves an area's scope to its owner. Every other area's criterion is transcribed verbatim from that table. Filed as **blocker [#1000136](https://cloudbongos.com/builders#/blocker/1000136)** — until it is answered, area 2 can never achieve, and a version closes when its last non-maintenance goal does (R16).
- **Areas 3 and 8 have no owner assigned.** Both are Scott's in §1, but two candidate accounts exist (`scootermack`, `scottymccormack`) and picking wrong assigns a working area to the wrong person.

### One correction to the execution plan, for whoever closes BONGOS-V2

`roll_forward` **does not carry a goal's done-when criteria** — the successor `INSERT` in [db-versions.js](../../modules/lifecycle/db-versions.js) copies prose, scope, membership and category, and nothing in the close path touches `done_when_criteria`. The pre-execution plan predicted this would drive invariant C4 to 7/27. **It did not**, because the same transaction promotes the planning version to `building` and C4 only measures a planning version — so the criterion-less successors were never counted. The substance still matters even though the invariant stayed green: a successor arrives unable to achieve, and only the fold (which archives it) or a hand-written criterion resolves that.

## 7. The names in §1, mapped to accounts — 2026-09-08

§1 names owners as people; the database knows accounts, and until now nothing wrote
down which was which. Recorded under [#1003729](https://cloudbongos.com/builders#/task/1003729). The map is evidenced from goal
membership rather than inferred from spelling — a name that merely *looks* like a login
is not a match.

| §1 name | Account | How it was established |
|---|---|---|
| Rini | `jaxri` (1000095) | Sole **lead** of area 2, which §1 gives to Rini; also a member of area 1, Rini's other area. |
| Will | `willHermesLines` (1000027) | **Lead** of area 5; member of areas 4 and 10 — the three areas §1 names him in. |
| Masterqua | `IAMMASTERQUA` (1000025) | Member of areas 7 and 10, both of which name Masterqua. |
| Lars | `example-owner` (3) | The owner; lead on every area. |
| Scott | `scootermack` (1000094) | **Owner decision, 2026-09-08.** Two accounts existed — `scootermack` (archon, already a member of area 1) and `scottymccormack` (1000160, xenos, no membership anywhere). Now **lead of areas 3 and 8**, which §1 gives to Scott and which previously carried no membership for him. |
| Nils | — | **Unmapped.** No roster account matches. |
| Niels | — | **Unmapped.** §3 says "Niels finishes" the rename; those five tasks carry no assignee (tasks have no assignee field — only `shipped_by`, and they are unshipped). |

**§1 spells the name two ways** — "Nils" in area 10's owner line, "Niels" in §3's rename
note. Whether that is one person or two is not derivable from the data, and neither
spelling matches any of the fifteen roster accounts. Worth resolving before anything
relies on area 10's "all except Nils and Scott".

**An owner in prose is not an owner in the database.** §1's owner column, and the
`Owner:` line in each area's done-when criterion, are text — they grant nothing and are
read by no gate. The load-bearing record is `goal_members`, which is why areas 3 and 8
could read as owned while holding no membership for their owner at all.
