# ADR 0246 — Catalog membership is a projection of the provisioning row, not a side effect of federation

- **Status:** Accepted
- **Date:** 2026-09-04
- **Task:** [task 1003576](https://cloudbongos.com/builders#/task/1003576) (BONGOS-V1, goal 1000046 — *Project creation*, criterion `proj-detail-interview` / C3)
- **Deciders:** jaxri (Archon), Claude
- **Related:** [ADR 0182](0182-project-visibility-two-axes.md) (the two axes; D4 is the publish gate, D5 makes the hub column a cache) · [ADR 0238](0238-the-join-door-is-a-provisioning-settings-policy-key.md) (the join door is a provisioning setting; the hub's owner column is attribution, never authority) · [ADR 0141](<redacted>.md) §2/§4 (the SSO client registry and what a client secret is for) · [ADR 0083](0083-modular-architecture-strangler-build-plan.md) (the module one-way rule — why this travels on a port) · [ADR 0181](0181-teardown-state-gate-and-address-retention.md) §2 (an abandoned address left pointing at platform infra)

---

## Context

Criterion C3 promises that skipping the "tell us about your project" step "leaves the project dark-matter until identity is added, **then it publishes**." The BV1.R18 proof ([task 1002337](https://cloudbongos.com/builders#/task/1002337)) demonstrated the whole criterion against live and found the last clause does not happen. Its §3 evidence, on core 1.19.524:

- `PATCH /provisioning/instances/18/detail` with a description answered `publish: { publishable: true, missing: [] }`, settings `visibility: "public"`, instance `status: active`.
- `GET /projects/featured` answered `{ "projects": [] }`, and no route existed that could change that.

The two answers come from two different tables and nothing bridged them:

| Question | Read from |
|---|---|
| "am I on the map?" — the owner's verdict | `provisioning_instances` (slug + description), through the `project.publishGate` port |
| "who is on the map?" — the public feed | `platform_identity_projects` (`status = 'active' AND publishable`) |

The **only** automatic write from the first into the second was `federateInstance → registerClient → upsertProject` in `scripts/gds/provision-net.js`. It has two properties that together are the bug:

1. **`shouldFederate` refuses any instance whose `hosting_shape` is not `co-tenant`** — and the creation wizard hard-codes `standalone`. So every project the wizard makes was never catalogued at all.
2. **It runs ONCE, at provision time,** off `inst.description`, and `upsertProject` COALESCEs `description`. So a project that answered *later* re-federated never, and the catalog kept its NULL.

The same missing row is [task 1003580](https://cloudbongos.com/builders#/task/1003580)'s GAP 1 seen from the invite door: `POST /projects/invite` resolves its target with `getClient()` against `platform_identity_sso_clients`, whose only writer is that same `registerClient` — so the invite could only ever 404 for a wizard-made project, which blocks R27 ([task 1002346](https://cloudbongos.com/builders#/task/1002346)), R28, R29 and the C6 proof.

Underneath both is one conflation: **federation mints CREDENTIALS and it was also, incidentally, the only thing that minted MEMBERSHIP.** A secret and a redirect-URI allow-list exist so an instance can run the sign-in handoff. Being nameable on the map is a different question, and ADR 0182 D4 already answered it — the gate is IDENTITY (a name and a description), which has nothing to do with where a project is hosted.

## Decision

**The catalog row is a PROJECTION of the provisioning row, re-derived at every write that can change its inputs.** Two halves, and neither works alone:

1. **THE ROW SHAPE — a catalog-only client.** Every control-plane project gets a `platform_identity_sso_clients` row *and* a `platform_identity_projects` row, whatever its hosting shape, so identity, membership and the map can name it. The client row carries **no credential**: `secret_hash = ''` and `redirect_uris = '{}'`.
2. **THE TIMING — the publish moment, every time.** The projection is re-taken on create, on `PATCH …/detail`, on `PATCH …/settings` when the door changes, and on `POST …/domain` (which changes the origin the row is *keyed* on). A once-at-provision write is exactly what R18 caught; nothing that writes only at standup can be correct.

Shape (1) alone leaves the catalog stale the moment the owner edits anything; timing (2) alone gives the map a row but leaves `POST /projects/invite` with nothing to resolve. The decision is both.

Mechanically: `modules/platform-identity/project-catalog.js` owns the two writes and publishes them as the kernel port **`project.catalog`** (the `project.publishGate` precedent — provisioning owns these projects and may not import that module); `modules/provisioning/catalog-bridge.js` owns the projection and calls the port. **No migration** — `secret_hash` is `NOT NULL`, and `''` satisfies `NOT NULL` while hashing to nothing.

### A catalog-only client can do nothing but be named

The row shape *is* the enforcement, rather than a flag a future caller could forget:

| SSO leg | Refuses because |
|---|---|
| `GET /sso/authorize` | `redirectUriAllowed` — an empty allow-list fails every exact match, so no code is minted and no redirect happens |
| `POST /sso/token` | `clientSecretValid` — it hashes the presented secret and constant-time-compares against a decoy, then fails closed because there was no real secret |
| `POST /sso/membership/check-in` | the same `clientSecretValid` |
| `POST /sso/activity/rollup` | the same `clientSecretValid` |
| `POST /sso/device/start` | **new guard.** This is the one leg that checked neither: it resolves a client from a user-typed ORIGIN and looked only at `status`. `clientIsCredentialed(client)` is now asked explicitly |

Four of those five were already true before this task, which is exactly why `tests/catalog_only_client.mjs` asserts them rather than assuming them: they are load-bearing for a decision made after they were written. The one that was not is the one that grew four lines of code.

### It grants NOTHING — two claim rules keep it that way

The catalog row is **attribution**, per ADR 0238: ownership stays `provisioning_instances.owner_builder_id`, which `instanceAccessDenied` already enforces on every route that triggers the projection. But the projection writes rows keyed on values an owner supplies — a slug and a bring-your-own domain — and neither hub table proves who owns an origin. So each write carries its claim rule in the `ON CONFLICT` action's own `WHERE`, one statement, no read-then-write window:

- **The client** is refreshed only `WHERE secret_hash = ''`. A slug colliding with a real federated client can therefore neither have its `origin` rewritten (that origin is what binds the CLI device-mint audience — the [task 1002108](https://cloudbongos.com/builders#/task/1002108) fix) nor its secret blanked. It is simply not claimed.
- **The project** is refreshed only `WHERE owner_github_id = EXCLUDED.owner_github_id`. `NULL = anything` is NULL, i.e. not true, so the hand-seeded catalog rows (owner `NULL`) cannot be claimed by someone creating an instance at their address. First INSERT wins and stamps the owner; every later write must match it. An instance whose owner has no GitHub id is refused outright rather than written un-refreshable.

### What is authoritative, and what the hub still does not decide

`description` and `visibility` are **assigned**, not COALESCEd. Clearing a description must take the project off the map, and the door must be able to change — the COALESCE is precisely why the catalog kept a NULL while the owner read `publishable: true`. `featured`, `tagline`, `art_url` and `template` are curation and are never touched here, so ADR 0182 D3 still holds: the bridge cannot feature anything.

Writing `visibility` looks like it contradicts ADR 0182 D5 ("the hub row is a CACHE; the hub never AUTHORIZES a door change — it accepts a report from the authenticated instance"). It does not, and the distinction is worth stating because the next reader will trip on it. **The hub is not authorizing anything: the authority already ran, on the provisioning plane.** ADR 0238 put the door on `PATCH /provisioning/instances/:id/settings`, own-scoped, vocabulary-validated, audited, and pushed to the instance through `web.env`. For a project the control plane owns, that row *is* upstream of the instance — the projection carries a decision the instance has not even received yet. A project the control plane does **not** own has no `provisioning_instances` row, the bridge never runs for it, and D5's instance report (R08, [task 1002327](https://cloudbongos.com/builders#/task/1002327)) remains the only channel. The two never write the same row.

### Lifecycle, and what is deliberately left out

`status` is projected: `tearing_down` / `torn_down` → `'hidden'`, everything else → `'active'`. `requested`, `provisioning` and `error` are all "the owner is standing this up"; the map is a directory of projects, not an uptime board (an unreachable `active` instance already stays listed — liveness is an overlay, never a state). An instance with **no address** (`no_address: true`) is not catalogued at all: the catalog is keyed on `origin`, and opting out of a public address means opting out of the public map.

Federation is left exactly as it is. `shouldFederate` still gates the SSO credential on `co-tenant`, because that is the shape whose `web.env` the platform writes — and that is now the *only* thing it decides.

## Consequences

- **C3's last clause is true.** A wizard-made standalone project that answers its description appears on `GET /projects/featured` in its door's orb — planet / star / black hole per ADR 0182 D1, stealth anonymised server-side by D2a, dark matter excluded in SQL. The C1 proof (R10, [task 1002329](https://cloudbongos.com/builders#/task/1002329)) and the C2 proof (R14) now have a wizard-created project that can be on the map.
- **[task 1003580](https://cloudbongos.com/builders#/task/1003580) shrinks to its GAP 2.** `POST /projects/invite` resolves a wizard-made project instead of 404ing. What remains there is purely the ownership branch: the route's `project.curate` floor is `metic` and has no own-scope arm, so the typical xenos owner still gets a 403. This ADR deliberately does not touch it — widening a permission is its own decision, and ADR 0238's "the hub's owner column is not an authority" is the constraint it has to answer to (the ownership proof it should carry is `provisioning_instances.owner_builder_id`, the authority the manage view already trusts).
- **Many more `sso_clients` rows exist than before** — one per control-plane project rather than one per co-tenant. Every one of them is uncredentialed, and `tests/catalog_only_client.mjs` is the standing proof; a future SSO leg that resolves a client must ask `clientIsCredentialed` if it does not already check a secret or a redirect URI.
- **A re-pointed address retires its old catalog row** (`status = 'hidden'`, owner-scoped). Without it a project that corrected its address would leave an orb on the map pointing at a hostname it no longer answers on — ADR 0181 §2's leak, in the catalog instead of in DNS.
- **The projection is best-effort and runs after the durable write.** A hub hiccup must never turn a saved description into a 500; the bridge swallows its own errors and each call site carries `.catch(() => {})` as the second belt.
- **The three existing catalogued rows are untouched by this change.** All three are `active, featured = true, description = null`, so the map has been empty since R06 ([task 1002325](https://cloudbongos.com/builders#/task/1002325)) swapped the predicate from `featured` to `publishable`. They are hand-seeded, carry `owner_github_id NULL`, and have no provisioning row, so no code path here reaches them — by design, since that NULL owner is what makes them unclaimable. Putting them back on the map is a **one-off data decision for the owner, not a code change**: for each, decide whether it is still a real project, then either `UPDATE platform_identity_projects SET description = '…', owner_github_id = <the owner's github id> WHERE origin = '…'` under a claimed task, or `status = 'hidden'` to retire it. Nothing in this ADR backfills them, and nothing should: a description invented by the platform is exactly the husk the publish gate exists to keep off the map.
- **Teardown does not currently re-take the projection.** The `hidden` mapping is in the projection, so it applies whenever the bridge next runs — but the teardown route itself is not a call site. A torn-down project therefore stays listed until something else writes. That is today's behaviour unchanged (nothing ever un-catalogued a project), it is a small follow-up, and it is named here so the next reader does not read the mapping and assume it fires.

## Alternatives rejected

- **Extend `shouldFederate` to every hosting shape** (the R18 proof's second suggestion). Rejected: it fixes the wrong half. It would hand a real client secret and a redirect allow-list to instances whose `web.env` the platform does not write — a credential nobody can use, on the trust-boundary-sensitive half of the row — and it would still run once, at provision time, so the stale-description bug survives untouched.
- **Bridge ONLY at the publish moment, with no client row** (candidate B as scouted). Rejected: it puts the project on the map and leaves `POST /projects/invite` with nothing to resolve, so 1003580 stays blocked and R27–R29 stay behind it. The map and the invite are the same missing membership.
- **Register the catalog row ONLY at standup** (candidate A as scouted). Rejected by the R18 evidence itself: a once-at-provision write is the bug. It would fix "standalone is never catalogued" and leave "answered later never reaches the map" exactly where it was.
- **A `catalog_only` boolean column on `sso_clients`.** Rejected: it needs a migration this task is not flagged for, and a flag is weaker than the shape — a row with a real secret and `catalog_only = true` is representable and would be a live credential one forgotten check away from working. `secret_hash = ''` cannot be that.
- **Let the bridge write `featured`.** Rejected: ADR 0182 D3 — featuring may rank among projects already on the map, never put one there.
- **Backfill the three existing catalog rows from code.** Rejected: it invents a description nobody wrote, on rows whose real owner the platform cannot identify. See the consequence above — it is an owner decision, executed once, under a claim.
- **Have provisioning write `platform_identity_projects` directly.** Rejected by the one-way rule (ADR 0083): a module may not import a sibling. The port is the same seam `project.publishGate` already travels on, in the other direction.
