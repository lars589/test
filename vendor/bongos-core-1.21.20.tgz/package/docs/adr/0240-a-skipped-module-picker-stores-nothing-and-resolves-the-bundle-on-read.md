# 0240 — A skipped module picker stores nothing, and the bundle is resolved on read

- **Status:** Accepted
- **Date:** 2026-09-03
- **Tasks:** [#1002339](https://cloudbongos.com/builders#/task/1002339) (this decision — BV1.R20)
- **Goal:** [#1000046](https://cloudbongos.com/builders#/goal/1000046) — Project creation: visibility and
  customization, criterion `proj-module-select` ("during setup a default set of modules is pre-selected…")
- **Related:** [ADR 0237](0237-a-starter-bundle-is-a-preset-over-the-always-on-core-keyed-by-declared-type.md)
  (R19 — the bundles this picker renders, and the file that closed with "where a chosen selection lands
  is R20's decision"), [ADR 0182](0182-project-visibility-two-axes.md) D4 (the publish bar a module set
  may not join), [ADR 0083](0083-modular-architecture-strangler-build-plan.md) (the one-way import rule),
  [ADR 0111](0111-instance-hosting-provisioning-module.md) (the enqueue-only web tier), migration
  `provisioning_013` (the `detail` column this deliberately does not use)

## 1. The problem

R19 declared the starter bundles and served them; nothing rendered them. R20 is the
picker: the owner sees what their declared project type preselects, switches
individual modules on or off, and the answer has to survive into the project.

Three questions had no answer yet, and the first is the one everything else hangs
off:

1. **Where does a chosen selection live?** ADR 0237 §6: *"Nothing is stored yet…
   there is still no module-selection column on any table."*
2. **What does *skipping* mean?** The picker is optional like the About step
   before it. "Skip = you get the preselect" is easy to say and easy to get
   subtly wrong.
3. **Where does the picker learn what may be chosen?** A bundle names module
   keys; a picker has to render a name and a sentence per key, for an owner who
   has met none of them.

## 2. Three-valued, or the skip is unreadable forever

A new nullable `modules jsonb` column on `provisioning_instances`
(`provisioning_014`), read through `effectiveModules(row)`:

| stored | means | what the project gets |
|---|---|---|
| `NULL` | nobody answered — the picker was skipped, or the caller does not ask | the declared type's starter bundle, resolved at read time |
| `[]` | the owner switched them all off | the always-on core, and nothing else |
| `["dev-box",…]` | what they picked | exactly that |

The temptation was `NOT NULL DEFAULT '[]'`, and it is the mistake: it collapses
rows 1 and 2, so a project that skipped and a project that deliberately declined
everything become the same row and no later surface can tell them apart. That is
the rule `PROJECT_DETAIL_VOCAB` already states out loud — *"a detail answer is
something the owner SAID… Absent stays absent, and skipped stays skipped"* — and
it applies here for the same reason: R23 ("add modules later") and R24 (the proof
walk) both need to know whether an owner has ever been asked.

**Skipping is safe because the preselect and the fallback are the same
declaration.** The panel preselects `bundleForProjectType(type).bundle`; an
omitted `modules` key makes the server resolve `bundleForProjectType(type).bundle`.
Not two lists kept in agreement — one function, called twice. That is what lets
the panel promise "skip and you get the suggested set" without the promise being
a thing anyone has to maintain.

It also means **`bongos onboard` and any API caller inherit the bundle for free**.
Neither asks the question, both omit the field, and both get the type's preselect.
So the canonical onboarding sequence (`onboard-plan.js`) grows **no new step** —
the picker is a refinement of an answer already in the sequence (`type`), not a
new question in it. `tests/onboard.mjs` says one optional step keeps that flag
meaningful; it still does.

## 3. Not `detail`, not `settings`

`provisioning_013`'s own comment named R19 as a reason `detail` was jsonb, so
`detail.modules` was the obvious home. It is the wrong one:

- `detail` holds the **interview's** answers under `PROJECT_DETAIL_VOCAB`, a
  closed map of scalar vocabularies that `normalizeProjectDetail` filters
  key-by-value and `badProjectDetail` 400s on. A list of module keys is not that
  shape. Carrying it there means teaching a normalizer, a route guard and a read
  projection about a value type none of them have — in order to store something
  ADR 0237 §2 already ruled the interview must not ask.
- `settings` is worse: a setting is a **policy the running instance obeys**. It
  rides `web.env`, queues a `settings-apply` intent and restarts the service.
  A module selection is a declaration made before the instance exists.

A column is the honest shape, and it is additive + namespaced (ADR 0083 §5), so
the previous release still runs against the schema and every pre-existing row
reads as its bundle rather than as an error.

## 4. The picker's catalog is declared beside the bundles

The picker needs, per opt-in module, a label and one owner-facing line. Neither
existing source can give it:

- `module.json`'s `title`/`description` are written for a builder reading a
  module list. *"Outbound ship broadcast + the inbound #ideas/#bugs bot +
  role-sync + channel management + account-link state. Mirror only, never
  authority (ADR 0033)"* is true, and it is not copy you put in front of someone
  who has not built anything yet.
- `GET /modules` needs a session and imports the live catalog; the create wizard
  is read **signed out**, and a module may not import `src/module-loader/catalog.js`
  (ADR 0083's one-way rule).
- `GET /public/modules` serves booleans, not copy.

So `OPTIONAL_MODULES` joins `STARTER_BUNDLES` in `starter-bundles.js` — the same
decision ADR 0237 §3 made for the bundle keys, extended to the choices, and kept
honest the same way: `tests/provisioning_starter_bundles.mjs` reads every
`modules/*/module.json` and fails the build if the declared opt-in set drifts from
the on-disk `default: false` set (minus the two hub-only modules). **A new opt-in
module therefore cannot ship without owner-facing copy**, which is the property
worth buying.

`GET /provisioning/starter-bundles` gains `optional` alongside `core` and
`bundles`. **One read, one declaration**: a picker that fetched its preselect and
its catalog separately could preselect a key it has no row for.

## 5. Loud at the boundary, quiet at the store

`normalizeModuleSelection` drops an unknown, always-on or hub-only key on the way
to storage. The **route refuses it** (`400 bad_modules`, naming the choices)
rather than dropping it silently — `badProjectDetail`'s rule, for `badProjectDetail`'s
reason: a caller who names a module that does not exist has made a mistake, and
being told nothing and handed a project without it is the silent-drop failure the
strict validator exists to prevent. A re-request reports `modules_ignored`, the
same honesty `type_ignored` carries.

## 6. Consequences

- **The picker cannot block a create.** A failed catalog fetch renders a
  "couldn't load" clause, leaves the answer unsaid, and the create still files —
  the server applies the bundle. A picker that could stop a project from existing
  would be worse than no picker.
- **A module selection is still not a publish precondition** (ADR 0182 D4,
  restated by ADR 0237 §6). Taking or declining a bundle cannot move a project's
  dark-matter state.
- **The column is a DECLARATION, not yet an input to the runner.** It is held on
  the platform row exactly as `type` and `description` are, until a catalog row
  materializes. `provisioning_intents` carries no payload, and turning a stored
  selection into the child instance's own `config/modules.json` is separate work —
  named here so nobody reads the stored array as already-provisioned.
- **The wizard renumbered a third time** (gate 0 · name 1 · type 2 · about 3 ·
  **modules 4** · home 5 · address 6 · review 7 · done 8), so `DRAFT_KEY` moved to
  `-v4`: a draft replayed under the old numbering lands on the wrong panel.

## 7. Rejected

- **`NOT NULL DEFAULT '[]'`** — collapses "skipped" into "declined everything",
  permanently.
- **Storing the preselect when the owner skips** — it writes down an answer
  nobody gave, and freezes today's bundle onto a project whose owner never
  expressed a view. Read-time resolution is what `effectiveSettings` already does
  for the same reason.
- **`detail.modules`** — the interview's vocabulary is scalar by construction, and
  ADR 0237 §2 ruled the interview does not ask this question.
- **A new step in `onboardPlan`** — the CLI and the skill would have to ask a
  question whose answer they already get by omission. The sequence gains nothing;
  `tests/onboard.mjs`'s "one optional step keeps the flag meaningful" stands.
- **Rendering the always-on core as sixteen disabled toggles** — a disabled
  control reads as a choice the owner failed to make. The core was never a
  choice, so it is a clause: visible, counted, and outside the band.
- **Reading the manifests at request time to build the catalog** — costs the
  purity ADR 0237 §3 bought, for copy that is fixed at build time anyway.
