# 0290 — "Disconnect from Bongos entirely" is the owner-initiated exception to retention

**Status:** accepted · 2026-09-16 · [task 1003249](https://cloudbongos.com/builders#/task/1003249)

## Context

[ADR 0181](0181-teardown-state-gate-and-address-retention.md) made retention deliberate. A teardown keeps the project's database, its nightly dumps, its `port` and its `domain`, so "Take it offline" is always reversible and a stale proxy block can never hand one owner's address to another project. [Task 1002897](https://cloudbongos.com/builders#/task/1002897) then made the kept address inert: parked at 192.0.2.1, with no Caddy block.

That left owners with no way to actually be done with a project. The manage page admitted it: "There is no permanent-delete button — clearing a project's database for good, and freeing its web address for another project, are done by hand today." The owner decided on 2026-08-24 (walkthrough decision 6) to rename the teardown control "Take it offline" and to add a separate, true delete.

## Decision

**1. A separate action, owner-initiated only.** `POST /provisioning/instances/:id/disconnect` is own-scoped with the archon override (404 for anyone else) and carries the typed name as `confirm_slug`, which the route checks server-side, because this erases a database. It is its own card after "Take it offline", never a mode of it, so the reversible control can never read as the destructive one. Every other path still retains everything, as ADR 0181 says.

**2. It deletes the provisioning row** (owner decision, this session). The alternative, a tombstone, would keep the name taken forever, since `slug` is UNIQUE. Deleting the row releases all three claims at once: the name, the port (`allocatePort` reads every row) and the address (the next standup UPSERTs it). The row's intents, events and OAuth-manifest attempts cascade with it. The core `audit_log` still records the request, the route writes a `disconnect` event before the delete, and the runner journal records each step.

**3. It erases the backups immediately** (owner decision, this session). There is no per-project retention mechanism to hold a "last dump for 30 days", and building one would add a scheduler to operate. The safety net is the typed-name confirm plus a fold that says "cannot be undone". The erase matches the nightly filename exactly (`<db>-YYYY-MM-DDTHHMMSSZ.sql.gz`). The nightly prune's own `<db>-*` glob would let a project named `test` erase `test-nk`'s dumps.

**4. The runner does it, in an order that keeps it retryable.** `scripts/gds/provision-disconnect.js`, dispatched from the drain loop's `disconnect` intent (migration `provisioning_016`), runs these steps in order:
- the teardown legs;
- dropping the database, then the role that owns it;
- erasing the dumps;
- removing the env and state dirs, the per-project checkout (standalone only) and the unix account;
- removing the catalog, membership and client rows through the new `project.catalog` verb `forget`, under the publish path's two claim rules;
- **deleting the row last**.

A failed erase or catalog step returns a retryable `{ ok:false }`; a teardown that throws ends the run with the intent at `error`, before anything is erased. Either way the row stays, because the row is what lets the runner, or the owner pressing Disconnect again, try again. A dedicated project skips the command erase, since its droplet went whole. The slug is re-validated before any `rm -rf` is built from it.

**5. A disconnect supersedes nothing.** Unlike a teardown, which supersedes a stale pending standup, a disconnect is refused while any other run is open, even a pending one. A destructive run must never race a standup that is about to start. A repeat while a disconnect is open is idempotent.

**6. The GitHub repository is never touched**, and neither is a GitHub App the owner registered for sign-in. GitHub has no API to delete an App, so the fold tells the owner where to remove it.

## Consequences

- The manage page's copy changed with the capability. The teardown truth now ends "Taking it offline erases nothing." rather than "Nothing here erases a project.", and the fold points at the new card instead of admitting the capability is missing.
- The `project.catalog` port has three verbs. `tests/catalog_only_client.mjs` still pins the list.
- If the runner dies mid-disconnect, the reconcile sweep re-enqueues a *teardown* for a `tearing_down` row, not a disconnect. The project is left offline, with its row, and the owner presses Disconnect again. This is accepted rather than giving the reconcile a memory of intent.
- The nightly prune's `<db>-*.sql.gz` glob could still reach a longer-named sibling's dumps older than 30 days. It was filed as its own row and fixed in [task 1003948](https://cloudbongos.com/builders#/task/1003948): the prune and its retained count now match the same exact filename.

Proofs: `tests/provisioning_disconnect.mjs` (queue + route), `tests/provision_disconnect.mjs` (runner order, shapes, failure, guards), `tests/project_catalog_forget.mjs` (claim rules), `tests/hub_disconnect_ui.mjs` + the kit probe (the card).
