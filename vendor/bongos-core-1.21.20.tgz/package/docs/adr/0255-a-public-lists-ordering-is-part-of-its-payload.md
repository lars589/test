# ADR 0255 — A public list's ordering is part of its payload, so an anonymous row must be ordered by nothing

- **Status:** accepted
- **Date:** 2026-09-06
- **Task:** [task 1003561](https://cloudbongos.com/builders#/task/1003561) (BONGOS-V1, goal 1000046 — *Project creation*), which absorbed [task 1003560](https://cloudbongos.com/builders#/task/1003560)
- **Deciders:** Claude, building against ADR 0182 D2a
- **Related:** [ADR 0182](0182-project-visibility-two-axes.md) D1/D2a/D3 (the join door, the stealth redaction, and `featured`'s remaining ranking job) · [ADR 0252](0252-the-self-hosted-visibility-report-is-a-pull-and-auto-appear-buys-a-retraction-lever.md) §5.3 (the per-IP ceiling on this route) · [ADR 0253](0253-the-takedown-lever-has-two-writers-and-provenance-is-a-column.md) (`visibility_source` / `visibility_reported_at`, the `DOOR_KNOWN_SQL` predicate this feed joins) · [ADR 0119](0119-api-pagination-contract.md) (the `?limit=&offset=` contract this feed was the last public list to hold out on)

---

## 1. The leak

`modules/platform-identity/projects-feed.js` takes considerable trouble over what a stealth
project may say. `feedShapeFor()` rebuilds an anonymous row from an allow-list —
`STEALTH_ANONYMOUS_KEEPS = ['state', 'orb']` — and the constant's own comment states the
threat model it is defending against:

> No stable per-project key appears here on purpose: an id, a slug or a hash of the origin
> would each let an observer who kept yesterday's public feed name the project that went
> stealth today. Black holes are interchangeable, which is the whole point of the metaphor.

The feed then sorted `ORDER BY featured DESC, updated_at DESC` and handed the observer a
stable per-project key anyway. **Ordering is a covert column.** Every row's position is the
result of a comparison, and enough comparisons reconstruct the key the comparisons were made
on. Three consequences followed, and the third is the one that matters:

1. **`updated_at` was published despite being deliberately withheld.** The projection
   excludes it on purpose — the same file notes that feature toggles and client
   re-registration bump it, so as a public "last updated" it would lie. Sorting by it
   published it anyway, one comparison at a time.
2. **A black hole sat between named neighbours**, whose own relative order is visible. That
   brackets the hidden row's `updated_at` between two rows an observer can identify by name,
   which is a far narrower fact about it than "a project exists."
3. **A black hole MOVED when its hidden project was touched.** This is the activity oracle.
   Two fetches of a public, CORS-open, unauthenticated feed are enough to learn *that the
   project behind this particular black hole was just active* — and correlating that with
   anything happening in the open (a release, a post, a commit) is how an anonymous row gets
   a name. Position was also stable enough between touches to follow one black hole across
   snapshots, which is precisely the "stable per-project key" the payload refuses to carry.

The redaction was doing its job. The `ORDER BY` was undoing it.

## 2. Decision — the rule

**A row may be ordered only by what it publishes.**

- An **identified** row (`public` → planet, `private` → star) publishes `created_at` and
  `origin`, so it is ordered by those, beneath `featured` — ADR 0182 D3's one remaining
  job, ranking among rows already on the map. The resulting order is a **pure function of
  the wire payload**: a reader holding nothing but the response can reproduce it. That is
  the strongest available statement that a sort leaks nothing, and it is worth stating as
  the positive form of the rule rather than as an absence of known leaks.
- An **anonymous** row (`stealth`, and anything unrecognised) publishes nothing, so it is
  ordered by nothing about itself. The black holes are collated into **one trailing block**,
  permuted by a **keyed, rotating hash**.

Concretely, four sort terms, of which the first partitions the two blocks so that no later
term ever compares across them:

```sql
ORDER BY (visibility IN ('public','private')) DESC,
         ((visibility IN ('public','private')) AND featured) DESC,
         (CASE WHEN (visibility IN ('public','private')) THEN created_at END) DESC,
         (CASE WHEN (visibility IN ('public','private')) THEN origin
                                                        ELSE md5(origin || $1::text) END) ASC
```

Terms 2–4 are **guarded**, and that is the whole trick. Without the guards the trailing
block would simply be re-sorted by `featured`, then `created_at`, then `origin` — none of
which a black hole publishes, and `created_at` in particular would place it by its listing
date, which narrows *which* project it is for anyone who watched the catalog fill up. The
"anonymous rows go last" half without the "and are blanked" half is not a fix.

The identified-state list is **derived from `ORB_BY_STATE`**, never re-typed, and is an
**allow-list**: a state this file does not know sorts into the anonymous block, the same
fail-closed direction `orbStateOf()` already takes for rendering. A deny-list would draw a
future fourth enum value as a black hole and then sort it by its `created_at` — anonymous in
the payload, identified in the ordering, which is the worst of both.

## 3. Why the anonymous block is keyed, and why it rotates

Two separate properties, both load-bearing:

**Secret.** Origins are guessable — they are domain names. A permutation an observer could
compute (`md5(origin)`, `md5(origin || today)`, or plain alphabetical order by `origin`)
would let them hash their candidate origins, match the resulting ranks against the live
block, and de-anonymise every black hole in one pass. The salt is therefore a random
per-process key. Nothing persists it, compares it across restarts, or reads it back — it
only ever *orders* rows — so there is no key to configure, distribute, rotate by hand, or
leak from disk.

**Rotating.** A permanently stable permutation would still make **position** a durable
per-project handle: an observer could not name a black hole, but could follow one across
months and watch it appear and disappear. The salt therefore also carries a coarse epoch
(24h), so the whole block is re-dealt on a fixed period regardless of process lifetime.
Within one period the order is stable, which is what lets the pages of a single listing agree
with each other.

`md5` is a permutation here, not a security primitive; the unpredictability comes from the
secret salt, and it is the most portable hash available without pgcrypto.

## 4. Pagination is the same decision, not a neighbouring one

Task 1003560 asked for a cap on an "unbounded" feed. **That premise was already stale:**
`<redacted> = 500` shipped with the feed itself, and its own comment named the
cap "the cheap half of that trade — the honest half is pagination, which is its own task."
The surviving work was pagination only, and pagination edits the same single SQL statement
this ADR rewrites — so the two tasks were built together and 1003560 was merged into 1003561.

- **`?limit=&offset=`, per ADR 0119**, whose helper (`parsePagination` / `pageMeta`) this
  route was the last public list not to use.
- **No cursor, and that is a security property as much as a style one.** An opaque cursor
  over this feed would have to encode a sort position, and the obvious encoding — the last
  row's timestamp — is exactly the side-channel §2 exists to close. An offset encodes nothing
  about any row.
- **The default page size *is* the maximum (500), deliberately.** A caller that sends no
  parameters gets byte-for-byte what it got before. One consumer of this feed is a static
  orbs site in **another repository** that this commit cannot update; a smaller default would
  have silently shrunk somebody else's map. `page` is added *beside* the existing `projects`
  key rather than wrapping it, so the wire change is additive and every consumer that
  destructures `data.projects` keeps working.
- **Paging cannot aim more fan-out than one request already could.** `?limit=` only ever
  shrinks a page. `?offset=` reaches deeper, and the cost of that is bounded not by the
  request count but by `project-stats.js`'s 10-minute per-origin cache: a second page reaches
  origins the cache would have covered anyway, and re-reading any page is free. The per-IP
  limiter (120 reads/60s, ADR 0252 §5.3) is unchanged and still bounds how often.
- **No `total`.** Counting is a second pass over the same predicate for a number nothing
  reads today; `pageMeta()` makes it optional for that reason. A caller learns there is more
  the standard way: `projects.length === page.limit` means ask for the next offset.

## 5. Alternatives weighed

| Option | Why not |
|---|---|
| Sort every row by `created_at DESC` | `created_at` is nulled on anonymous rows, so a black hole would be *positioned* by a date its own row refuses to carry — and its listing date is a strong hint at which project it is. Worse than the bug being fixed. |
| Order the anonymous block alphabetically by `origin` | Deterministic and timing-free, but position then reveals the alphabetical rank of a hidden domain — an oracle against a candidate set. |
| `ORDER BY random()` for the anonymous block | Kills both the timing signal and the durable handle, maximally. Rejected because it breaks pagination outright: a black hole could appear on two pages or none, and the count of black holes — which *is* public by design — would stop being stable within one listing. |
| Drop the anonymous rows from the feed entirely | Contradicts ADR 0182 D2a, which exposes existence on purpose. A black hole is a deliberate feature of the map. |
| Keep `updated_at` but bucket it coarsely (e.g. by week) | Still a timing channel, only quieter, and it would need a defensible bucket width nobody could justify. A sort key that must be blurred is a sort key that should not be there. |

## 6. What this does NOT close

Stated plainly, because a privacy fix that oversells itself is worse than none:

1. **Existence and count are public by design.** The number of black holes on the map is
   visible and always was — that is ADR 0182 D2a, not a defect.
2. **The identified set still changes when a project goes stealth.** An observer diffing
   yesterday's feed against today's sees a named project leave the identified block while
   the black-hole count rises by one, and can name it that way. This is a **larger** channel
   than the ordering one and it is untouched here: it is inherent in publishing a named list
   at all, and closing it needs a different mechanism (a delay, a decoy, or accepting that a
   project's *departure* from the public list is public). Filed separately rather than
   silently implied to be fixed — and **now decided**: the owner chose to accept it and say
   so in the copy ([ADR 0259](0259-a-projects-departure-from-the-public-list-is-public.md),
   [task 1003672](https://cloudbongos.com/builders#/task/1003672)), which also carries the
   §6.3 residual below.
3. **Position is stable within one epoch.** Two snapshots taken the same day can still tell
   black holes apart, though not name them. The rotation bounds this to the epoch.

## 7. Consequences

- The map's identified rows now sort by **listing date**, not last-touched. The feed stops
  churning on `updated_at` bumps that meant nothing to a reader anyway.
- `<redacted>` is renamed `PUBLIC_FEED_MAX_PAGE_SIZE`, which is what it now is:
  a per-request fan-out ceiling that doubles as the default page size.
- `listPublicProjects({ pool, limit, offset, now })` clamps its own window as well as the
  route clamping it, because it is a module-public function and the ceiling is a fan-out
  bound — it may not depend on every future caller remembering to pass one.
- Proof lives in `tests/visible_projects_feed.mjs`, which now pins the guards structurally:
  the first sort term partitions the blocks, every identified key is guarded, there is no
  fifth unguarded term, `updated_at` appears nowhere in the query, and the salt is bound as
  a parameter rather than interpolated.
