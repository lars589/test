# ADR 0352 — A rollup report carries its "as of" in a header, and the hub keeps the newest

- **Status:** accepted
- **Date:** 2026-09-30
- **Task:** [task 1004268](https://cloudbongos.com/builders#/task/1004268) (goal 1000110), found in [task 1004244](https://cloudbongos.com/builders#/task/1004244)'s code review
- **Interacts with:** [ADR 0141](<redacted>.md) §4 (the activity rollup), [ADR 0171](0171-profile-rollup-join-and-consent.md) D7 (a report is third-party self-report), [ADR 0083](0083-modular-architecture-strangler-build-plan.md) §5 (module-namespaced migrations)

## Context

`POST /sso/activity/rollup` upserted the live activity row last-writer-wins, and a report carried no timestamp. An instance pushes one on every federated sign-in and one on every ship, so a sign-in report read earlier and a ship report read later can reach the hub together, and the older one can commit last. The live row and, since task 1004244, the newest snapshot then show the older totals. The leaderboard reads a regression that never happened until the builder's next report. It is low-urgency, since the next report corrects it, but it is wrong in exactly the place people compare numbers.

The fix the task names is for the instance to send when it read the totals, and for the hub to refuse an older report. What is not obvious is where that stamp travels.

## Decision

**D1 — The stamp is a request header, `Bongos-Report-As-Of`, not a body field.** The hub validates the rollup body strictly (`validateOrRespond`), so an unknown field is a 400. The hub and its instances upgrade independently, and an instance can run a newer core than the hub (today the hub's pin trails main). A body field sent by an upgraded instance would be refused by a hub that predates it. The sender never reads the response, so every report from that instance would be lost silently until the hub caught up. An unknown header is ignored, so the header is safe in both directions: an old hub ignores it, and a new hub treats its absence as "unstamped".

**D2 — Unstamped means the old behaviour, never a refusal.** A missing or unparseable header binds NULL. A NULL on either side of the comparison (an older instance's report, or a row written before migration 026) applies last-writer-wins, as before. An unstamped report also clears the stored stamp, so a stamp never outlives the numbers it described. A malformed header is not a 400, for D1's reason: a refusal drops the report, when the only thing lost should be its ordering.

**D3 — The guard is a WHERE on the upsert's conflict branch.** `ON CONFLICT (client_id, github_id) DO UPDATE … WHERE EXCLUDED.reported_as_of IS NULL OR <row>.reported_as_of IS NULL OR EXCLUDED.reported_as_of >= <row>.reported_as_of`. A skipped update still takes the row lock, so racing reports stay queued exactly as task 1004244 arranged, and the snapshot beside it copies an unchanged live row, which records nothing. Ties apply (the later arrival wins, as before).

**D4 — The stamp is the instance's clock, compared only with itself, and clamped to the hub's.** A row's stored stamp only ever comes from the same client for the same builder, so skew between an instance and the hub does not matter. A stamp later than the hub's `now()` is stored as `now()`, so an instance whose clock runs ahead cannot freeze the row until its clock is reached. The sender stamps before its first read, so a report is never ordered ahead of totals read after it.

## Consequences

- Migration `platform_identity_026_activity_reported_as_of.sql` adds one nullable column, with no backfill and no default. An invented stamp on an existing row could refuse an honest report from an instance whose clock reads earlier than the hub's.
- A mixed fleet behaves as before until each instance upgrades. An upgraded instance talking to an old hub is also unaffected.
- **Honest limit:** an instance clock that steps backwards (an NTP correction after running fast) has its reports refused until it passes the last stamp it sent. The skew bounds this, the clamp bounds the skew by the hub's own time, and the next report after that applies. A report refused this way still answers `{ ok: true }`, because the instance ignores the body.
- **The pattern generalises:** a field added to a hub↔instance wire that the older side validates strictly must be able to ride where the older side ignores it, or the change must land on the hub first and be released before any instance sends it.

Proof: `tests/activity_rollup_order_db.mjs` (real Postgres: the out-of-order race, ties, NULLs on each side, the future clamp, and ten rounds of five racing writers ending on the latest stamp with the snapshot agreeing) and `tests/activity_rollup_as_of.mjs` (DB-free: the sender stamps a header before its reads and never the body; the route binds it and degrades a bad one to unstamped).

## Alternatives considered

- **A body field `as_of`.** This is what the task sketched. It is lost against any older hub (D1).
- **`GREATEST` on each total.** Credits and karma can legitimately fall, so this would pin a clawback forever.
- **The standard `Date` header.** It has one-second granularity, and a sign-in push and a ship push inside the same second are exactly the case being fixed.
- **A 400 on a malformed stamp.** It turns a sender bug into silent data loss (D2).
