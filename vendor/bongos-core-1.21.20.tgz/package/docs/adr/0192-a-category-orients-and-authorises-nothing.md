# 0192 — A work category orients a human and authorises nothing

- **Status:** Accepted
- **Date:** 2026-08-25
- **Tasks:** [#1003275](https://cloudbongos.com/builders#/task/1003275) (this decision + the storage/API), with the hall surfaces in [#1003276](https://cloudbongos.com/builders#/task/1003276) and the assignment path in [#1003277](https://cloudbongos.com/builders#/task/1003277).
- **Goal:** [#1000072](https://cloudbongos.com/builders#/goal/1000072) — Human legibility, criterion `legibility-categories`.
- **Constrains, does not amend:** [ADR 0086](0086-goal-scoped-work-hierarchy.md) — the real work hierarchy. This decision adds a label *beside* that hierarchy and forbids it from behaving like part of it.

## 1. The problem

A person scanning the goal board cannot tell at a glance which goals are about
money, which are about the walls, and which are about the hall. Each goal's own
words say so — but only if you read all thirty-eight of them. The owner asked for
one word per goal that answers it, and named the set: Builders Hall, Context
Management, Government (Decision Making), Modules, Security, Economics, Legal,
User/ABI Experience.

That is the easy half. The hard half is the constraint the owner attached to it,
twice: this organisation "has no hierarchical purpose", and these categories have
"no effect on the creation and agentic management of these elements".

## 2. Why the constraint needs a decision record and not a comment

The system **already has** a hierarchy — Project → Version → Goal → Criteria →
Task ([ADR 0086](0086-goal-scoped-work-hierarchy.md)) — and that one is
load-bearing: the `scope_modules` wall, per-task rank floors, and goal membership
all refuse real work. Goal 1000072's own prose predicts what happens next: *"A
second thing that LOOKS like a hierarchy will be mistaken for one within a
release."*

The mistake does not arrive as a decision anybody announces. It arrives as one
plausible line inside a gate — *skip Legal goals in the claimable feed*, *require
Archon for Security ones* — and from that moment work is refused because of a
label nobody meant as a permission. Nothing in a comment can refuse that line.

## 3. Decision

**A category is advisory. It orients a human and steers Claude; it authorises
nothing.**

Concretely:

1. **No decision surface reads it.** Not authority, not claim eligibility, not the
   claimable feed, not dependency satisfaction. Enforced by a fitness check,
   `scripts/gds/category-advisory-guard.js`, which scans every such file with
   comments stripped — so a gate may *cite* this rule but may never branch on it.
2. **The guard cannot pass vacuously.** It also asserts the category surface still
   exists (migration, module, route). A guard whose subject was renamed away
   passes silently and reads as proof — the assurance-of-assurance finding from
   the [ADR 0022](0022-secrets-policy.md) audit that produced
   `control-manifest.js`.
3. **Uncategorised is a legal state.** `goals.category_id` is nullable with no
   default, and no write requires it. The criterion is explicit that Claude
   failing to place a goal is *"a designed prompt, not an error"*: the human is
   asked to name a new category, and asking is not refusing.
4. **A task stores no category.** It inherits its goal's through `tasks.goal_id`.
   The criterion's own wording is "every goal (and task, **by inheritance**)", and
   a stored copy would be a second answer to one question with no way to know
   which is right.
5. **The set is data, not an enum.** A runtime-extensible set cannot be a `CHECK`
   constraint or a pg enum without a migration per addition — and it must not be a
   free-text column, or two spellings of "Security" stop it being a set at all.
   Retiring is `active = false`, never a `DELETE`, so a goal already carrying a
   category keeps rendering its label.
6. **The rank pins are a tripwire.** `GET /work-categories` is any-builder (a
   vocabulary a client cannot read is a vocabulary a client hard-codes),
   `POST /work-categories` sits at the same permission as authoring a goal
   (extending the project's words is a planning act), and
   `PATCH /goals/:id/category` rides the same owner|manager|Archon in-handler gate
   as the prose edit. If one of these ever needs a *wider* gate than its
   neighbours, that is the signal the label has grown into a permission.

## 4. What was deliberately not built

- **No per-category page or filtered navigation view.** A chip is a label; a
  drill-down destination is a tier. Building the destination is how an advisory
  label becomes the second hierarchy in practice regardless of what the code
  gates on.
- **No category on a task, no category-scoped permissions, no category-ordered
  work feed.**

## 5. If this ever needs to change

Making a category gate something is an **owner decision** and needs its own ADR
before the guard is relaxed. The guard's failure message says so, because the
person who trips it is the person who needs to read it.

## 6. Consequences

- A human can scan the goal board by kind, which is the whole point of goal
  1000072.
- One more fitness check to maintain, and a `GATE_FILES` list that must grow when
  a new decision surface lands. That maintenance *is* the mechanism — a new gate
  either gets added to the list or is not a gate.
- The false-positive posture is deliberate: the scanner errs toward keeping text
  when comment-stripping is ambiguous, because a guard that fails loudly is safer
  than one that fails quietly.
