# ADR 0228 — The reading room owes a reference its content rules, not a second archetype

**Status:** accepted · **Date:** 2026-09-02 · **Task:** [task 1003473](https://cloudbongos.com/builders#/task/1003473) · **Goal:** 1000081 (the builders' hall in the chrome world)

## Context

Task 1003306 built the reading-room archetype (`modules/hall-ui/public/room.css`) for the primer: a progress hairline under the top bar, the room's name alone over the ground, a glass table of contents beside a `--bg-card` article card, numbered sections, and an acknowledge gate at the end. Task 1003307 found that drachmae (`/builders/drachmae`, the "how you get paid" doc) had been wearing half of that room since task 1472 — no `room.css`, no `room` class, unstyled loading states — and repaired the source without moving the screen.

What was left was a design question rather than a repair: the archetype was designed for ONE document and now serves two, and the second is not shaped like the first. The primer is a linear onboarding read with a gate at the end. Drachmae is a **reference**: people open it to answer one question about how they get paid, it carries a live table (the security bounty rates, fetched from `/public/bounty-table`), and it is scanned and deep-linked rather than read start to finish. The task asked what the room owes a reference, and whether that is a variant of `.page-head--room` and `room.css` or the same room with different content rules.

Rendering the page through the kit against the fixture harness before touching it found four things no floor measures:

- The shared markdown reader (`md-reader.js`) parsed headings to `###` only, so the doc's six `####` earning sources — the very questions a reader arrives with — rendered as paragraphs beginning with a literal `####`.
- The bold rule refused an inner `*`, so `**It's the API *list* price, deliberately**` showed its asterisks.
- The live rate card was appended as the LAST section, after the doc's own "See it / dig deeper" links: an appendix to a footer.
- A deep link into the page landed nowhere: the document arrives after `load`, so the browser's own fragment jump found nothing, and `:target` resolved against nothing.

One thing the task said to raise rather than decide: the mock's `.pane` carries a `--rule-soft` hairline while the shell's `.scroll` is `border: 1px solid transparent`, and `docs/design/hall-direction-v2.md` §6 says v3 has "no hairline edge". Changing `.scroll` repaints all 27 hall pages, so it is an owner decision. It was raised in task 1003470 and the owner closed it: **the transparent edge stands.** This task inherits that decision — the article, the skeleton and the failure note stay the shell's `.scroll`, and nothing is repainted.

## Decision

**The same room, one body modifier, and the difference is content rules.** `drachmae.html` opts into `room room--reference`; `room.css` §8 is what the modifier switches on. Nothing about the composition changes — the head keeps `.page-head--room` (in a reading room the document *is* the page, and that is as true of a reference), the glass contents sit beside the card, the measure and the rhythm are the archetype's — because the room is right for both documents. What the room does for a reader who is *looking* rather than *reading* is:

1. **The linear-read instruments are off.** No progress hairline (the page omits the markup; §1 stays for the primer, whose gate is fed by it), no section counters (`content: none` on the h2's and the contents' `::before`), no "About a five-minute read" (the sub line says what kind of document this is). `primer.css` is no longer loaded: it holds only the acknowledge gate.
2. **The outline goes to h3 depth, nests, and lights the trail.** `drachmae.js` collects `h2[id], h3[id]` from the RENDERED article — so `*not*` and a link in a heading arrive as words, and the live section inserted below is one more heading in order — nests h3s under their part (`.primer-toc__sub`), and the scrollspy lights the entry AND its part (`.is-trail`). On a phone the collapsed toggle rides under the top bar (`position: sticky` at the room's 760px breakpoint, on the card's ground at 92% because light's glass has no blur and prose showed through the bare tint) and its middle (`#primer-toc-current`) names the part the reader is in.
3. **Every heading is an address.** `.room-anchor` on every h2/h3/h4: the heading's own id as a real `<a href>`, a 24px box of its own, ALWAYS visible in the faint ink (an address is part of the content, not a hover secret, and a phone has no hover), the accent when it is the one the reader arrived at, copying the absolute link on click. The landing is the page's: `landOnHash()` scrolls to the target after the document, the live section AND the fonts (a swap after the jump moved the landing 300px short on a phone and past it on a desktop), and marks it `.is-target` until the next hash change hands the mark back to `:target`.
4. **The live table is a section ahead of the closing links,** not an appendix after them: `insertBountySection` puts it before the h2 matching `/^see it/i`, and falls back to appending if the footer is retitled.

**The parser reaches h4, slugs a linked heading by its text, and renders nested emphasis.** `md-reader.js` is `#{1,4}` in both regexes (the heading and the paragraph break), the bold rule is `\*\*(.+?)\*\*`, and `slugify` strips a markdown link down to its text first so the copied address is `#<redacted>` rather than the target's path. The primer's markdown has no `####` and no linked heading, so its render is unchanged; `room.css` gives the h4 a rule (the body face at the body size, one weight step up) and the measure.

## Alternatives rejected

- **A second archetype sheet (`reference.css`) or a `.page-head--reference` voice.** It would be `room.css` again with the counter deleted, and the head is the same voice for the same reason. The third scanned document (the ranks ladder, the API docs) takes the four rules by one body class.
- **Hover-only anchors,** the documentation-site default. A phone has no hover, and on a reference the addresses are content.
- **An accordion outline** that shows a part's h3s only while the reader is in it. Fourteen entries fit beside the card at 1440, and the sub-questions are what a reader is scanning FOR — hiding them defeats the outline.
- **Placing the live table inside the prose that describes it** (under the `####` bounty source). It would lose its outline entry and its deep link, which for a live schedule are the point.
- **Teaching the kit stub to serve the markdown** so the states file could pin the populated document under both bases. The kit's stub (`modules/ui-design/kit/serve.js`) is the ui-design module's; the states file documents that the populated render is the harness's job, as `primer.states.json` already does.

## Consequences

- `tests/hall_reference_world.mjs` pins the modifier, the instruments' absence (and the primer's keeping them), the outline, the anchors, the landing order, the table's placement, the h4 rule, and RUNS the reader in a vm for the h4, the slug and the nested emphasis.
- The primer is untouched; `tests/hall_reading_world.mjs` still passes on it. The reader change reaches every document the hall renders through `OTBMdReader`; both changes only add rendering where a literal marker showed before.
- Measured through the kit against the harness: 24 renders + 2 reduced-motion passes, all clean, at 1440/390/320 in both modes, across `read`, `toc-open`, `jump` and `out`.
- Honest limits: no page has been used in a real browser by a person; the kit stub still renders the failure note for this page (documented in the states file); the `:target` mark on the initial landing is script-set, since the browser resolved `:target` before the heading existed.
