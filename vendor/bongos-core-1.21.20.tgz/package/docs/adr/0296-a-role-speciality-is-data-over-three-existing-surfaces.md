# ADR 0296 — A role speciality is data over three existing surfaces, not a fourth mechanism

**Status:** accepted · **Date:** 2026-09-17 · **Task:** [#1003855](https://cloudbongos.com/builders#/task/1003855) · **Goal:** 1000095

## Context

A craft (`discipline`) says *how* you work: engineer, ideator, artist, ui. Each maps to a playbook in [`scripts/gds/discipline-modes.json`](../../scripts/gds/discipline-modes.json). Nothing said what you work *on*.

The owner's ask (2026-08-16, expanded by direct ruling 2026-09-17) is **role sub-specialities**: an ideator might hold an Economics speciality, where what matters is the subject knowledge and the terms that expert wants to be engaged on. The constraint attached to the ask is the point of it — *"do not get too into the weeds… the deliverable is NOT a catalogue of specialities we author. It is the MECHANISM."*

The 2026-09-17 ruling settled the questions the original filing left open:

1. **Training is two-fold** — knowledge the builder *supplies* (their own documents), **and** learning from sessions. Not authored prose alone.
2. Specialities are for subject-matter experts, and are **both per-builder and per-project**.
3. Sharing is **open or closed, the owner's choice**.
4. A speciality is effectively a **harness**, and its owner decides whether it may be **sold on the module marketplace**.

## Decision

### A speciality is DATA, not an ADR 0083 code module

The owner's phrasing is that specialities "are more or less MODULES", and the pull toward implementing them *as* modules is real. We rejected it: a subject-matter expert authors a speciality, and requiring them to ship a code package to do so puts the mechanism out of reach of exactly the person it exists for. A speciality is a row; a module is a package; the resemblance is in what they *contribute*, not in what they *are*.

### It layers over three surfaces that already exist

| Ingredient | Where it already lives |
|---|---|
| craft → playbook | `discipline-modes.json` |
| the per-session interaction contract | `behavior_prefs.interaction` → `GET /me` → the Conductor hook |
| declared skills | **not built by this ADR** — see [ADR 0310](0310-a-speciality-offers-skills-and-the-adopter-chooses-them.md), which decides the shape (a speciality OFFERS skills; the adopter enables them one at a time, walked through each) and leaves the build to its own tasks |
| **the knowledge bundle** | **new — `speciality_documents` + `speciality_learnings`** |

Only the fourth is new machinery. In particular **a speciality contract rides the existing injection path rather than adding a second one**: `GET /me` gains a slice, the Conductor relays it, and the composition stays server-side exactly as it does for the interaction profile.

### The injected contract is craft-scoped, and silent without a claim

The hook injects only the contract whose craft matches the claim in hand — an artist's expert contract in an engineering session is noise at best. This required one small honest addition: the active-claims read now carries `t.discipline`. **With no active claim there is no craft and nothing is injected**; silence beats guessing which expertise applies.

### The corpus is inventoried, never inlined

A document may run to 100k characters. The contract names *what the speciality knows* and tells the agent to reach it with `/recall` — and `speciality_documents` is therefore added to the recall ingester, because otherwise that instruction is a lie whose failure mode is silent (the agent searches, finds nothing, and answers from general knowledge as though the expert had never trained it).

### `sellable` is recorded; no storefront is built

[ADR 0107](0107-module-upstreaming-contribution-to-core-catalog.md) states there is no submission flow and no catalog/registry, and **explicitly rejected** "a package marketplace now" as premature. There is no payments surface either. So ruling 4 is honoured as a **seam, not a storefront**: `visibility` and an owner-set `sellable` flag capture the decision at the moment the owner makes it, so the deferred marketplace reads fields that already hold honest values instead of asking every existing owner to answer retroactively. The flag grants nothing and lists nowhere.

This is a deliberate partial implementation of an owner instruction, recorded here rather than silently made. Reversing it means taking the marketplace fork, which is a larger decision than this task.

## Consequences

**Good.** The mechanism ships without a catalogue, as asked. A speciality costs one row and nothing in a session that has not adopted one. The contract path, the knowledge corpus and the learning capture are all existing machinery pointed at a new subject rather than rebuilt.

**The scoping compromise to know about, and the bug in its first implementation.** The recall index expresses two axes — `min_rank` and `owner_builder_id` — and `project` visibility is neither: it names a set of builders the index cannot. A **null owner means corpus-wide**, which is the fact everything here turns on.

So: a **public** speciality's documents are corpus-wide; a **builder-owned** non-public one is scoped to its owner; and a **project-owned** non-public one is **not indexed at all**, because there is no single builder to scope it to and the honest alternative to "the right audience" is "nobody", never "everybody".

The first implementation got that last case exactly backwards. It mapped `ownerBuilderId: visibility === 'public' ? null : owner_builder_id` — correct for a builder-owned row, and a leak for a project-owned one, because the migration's own CHECK forces `owner_builder_id IS NULL` whenever `owner_kind = 'project'`. The null flowed through and published private project material to every builder on the instance. **This paragraph previously claimed the scoping "errs toward under-sharing", so the documentation actively vouched for the leak** — which is why the correction is recorded here rather than quietly fixed. It is now guarded twice, in the ingest `WHERE` clause and again in the mapper, and every visibility/ownership combination is pinned by `tests/speciality_corpus_scope.mjs`.

A project member can therefore see and adopt a project speciality but will not get its documents in `/recall` until it is public. That is a smaller answer than the sharing rule allows, which is the right direction for an index to be wrong in.

**Project membership is resolved through an optional seam.** It belongs to `platform-identity`, which exposes no port for it. Rather than reach across a module boundary, the routes resolve `project.membership` optionally; absent means *no projects*, never *all projects*. On a non-hub instance project-owned specialities are therefore authorable only by nobody — the honest behaviour until that port exists.

**A speciality's craft is immutable.** Moving one between crafts would silently re-scope everyone who adopted it, and the adoption rows carry a denormalised copy of the craft so the "one active per craft" rule can be a real unique index rather than a documented hope. The update path rejects the change and says why.

## Alternatives rejected

- **Specialities as real modules.** Puts authoring behind shipping a package. See above.
- **A second injection mechanism.** A separate hook or file would have duplicated a resolve-and-inject path that already works and is already tested.
- **Inlining the knowledge into the contract.** Blows the session's context, and scales with the expert's diligence in exactly the wrong direction.
- **Structured knobs instead of prose for the contract.** A speciality is an expert saying how they want to be worked with; that is not enumerable up front, and `interaction-prefs` already owns the enumerable half.
- **Building the marketplace.** Reverses an accepted ADR and is a larger decision than this task. Filed as a follow-up instead.
