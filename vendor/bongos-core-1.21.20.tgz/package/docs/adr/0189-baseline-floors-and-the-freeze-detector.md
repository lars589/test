# 0189 — A frozen baseline must justify itself: declared floors and the freeze-forever detector

- **Status:** Accepted
- **Date:** 2026-08-24
- **Tasks:** [#1003210](https://cloudbongos.com/builders#/task/1003210) (goal 1000079 — criterion C4 `reduction-durable`)
- **Builds on:** [ADR 0180](0180-dependency-intake-and-drift-policy.md) (shrink-only baselines), [ADR 0188](0188-patrol-runs-on-ci-not-the-server.md) (the weekly patrol that now files this)
- **Related:** [ADR 0091](0091-bounding-the-kernel-and-db-carve.md) §2 (the boundary-forced duplication that gets the first declared floor), [ADR 0158](0158-choke-point-verdict-taxonomy.md) §2 (findings are advisory)

## 1. Context

`config/fitness-baselines.json` is a shrink-only ratchet: a metric may never
exceed its baseline, and lowering one is how debt gets paid down. It makes
regression impossible.

It also makes standing still invisible. The follow-up audit measured the file at
*"every metric equal to baseline, 0 reduced"* — and the ratchet reported a clean
**PASS**, because that is what it is for. The same green covers the team actively
paying debt down and nobody having looked in a year:

> A shrink-only baseline that never shrinks is indistinguishable from unmanaged debt.

The ratchet has no concept of time, so it cannot tell those apart. Nothing else
did either.

## 2. Decision

### 2.1 Age comes from git, never from a stored timestamp

A `since:` field beside each metric would be faster and hermetic. It would also
be the field that silently stops being updated — leaving old debt looking
permanently fresh. That is *worse* than no check, because it produces confident
green. Git history cannot be forgotten. Where history is unavailable (a shallow
clone), the age is reported **UNKNOWN**, never fresh — the `main-audit.js
--require-roster` doctrine.

A metric's age is the date of the **oldest commit still carrying its current
value**; a metric present unchanged in every commit dates to its introduction,
which is exactly the "recorded once and never revisited" case being hunted.

### 2.2 A metric may declare a FLOOR, and a floor must say why

The naive check — flag anything unmoved for N weeks — fires forever on metrics
that are *finished*. `require_cycle_count: 4` is four deliberate lazy requires
with written rationale. `duplicate_window_count` cannot go below ~28 because that
much duplication is forced by the module boundary (ADR 0091 §2); merging the two
files would break ADR 0083. Nagging weekly about those is how a check becomes one
everybody skips.

So a metric may declare `floors: { name: { value, why } }`, and a metric **at its
floor is done, not stale**. The `why` is mandatory and length-checked: a floor
exempts a metric from the clock permanently, so it must be a written, reviewable
claim. That is the whole point — **silence was the problem**, and this replaces
silence with a sentence someone can disagree with.

A floor exempts only *down to* the floor. `duplicate_window_count` is 59 with a
floor of 28, so the ~31 reducible windows keep counting against the clock. A
floor is not a blanket pardon.

### 2.3 Two severities, split by whose fault it is

| what | where | severity |
|---|---|---|
| a floor names a metric that doesn't exist; a floor has no reason; a floor the metric already dropped below | merge gate (fitness Check 26) | **hard fail** |
| a metric above its floor unmoved for > 8 weeks | fitness **warning** + weekly patrol report | advisory |

Declaration rot is hermetic, needs no git, and is caused by the diff at hand —
that is what a merge gate is for. **Age is nobody's diff.** Failing a PR because
ambient debt turned eight weeks old punishes whoever pushed next and gets the gate
switched off. The audit asked for *"the repeatable, scheduled version"* of the
review it had just done by hand, and the patrol is that: history-wide, time-based,
filed for adjudication.

Eight weeks (`BASELINE_STALE_DAYS`) is long enough that a metric anyone is
actively working is never flagged.

### 2.4 `--update-baselines` had to stop eating the file

The refresh path wrote a fixed object literal — `{_comment: '<hardcoded>',
metrics}` — so a single run silently destroyed the accumulated `_comment` that
documents *why* each number sits where it does. Once floors live in the same file
the stakes change: losing a floor turns a finished metric into permanent weekly
noise **with its justification deleted from the repo**. The writer now recomputes
only `metrics` and passes every other key through untouched.

## 3. Consequences

- Nothing is flagged today: the baseline file is six days old, so no metric can be
  stale yet. This is a tripwire for the future, verified by shrinking the window
  (a 1-day window flags four real metrics) rather than by waiting.
- Paying a metric to its true limit now ends in a written floor rather than in the
  metric quietly sitting at a number forever.
- `duplicate_window_count`, `doc_stale_links`, `doc_broken_anchors`,
  `doc_duplicate_prose`, `console_call_count` and `knip_issue_count` all carry no
  floor, which is the correct claim: every one of them is still reducible.

## 4. Alternatives rejected

- **A stored `since:` per metric.** §2.1 — the field that stops being updated.
- **Flag every unmoved baseline, no exemptions.** Weekly noise about finished
  metrics; the check gets ignored, which is the failure it exists to prevent.
- **A floor without a required reason.** Then a floor is just a mute-button, and
  muting is exactly the silence this replaces.
- **Hard-failing the merge gate on staleness.** Blocks unrelated work on ambient
  debt age; the predictable outcome is the check being removed.
- **Putting it only in the patrol.** A builder editing baselines would never see
  declaration rot until the following Monday, when it is cheap to catch instantly.
