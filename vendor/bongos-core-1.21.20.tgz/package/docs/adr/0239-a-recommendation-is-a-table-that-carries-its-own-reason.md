# 0239 — A recommendation is a table that carries its own reason; governance is a preview and invites are a seam

- **Status:** Accepted
- **Date:** 2026-09-03
- **Tasks:** [#1002336](https://cloudbongos.com/builders#/task/1002336) (this decision — BV1.R17)
- **Goal:** [#1000046](https://cloudbongos.com/builders#/goal/1000046) — Project creation: visibility and
  customization; criteria `proj-module-select` ("additional modules are recommended (rule-based) from the
  project's details"), `proj-governance-reco` ("a recommended governance setup … derived from its details"),
  `proj-invite-builders` ("the owner can optionally invite guilds or top builders")
- **Related:** [ADR 0237](0237-a-starter-bundle-is-a-preset-over-the-always-on-core-keyed-by-declared-type.md)
  (R19, the per-type preset this adjusts), [ADR 0182](0182-project-visibility-two-axes.md) D4 (skipping the
  interview is a supported answer), [ADR 0083](0083-modular-architecture-strangler-build-plan.md) (the
  one-way import rule that makes the invite lookup a seam),
  task [#1002334](https://cloudbongos.com/builders#/task/1002334) (R15, the interview whose answer this reads),
  task [#1002772](https://cloudbongos.com/builders#/task/1002772) (the declared project type),
  task [#1003500](https://cloudbongos.com/builders#/task/1003500) / idea 1000552 (the deferred AI layer)

## 1. The problem

Three of goal 1000046's criteria ask the same question in three places: after an
owner answers the optional project-detail interview, what do we *recommend* — which
modules, which governance setup, which builders to invite. The goal's own text pins
the near term: "near-term recommendations are rule-based and module search is
lexical; the AI/embeddings layer … is a deferred follow-up captured in the idea
inbox."

R19 ([ADR 0237](0237-a-starter-bundle-is-a-preset-over-the-always-on-core-keyed-by-declared-type.md))
already answered the type half — a starter bundle per declared project type — and
said explicitly that it is "a declaration and not a rule engine … R17/R22 own the
layer that reasons." This is that layer.

## 2. Two inputs, and the description is not one of them

The engine reads exactly two things, and they arrive separately because they are
stored separately: `type` is a column (the closed set task 1002772 fixed —
`game · research · business · non-profit · not-sure`) and `team_shape` is the one
closed-answer key the R15 interview collects (`PROJECT_DETAIL_VOCAB.team_shape ∈
solo | small-team | community`). The interview deliberately does not re-ask the type
(ADR 0237 §2), so `recommendationsForDetails({ type, team_shape })` is the file that
puts the two back together, and a caller holding a row passes
`{ type: row.type, ...projectDetail(row) }`.

The interview's *third* answer — the free-text `description` — is deliberately
**not** read. Inferring a bundle from prose is the deferred semantic layer
([#1003500](https://cloudbongos.com/builders#/task/1003500), idea 1000552), and ADR
0237 §7 already rejected it once for the same reason.

## 3. A table, and every row carries the sentence that explains it

The engine is three frozen tables and a resolver over them — not a scorer, not a
weighting, not a model:

| table | keyed on | effect |
|---|---|---|
| `TEAM_SHAPE_RULES` | `team_shape` | add/remove ONE opt-in module from the type's bundle |
| `GOVERNANCE_RULES` | `team_shape` | a named preset out of `GOVERNANCE_PRESETS` |
| `INVITE_RULES` | `team_shape` | a `seeking` descriptor, or `null` for "suggest nobody" |

Every row carries a `reason` — one sentence in the owner's own words, shipped
alongside the effect rather than reconstructed by whichever surface renders it. That
is the constraint that makes the whole thing auditable: a recommendation an owner
cannot be told the reason for is one they cannot disagree with, and a reason written
separately from the rule drifts from it the first time either changes.

The three bundle rules today: `community` **adds** `discord` (somewhere for it to
gather); `small-team` **adds** `dev-box` (one shared environment); `solo` **removes**
`dev-box` (your own machine is the setup). They are few for the reason ADR 0237 §4
gave — today's opt-in catalog is three modules wide, and a preselect an owner must
audit is worse than none. The rules' job is to correct a preset the owner's answer
contradicts, not to re-derive it.

## 4. `adjustments` is a delta — a rule that changes nothing claims nothing

`bundle.adjustments` lists only the rules that ACTUALLY moved the module list. The
game bundle already carries `discord`, so a `community` answer records no adjustment
even though its condition matched; the non-profit bundle has no `dev-box`, so a
`solo` answer removes nothing and says nothing.

The alternative — record the reason whenever the condition matches — was rejected
because it conflates two different sentences: "discord is on because your project is
a game" (the bundle, R19's opinion) and "we switched discord on because you said
community" (the rule). A picker rendering the second over a module the owner would
have had anyway is telling them something they can check and find false.

## 5. Governance is a named preview, never an applied setting

Criterion `proj-governance-reco` says it out loud: the recommendation "depends on the
governance module (goal 1000030), which is planned but not yet built." So a preset
here is a **name plus one sentence of what living under it feels like** — `owner-only`
/ `trusted-team` / `open-contribution` — and never a set of roles or permissions,
because there is nowhere to put them.

Every recommendation carries `governance.applied: false`. A constant field looks
redundant until you count the surfaces that otherwise hardcode the same fact: R25's
preview step ([#1002344](https://cloudbongos.com/builders#/task/1002344)), R18's proof
([#1002337](https://cloudbongos.com/builders#/task/1002337)), the wizard and the
project page. One flag flips when goal 1000030 lands; a test pins it false until then.

## 6. Invites are a seam, because the leaderboard is a sibling module

`invites.suggested` is **always empty**, and that is a decision rather than an
unfinished edge. Ranking builders means querying the leaderboard, which lives in
`economy` — a sibling module `provisioning` may not import (the one-way rule, ADR
0083). Making the route do it instead would cost the engine's purity, put a database
read behind a public endpoint, and duplicate work
[#1002347](https://cloudbongos.com/builders#/task/1002347) (R28) already owns and
whose dependency is R27, not R17.

So the engine emits what to look for — `invites.seeking = { kind: 'top-builders',
limit }`, or `null` for "suggest nobody" — and R28 turns it into names. `null` is a
real answer here: a solo builder is suggested nobody on purpose, which is a different
statement from an empty list nobody has filled yet.

## 7. Skipping is an answer, and every default is the narrowest one

The interview is optional (ADR 0182 D4), so every table has a stated default for
"nobody said" and each is deliberately the narrowest option: the type's own bundle
unadjusted, `owner-only` governance, and no invites. Widening later costs one
setting; a project that quietly granted strangers a role it was never asked to grant
is not recovered by setting it back.

An **off-vocabulary** `team_shape` — absent, misspelled, or a value that has since
left the vocabulary — reads as *no answer*, exactly as `normalizeProjectDetail` drops
it on the way in. The route follows the same rule: a missing or unusable query value
returns 200 with the defaults, never a 400, because refusing the request would make
the supported path an error.

`tailored: boolean` is the machine-readable half of criterion
`proj-detail-interview`'s split ("completing it produces tailored recommendations;
skipping produces sensible defaults") — false exactly when no detail answer shaped
anything. R18 is the live proof of that line.

## 8. The read surface

`GET /provisioning/recommendations?type=&team_shape=` returns
`{ recommendations: { type, teamShape, tailored, bundle, governance, invites } }`.
`bundle` is ADR 0237 §5's shape with `adjustments` added, so R20's picker
([#1002339](https://cloudbongos.com/builders#/task/1002339)) and this engine resolve
through the same `bundleForProjectType` and can never name different modules — a test
asserts that against the live `starter-bundles` route.

`rank: public`, the same absent gate as `starter-bundles` and `onboard-plan`: the
signed-out wizard asks while the owner is still answering, *before* any row exists to
be own-scoped against, and the answer is a declaration that names nothing private.
The route touches no database, and the test proves it by stubbing `pool` to throw.

## 9. Consequences

- **The UI is not wired here.** R20 renders the picker, R22
  ([#1002341](https://cloudbongos.com/builders#/task/1002341)) surfaces these
  recommendations inside it, and R18 proves the details→recs / skip→defaults split.
  The creation wizard currently hardcodes a `TEAM_META` copy table in
  `modules/public-landing/public/projects.html` that says roughly what
  `governance.preview` now says — R22 should collapse that duplicate into this route
  rather than leave one sentence written twice.
- **Adding a fourth team-shape answer is a two-file change.** The interview vocabulary
  and this file, and `tests/provisioning_recommendations.mjs` fails the build if a
  vocabulary value has no governance rule and no invite rule.
- **A recommendation is still never a publish precondition** (ADR 0182 D4 — the bar is
  name + description alone), and taking or declining one cannot move a project's
  dark-matter state.

## 10. Rejected

- **Reading the free-text description** — that is the deferred AI/semantic layer
  ([#1003500](https://cloudbongos.com/builders#/task/1003500)), and the goal pins the
  near term as rule-based.
- **Filling `invites.suggested` from `GET /public/leaderboard`** — the route exists and
  is public, but reaching it means importing a sibling module, and R28 owns that work
  behind a different dependency.
- **A scoring function over weighted signals** — with two inputs and three opt-in
  modules there is nothing to weigh, and a score cannot be shown to an owner as a
  sentence they can disagree with.
- **Recording a reason for every matched condition** — see §4; it makes a claim the
  owner can check and find false.
- **Refusing an unknown `team_shape` with a 400** — skipping is the supported path, so
  the shape of a skipped answer must not be an error.
