# 0282 — A module that spends money for its callers declares so, and the core refuses to enable it where anyone can sign up and nobody is on the hook

- **Status:** Accepted
- **Date:** 2026-09-13
- **Tasks:** [#1003884](https://cloudbongos.com/builders#/task/1003884) (owner decision, 2026-09-13: the agents module must not be enabled on a publicly-enrollable instance until agent spend is attributed to a payer and paid)
- **Supersedes in practice:** [#1001393](https://cloudbongos.com/builders#/task/1001393) (*Autonomy groundwork: server-side spend ceiling that works off-droplet*, abandoned with goal 1000028) — its finding outlived its goal, and §4 below is the answer it asked for
- **Related:** 0083 (modules declare what they are; the core never special-cases one by name), 0016 (authority is resolved server-side, never from a committed file), 0247 / 0182 D6 (the composed join door), 0241 (the precedent for a per-project policy that can hold something)

## Context

`modules/agents` fires a subagent on demand. One fire costs roughly $0.90, takes 60–120 seconds,
and `POST /agents/:name/invoke` answers **202** — the caller does not even wait for it. The route
is gated at `requireBuilder` and nothing else, deliberately: which agents exist at all is an
operator decision, and a v1 agent is hard-read-only by plumbing.

That reasoning bounds **capability**. It does not bound **spend**, and the module says so in its
own code. `lib/fire-budget.js` opens by declaring what it is not:

> A CEILING, NOT A BUDGET. This bounds the blast radius of a loop; it does not decide what agents
> may cost. […] Do not grow this into a budget — a ceiling that silently became the accounting
> would be a second, wrong answer to "what did agents cost".

It then defers the real cap to `agents_runs.cost_usd`. That cap did not exist.

The exposure is the composition of three separate facts, each reasonable alone:

1. a fire is expensive and asynchronous;
2. the invoke route admits any **any-builder**;
3. with the join door `open`, any GitHub account **is** an any-builder seconds after sign-up.

`modules.enabled.agents` is `false` on cloudbongos.com (confirmed live 2026-09-13), so nothing was
leaking. This ADR is what keeps that true on every instance, including ones nobody is watching.

## Decision

### 1. The module declares metered spend; the core never names the module

`module.json` gains an optional block:

```json
"spend": { "requiresPayer": true }
```

It is the module saying *my surfaces can spend real money on behalf of whoever calls them*.

The declaration has to live there rather than in the resolver because fitness Check 10 forbids the
kernel from naming a discovered module key — `src/modules.js` may never write `if (key ===
'agents')`. That constraint is not an obstacle here, it is the better design: the guard is true of
**any** module that says this about itself, so the next metered module inherits it by declaring
one line rather than by someone remembering to widen a list.

The key set is closed, for the reason `contributes` and `maintenance` have closed key sets: a
misspelled `requirespayer` would silently declare **no** spend, and that is the direction that
costs money.

### 2. The refusal is at config load, and it is a wall rather than a precedence level

`src/modules.js` refuses to enable such a module when the project's **composed join door** is
`open` (ADR 0247 — the door, never the `joinability` knob alone) **and** no payer is configured.
The module simply does not resolve on; its routes never mount and its migrations never run.

*Why not at first invoke.* A per-request check would let the module mount, advertise its routes,
run its migrations and read as enabled everywhere the UI reads `modules.enabled` — and then refuse
one caller at a time. That is a broken feature, not a closed door.

*Why it outranks env.* `<PREFIX>_MODULE_<KEY>` is the highest-precedence way to turn a module on
and exactly the knob a hurried deploy reaches for. The refusal is applied **after** config, env and
default alike. A wall that env could outrank would be a suggestion.

*Why an unreadable posture refuses.* Everywhere else in that file an unreadable pack falls back to
the value that changes nothing. Here "I could not tell whether strangers can sign up" has to mean
"assume they can". The cost of being wrong is one module resolving off — and since every module
defaults to off, an instance that never enabled one notices nothing.

### 3. Who pays is a per-project setting, and a run records the answer it fired under

`spend_payer` joins `SETTINGS_VOCAB` — `none` | `project` | `builder` — and rides the same env
transport as its neighbours (ADR 0241's precedent), because the guard reads it before the first
require.

`agents_runs` gains `payer_kind` + `payer_builder_id` (`agents_002_payer.sql`). **Stored, not
derived.** The payer is derivable today from the setting plus `requested_by_builder_id`, and that
is the trap: the setting is a live knob, so deriving would make last month's bill change when an
owner flips it. A ledger whose past moves is not a ledger — the same reason the row stores the
concrete `model` rather than the tier that resolved it.

`none` is **not** a third kind of payer. A run always has a real one, and `none` attributes to the
project, because that is who the money actually came from. `none` does its work at config load
instead. So on a **closed-door** instance the module keeps working exactly as it does today and the
project's own ceiling bounds it; `none` is only ever fatal where it is also dangerous.

An **event** fire has no caller, so `builder` cannot apply to one — nobody asked for it and there
is nobody to bill. It falls to the project, never to "no payer", which would otherwise make the
event path the single unbounded route.

### 4. The ceiling is a second wall, and it fails closed — the 1001393 finding, honoured

`lib/spend-ceiling.js` sums `agents_runs.cost_usd` for the payer over the calendar month and
refuses at the cap. It is deliberately **not** `fire-budget.js` and must never be merged into it:

| | bounds | reads |
|---|---|---|
| `fire-budget` | a runaway loop, in real time | its own sliding window, per **builder** |
| `spend-ceiling` | the **bill** | `agents_runs.cost_usd`, per **payer** |

A rate ceiling cannot bound a bill (ten fires an hour is ~$650/month/builder) and a spend ceiling
cannot bound a loop (it reads spend that has already landed). The ceiling records **nothing** — the
ledger row is the tally, and a second tally is precisely the disagreeing answer `fire-budget`'s
header refuses to become.

Task 1001393 found the autonomy spend-brake **structurally blind**: it read month-to-date spend
from a database unreachable from where the spender ran, so the precheck **failed open** and the
brake never tripped once. A guard that answers "I don't know" with "go ahead" is not a guard. So
this one refuses on every unknown: no cap configured, a non-positive or non-finite cap, no payer, a
ledger read that threw, and a sum that is absent or unparseable. Writing that last case down is not
paranoia — the first draft admitted the fire on a null sum, because `Number(null)` is `0`, and a
test written for exactly this clause is what caught it.

The refusal is **402**, distinct from `fire-budget`'s 429: "this month's money is gone" and "too
fast, try later" are different operator problems, and one status for both hides which.

**The overshoot is stated, not hidden.** A fire is checked before it runs and its cost lands after
it finishes, so in-flight fires are invisible to the read. Overshoot is bounded by concurrent fires
× ~$0.90 — and what bounds the concurrent count is `fire-budget`. Each wall's blind spot is the
other's window, which is the second reason both exist.

## Consequences

- The agents module can be enabled on a closed-door instance exactly as before, now with an
  attributed ledger and a $25/month default cap (`BONGOS_AGENTS_SPEND_CAP_USD`).
- Enabling it on an open-door instance requires one deliberate act: the owner names a payer. The
  warning at config load names the module, the variable and the two words that lift it.
- A default cap of $25 will be too small for some instance, and that instance will discover it as a
  402 with the number in the message. That is the right direction to be wrong in: a generous
  default is how an unbounded bill arrives.
- The constraint that a run which cost money must name a payer is added `NOT VALID`, so it binds
  every write from here on without failing the migration of a self-hosted instance whose history
  predates the column. Those rows stay honestly un-attributed and the ceiling counts none of them.
- **What this does not do:** nobody is billed. `builder` attributes spend to a person; it does not
  collect from them. Turning attribution into a charge is a later decision, and it now has a ledger
  to read.
