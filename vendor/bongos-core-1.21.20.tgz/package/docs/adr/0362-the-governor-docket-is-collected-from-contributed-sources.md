# ADR 0362 — The governor's docket is collected from sources each module contributes, scoped by each source's own atom

- **Status:** Accepted.
- **Date:** 2026-10-01
- **Task:** [task 1004523](https://cloudbongos.com/builders#/task/1004523) (goal 1000125, the Governor City).
- **Builds on:** [ADR 0083](0083-modular-architecture-strangler-build-plan.md) (a module never requires a sibling), [ADR 0016](0016-trust-boundary-server-enforced-permissions.md) (authority is resolved server-side, per request), [ADR 0151](0151-governance-permissions-as-atom-ranks-as-roles.md) (permissions are the atom).

## Context

The Governor City (docs/design/mocks/governor-city/) draws every part of a project's government as a building, with a pin over each open matter, a per-viewer state (needs you, moving, settled) and six readings on the street. Five screen tasks (1004524 to 1004528) all need the same answer to "what is open, where does it stand, and whose move is it".

The matters live in a dozen places owned by five modules and the core: the board (government), blockers (ideas), access requests (onboarding), override requests, removal proposals, criteria awaiting UAT, CI gate approvals and goal join requests (lifecycle), red-team reports (security), the Autobongos fence (autonomy), and the core update (core). Before this, the only cross-source summary was the hall's "Needs your attention" card fetching five endpoints one by one.

Three shapes were open. (a) A core route requiring each module's db: forbidden, core imports no module. (b) A new port per source, resolved by government: twelve ports, each a second surface to keep in step with its list route. (c) The existing `seams.contribute` contribution point, which `/me` already uses for `profile.fields`.

## Decision

**D1 — One contribution point, `governor.docket`.** Each owner contributes its own source from its route factory (the boot hook that runs live and in every test that rebuilds the router), built on the db read its own list route already serves. Where that read was inline in a handler, it was lifted into a function the route and the docket now share (`listAccessRequests`, `listAwaitingGateApprovals`), so there is still one query. `modules/government/docket.js` collects them; `GET /government/docket` serves the result.

**D2 — Each source declares the atom of its own list route, and the collector enforces it.** A contribution carries `gate: { permission }` or `gate: { anyBuilder: true }` (for reads that scope themselves, like a goal lead's join requests, or are public, like blockers). The collector resolves the viewer's permissions once per request and runs a source only when its gate passes. A gated-out source reports `not_yours` and returns no rows. A contribution with no recognisable gate is dropped, never run. `tests/governor_docket.mjs` reads each list route's atom off the route source with the route-rank auditor and asserts the contribution names the same one, so the two cannot drift.

**D3 — Nothing is invented.** A source the design names that nothing records yet (grade appeals, proposals for new standing rules, spending votes) is reported `coming` with a reason; a source whose module is off is `off`; a read that throws or does not answer within four seconds is `unavailable`. None contributes a row.

**D3a — Each reading is answered by the one record that honestly carries it.** Flow: finished tasks at `completed`/`confirmed` and the longest wait (lifecycle). Promises: the building version's done-when criteria, kept of total (lifecycle). Money: the only budget the project records is the unattended-spend ceiling the autonomy gate brakes on, so "money left" is that ceiling minus the month's unattended spend, and the line says so (autonomy, gated `autonomy.precheck`). People: active humans (government). Fairness: open matters at Disputes the viewer can see. Rules at work: the idea routing rule, counted by this month's routed filings (ideas). Module re-checks read the assessment ledger (core_265): a current failed Security gate needs a governor who may ask for a re-check, a pending part is one already running.

**D4 — The board's "needs you" is the summons rule.** A sitting needs a viewer when they are a member under the item's own snapshot, have not cast, are not the subject's author and the clock has not run out. That is `pendingVotesFor`'s rule on `/me`, so the city and the roster never disagree.

**D5 — The route's own gate is the room's.** `GET /government/docket` gates on `board.vote.cast` (xenos floor), pinned in route-rank-check's `GOVERNMENT_PINS`. The real scoping is per source (D2).

## Consequences

- A new source is one `api.contribute('governor.docket', …)` call in its owning module plus a row in `EXPECTED_SOURCES`; nothing in government changes shape.
- The docket fans out to every source on each read. Two sources leave the box (GitHub for gate approvals, without the per-PR file read; the npm registry for the core update, TTL-cached); the timeout keeps either from holding the city.
- When the project records a real budget, the money reading should read it instead of the unattended ceiling; the reading's `value.scope` names what it counts so a screen never mislabels it.
