# ADR 0298 — The grader gets a reader lens: advisory, scoped to copy-bearing diffs, and it waits on a written voice

**Status:** accepted · **Date:** 2026-09-17 · **Task:** [task 1003937](https://cloudbongos.com/builders#/task/1003937) (goal 1000095 — Working area 6, the artist experience)

**Related:** [ADR 0241](0241-the-artist-gate-is-a-per-project-deploy-gate-that-reads-a-state.md) (the artist holds a deploy, never a ship) · [ADR 0242](0242-a-cascade-is-a-declaration-table-on-the-event-that-already-exists.md) (a cascade is a row, not a runner edit) · [ADR 0024](0024-multi-agent-system-architecture.md) (the panel) · [ADR 0233](0233-a-copy-proposal-is-a-task-carrying-a-patch.md) (there is no live CMS)

## Context

Every artist review the cascade files opens with the same instruction:

> STEP 1 — REVIEW THE GRADER, not only the work. Read how the grader judged task N's copy
> and visuals, and coach it: where was it right, and where did it miss what an artist would
> catch? … this step is the one that compounds.

It cannot be followed, and [task 1003937](https://cloudbongos.com/builders#/task/1003937)
established why across four reviews worked on 2026-09-15 — 1003621 (of
[task 1003583](https://cloudbongos.com/builders#/task/1003583)), 1003831 (of
[task 1003761](https://cloudbongos.com/builders#/task/1003761)), 1003833 (of
[task 1003828](https://cloudbongos.com/builders#/task/1003828)) and 1003836 (of
[task 1003829](https://cloudbongos.com/builders#/task/1003829)). The grade itself reads back
fine; `GET /tasks/:id?include=grade` returns scores, verdict, rubric and per-worker notes. The
problem is what comes back. `modules/grading/grader-rubric.json` v4.0 runs four lenses:

| worker | judges |
|---|---|
| `narc` | semantic completion — description vs diff |
| `quality` | code quality (idiom, dead code, tests) + economy |
| `hacker` | security red-team |
| `efficiency` | runtime cost, hot paths |

None of them reads a sentence for whether it is true, clear, in the project's voice, or worth
a person's attention. There is no axis an artist can coach. All four graded tasks passed, and
all four deserved to pass on the axes that were measured — the gate is not too lenient, it is
not pointed at this.

**One partial mechanism already exists, and its limit is the shape of the gap.**
`modules/grading/grader-prompt.js` injects the craft's written responsibility into the panel
prompt — *"No slop in the appearance and text of the project; the story, emotion and ideology
of the project are communicated effectively; project purpose and gravitas are upheld"* — but
only when `task.discipline === 'artist'`. All four graded tasks were engineer ships. So the
unjudged case is exactly **copy shipped by someone whose craft is not the copy**, which is
most of it.

## Decision

A fifth panel worker — the **reader** — scoring a copy/voice axis. Three things were open;
the owner settled all three on 2026-09-17.

### 1. It runs on copy-bearing diffs only, not on every ship

The panel already runs four subagents per ship. A fifth on every ship is a standing spend
increase on the large majority of ships that change no visible string.

The predicate is not new work: `hasCopyOrVisualWork(task)` in `modules/lifecycle/cascade.js`
already decides, for the artist-review cascade, whether a shipped task put copy or visuals in
front of a person — `source === 'copy-proposal'`, `discipline === 'artist'`, or a
`module_key` in the explicit `COPY_VISUAL_MODULES` set. **The reader lens keys off the same
predicate.** One definition of "this ship is copy-bearing", used by both the after-the-fact
review and the at-ship lens, so the two can never disagree about what they cover. Widening
that set widens both at once, deliberately.

Where the predicate says no, the panel is exactly what it is today and costs exactly what it
costs today.

### 2. It is advisory — findings, never a verdict

The reader records `issues[]` and a `copy_score`. It **cannot** verdict `fail`, and it cannot
drag the panel to `concerns`.

This is not caution, it is [ADR 0241](0241-the-artist-gate-is-a-per-project-deploy-gate-that-reads-a-state.md)
applied as written. That ADR settled that an artist's judgement may hold a **deploy**, decided
per project, and never a **builder's ship** — after ADR 0162 retired review gates for stranding
graded-PASS work. A reader worker that could verdict `fail` would put an artist-shaped
judgement back on the ship path, which is the precise thing 0241 removed. Gating it would
require amending 0241 first, and nothing here justifies that.

Advisory is also what makes STEP 1 answerable: the artist's review reads the reader's findings
and coaches *them*, which is a real conversation with a real counterpart, rather than coaching
four lenses that were never looking.

### 3. It waits on a written voice, and does not ship before one exists

A copy lens needs a standard to judge against or it is a second model's taste wearing a
score. The instance's voice is, today, almost entirely unwritten:

| source | what it actually carries |
|---|---|
| `DESIGN.md` | one hard copy rule — no em/en dash in visible copy, no emoji |
| `config/branding.neutral.json` | a tagline and a handful of fixed strings |
| `docs/copy-registry.json` | which 1,860 strings exist — not what good is |
| `src/role-responsibilities.js` | one sentence, and it only reaches artist-discipline ships |

So the build order is fixed: **voice guide first, reader second.** The reader worker is not
started until the guide is written, and the guide is the artist's own work, not an agent's
draft of it. A lens built against the four rows above would be recording opinions and calling
them findings, and that residue would be worse than the silence it replaced — a score nobody
can appeal to a standard is harder to remove than a missing score.

### 4. Until the reader exists, the cascade brief says something an artist can do

STEP 1 stays — the instinct behind it is right and this ADR is the proof that it compounds —
but it stops asking for coaching that has no recipient. In the interim it asks the artist to
record *where the grade missed what an artist would catch*, naming that the record is the
evidence this lens is being built from. That is followable today, it produces exactly the
corpus the voice guide needs, and it converts back into true coaching the moment the reader
lands.

## Consequences

- `modules/lifecycle/cascade.js` — STEP 1 rewritten to an instruction that can be carried out,
  pointing at this ADR. No change to the predicate, the trigger, the anti-recursion guard, or
  the fact that the review blocks nothing.
- Two follow-up tasks are filed at `backlog`, in order, with the dependency edge wired:
  [task 1003976](https://cloudbongos.com/builders#/task/1003976) — the **voice guide** (artist) —
  then [task 1003977](https://cloudbongos.com/builders#/task/1003977) — the **reader worker**
  (engineer, `depends_on` 1003976, so it cannot reach `ready` until the guide ships).
  Neither is started by this ADR.
- The rubric, the active panel, and every existing worker are untouched. No ship's cost or
  verdict changes as of this decision.
- If the voice guide is never written, the reader is never built, and STEP 1 is still honest —
  which is the outcome this ADR is careful to leave standing rather than forcing.
