# ADR 0054 — Flat cost-plus session token reward (example as equity)

**Date:** 2026-06-13
**Context:** GDS-V4, task [#1005](https://example.com/builders#/task/1005). Builds on [ADR 0023](0023-kind-multipliers-and-idea-bonus.md) (per-task kind-multiplied credits), [ADR 0028](0028-honest-llm-spend-accounting.md) (the `llm-pricing.js` token→USD table + session-cost capture), and [ADR 0027](0027-bfg-session-inefficiency-evaluator.md) (the `session_records` upload-on-ship path this reward rides). Complements — does **not** replace — the per-task `credits_reward × kind_multiplier` path. Related future work: the full-transcript capture ADR (planned, task [#1004](https://example.com/builders#/task/1004)) will give this reward a more trustworthy raw-usage source, and the token-feed hardening scoped in task [#1005](https://example.com/builders#/task/1005) itself.
**Status:** Accepted.
**Track:** `internal` (development system / methodology).

## Problem

We are about to onboard the first **incentivized** builders. Today the only payout is per-task `credits_reward` — a unitless number an author sets at task-creation time. It rewards declaring a big number, not doing expensive, real work. The owner's decision (2026-06-13) is to pay builders proportionally to the **true economic cost** of the work they did — the API token spend of the session — plus a margin, with example standing in as **equity** in the project. It must go live today, be idempotent and reversible, and be impossible to inflate with a client-sent dollar figure.

## Decision

Per **shipped session** (the unit; per-task attribution is a later refinement — see the future-review trigger), grant a flat cost-plus reward:

    example = round(true_cost_usd × (1 + REWARD_MARGIN_PCT/100) × 100)   // integer cents
    REWARD_MARGIN_PCT = 20

- **`true_cost_usd` is computed SERVER-SIDE** from the per-model token counts the ship upload already carries (`session_records.model_usage`), priced via `src/bongos/llm-pricing.js` (the locked API list-price table). The client uploads token *counts*, never a dollar figure — that figure is never trusted from the client.
- **`true_cost` is deliberately the API LIST price**, not the builder's discounted subscription cost. A builder on a flat Claude Code subscription obtained those tokens far below list, so paying list-cost + 20% routes the subscription-vs-list spread to the builder as profit *on top of* the margin. This is intended: it is how the reward funds the builder's time and ideas, and it rewards taking advantage of the subsidy.
- **Margin is a code constant** (`REWARD_MARGIN_PCT` in `src/bongos/db.js`), owner-changed via a commit, not a settings UI — the same review-trail rationale as `KIND_MULTIPLIERS` ([ADR 0023](0023-kind-multipliers-and-idea-bonus.md)). A future migration can promote it to a per-builder/per-version table if the economics ever need live tuning. No rank above Archon is introduced; the knob is an owner-scoped policy constant.
- **Idempotent per `session_id`**: a new `credit_log.reason = 'session.token_reward'` row carries a `session_id` column backed by a partial-unique index, plus a SELECT fast-path guard inside the upsert transaction. Re-uploading the same session (re-ship, retry) is a true no-op — no double payout.
- The existing per-task credit path is untouched. Both the token reward and per-task credits accrue to `builders.total_credits` via the existing `pms_apply_credit` trigger.
- **Example = equity units** (owner framing). No special code — it is the interpretation of `total_credits`.

### Two drachma conventions, one ledger (the load-bearing tension)

We knowingly accept that a drachma now means two things on the same ledger: a *unitless author estimate* (the per-task path) and a *USD-cent of real cost + 20%* (this path). We accept this for MVP speed; a future version may reconcile them (re-denominate per-task credits in cents, or split the ledgers). This ADR records the inconsistency so it is a deliberate decision, not a latent bug.

## The residual "rewards waste" risk + the equity mitigation

A flat cost-plus reward pays **more** for a more expensive session — it can reward token *waste* (thrashing, re-reading, long unproductive loops) as much as productive spend. This was raised and explicitly accepted by the owner, for three reasons:

1. **PASS-gated by construction.** Only a *successful ship* uploads a session record, so a session that burned tokens and shipped nothing earns nothing.
2. **Example are equity, not cash.** A builder who pads cost dilutes a pool they themselves hold; the incentive to waste is bounded by the fact that the payout currency is ownership in the thing being built. Early builders want their percentage to be worth something, so they self-police. Inflating the denominator hurts the inflator.
3. **The waste signal already exists.** The BFG session-inefficiency evaluator ([ADR 0027](0027-bfg-session-inefficiency-evaluator.md)) flags wasteful sessions from the same uploaded digest; a later refinement can gate or discount the reward by a quality/efficiency factor, moving from flat cost-plus to cost-plus-adjusted-for-value. The owner's stated direction is to move toward **market dynamics** (bidding) once the builder pool is genuinely multi-party.

## Consequences

- **Migration 090** adds `session_records.model_usage` + `session_records.token_reward_example`, `credit_log.session_id` + the partial-unique index `uniq_credit_session_token_reward`, and bumps the migration counter.
- `llm-pricing.js` gains pure, tested `priceModelUsage` + `canonicalizeModelId`.
- `db.js` gains `REWARD_MARGIN_PCT`, `computeSessionTokenReward`, `awardSessionTokenReward`, and the transactional `upsertSessionRecordWithReward` (the route now calls it instead of the bare upsert).
- `scripts/gds/ship.js` accumulates per-model usage into the digest; `POST /api/gds/sessions` accepts `model_usage`, prices it, and returns `token_reward` on the 201.
- The award is **append-only and reversible**: a compensating negative `credit_log` row reverses any reward without mutating history; the `total_credits` trigger nets it out automatically.
- First incentivized builders can onboard tomorrow with no further code.

## The future-review trigger

Revisit when: (a) per-task token attribution lands (the unit becomes the task, not the session); (b) the grader/BFG efficiency score is wired into the reward (cost-plus → value-adjusted); (c) the two-drachma-conventions tension is reconciled into one unit; or (d) the builder pool becomes multi-party enough to move to market/bidding pricing.

## Amendment — 2026-06-15 (task [#1138](https://example.com/builders#/task/1138)): 1 drachma = $1

**Trigger (c), partial.** An audit of the first incentivized builder's ledger (owner request) found the cents convention had inflated the balance ~100× (one builder, 31 sessions → 295,218 example ≈ $2,952 of cost-plus) and that summing cents-denominated token rewards with the unitless per-task credits made the total incoherent. The owner's decision: **re-denominate the token reward so 1 drachma = $1**, not 1 cent.

**Change to the Decision formula** (supersedes the `× 100` in the formula above):

    example = round(true_cost_usd × (1 + REWARD_MARGIN_PCT/100))   // whole example, 1 drachma = $1
    REWARD_MARGIN_PCT = 20   // unchanged

- The trailing `× 100` (cents) is **dropped**. A $100 true-cost session now mints `round(100 × 1.20) = 120` example (was 12,000). A sub-$0.42 session now rounds to 0 (was ~50) — intended.
- `computeSessionTokenReward` in `src/bongos/db.js` changed accordingly; `tests/credit_grant.mjs` updated; `llm-pricing.js` (the token→USD table) is **unchanged** — only the cents→dollars scale factor moved.
- **History was re-denominated, not left mixed.** Per the "append-only, reversible" rule above, existing `session.token_reward` rows were **not mutated**; a single compensating `credit_log` row (`reason='redenominate.token_reward_dollars'`, `task_id` → [#1138](https://example.com/builders#/task/1138)) restates the running total from cents to dollars, and the `total_credits` trigger nets it automatically. The original cents rows remain as historical record; the `session_records.token_reward_example` display mirror was divided by 100 to match. At amendment time builder `#1` (example-owner) was the only holder of token rewards, so this touched one builder.
- **The per-task `credits_reward` path (ADR 0023) is untouched** — it stays a unitless author estimate. The two-conventions tension (§"Two drachma conventions, one ledger") is now *narrower* (both paths read on a ~dollar scale) but not formally reconciled; trigger (c) remains open for a full reconciliation.

## Amendment — 2026-08-30 (task 1003435): the priced unit is the SESSION, subagents included

**A gap in the Decision's premise, not a change to its formula.** The formula above prices `session_records.model_usage`, and that map was built from exactly one file — the interactive transcript. Claude Code persists Agent/Task-tool spawns in a sibling subtree (`<project-dir>/<session-id>/subagents/*.jsonl`), so a session's subagent tokens were invisible to the reward. The spend ledger had already closed this gap on its side: [ADR 0028](0028-honest-llm-spend-accounting.md)'s `session-cost.js` prices that subtree into its own `session:<redacted> cost row. Only the reward still read one file.

That inverted the methodology's own instruction. CLAUDE.md tells builders to delegate freely and to route most subagent work to the top model tier; following it moved real, productive spend into a bucket the reward could not see, so the same work paid less when it was parallelized. This is **not** the accepted waste risk recorded in §"The residual rewards waste risk" — that section knowingly accepts paying for tokens that turned out wasteful. This was the opposite failure: guidance-following spend that earned nothing.

**Change:** `model_usage` now describes the whole session — the interactive thread plus its subagents subtree. Grader worker transcripts are excluded **by signature**, not by location, reusing `looksLikeGraderTranscript()`, because a grader run can nest inside a `subagents/` dir and its cost is already captured through the worker envelope; re-pricing it would double-count, which is the ADR 0028 invariant.

**The deliberate asymmetry, recorded because it looks like a bug otherwise.** Only `model_usage` grew. `detail`, `metrics.tokens`, `assistant_turns` and `total_tokens` remain the **interactive thread's** record. Those feed the BFG session corpus and the inefficiency evaluator ([ADR 0027](0027-bfg-session-inefficiency-evaluator.md)), which reason about one agent's turn-by-turn behaviour; splicing N subagent transcripts into that per-turn story would distort the very signal it exists to measure, and bloat the payload. So `total_tokens` is deliberately **less than** the sum of `model_usage`, and three counters — `subagent_files`, `subagent_tokens`, `subagent_grader_skipped` — carry the difference explicitly rather than leaving a reader to infer it from a mismatch.

**The acceptance test is a reconciliation, not a fixture.** `tests/credit_grant.mjs` runs both real pricing paths over one on-disk fixture and asserts the reward's `true_cost_usd` equals the sum of that session's `session:<redacted> and `session:<redacted> cost rows within independent-rounding epsilon — so a change made to one side and not the other fails the build. Idempotency is unchanged: the award is still a per-session watermark, so a re-ship pays only the increment and never twice.

**Not done here, and an owner decision:** past parallel sessions were underpaid. History stays append-only; a backfill would be its own task, with the 2026-06-15 re-denomination above as the worked precedent for the compensating-row shape.

## Amendment — 2026-08-30 (task 1003436): the subagent backfill is an instrument first, a payout second

The amendment above fixed the reward forward. This one is about history: every session shipped before it was paid `round(interactive x 1.20)` when it was owed `round((interactive + subagent) x 1.20)`. The owner asked for the backfill; `scripts/gds/backfill-subagent-rewards.js` is it.

**Where the missing number comes from.** Not from transcripts — the subagents subtree lives only on builders' machines and is routinely gone. The spend ledger recorded the leg the whole time: the `cost_log` row with source ending `:subagent` and `source_ref = '<session-id>:sub'` ([ADR 0028](0028-honest-llm-spend-accounting.md)), priced through the same locked `PRICES` table the reward uses. That row is the evidence, and it is per-session.

**The top-up is booked through the normal reward writer, not a private reason key.** `awardSessionTokenReward` gained an optional `extraCostUsd` (default 0, so every existing call site is unchanged), and the backfill passes the recovered subagent dollars into it. That is the load-bearing choice, and it is not cosmetic: the watermark selects on `reason = 'session.token_reward'`, so a backfill written under its own reason would be **invisible** to it and the next ship in that session would pay the same leg a second time. Routing through the real writer means the backfill is just a top-up at a higher `reward_basis` — the `(session_id, reward_basis)` unique index gives idempotency, the no-clawback rule and the legacy refusal keep applying, and a later ship still books only its own increment. All four properties are pinned in `tests/backfill_subagent_rewards.mjs`.

**What it refuses to pay, and why that is the point.** [ADR 0173](0173-legacy-multi-ship-shortfall-not-backfilled.md) declined a structurally similar backfill because the reconstruction was incomplete and correcting in one direction only is a policy choice, not a repair. Rather than repeat that argument or quietly ignore it, the dry-run states the same asymmetries as first-class output. Four classes are reported and never minted:

- **`pre_dedup_fix`** — task 1003217 (landed 2026-08-23T21:50Z) fixed a ~2.22x over-count in *both* the cost ledger and the digest: one API call is written as several transcript lines that repeat the same usage block, and every line was being priced. Cost rows recorded before that fix are inflated, so paying from them would **overpay**. The cutoff is a lower bound, not a guarantee — a machine still on an older core kept writing inflated rows after that date — so `--since` moves it and the report names the dollars parked in this class.
- **`no_subagent_record`** — the cost hook never ran (no token, hard kill, 401). Unrecoverable, and deliberately never estimated from `total_tokens` or a ratio.
- **`pre_split`** — a pre-task-1344 single `session` cost row that lumps both legs and cannot be separated.
- **`legacy`** — the `reward_basis = 0` population ADR 0173 already declined. A different gap with a different signoff; the two are not folded together.

**The report is the deliverable; the mint is the owner's call.** The script is dry-run by default and a live mint needs `--apply` **and** Archon rank verified server-side **and** a typed confirmation. It must run where Postgres is — the box — so the grand total is a number the owner reads before deciding, exactly as blocker 1000113 put ADR 0173's total to them. It writes no `builders` update: `trg_credit_log_apply` (migration 003) bumps `total_credits` on insert, and a second update would double-credit.
