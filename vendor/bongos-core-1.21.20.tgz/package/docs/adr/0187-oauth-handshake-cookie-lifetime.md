# 0187 — The OAuth web-handshake cookies live 30 minutes, and move together

- **Status:** Accepted
- **Date:** 2026-08-24
- **Tasks:** [#1003234](https://cloudbongos.com/builders#/task/1003234) (goal 1000058 — the non-cloudbongos project lifecycle; a walk finding from the 2026-08-24 stranger's-walk review, task 1003232)
- **Builds on:** [ADR 0143](0143-onboarding-repo-picker-oauth-scope.md) (the `gds_oauth_repos` opt-in cookie), #726/#734 (the `gds_return` return cookie and the apex-scoped state)
- **Related:** [ADR 0141](<redacted>.md) (the federated leg shares the same state cookie)

## 1. Context

`GET /api/gds/auth/web/start` sets three cookies before bouncing the visitor to
GitHub: the CSRF **state** (`gds_oauth_state`), the validated **return target**
(`gds_return`) and the **repo-scope opt-in** (`gds_oauth_repos`). All three were
`maxAge: 10 minutes` — written for a hall builder who already has a GitHub
account and is back in seconds.

A founder's first sign-in is not that. The project wizard's gate sends them to
GitHub with `?repos=1`; a stranger with no GitHub account signs up there first,
verifies an email, sometimes sets up 2FA, and comes back. Past ten minutes the
callback found no state cookie and answered **"State mismatch"** — and because
the return and repos cookies had expired with it, the page's "try signing in
again" door was a bare `/auth/web/start`: the founder re-entered without the
repository scope and landed on the default post-login landing, nowhere near
the wizard. The review filed it as a founder-shaped dead end.

The state cookie is CSRF protection for the OAuth callback. Lengthening it is a
security-posture change, not a copy tweak, and the task said so; hence this
record.

## 2. Decision

1. **One lifetime, `HANDSHAKE_COOKIE_MS = 30 * 60 * 1000`, for all three
   cookies.** They MUST move together: a state that outlives its return cookie
   lands a founder on the default landing with no repo scope; a return that
   outlives its state lands them on "State mismatch". The constant lives beside
   the cookie names in `src/bongos/routes/auth.js`; the State-mismatch copy
   reads it rather than hardcoding a number.
2. **Every OAuth error page rebuilds its retry door from whatever cookies are
   still valid** (`recoveryStartHref(req)`: `return` through the same
   open-redirect allowlist as the callback, `repos=1` from the opt-in cookie),
   and so does the access-pending page's auto-walk-in. The lifetime change
   makes the dead end rare; the door change makes it recoverable when it
   still happens.
3. The Discord account-link state cookie is a different flow (an already
   signed-in builder linking an account) and keeps its 10 minutes.

## 3. What did NOT change — the posture, stated plainly

- The state is still **single-use**: the callback clears it (apex-scoped and
  host-only forms) on every path, and GitHub's authorization code is itself
  single-use, so a captured state cannot be replayed into a session.
- Still `httpOnly`, `sameSite=lax`, `secure` behind TLS, apex-scoped — a
  cross-site page cannot read or send it.
- The redirect_uri is still pinned to the canonical origin (#734), and
  `safeReturnTo` still bounds every return target.

What grew is only the **window in which a legitimate handshake may complete**:
an attacker who could fixate a victim's state cookie (already requiring a
foothold this cookie's flags deny) has thirty minutes instead of ten to
complete a login-CSRF against a browser that has not itself finished the
handshake. Thirty was chosen as the smallest round number that comfortably
covers a GitHub signup with email verification; sixty was not needed.

## 4. Rejected

- **Keep the state at 10 minutes and lengthen only `return` + `repos`.** That
  makes the "State mismatch" page recoverable (its door would still carry the
  return + scope) but keeps the dead-end page itself as the founder's
  experience — and it breaks the one-lifetime invariant in the other
  direction, so a builder who *did* come back inside ten minutes could see a
  return cookie from an older, abandoned start. The three move together.
- **A server-side state store with a long TTL.** Correct in the abstract, a new
  table and a sweep for a problem a cookie lifetime solves; not for this task.
- **Sixty minutes.** Wider than the failure needs.

## 5. Consequences

- `tests/auth_web_recovery.mjs` pins the constant, the three `maxAge` sites in
  `/auth/web/start`, the copy that reads it, and the recovery helper by value
  (including the allowlist dropping foreign, protocol-relative and
  `javascript:` returns).
- If GitHub's signup flow ever grows past thirty minutes for a typical
  founder, the constant is the one place to move — and the invariant is that
  all three cookies move with it.
