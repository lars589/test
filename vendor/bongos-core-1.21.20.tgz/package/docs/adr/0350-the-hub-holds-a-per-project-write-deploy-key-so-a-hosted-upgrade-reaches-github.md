# ADR 0350 — The hub holds a per-project WRITE deploy key, so a hosted project's upgraded pin always reaches its GitHub repo

- **Status:** accepted
- **Date:** 2026-09-29
- **Task:** [task 1004291](https://cloudbongos.com/builders#/task/1004291) (follow-up to task 1004065)
- **Deciders:** the owner chose this option on 2026-09-25 (a per-project write key, over keeping the owner's GitHub access longer, or leaving it as is); the shared-account default below was stated in the task and is the safe default, not a new ruling; Claude wrote the record.
- **Amends:** [ADR 0176](0176-private-repo-deploy-keys.md) (which said the deploy key is read-only and that pushes ride the owner's token) · **Related:** [ADR 0281](0281-an-instance-identity-is-its-own-unix-account-and-pg-role.md) (a project's own account and database) · [ADR 0155](0155-adopt-private-repo-widen-oauth-scope.md) (the owner's token)

## Context

When a hosted project's core is upgraded, the pin is committed in the project's checkout and
the hub's runner pushes it to the owner's GitHub repo (task 1004065, `pushUpgradePin`). That
push needs a credential that can WRITE. There were two, and neither lasts:

- the owner's token is stored for one hour after they sign in with repository access
  (`GITHUB_TOKEN_TTL_MS`), and the scaffold path deletes it after use, so an upgrade days later
  normally finds none;
- the checkout's own `origin` is the read-only pull key of ADR 0176 (or the shared alias key),
  which cannot write the owner's repo.

So most upgrades still ended "GitHub was not updated". The box and the repo split, and the
box's local commit stopped its fast-forward pull from taking the owner's new work (the
hermeslines-marketing shape).

## Decision

**D1. A second deploy key per hosted repo, registered writable.** Minted with
`ssh-keygen -t ed25519`, registered with `read_only: false` under its own title
`cloudbongos-pin-<slug>`, distinct from the ADR 0176 pull key `cloudbongos-deploy-<slug>`. The pull key
stays exactly as it was and stays read-only. Registering a deploy key needs repository admin
for the owner, the same requirement the pull key already has. Public repos get one too (they
have no per-repo key today).

**D2. Where it lives and who can read it.** Outside every project checkout, in a directory of
the runner's own account: `PROVISION_PIN_KEY_DIR`, default `~/.config/cloudbongos/pin-keys/`,
directory mode 0700, key mode 0600, born under `umask 077`, and the modes are read back and
the key deleted if they are not exactly 700/600. It is never written into the project's
`.git`, its unix home (`/var/lib/bongos-<slug>`) or anywhere the project's account
(ADR 0281) can read.

**D3. When it is minted.** At standup (scaffold and adopt), right after the ADR 0176 wiring, and
on any later pass that holds a fresh owner token and finds no key: `pushUpgradePin` mints it
before pushing. So an existing project needs the owner to reconnect GitHub with repository
access once; the next upgrade then sets up lasting access. Minting is best effort and never
fails a standup or an upgrade.

**D4. How it is used.** `pushUpgradePin` tries, in order: the write key, then the owner's token
(when fresh), then the checkout's own `origin`. The write key is passed for that one push only
(`-c core.sshCommand="ssh -F /dev/null -i <key> -o IdentitiesOnly=yes -o StrictHostKeyChecking=accept-new"`
against `git@github.com:<owner>/<repo>.git`), with hooks off, no prompt, never forced. A push the
key made that GitHub rejects as non-fast-forward is reported as "behind" and nothing else is
tried, because the credential worked and the history is what stopped it.

**D5. Revoked when the project leaves.** Teardown, and therefore disconnect (which runs the
teardown first), deletes the `cloudbongos-pin-<slug>` registration by title next to the pull
key's, and removes the local key whatever else happened. With no usable owner token the
registration cannot be removed by us; the log names it so the owner can remove it in their repo
settings.

**D6. A project with no account of its own is refused a key (the recorded default).** A project
still running as the shared app user (the `resolveRunAs` fallback, no `bongos-<slug>`
account) has the SAME uid as the runner and could read the runner's key, so no write key is
minted for it, and the deploy page reports "needs its own account first" (repo note code
`needs_account`) instead of offering a reconnect that could not help. The check is fail-closed:
only a positive `id -u bongos-<slug>` counts; an inconclusive probe refuses. If the owner wants a
shared-uid project to hold a write key anyway, that is a new decision recorded here, not a
silent one.

**D7. The deploy page.** The `no_access` note and the reconnect link now say that reconnecting
sets up lasting access, no longer "about an hour".

## What a compromise can and cannot do

- **The runner account** (the hub's app user) already holds the database, the owner tokens and the
  process manager, so it can already do everything the write key can. The key adds, for that
  one account, the ability to push to each hosted owner repo without a live token — one repo per
  key, revocable individually from the owner's repo settings.
- **A project's own process** (its `bongos-<slug>` account, ADR 0281) can read the read-only pull
  key, exactly as before, and can NOT read the write key: wrong owner, directory 0700. It
  therefore cannot push code into the owner's repo, which is the point of keeping the key
  outside the checkout. A project on the shared account can, which is why D6 refuses it a key.
- **GitHub or the network** learn only the public half. A leaked write key can push to that one
  repository until the owner deletes it in their settings; it cannot read other repos, and it
  is a per-repo deploy key, not an account token.

## Alternatives rejected

- **Keep the owner's token longer.** A long-lived account-wide token in the hub is a bigger
  prize than a per-repo key, and it still lapses when the owner revokes the OAuth grant.
- **Leave it as is.** Most upgrades keep ending in a split that blocks the owner's own pushes.
- **Make the pull key writable.** It lives in the checkout, readable by the project's own
  account, so a compromised project could push code to the owner's repo.

## Consequences

- Existing projects get the key on the next runner pass after the owner reconnects GitHub with
  repository access; until then the deploy page still reports "GitHub was not updated" with the
  corrected copy.
- Reconciling an already-split repo (hermeslines-marketing) and auto-rebasing a pin onto newer
  GitHub commits stay out of scope; both are still reported, not resolved.
- Code: `scripts/gds/provision-pin-key.js`, `pushUpgradePin` in
  `scripts/gds/provision-core-upgrade.js`, the revoke in `scripts/gds/provision-teardown.js`,
  the copy in `modules/hall-ui/public/deploy.js`; tests in `tests/pin_write_key.mjs`.
