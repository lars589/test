# ADR 0180 — Dependency intake & drift policy

**Date:** 2026-08-19
**Context:** Task 1003127 (goal 1000076, criterion `dependency-watch`). Grounded in the red-team baseline audit ([`docs/audits/ai-dev-redteam-baseline.md`](../audits/ai-dev-redteam-baseline.md) §3): 18 known advisories (2 high) sat unwatched in the 9 production dependencies, the `undici` override pinned a vulnerable range while also breaking Node 26 CLIs, and nothing gated what an agent may `npm install`. Threat backdrop: the 2025 npm wave (chalk/debug takeover, the Shai-Hulud self-replicating worm, the Nx postinstall stealer) ran on **install-lifecycle scripts** and **stale long-lived publish tokens**.
**Status:** Accepted.

## Decisions

### 1. CI audit gate with a shrink-only baseline

`scripts/gds/audit-gate.js` runs in the required `unit` workflow: `npm audit --omit=dev --json`, deduped to advisory×package findings, compared against the committed [`config/audit-baseline.json`](../../config/audit-baseline.json).

- A **new high/critical** advisory (not in the baseline) **fails the merge gate**.
- New low/moderate advisories warn; a baseline entry that stops reproducing prints a ratchet-down nudge.
- The baseline records **pre-gate debt only** (10 findings, 3 high+ at adoption). It shrinks via fix tasks; adding an entry to silence a *new* advisory defeats the gate and is out of policy.
- **Fail-open on infrastructure, fail-closed on findings:** a registry outage or unparseable audit output warns and exits 0 — the gate catches new advisories, it does not prove registry uptime.
- Blanket `npm audit fix` does not run against this tree (`workspace:` protocol in the dependency graph, `EUNSUPPORTEDPROTOCOL`) — one more reason fixes are explicit tasks, not autofix side effects.

### 2. Install-lifecycle scripts are off (`.npmrc ignore-scripts=true`)

The dominant live npm attack vector is the postinstall script. This tree needs none: **sharp** (the only native dep) installs prebuilt binaries via `optionalDependencies`, verified by a script-less `npm ci` followed by a sharp load (`vips 8.17.3`) and the full 430-test suite. `npm test`/`npm run` are unaffected (npm only suppresses install-time lifecycle hooks). A future dependency that genuinely needs an install script is an ADR-level exception with justification, not a reason to flip the flag.

### 3. Update cooldown: patrol-enforced now, npm-native later

The consensus post-Shai-Hulud control is a **release-age cooldown** (don't install versions younger than a few days; let the ecosystem catch registry malware first). npm supports this natively from 11.10 (`minimum-release-age`), but the CI toolchain (Node 22 → npm 10) would warn on the unknown key for every builder. So:

- **Now:** the weekly red-team patrol (task 1003128) flags any dependency bumped to a version **younger than 7 days** at install time, plus stale overrides (the `undici ^6.27.0` case — pinned inside a vulnerable range) and unpinned workflow actions.
- **Later:** when the toolchain floor reaches npm ≥ 11.10, move the cooldown into `.npmrc` and drop the patrol's version-age check.

### 4. Publish auth: OIDC trusted publishing, token as documented exception

The publish-on-merge lane (ADR 0161) authenticates with a long-lived `NPM_TOKEN` repository secret — exactly the credential class the Sept-2025 attacks monetized, and why GitHub revoked classic tokens and capped granular ones at 90 days. Decision: **adopt npm trusted publishing (OIDC)** — no long-lived secret, provenance for free. It needs a one-time owner action on npmjs.com (register the repo+workflow as a trusted publisher for `@bongos/core`), filed as a blocker. **Until then** the granular `NPM_TOKEN` remains a *documented exception*: 90-day expiry, publish-only scope, rotated on expiry.

> **Landed 2026-08-25 — task 1003202, blocker 1000115 resolved.** The owner registered the trusted publisher; `publish.yml` now carries `id-token: write` and publishes with no secret. Three things this needed that the decision above did not anticipate, each of which fails SILENTLY if missed:
>
> - **npm ≥ 11.5.1.** Node 22 ships npm 10.x, which ignores the OIDC token and publishes unauthenticated. The lane now installs a pinned npm and refuses to continue below that version.
> - **Provenance had to be turned OFF.** Trusted publishing enables it by default and npm *refuses* to generate provenance from a **private source repository** — so the "provenance for free" clause above does not apply to this repo, and leaving the default would have failed every publish.
> - **The registry could no longer answer "is this version taken?".** `@bongos/core` is private, so an unauthenticated `npm view` is a flat `E404` rather than a "no", and OIDC authenticates `npm publish` and nothing else. Keeping that check would have skipped the auto-bump on every run and collided on the published version — **breaking after exactly one release**. The lane now reads its own `release: core X.Y.Z` commits (`laneReleasedVersions`), which need no auth and are the source the cascade terminator already trusts.

> **Closed 2026-09-18 — task 1003262. Migrating the lane is not the same as deleting the credential, and for three weeks only the first had happened.** `publish.yml` stopped using `NPM_TOKEN` on 2026-08-25 and the repository secret was removed, after which this ADR, [ADR 0161](0161-publish-on-merge.md) and the red-team follow-up all recorded that "no long-lived npm credential exists to steal". That was true of the *repo* and false of the *npm account*: the granular write token `ci-publish-on-merge` (scope `@bongos`, package:write, 2FA-bypass, expiring 2026-11-06) was never revoked — it simply stopped being used, which produces no signal at all. A credential nothing reads is not a credential nothing can use.
>
> The same shape a second time, for reads: `droplet-registry-read` outlived [ADR 0283](0283-the-core-publishes-publicly-because-access-was-never-the-thing-protecting-it.md)'s public flip and `fcea51ca`'s deletion of every code path that consumed it — and that one had already leaked, in cleartext, into the droplet's persistent journal (blocker 1000118).
>
> **The rule this adds: a credential is retired when it is revoked at the issuer, not when the last caller stops passing it.** Removing the use is the safe half and the reversible half; it is not the finish. Both tokens are enumerated in this task's ship notes, and `npm token list` is the check — the repo cannot answer this question about itself, which is why nothing caught it.

## What this deliberately does not cover

New-dependency *intake vetting* (registry existence/age/download checks — the slopsquatting defense) lives in the weekly patrol (task 1003128), and one-off vulnerability *fixes* (sharp ≥ 0.35 for the libvips CVEs, the colyseus chain for nanoid) are ordinary tasks that shrink the baseline — filed in the idea inbox at adoption time.
