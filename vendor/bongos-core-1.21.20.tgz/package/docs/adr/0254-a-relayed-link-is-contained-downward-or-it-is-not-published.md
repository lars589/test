# ADR 0254 — A relayed link is contained downward, or it is not published

- **Status:** accepted
- **Date:** 2026-09-06
- **Task:** [task 1003670](https://cloudbongos.com/builders#/task/1003670) (BONGOS-V1, goal 1000046 — *Project creation*, criterion `proj-visibility-states` / C1) — the gap [ADR 0252](0252-the-self-hosted-visibility-report-is-a-pull-and-auto-appear-buys-a-retraction-lever.md) §5 named and filed rather than left
- **Deciders:** Claude, building the task ADR 0252 §5 opened
- **Related:** [ADR 0252](0252-the-self-hosted-visibility-report-is-a-pull-and-auto-appear-buys-a-retraction-lever.md) §3/§5 (auto-appear, and the condition it was granted on) · [ADR 0253](0253-the-takedown-lever-has-two-writers-and-provenance-is-a-column.md) §2 (*narrowing is free; widening is what costs* — the asymmetry this applies again) · [ADR 0182](0182-project-visibility-two-axes.md) D2a (redaction is server-side, because the page cannot be the gate) · [ADR 0171](0171-profile-rollup-join-and-consent.md) D7 (validation lives next to the data, where no caller can forget it) · [ADR 0114](0114-instance-docs-discovery-contract.md) (the discovery index this value arrives on) · [ADR 0083](0083-modular-architecture-strangler-build-plan.md) (the module boundary the shared file sits inside)

---

## 1. The defect: "differs from" is containment inverted

`hall_origin` is the project's builders'-hall address on the public projects feed. It comes
from the REMOTE instance's own discovery index (`GET <origin>/api/bongos` → `index.hall`,
read in `modules/platform-identity/project-stats.js`), and the hub renders it as an
`<a href>` on `/projects`, under that project's name.

Its only check was that the advertised host **differed** from the project's own site host.
That is not a weak containment rule; it is containment turned inside out. It admits every
host on the internet and refuses exactly one — the one that is certainly safe. An instance
answering

```json
{ "hall": "https://evil.example/builders" }
```

got that link published on the hub, on the hub's domain, attached to the victim's project.

The rule was written for a different question ([task 1003257](https://cloudbongos.com/builders#/task/1003257),
owner decision (a): *a door only where it opens somewhere else*) and it answers that
question correctly. Nothing was ever asked to answer the security one.

**Why it stopped being survivable.** Under control-plane provisioning the set of origins the
hub would ever fetch was bounded by whom the operator had provisioned. [ADR 0252](0252-the-self-hosted-visibility-report-is-a-pull-and-auto-appear-buys-a-retraction-lever.md)
§3 replaced that bound with *whoever points a domain at the hub*, and §5 named this gap in
the same breath — auto-appear turns a curated-origin risk into a phishing hop anyone can
mint. Auto-appear was granted on the condition that its guards ship; this is one of them.

## 2. Decision — the same downward-only rule, with one home

`hall_origin` is bound by the rule the corpus already had one field over: a relayed URL must
point **at or below** the origin that reported it. Concretely, a hall link survives only as
the project's own host or a **dot-anchored subdomain** of it, `http(s)` only, with no
embedded credentials, and **refused whole at the length cap rather than truncated** —
slicing a URL changes where it points, so a shortened one that still parses is worse than
no link.

Containment runs **first**; the existing "is this a different door" test runs second and is
unchanged. The two compare different things on purpose: containment compares **hostnames**,
because a port is not a trust boundary; the door test compares **hosts with the port**,
because a hall on another port of the same machine really does open somewhere else. Net
effect: a hall link is published only for a strict subdomain, or another port, of the
project's own origin.

**The rule now has exactly one home.** `shipUrlWithinClientOrigin` was a private helper
inside `platform-identity.js`; it is lifted to `modules/platform-identity/origin-containment.js`
as `urlWithinOrigin(raw, origin, max)` and required by both callers. This is not tidying:
the defect *was* two surfaces answering one question differently, and leaving the answer
where only one of them could reach it is what let them differ. (The rename is why ADR 0252
§5's `shipUrlWithinClientOrigin` no longer greps; ADR 0252 is left as written, per the
[ADR 0253](0253-the-takedown-lever-has-two-writers-and-provenance-is-a-column.md) §1
convention that a decision record is not edited after the fact.)

Its own file, rather than a shared symbol left in place, for the reason a row of siblings in
this module already give in their headers: `platform-identity.js` is **at** the 1500-line
file-size ratchet with no headroom, and `project-stats.js` is a different file besides. The
lift shrinks `platform-identity.js` by 11 lines, so the ratchet is paid rather than fought.
It is deliberately **not** re-exported from `platform-identity.js` — a re-export would be a
third name for one answer, and no caller needs it.

## 3. Downward only, and the cost of that stated plainly

The mirror rule — *the link host is an ANCESTOR of the reporting origin* — looks symmetric
and is not. On a shared multi-tenant apex it lets an instance registered at `foo.github.io`
publish links on bare `github.io`, which it does not control, and by extension vouch for
every neighbour under it. The upward direction is not offered, here or for ship links.

**What that costs, named rather than discovered later:** a project whose hall is a *sibling*
of its site — site `www.example.com`, hall `builders.example.com` — loses the hall glyph on
the hub. The hall is still reachable and the project is otherwise unaffected; the hub simply
stops vouching for the address. That is [ADR 0253](0253-the-takedown-lever-has-two-writers-and-provenance-is-a-column.md)
§2's asymmetry applied again — **narrowing is free; widening is what costs** — and the only
rule that would admit the sibling is the one that hands away the apex.

## 4. Rejected

- **Mirroring the check in the browser** (`modules/public-landing/public/projects.html`
  already scheme-checks and re-applies the door test client-side). Rejected: the page is not
  the gate ([ADR 0182](0182-project-visibility-two-axes.md) D2a — a client-side filter still
  ships the value to anyone who opens a network tab), the server is now the only producer of
  the field, and a second copy of a containment rule is precisely the drift this ADR exists
  to end. The existing client-side scheme check stays as cheap defence in depth.
- **An allow-list of hall hosts per project.** A stored second address the owner would have
  to maintain, to answer a question the origin already answers.
- **Keeping the rule private and copying it into `project-stats.js`.** The cheapest diff, and
  it re-creates the defect's cause in a new place.
- **Truncating an over-long URL at the cap** (what `project-stats.js:httpUrl` does for an
  `<img src>`). Fine for a display bound, wrong for a containment decision: the truncated
  string still parses and addresses somewhere nobody reported.
- **Making the door test compare hostnames too**, which would fold both tests into one
  comparison. It would silently drop a legitimate same-host, different-port hall — a
  behaviour change this task was not asked for and that no security argument supports.

## 5. Consequences

- **A hall link on the hub can only ever address the project it is filed under.** The one
  free-text URL a remote instance could put in front of hub visitors is now bounded by the
  instance's own domain.
- **One rule, one file, two callers** (`sanitizeRecentShips` and `hallOrigin`). A third
  surface that relays a third party's URL has somewhere to go, and a test file that already
  states the attack matrix.
- **`shipUrlWithinClientOrigin` no longer exists by that name.** Its behaviour is unchanged
  — the ship-link proofs pass untouched — but prose and ADRs citing the old name (including
  ADR 0252 §5) now point at `origin-containment.js:urlWithinOrigin`.
- **One guard was added on the way in:** an origin with no host at all (`file:`, `data:` — a
  stored value is not a validated one) is refused outright. The old suffix test would have
  matched a legal trailing-dot FQDN such as `evil.example.` against the bare `.` such an
  origin leaves behind.
- **A sibling-hosted hall loses its glyph on the hub** (§3). No project loses its hall.
