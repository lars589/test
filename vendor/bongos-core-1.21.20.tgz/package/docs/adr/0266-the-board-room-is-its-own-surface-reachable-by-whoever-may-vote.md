# 0266 — The Board Room is its own surface, reachable by whoever may vote

- **Status:** Accepted
- **Date:** 2026-09-08
- **Tasks:** [#1003734](https://cloudbongos.com/builders#/task/1003734) (this record). Executed by [#1003735](https://cloudbongos.com/builders#/task/1003735) (the carve), [#1003736](https://cloudbongos.com/builders#/task/1003736) (the deep links), [#1003737](https://cloudbongos.com/builders#/task/1003737) (the waiting-vote count).
- **Goal:** [#1000111](https://cloudbongos.com/builders#/goal/1000111) — Working area 7, Government; criterion `wa7-government`.
- **Decided by:** the owner (Masterqua / `IAMMASTERQUA`, Archon, member of area 7), 2026-09-08.
- **Builds on:** [ADR 0175](0175-the-board-room-full-idea-ratification.md) (the Board Room, and §6 — who governs is configuration), [ADR 0157](0157-archon-is-rank-and-identity-only.md) (the `page.view.government` floor at metic), [ADR 0151](0151-governance-permissions-as-atom-ranks-as-roles.md) (permissions as the atom), [ADR 0016](0016-trust-boundary-server-enforced-permissions.md) (server-enforced, uncached, per request).
- **Related:** [ADR 0174](0174-government-terminology-ranks-not-roles.md) (government, not governance).

## 1. Context — the room with no door

The Board Room is the hall's only upward-pointing gate (ADR 0175): the surface
on which a Full Idea that cleared the completeness bar is ratified, and the only
surface on which the constitution itself can be amended. It ships today as a
**hash tab** (`#board-room`) inside the `/government` page, beside Permissions
and Constitution.

Two facts about that placement do not survive inspection.

**The nav never followed the page.** When R16 turned `/government` into three
rooms it correctly widened the *page* gate from `government.manage` (archon) to
`page.view.government` (metic+). The comment it left in
[`serve-internal.js`](../../src/bongos/serve-internal.js) states the principle
plainly — *"The shell follows the widest legitimate audience — the audience
changed when the page did."* But `modules/hall-ui/public/shell.js` still
declares that nav item as `label: 'Permissions'`, `gate: 'archon'`. So the page
widened and the door did not: a Metic who sits on the board has **no nav link to
the Board Room at all**, and the only word an Archon sees in the nav is
"Permissions", which does not suggest a voting room is behind it. Every other
government room — Watch, Harbor, Gate, Sessions — carries its own nav item. The
Board Room is the one room reachable only by knowing a URL fragment.

**The surface is narrower than the franchise.** `board.vote.cast` floors at
**xenos**, and that is deliberate: `modules/government/board.js:149` records the
floor is low *so that widening the board works*. The page shell requires
metic+. Today `membership: rank:archon` and every Archon clears both, so the
contradiction is latent. The moment a constitution widens membership below
Metic — the exact act ADR 0175 §6 exists to make a configuration change — those
members may cast a vote through the API and **cannot load the page they would
cast it on**.

The second is the load-bearing one. ADR 0175 §6 put membership, pass rule and
window in `config/government.json`, resolved per request and uncached, so that
"flipping the switch later changes numbers, not a code path that has never run."
A page gate keyed to a different atom than the vote reintroduces exactly the
code-path change that decision removed.

## 2. Decision

### 1. The Board Room becomes its own page at `/board-room`

Carved out of `/government`, which keeps Permissions and Constitution. It joins
Watch, Harbor, Gate and Sessions as a first-class room in the Government nav
group, with its own nav item.

The alternative — leaving the tab in place and adding a nav item that deep-links
to `/government#board-room` — was considered and rejected. It is cheaper and it
preserves the existing hash links for free, but it leaves the voting room inside
a page whose gate answers a different question, which is defect (2) above left
standing. The room that constrains the owner should not be a tab inside the
owner's admin page.

### 2. Its reach follows `board.vote.cast`, not `page.view.government`

The page gate resolves the **same atom the vote route checks**. The surface
reach and the right to vote become one thing, and widening the board stays a
configuration change.

`board.vote.cast`'s floor is only the coarse gate. **Membership is still checked
in-handler, per item, against that item's own snapshotted constitution** — the
floor decides who may receive the shell, never who may vote on what. A builder
who clears the floor but sits on no board sees the room and no ballot, which is
the correct and honest state: ADR 0175 §9 made the ballot open on purpose,
because "a board whose votes are invisible cannot constrain anyone."

### 3. The old deep links are migrated client-side, because a fragment never reaches the server

`#board-room` is a URL fragment. It is **not sent to the server**, so no
server-side route or redirect can ever see it. The compatibility path is
therefore a client-side redirect in `government.js`: on load, a `#board-room`
hash sends the browser to `/board-room`, preserving `?item=N`.

This is recorded as a decision rather than left as an implementation note
because it is the thing a reader will otherwise get wrong — adding
`GOVERNMENT_BOARD_RE` to `serve-internal.js` looks like the obvious fix and
silently never fires.

Three writers emit the old form and all three move (task
[#1003736](https://cloudbongos.com/builders#/task/1003736)): the Discord
window-open announcement (`modules/discord/board-broadcast.js`), the
`board_votes` need's action href (`modules/builder-settings/builder-needs.js`),
and the docs. The redirect stays for at least one release regardless, because
announcements already sitting in Discord channel history carry the old link
forever and ADR 0175 §8 makes that mention the "vote within X" notice.

### 4. A waiting-vote count belongs on the nav item, and the hall has no mechanism for one

The owner's second ask was to see that items are waiting **without going
inside**. The data already exists and needs nothing new server-side:
`boardVotesNeed` (`builder-needs.js`) carries a live count and the oldest
waiting item id, pre-filtered to what the vote route would actually accept, and
`GET /me` already serves it.

What does not exist is any badge, bell, dot or count mechanism in
`shell.js` — the nav renders label and icon and nothing else. Task
[#1003737](https://cloudbongos.com/builders#/task/1003737) adds that once,
generically, so a second consumer can adopt it without a second pattern. Zero is
silent, and the badge is visible to exactly whoever the nav item is: a count is
board activity, and it must not leak to someone who cannot see the room.

A **sound** is deliberately out of scope. The instance ships `alert.wav` and
`chime.wav`, so it would be easy and it was not asked for.

## 3. Consequences

**The `/government` tab strip loses a room, and that is the point.** Two rooms
remain, both administrative, both correctly behind the archon-shaped item they
already sit behind. The existing Permissions nav item keeps `gate: 'archon'` —
it *is* the archon admin surface, so that gate was never wrong for it. It was
wrong as the only door to three rooms.

**Widening the board becomes a real config change.** After this, an instance may
set `membership: rank:metic` — or wider — and the members it names can actually
reach the room. Before it, that edit produced members who could vote only by
`curl`. This is the property ADR 0175 §6 claimed and did not have.

**One more page joins the statically-parsed gate map.** `tests/hall_page_gate_map.mjs`
rebuilds the URL→gate map by parsing `serve-internal.js` as text, so the new
`const BOARD_ROOM_PAGE_RE = /…/;` must keep the bare form with nothing between
the `=` and the literal — a comment in that gap drops the regex out of the map
and the page silently tests as ungated. The file already records this rule at
`PROJECT_SETTINGS_PAGE_RE`; this ADR notes it because the failure is invisible.

**A defect found while scoping this, filed separately.** The hall renders needs
as a *single slot* (`needs.items.find(n => n.state !== 'satisfied')`), and
`computeNeeds` sorts only by state with a stable sort — so inside the
`action_needed` bucket the registry array order decides, and `boardVotesNeed` is
fourth, behind `artKeyNeed`. Any builder with an unresolved image-generation key
therefore never sees the board notice at all. It was live for the owner of this
decision at the moment they asked for the bell. Filed as
[#1003738](https://cloudbongos.com/builders#/task/1003738) rather than folded in
here: the badge and the banner are two surfaces, and fixing the ordering is a
change to what every need in the hall does.

**Rejected: a bell in the global header rather than on the item.** A header bell
is a second inbox — it needs its own read/unread state, its own dismissal
semantics, and a home for notifications that are not board votes. The ask was to
see the count on the section, and the nav item is where the reader already looks
for the room.
