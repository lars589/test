# 0250 — Strict versioning: the version boundary is the scope gate

- **Status:** Accepted
- **Date:** 2026-09-06
- **Tasks:** [#1003589](https://cloudbongos.com/builders#/task/1003589) (this decision), seeded by the planning session `#1003586`. The implementation is BV1.R03–R30 under the same goal.
- **Goal:** [#1000086](https://cloudbongos.com/builders#/goal/1000086) — Strict versioning: a goal cannot outlive its tasks, and a version's goal set is closed.
- **Builds on:** [ADR 0086](0086-goal-scoped-work-hierarchy.md) (Project → Version → Goal → Criteria → Task — the hierarchy this decision finally closes at the top), [ADR 0015](0015-task-dependencies-and-auto-promotion.md) (deps are load-bearing, the rank prefix is decorative), [ADR 0183](0183-criteria-close-themselves.md) (a criterion satisfies itself when its tasks ship).
- **Amends:** [ADR 0157](0157-archon-is-rank-and-identity-only.md) — for one key, `version.create`. See §6.

## 1. The problem, measured

The hierarchy has a bottom and no top. Tasks close, criteria close, goals close —
and a version never does. Measured on the live instance:

| | 2026-09-04 (planning session) | 2026-09-06 (this ADR) |
|---|---|---|
| Goals on BONGOS-V1 | 62 | 64 |
| Closed goals still holding unfinished tasks | 10, holding 28 | **14, holding 35** (both versions) |
| Open tasks across open goals | 502 | **523** |
| Versions `building` on one project | 2 | 2 (`BONGOS-V1`, `CB-V1`) |

The second column is not a re-count for its own sake. Two days of ordinary work
made every number worse, which is the argument: nothing in the system pushes
back, so the drift is not a backlog to clear once — it is the steady state.

"Closed goals still holding unfinished tasks" is the sharp one. Fourteen goals
report `achieved` or `archived` on every surface a person or an agent reads,
while thirty-five tasks inside them are still `ready`, `backlog`, `active`,
`completed` or `confirmed`. A goal that says it is done and is not is worse than
no goal at all: `/status` rolls it up as delivered, the board stops showing its
work, and the tasks become unreachable except by direct id.

## 2. The cause is mechanical, not social

No one decided any of this. Four gaps in the code produce all of it:

1. **`POST /goals` never reads the version's status** ([`modules/lifecycle/routes/goals.js`](../../modules/lifecycle/routes/goals.js)). It fetches the version row to validate the id and ignores `status`, so a goal can be added to a version that has been building for months. That is how a version's scope grows without anyone widening it.
2. **Goal achievement is computed from criteria alone** ([`db-goals.js`](../../modules/lifecycle/db-goals.js) `achieveGoalIfComplete`, and the cascade in [`done-when.js`](../../modules/lifecycle/done-when.js)). Neither writer consults `tasks`. Since [ADR 0183](0183-criteria-close-themselves.md) criteria satisfy themselves on ship, the path from "the criteria I happened to link are satisfied" to `achieved` is fully automatic — and a task nobody linked to a criterion holds nothing open.
3. **`POST /goals/:id/archive` checks nothing at all.** Archiving is a single call that discards whatever the goal was holding, silently.
4. **No route ships a version.** Version status has only ever moved by hand-run SQL on the droplet; `scripts/gds/version-close.js` prints that the API cannot do it. A thing with no closing move does not close.

Each gap is small. Together they mean the version boundary — the one line that is
supposed to say *this much and no more* — has no enforcement anywhere.

## 3. Decision

**The version boundary is the scope gate.** A version's goal set is fixed when
the version starts building; a goal stays open until its work is genuinely
finished; and a version can reach done. Five rules:

**D1 — The goal set closes when the version starts building.** New goals may be
created freely on a version in `planning` — that is where the *next* version is
scoped, in advance and at leisure. `POST /goals` reads `version.status` and
refuses anything else with a named 409 an agent can act on.

**D2 — A goal cannot close while it holds non-terminal work.** A goal reaches
`achieved` only when its criteria are satisfied **and** no task in it is
non-terminal. Terminal means `shipped` or explicitly `abandoned` — the vocabulary
declared once in [`modules/lifecycle/task-status.js`](../../modules/lifecycle/task-status.js) ([task #1003588](https://cloudbongos.com/builders#/task/1003588)). `completed` and
`confirmed` are mid-ship states that can still fail a grade or strand, so they
hold the goal open. **Shipping is never blocked by this** — only the goal's flip
to `achieved` is. Both writers gain the check, and the cascade's copy runs on the ship
transaction's own client so it sees uncommitted flips.

**D3 — Killing a goal is one recorded decision.** Archiving a goal that still
holds open tasks returns those tasks and refuses until the caller says what
happens to each: abandon with the archive's reason, or move to a named surviving
goal. Archiving a goal with nothing open stays a single call.

**D4 — Every task belongs to a real, open goal.** `goal_id` becomes required at
creation, the per-version catch-all fallback is deleted, and no vector can put a
task into a closed goal.

**D5 — Exactly one version builds per project, and the next is scopeable while it
runs.** The server refuses a second `building` version. A version auto-closes
when its last non-maintenance goal achieves; an Archon may close one early, with
a per-goal disposition (roll forward as a successor goal, or abandon). The single
`planning` version promotes itself on close, so the project is never without a
live train.

### The override, and why it is not a loophole

D1 without an escape hatch would be a rule people route around instead of using —
the standard failure of a hard scope gate is a fake "hotfix version" cut to hold
the thing that did not fit. So: an **Archon may admit one named goal to a building
version, with a reason**, and the overrides are **counted and shown on the
version**. A visible counter is what keeps the exception honest; an override that
leaves no trace is just a slower version of no rule.

The maintenance goal is the other pressure valve. Each version carries one
auto-created maintenance goal, exempt from the auto-close count, whose open bugs
carry forward — because bugs arrive on their own schedule and must not need an
override to be filed.

## 4. What this is not

- **Not a new gate on shipping.** Nothing here can refuse a ship, block a claim, or park a task. Every rule acts on a *closing* move — goal achievement, goal archive, version close, goal/task creation. A builder's day is unchanged unless they try to close something that is not finished.
- **Not a re-litigation of [ADR 0183](0183-criteria-close-themselves.md).** Criteria still satisfy themselves. D2 adds a second condition to the *goal's* flip, not a human gate in front of the criterion's.
- **Not a change to what `abandoned` means.** [Task 1002651](https://cloudbongos.com/builders#/task/1002651) already made abandoned terminal; D2 relies on that and adds nothing.

## 5. Rejected alternatives

- **Count `completed`/`confirmed` as finished.** It would close the visible symptom with one word and is wrong: those states can fail a grade, strand at `confirmed`, or be reconciled back. A goal closed on a task that never landed is the same lie in a shorter timeframe. (The goals **board** does bucket them as done — that is a progress ring, and `task-status.js` keeps the two questions apart on purpose.)
- **A nightly reconciler that reopens wrongly-closed goals.** Repairs the ledger after the fact and leaves the four gaps open, so the report can never be trusted between sweeps. Prevention is available here; detection is what you build when it is not.
- **A human review gate before a goal may close.** This is the queue [ADR 0183](0183-criteria-close-themselves.md) deliberately dismantled. The check D2 needs is a fact the database already holds — asking a person to assert it is slower and less reliable than asking the table.
- **Allow concurrent building versions and scope them by module.** Tempting, because it is the state the instance is in. But two live trains on one project means every "what is in this version" question has two answers, and the goal set can never close on either. The `planning` version is the supported way to work ahead.
- **Retire versions entirely and let goals stand alone.** Genuinely considered: goals already carry criteria, membership and scope, so the version is arguably ceremony. Rejected because the version is the unit the owner sets scope in and the unit `limitations/<version>-shipped.md` archives — removing it would move the scope conversation somewhere with no home.

## 6. The one amendment to ADR 0157

[ADR 0157](0157-archon-is-rank-and-identity-only.md) lowered `version.create` to
`metic`, on the argument that **authoring delegates, disposition does not**:
creating a version confers no authority, so its siblings are `goal.create` and
`task.create`, and only `version.close` stays Archon. That argument was correct
about what a version *was*.

This decision changes what a version *is*. Once the version boundary carries the
scope gate, cutting a new version is no longer authoring — it is **the way around
D1**. A builder refused a goal on a building version needs only create a fresh
version to put it somewhere, and the gate evaporates without anyone overriding
anything. So `version.create` returns to the Archon floor, and the pairing
canonical-permissions has always described — close and rank as the powers that
never delegate — extends to create for the same reason it covered close: it is
now a disposition over scope, not a piece of authoring.

The rest of ADR 0157 stands; this touches exactly one key.

### 6a. The `system` flag on that key: asked, and answered NOT NOW (2026-09-17)

Raising the floor left a gap that §6 did not close and did not hide. `version.create`
is `system: false`, and the `system` flag is what permanently bars granting a key to a
**custom** rank. So the government may still grant `version.create` to a custom
sub-Archon rank, and for a builder holding that rank D1 is decorative again: refused a
goal on a building version, they cut a fresh version and put it there — exactly the
escape hatch D1 exists to close.

The question "should `version.create` become `system: true`, joining `version.close`?"
was raised as task 1003853 and **decided by the owner on 2026-09-17: not now.**

The case *for* was real and was heard: create is now a disposition over scope in this
ADR's own words, its pair `version.close` is already `system: true`, and a gate a custom
rank can be granted is not a gate. It lost to the cost of the remedy. `system: true` is
**permanent and instance-wide** — it would remove for good the ability to delegate
version authoring to any custom rank, which is a real capability an instance might want,
and no instance has asked for the loophole to be closed. The gap is theoretical until
someone defines a custom sub-Archon rank *and* grants it this key; at that moment it
stops being theoretical and this is worth reopening.

This subsection records that the question is **answered, not pending**. A future reader
should not implement the one-word catalog change on the strength of the For argument
alone — it was already weighed. `tests/government_catalog.mjs` pins `version.create` at
`system: false` with the archon floor so the flag cannot move without someone meeting
this decision head-on.

## 7. Consequences

- The live instance is **not** in the state these rules describe, and the rules cannot be enforced on data that violates them. Bringing it over is explicit work under criterion `sv-cutover-proven-live`: fold `CB-V1` into `BONGOS-V1`, disposition the closed goals holding open tasks, rehome the catch-all tasks, and scope `BONGOS-V2` in `planning`. Each invariant lands with a query proving it.
- `POST /goals`, `POST /tasks`, `PATCH /tasks/:id` and `POST /goals/:id/archive` gain refusals that did not exist. Every one is a **named** code, because the callers are agents and an unnamed 409 is an agent stopping to ask a human.
- Anything that created a task without a goal — capture, idea routing, the CLIs — has to name one. That is the point of D4, and it is the widest blast radius here.
- `/status` and the goal board start telling the truth about what is finished. Some goals that read `achieved` today will read `open` again after the cutover; that is the repair, not a regression.
