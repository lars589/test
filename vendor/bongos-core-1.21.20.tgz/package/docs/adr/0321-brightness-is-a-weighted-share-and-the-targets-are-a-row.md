# ADR 0321 — Brightness is a payout-weighted share, and a removal's targets are rows

- **Status:** Accepted
- **Date:** 2026-09-20
- **Task:** [task 1004099](https://cloudbongos.com/builders#/task/1004099) (BV2.R16, goal 1000095 — BONGOS-V2)
- **Spec:** `docs/specs/<redacted>.md` decisions 4 and 20
- **Under:** [ADR 0313](0313-a-removal-is-proposed-by-the-ship-and-confirmed-by-a-person.md), [ADR 0319](0319-a-removal-verdict-is-a-row-beside-the-question.md)

## Context

An idea's **size** is its total ideator payout from its descent and never falls
([ADR 0312](0312-provenance-is-a-second-ideas-owned-edge-table.md) and
`modules/economy/idea-size.js`). **Brightness** is the other channel: how much of that
work is still alive. The pair is what lets a thought whose version the project later tore
out draw *large and dark* — visibly different from a thought that never caused anything
and draws *small and dark*. One number cannot express both, which is why there are two.

Two things had to be settled before it could be computed.

**First, what a share is a share OF.** The spec says graded, not binary (decision 20): a
descent of five things with three alive is partly lit, and goes out only when nothing
survives.

**Second, and the real blocker: the removal facts are stored in the wrong direction.**
ADR 0319 gave a confirmed removal a row — `lifecycle_removal_verdicts`, keyed on the
proposal, carrying the verdict and `ship_task_id`. It also said, in the migration and in
its own text, that the list of tasks whose work was removed was deliberately absent, and
that *"brightness designs its own storage for targets when it needs one."* That deferral
is now due.

The gap is not cosmetic. `ship_task_id` is the task whose merge **deleted** the files.
Brightness needs the previously-shipped tasks that **stopped counting**. Those are
different rows, almost always under different ideas — a later, unrelated piece of work
tears out an earlier one. Reading the ship as the removed task dims the wrong star, and
dims it for the wrong idea, while looking like a working query.

The attribution itself already exists. `modules/lifecycle/removal-derivation.js` blames
each deleted path back to the task that introduced it, and the cascade renders the result
as prose in the proposal's body. `removal-proposals.js` refuses to parse that prose back
and is right to: *"a body is written for a person to read, and a reader that silently
depends on its line shape breaks the day somebody improves the wording."*

## Decision

### D1 — The targets are rows, written at proposal time

`modules/lifecycle/migrations/lifecycle_010_removal_targets.sql` adds
`lifecycle_removal_targets (proposal_task_id, removed_task_id, paths)`, written by
`recordRemovalTargets` from the same `ctx.removals` objects the proposal body renders.
**One derivation, two renderings** — the prose and the rows cannot disagree, and
`removal-proposals.js` keeps its refusal intact because something else now carries the
fact.

It must be written at **proposal** time rather than at verdict time. The attribution comes
from GitHub commit-history reads, capped at eight paths per ship
(`MAX_ATTRIBUTED_PATHS`) and running on the server's shared push credential — the same
credential the publish path depends on. Re-deriving when a person clicks Confirm, days
later, would spend that budget again against a history that has moved on.

This is **not** the cascade runner fanning out, which [ADR 0242](0242-a-cascade-is-a-declaration-table-on-the-event-that-already-exists.md)
forbids: the removal rule still files exactly one task. This records a side fact *about*
that one task — the same shape as the verdict row its answer writes.

`ON CONFLICT DO NOTHING`, never `DO UPDATE`. A second walk can legitimately find *fewer*
paths, because the cap and the rate limit make an exhausted page yield no attribution at
all; overwriting would let a degraded re-read erase a good first one. For the same
reason the writer runs on the cascade's `skipped` row as well as its `created` one, so a
re-ship **repairs** an attribution that a derivation outage missed.

### D2 — Brightness is weighted by payout, not by task count

The share is `live / credits`, where each descent task is weighted by what it actually
earned the idea.

Counting tasks instead would make deleting a one-line fix dim a star as hard as deleting
the feature it belongs to. Weighting by payout makes brightness fall in proportion to how
much of the idea's *worth* died — and since size is drawn from the same quantity, the two
channels become a share of one number rather than two unrelated measurements sitting side
by side. It also makes "large and dead" exact: full size, zero brightness.

The basis is **paid + estimated**, matching size. A historical idea's descent was never
paid for (`idea-size-historical.js` prices those hops); counting only banked credits would
mean removing an estimated hop dims nothing while the size drawn beside it still counts
that hop. To support this, `priceDescentForIdea` and `ideaSizes` now return a per-task
`byTask` breakdown that **sums exactly to `credits`** — assembled from the priced descent
plus any ledger payment for a task the descent no longer reaches, because `idea-size.js`
deliberately keeps those in `credits` so size cannot fall, and dropping them here would
make the parts sum to less than the whole and silently overstate brightness.

### D3 — An idea that earned nothing is LIT, not dark

Zero over zero is not zero. A freshly-filed thought has had nothing removed from it, so
`share: 1` with `hasWork: false`. Returning 0 would make it pixel-identical to the thought
whose version was torn out — which is precisely the distinction BV2.R19's proof exists to
check, and would quietly defeat the reason size and brightness are two channels.
`hasWork` is what lets the five states (BV2.R17) tell a protostar from a remnant without
re-deriving it.

### D4 — "Could not look" is not "nothing was removed"

When the removal facts cannot be read — the lifecycle module is off, the port is
unregistered — `share` is `null` and `attributable` is `false`, never a confident 1. Same
posture `idea-size.js` already takes with `historical: null` when the descent walk is
unavailable: an established absence and an unreadable one are different answers, and only
one of them may be drawn as a plain full-brightness star.

A **confirmed removal that names no target** is the residual case D1 cannot close: it is
genuinely gone, and brightness does not know which idea to dim. It happens for proposals
filed before `lifecycle_010`, for attributions where every deletion predates
`claims.published_head_sha`, and for a derivation outage. Guessing in either direction is
worse than not dimming — so nothing dims, and `countUnattributedConfirmed()` exists so a
surface can say *"the sky may read brighter than the truth by up to N confirmed
removals"* instead of being silently optimistic.

### D5 — Brightness lives in `economy`, behind a port

It is a share of the same payouts size is built from, so it sits beside size in
`modules/economy/idea-brightness.js`; putting it in `lifecycle` would mean that module
doing money arithmetic. That makes the removal facts a cross-module read, so they come
through a kernel-mediated port — `lifecycle.removals` — and never a `require`
([ADR 0083](<redacted>.md) rule 1), exactly as economy already
reaches `ideas.descent`.

Economy resolves it with `resolveOptional` and **does not declare it in `consumes`**.
`consumes` means *required*, and `verifyEnabledPorts` refuses to boot when an enabled
module consumes an unprovided port — declaring it would turn "lifecycle off" into
"instance will not start". The same non-declaration, for the same reason, as
`ideas.descent`.

## Consequences

- Brightness is computable per idea and falls only when a **person** confirms a removal.
  A dismissed or unanswered proposal dims nothing, which is what stops refactors, renames
  and moves from dimming the sky continuously — ADR 0313's central finding.
- **No credit is ever clawed back.** `modules/economy/idea-brightness.js` contains no
  writer and is unreachable from any ship path. `shipped` stays terminal, the ledger is
  never rewritten, and size does not move. Only the picture changes.
- `ideaSizes` grew a field. Callers that spread its result now carry a `Map`; nothing
  serialises it to JSON today, and a surface that wants to must project it rather than
  pass it through.
- BV2.R17 (the five states) can resolve protostar-vs-remnant from `hasWork` and `share`
  without re-deriving either, and BV2.R18 (the sky) has `removedTasks` to explain *why* a
  star dimmed rather than only that it did.

## Rejected

- **Parsing the proposal body.** The attribution is right there as
  `  - task <id> — <title>`. It is also documentation prose that a copy edit may reword at
  any time, and ADR 0319 already refused this for that reason. A reader that depends on a
  human-facing line shape fails silently and dims nothing.
- **Re-deriving targets at verdict time.** Spends the capped GitHub budget a second time,
  against a history that has moved, on the interactive path where a person is waiting.
- **Treating `ship_task_id` as the removed task.** The wrong direction; dims the ship's
  own idea instead of the one whose work died. Named here because the column is right
  there on the verdict row and is the obvious thing to reach for.
- **Counting tasks rather than payouts.** Simpler, and makes a one-line fix weigh the same
  as a feature.
- **Clamping the share at both ends.** The bottom is clamped so an anomaly renders as a
  legible "nothing survives" rather than a negative; the top is not, and `live` / `removed`
  are reported unclamped, so an impossible figure stays visible instead of being hidden by
  the thing that claims to prevent it — `idea-size.js`'s argument against clamping size.
- **Storing the removed task's title beside the row.** It lives on `tasks` and can be
  joined for; a copy goes stale the first time a title is edited.
