# ADR 0336 — A guild is a hub-side group whose members each consent twice, and its collective record is only ever the sum of what those members already show

- **Status:** accepted for D1–D4 and D6–D8. **D5 was not ratified: the owner chose a different rule, recorded in [ADR 0337](0337-the-hub-account-is-the-person-a-hall-account-is-their-seat-in-one-project.md) D4.4** (totals count hidden and private members by default, with a notice and a per-guild off switch, rounded, once a guild has at least 3 of them, refreshed weekly; D4's size rule is unchanged). [Task 1002302](https://cloudbongos.com/builders#/task/1002302) (R26) builds to ADR 0337, and D8's map ranks by the rounded figure.
- **Date:** 2026-09-24
- **Task:** [task 1002299](https://cloudbongos.com/builders#/task/1002299) (R23, goal 1000110 — which folds in goal 1000045's criteria C7/C8/C9)
- **Namespace:** `/g/<slug>`
- **Relates to:** [ADR 0171](0171-profile-rollup-join-and-consent.md) D2/D4 (the leak-by-subtraction ban, read-time rollup, `no-store`), [ADR 0202](0202-connections-graph-and-bounded-degree.md) D2/D4/D5 (the lifecycle reused here, "every count is the length of the list you may see", the reserved guild slot), [ADR 0207](0207-connections-implementation-departures-and-honest-limits.md) D3/D4 (one predicate file; own-scope floors on consent), [ADR 0201](0201-cross-project-application-vouched-row-live-record.md) + [ADR 0260](0260-the-application-is-the-consent-and-the-echo-is-the-gate.md) (the application is the project's own row; applying is consent to be seen), [ADR 0215](0215-the-recruiter-sliver-is-a-ceiling-not-a-step.md) D1 (a stale consent must not activate on a widening), [ADR 0174](0174-government-terminology-ranks-not-roles.md) (`role` means a craft), [ADR 0255](0255-a-public-lists-ordering-is-part-of-its-payload.md) (a public list may be ordered only by what it publishes), `docs/specs/<redacted>.md` (D1/D2 matrix; its Deferred guild bullet), `docs/specs/<redacted>.md` (the reserved project-slug list), `docs/specs/<redacted>.md` (the owner's guild decisions)

> ADR **0332** is held by three sibling sessions in flight at the time of writing (tasks 1002285, 1002813, 1003338), and the numbers after it will go to them as they renumber; this ADR takes 0336 rather than race them. The gap is deliberate (the ADR 0199 / 0202 / 0215 precedent).

## Context

The owner's interview fixed four things about guilds and left the model to this spike: guilds are **open to any builder** to create or join, a builder may belong to **several**, visibility is the **guild owner's choice of public or unlisted** (unlisted stays off the map and search), the collective record **excludes hidden members and says "N of M members counted"**, and a guild engages a project **only with each member's own opt-in**. Five facts found in the tree decide the rest.

1. **No platform guild exists.** Every "guild" in the repo is Discord's word for a Discord server. There is nothing to extend and nothing to migrate.
2. **The social layer is account-global and lives on the hub.** Accounts, connections, the activity rollup and the application echo are all `platform_identity_*` tables keyed on `github_id`, in a module that is `default: false` everywhere except the hub. Core `goal_members` is per-instance and cannot say "these people are a group across projects".
3. **The privacy machinery is finished and centralised.** `modules/platform-identity/account-visibility.js` is the one home for every effective-visibility answer (existence, consent, numbers, reach), and `tests/effective_visibility_predicate.mjs` fails any read of `platform_identity_accounts` that does not join one of them. A guild feature either composes those predicates or it forks the matrix.
4. **The tension the privacy spec deferred here is real but narrower than it looks.** "N of M counted" is a leak by subtraction *only if* M counts someone the reader could not otherwise see, or the total includes someone whose own record is not public. With both fixed, it is not a leak at all (D5).
5. **Admission is per person, on the project, and already has one door.** ADR 0201 made an application the project's own `access_requests` row, vouched by the hub; the hub's individual invite (`POST /projects/invite` → `inviteToProject`) pre-seeds a pending membership the invitee accepts. A guild is a group of people, and a project still admits people.

Nothing in this feature confers authority. A guild membership grants no rank, no credits, no admission and no access to any project (ADR 0016 / ADR 0141).

## Decision

### D1 — Three hub tables in `platform-identity`, in their own files, distinct from `goal_members`

A guild is account-global, so it belongs beside connections: `modules/platform-identity/guilds.js` (domain) and `routes/guilds.js`, **not** `platform-identity.js`, which sits at its 1,500-line ratchet. Migration sketch, authored by [task 1002300](https://cloudbongos.com/builders#/task/1002300) (R24) at the next free `platform_identity_` number, additive only (ADR 0083 §5):

```sql
CREATE TABLE IF NOT EXISTS platform_identity_guilds (
  id                   bigserial PRIMARY KEY,
  slug                 text NOT NULL,          -- the /g/<slug> key; fixed at creation (D6)
  name                 text NOT NULL,          -- display name; renamed freely
  description          text,
  -- No DEFAULT: the creator chooses. A silent default would decide a privacy question for them.
  visibility           text NOT NULL CHECK (visibility IN ('public', 'unlisted')),
  -- No creator column: the owner row below is the authority, and a permanent
  -- "created by" would keep a departed creator's tie to the guild (D2's hard-delete rule).
  created_at           timestamptz NOT NULL DEFAULT now(),
  updated_at           timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS uniq_platform_identity_guilds_slug
  ON platform_identity_guilds (lower(slug));

CREATE TABLE IF NOT EXISTS platform_identity_guild_members (
  guild_id        bigint NOT NULL REFERENCES platform_identity_guilds(id) ON DELETE CASCADE,
  github_id       bigint NOT NULL,
  -- membership_kind, never `role`: ADR 0174 reserves that word for the three crafts.
  membership_kind text NOT NULL DEFAULT 'member' CHECK (membership_kind IN ('owner', 'member')),
  -- This member agreed to appear on the guild's PUBLIC page (D4). Not the guild's visibility.
  shown_publicly  boolean NOT NULL,
  joined_at       timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (guild_id, github_id)
);
-- Exactly one owner per guild, held by the database rather than a route.
CREATE UNIQUE INDEX IF NOT EXISTS uniq_platform_identity_guild_owner
  ON platform_identity_guild_members (guild_id) WHERE membership_kind = 'owner';
CREATE INDEX IF NOT EXISTS <redacted>
  ON platform_identity_guild_members (github_id);

CREATE TABLE IF NOT EXISTS platform_identity_guild_requests (
  id              bigserial PRIMARY KEY,
  guild_id        bigint NOT NULL REFERENCES platform_identity_guilds(id) ON DELETE CASCADE,
  github_id       bigint NOT NULL,             -- the person who would join
  kind            text NOT NULL CHECK (kind IN ('invite', 'request')),
  status          text NOT NULL DEFAULT 'pending'
                    CHECK (status IN ('pending', 'accepted', 'rejected', 'cancelled', 'expired')),
  seen_at         timestamptz,
  created_at      timestamptz NOT NULL DEFAULT now(),
  resolved_at     timestamptz
);
CREATE UNIQUE INDEX IF NOT EXISTS uniq_platform_identity_guild_requests_open
  ON platform_identity_guild_requests (guild_id, github_id) WHERE status = 'pending';
```

A fourth table, the guild's engagement with a project, is D7's and lands with [task 1002303](https://cloudbongos.com/builders#/task/1002303) (R27), not R24. A standalone or self-hosted instance has none of these tables and shows no guild surface: the goal spec's "degrade to local-only" rule, free.

**Rejected.** *A core table beside `goal_members`*: it would exist empty on every self-hosted instance and breach the module boundary (the ADR 0202 D1 reason). *Reusing `goal_members`*: a goal is an instance-local work container and a guild is a cross-project group of people. They share a word ("member") and nothing else.

### D2 — Two membership kinds: one owner, and members. Neither is authority.

- **The owner** (exactly one, the creator until they transfer) invites, accepts or declines join requests, removes members, sets visibility, edits name and description, files a guild application (D7), and dissolves the guild. Transfer is **two statements in one transaction**: demote the old owner, then promote the new one. A single `UPDATE` that swaps both rows would fail or succeed depending on the order Postgres visits them, because a unique index is checked row by row and a partial one cannot be deferred.
- **A member** leaves, sets their own `shown_publicly`, and opts in or out of each engagement.
- **Leaving:** any member may leave. The owner must transfer first, unless they are the last member, in which case leaving **dissolves** the guild. Removing a member, leaving and dissolving are hard deletes (cascading to open requests): a tombstone saying "A was removed from G" is data nobody consented to keep, the ADR 0202 D2 reason.

A third "officer" kind is **deferred, not refused**. Nothing in C7–C10 needs a delegate yet, and adding one later is a widened `CHECK` with no data migration. The task title says "roles"; in the schema the word is `membership_kind` (ADR 0174/0177).

### D3 — Joining takes two consents, through the connections lifecycle verbatim

No self-join. A guild's record and roster are its reputation, and a builder's guild list is theirs, so **nobody is added to a guild they did not accept, and no guild gains a member it did not admit.** Two directions, one table:

- **Invite** (owner → a builder): the invitee accepts or declines.
- **Request** (a builder → a *public* guild): the owner accepts or declines. An unlisted guild takes no requests, because a stranger cannot address it (D4).

The lifecycle is ADR 0202 D2's, reusing its exported constants so the two features cannot drift: `pending → accepted | rejected | cancelled | expired`; **a decline is silent**, and a re-ask of the same pair inside 90 days is swallowed with the same response a real one gets; expiry is 30 days, read-time, with the expired row resolved in the same statement that inserts the next one; accept resolves the request and inserts the membership in **one statement**. **`accountActiveSql` floors the whole feature**: a provisional or terms-less account cannot create, request, be invited, or appear anywhere (ADR 0171 D3, ADR 0213). A private account *can* join; D4 decides where it shows.

R35 (a cluster invited to form a guild) needs a batch. R24's invite route takes a **bounded list** (at most 25, a named constant), and each entry is an ordinary individual invite. A batch is a loop, never a new kind of membership.

### D4 — `public | unlisted` is the guild's choice. Being *shown* is each member's.

- **A public guild** has a public page (`GET` by slug, viewer-independent, `no-store`), appears on the map and in search, and takes join requests.
- **An unlisted guild** has no public existence. Its public read answers **404 to everyone, its own members included**, exactly like a private account's profile. Its members reach it through an own-scope read, which is the privacy spec D2 page-shell composition. It takes invites only. **Rejected: "unlisted = anyone with the link".** A slug is a human word and guessable, so a link-reachable unlisted roster is public to anyone with a dictionary.

**The public roster is `shown_publicly AND accountVisibleSql(a)`**, composed from the shared predicate and never restated. Three consequences:

1. **A private account is never on any public roster**, whatever its flag. Rendering it there is "the 404 bypass wearing a different hat" (ADR 0202 D4 §2). Its fellow members still see it in the own-scope read, because joining is consent to be seen **by the guild**, never by the world (the ADR 0260 D2 shape).
2. **`hide_stats` never hides membership.** It suppresses the numbers beside a name, not the name (ADR 0202 D4 §3).
3. **Widening a guild does not widen its members.** `shown_publicly` is set `true` by joining a guild that is public at that moment (the invite or request card says so), and `false` by joining an unlisted one. **The consent is to what the card showed, not to what the guild became.** An accept carries the visibility its card displayed, and if the guild's visibility has changed since, the accept is refused (409) and the card re-renders for a fresh decision. Otherwise an owner could flip to public between the card and the click and publish someone who agreed to an unlisted guild. A request is only ever made to a public guild, so its consent to be shown is given when it is sent. The member may flip it at any time. **Changing the guild's visibility changes nobody's flag except the owner who flipped it.** So an unlisted guild that goes public shows only its owner until each member agrees, and each member is asked in their inbox. This is ADR 0215 D1's lesson in reverse: consent given to a small audience must not quietly become consent to a large one.

Every count is the length of a list the reader can see (ADR 0202 D4). The guild's public **size** is the length of its public roster. There is never a "+N more".

### D5 — The collective record counts a member if and only if that member's own record is public right now *(recommendation, NOT ratified — superseded by [ADR 0337](0337-the-hub-account-is-the-person-a-hall-account-is-their-seat-in-one-project.md) D4.4)*

**The rule:** a member is **counted** iff `shown_publicly AND rollupVisibleSql(a)`: they agreed to be on this guild's public page, **and** their own cross-project record is publicly visible (active, public, not hidden). The record is computed **at read time, on every read**, sent `no-store`, and never stored, cached or snapshotted. It shows:

| Field | Computed as | Why it is safe |
|---|---|---|
| credits, works shipped, karma | sums over the **counted** members | each addend is already on that member's own public profile |
| disciplines | the union over the counted members | same |
| projects | the **named** public projects the counted members build on (`onMapSql AND visibility = 'public'`, the ADR 0171 D2 amendment rule) | a profile already names exactly these |
| "**N of M** counted" | N = counted, M = the public roster's length | both are lengths of lists the reader can see |

**Deliberately absent:** a distinct count of *all* the members' projects, non-public ones included. Unioning counts that profiles only give as `more_projects` would reveal that two members share a private project (3 + 3 projects, 5 distinct). That fact appears on no profile.

**Why this dissolves the tension instead of trading it off.** Every number the guild shows is a sum of numbers each counted member already shows on their own public profile, at the same instant. So the guild record **cannot disclose anything a reader couldn't add up from the members' own profiles**. There is nothing to subtract. The M − N members who are shown but not counted are the listed members who hide their numbers, and each one's own profile already says "keeps their track record private". Joins, leaves, hides and un-hides move the total by numbers that were public at that moment, so watching the total over time learns nothing either. The two ways "N of M" *would* leak are both closed by construction. M never counts an account the reader can't see, so private members' existence does not leak through the count. The total never includes an account whose own record is not public, so a hidden or private member's numbers do not leak through subtraction.

**The two options the brief named, and why neither is recommended:**

- **All-or-nothing** (the guild shows no numbers if any member hides). Safe, but it lets any single member blank everyone's record. It puts social pressure on exactly the people the hide switch exists for ("you're the reason our guild shows nothing"), which turns a free choice into a costly one. It also still leaks one bit: a blank record means someone hides.
- **Per-member consent per guild** (each member opts in to being counted in this guild). For a member whose record is already public, the consent adds nothing, because their numbers are on their profile anyway. For a hidden or private member, "opting in" would mean their numbers enter a public sum while their own profile withholds them. That breaks the owner-signed rule that **`hide_stats` beats everything** (privacy spec D2), and the sum reveals them by subtraction the moment they are the only such member, or on any join or leave. So this option either does nothing or breaks the one invariant every other surface keeps. What survives of it is the part that only **narrows**: `shown_publicly` (D4) lets a member stay in a guild without being on its page or in its numbers.

**The trade-off, stated plainly for the owner:** a guild's public numbers and its public size **understate** it whenever members hide their stats, keep their accounts private, or haven't agreed to be shown. A guild of privacy-minded builders will look smaller and rank lower on the map (D8) than it really is. In return, no member's choice is ever overridden or vetoed by another member's, the guild page can never be used to recover a hidden record, and the rule needs no new privacy setting. The only new flag is D4's `shown_publicly`, which is about the guild page and not about numbers.

**Honest limit:** because the record is derivable from public profiles, it carries no information of its own. It is a convenience sum and a ranking input, and it must be described that way. It is also not a record of work done *as a guild*. The goal's C7 says "collective track record", and this is the members' combined record, not a joint one. A true joint record (work shipped by a guild's engagement on a project) is a different feature and is deferred.

### D6 — The namespace is `/g/<slug>`, reserved in the SEO spec, and the slug is fixed at creation

The guild page lives at **`/g/<slug>`** on the hub, the sibling of `/u/<handle>`. The word **`g`** joins the reserved project-slug list in `docs/specs/<redacted>.md` (its Routing bullet), the way `u` guards the profile namespace, per [task 1002912](https://cloudbongos.com/builders#/task/1002912)'s rule. The word is reserved and **no route is squatted**. The page itself is [task 1002301](https://cloudbongos.com/builders#/task/1002301)'s (R25). `tests/guild_namespace_reserved.mjs` fails if this ADR's `Namespace:` line and the spec's reserved list disagree. The guild API mounts under the module's API prefix like every other hub route, so it needs no top-level word.

- **Slug:** `normalizeHandle`'s charset (lowercase letters, digits and inner hyphens, at most 39 characters) with a two-character floor, unique case-insensitively, owner-picked at creation, and refused if it is a word the `/g` namespace uses (`me, new, edit, settings, admin, api`, exported as a constant like `RESERVED_HANDLES`).
- **Fixed in V1.** The display name changes freely and the slug does not, so there is no 301 machinery to build. A rename with a previous-slug window (the handle precedent) is a named follow-up.
- **Search engines:** a public guild page may be indexed. Adding guilds to the sitemap is the SEO goal's call (its R10/R15 pattern), not this tree's. An unlisted guild has no page to index.

### D7 — A guild engages a project only through the individual door, one person at a time

A project still admits **people**, through the one door ADR 0201 built, so no new admission path exists. The hub holds a guild-level **engagement** row: `(guild_id, client_id, kind ∈ {'apply','invited'}, created_at)`. It records no filer, for the same reason the guild row keeps no creator. It is **statusless**, for the ADR 0201 D1.3 reason (the hub may not hold an admission fact about someone else's project), and it ages out read-time at 30 days.

- **A guild applies** (the owner files it). Each member sees "G is applying to P — apply with them?" in their own inbox. **Opting in is applying as yourself** through the existing relay (`POST /my-projects/join`, vouched, echoed), with the engagement attached to that member's application echo. Nobody reaches P without their own act. P receives ordinary vouched applications and approves each with `access_request.review`, exactly as today. The **guild label reaches P's queue through the live applicant-profile read** (ADR 0260's `POST /sso/applicant-profile`, which already reads the echo), returning `guild: { slug, name }` when the echo carries an engagement. There is no new body field, header or instance column, so a project on any core pin keeps working (the ADR 0201 D2.2 compatibility rule). For a public guild, the reviewer may open its public page. For an unlisted guild, the reviewer sees its name and the applying members' own applicant views, and nothing else.
- **A project invites a guild** (whoever passes P's existing inviter gate, `requireProjectInviter`). The hub fans out **ordinary individual invites**, through the same primitive used to invite one builder (today `inviteToProject`), **to exactly the members on G's public roster at that moment**: the people the inviter could see. Each accepts or declines their own. **Nobody who joins G later inherits the invite, and members the inviter could not see are not invited.** The alternative, a guild-level pre-approval, would let a guild owner decide who gets admitted to someone else's project just by editing their own roster. That is the inversion ADR 0141 exists to prevent. The engagement row (`kind = 'invited'`) lets the members who were *not* invited (private or not shown) see "P invited this guild" in their own-scope view and apply themselves, landing as ordinary applications. **That notice names P only when P is on the map and Public**, the rule that decides which projects a profile may name (`onMapSql AND visibility = 'public'`, the ADR 0171 D2 amendment). A Private or Stealth project's invite reaches the people it chose and nobody else, because telling members P never saw that P is recruiting would let the roster widen P's reach. An unlisted guild cannot be invited, because it cannot be addressed.

### D8 — The map ranks public guilds by two published numbers, computed at read time

**Who:** `visibility = 'public'` and a non-empty public roster. **Two orderings, no stored score:** **size** = M, and **shipped** = the counted members' summed works shipped (D5; per [ADR 0337](0337-the-hub-account-is-the-person-a-hall-account-is-their-seat-in-one-project.md) D4.4, the rounded weekly total). Ties break on `slug`. Every sort key is a number the row itself publishes (ADR 0255: a public list's order is a covert column otherwise), and nothing ranks on a hidden input. The read is `no-store` and paged like the projects feed. **Cost:** one aggregate over public-guild memberships joined to the activity rollup, per read. At the hub's current scale (hundreds of accounts) that is a few index scans. The revisit trigger is a measured p95, and any cache added then must be invalidated by a hide, a privacy flip, a `shown_publicly` change, a membership change and a visibility change. Otherwise a stale rank position would keep publishing a withdrawn number (the ADR 0202 D3 reason). The ranking inputs are decided here. [Task 1002305](https://cloudbongos.com/builders#/task/1002305) (R29) keeps the visual approach, plus whether a combined score earns its place. Any such score may use only M and the D5 totals.

## What this unblocks, and how each task's scope changes

| Task | Scope as filed → scope after this ADR |
|---|---|
| [task 1002300](https://cloudbongos.com/builders#/task/1002300) R24 — CRUD + membership + visibility | Adds: D1 migration (three tables, single-owner index, `shown_publicly`, `membership_kind` not `role`); D2 owner/member + transfer (two statements, one transaction) + last-member dissolve; D3 two-consent join, the connections lifecycle and constants reused, **no self-join**, **unlisted takes invites only**, batch invite (≤ 25); D4 public read 404s unlisted to everyone, own-scope read for members, `shown_publicly` own-scope toggle, and an accept that carries its card's visibility (409 if it changed); D6 slug rules + reserved words, slug immutable; new files `guilds.js` + `routes/guilds.js`, every route in `tests/own_scope_guard.mjs`, every account read joining `account-visibility.js`. |
| [task 1002301](https://cloudbongos.com/builders#/task/1002301) R25 — guild page UI | Page at `/g/<slug>`; public roster per D4 (handle, display name, avatar, kind; never `github_id`/login); "N of M" per D5; members' view via own-scope call; the "show me on this guild's public page?" prompt after an unlisted→public flip. |
| [task 1002302](https://cloudbongos.com/builders#/task/1002302) R26 — collective rollup | **Superseded: build to [ADR 0337](0337-the-hub-account-is-the-person-a-hall-account-is-their-seat-in-one-project.md) D4.4.** Original text: **Retitle:** "counts only members whose own record is public" replaces "excludes hidden members". Read-time, never stored, `no-store`; counted = `shown_publicly AND rollupVisibleSql`; projects = named public projects only, **no union count of non-public projects**. **Blocked on the owner ratifying D5.** |
| [task 1002303](https://cloudbongos.com/builders#/task/1002303) R27 — guild applications + invites | Adds the engagement table (D7). Apply = each member's own vouched application through the existing relay, tagged via the echo. Invite = individual invites fanned out to the public roster at that moment, **never** a guild-level pre-approval; the "P invited this guild" notice names P only when P is on the map and Public. The guild label travels on the applicant-profile read, never a new instance field. |
| [task 1002304](https://cloudbongos.com/builders#/task/1002304) R28 — owner view of guild applications | **Dependency fix:** it depends on R11 ([task 1002287](https://cloudbongos.com/builders#/task/1002287)), which is **abandoned** (merged into [task 1002332](https://cloudbongos.com/builders#/task/1002332), which shipped), so R28 can never auto-promote. Repoint that edge to 1002332. Scope: group vouched rows by the guild label; "approve all" = N individual approvals. |
| [task 1002305](https://cloudbongos.com/builders#/task/1002305) R29 — ranking + viz spike | **Narrows to the visual approach.** The ranking inputs, audience and ordering are decided in D8. Must also confirm which orb surface exists, since goals 1000044 and 1000049, which it names, are both **archived**. |
| [task 1002306](https://cloudbongos.com/builders#/task/1002306) R30 — map API | Public guilds with a non-empty public roster; size and shipped orderings per D8; slug tiebreak; read-time, `no-store`, paged. |
| [task 1002307](https://cloudbongos.com/builders#/task/1002307) R31 — map UI | No change beyond R29's archived-goal risk. |
| [task 1002308](https://cloudbongos.com/builders#/task/1002308) R32 — PROOF | Adds negatives: a hidden member lowers N but not M; a private member moves neither and is absent from the roster; an unlisted guild is absent from the map and 404s publicly; after an unlisted→public flip, a member who has not agreed is not shown, and an invite accepted from a card that predates the flip is refused; someone who joins after a project invites the guild gets no invite. |
| [task 1002309](https://cloudbongos.com/builders#/task/1002309) R33 — proximity spike | A guild co-membership may feed a closeness signal **only where the viewer can see both memberships**: the viewer's own guilds, or public rosters. An unlisted guild never shapes what a non-member sees. |
| [task 1002311](https://cloudbongos.com/builders#/task/1002311) R35 — cluster → guild | Uses R24's batch invite. Forming a guild from a cluster is create + invite, and each invitee accepts individually. |
| [task 1002310](https://cloudbongos.com/builders#/task/1002310), [task 1002312](https://cloudbongos.com/builders#/task/1002312), [task 1002313](https://cloudbongos.com/builders#/task/1002313) — R34, R36, R37 | No change. Recruiting a cluster (R36) is individual invites to people, not a guild act, and a cluster carries no collective record. |

ADR 0202 D5's reserved "shared guilds" term in *builders you may know* ([task 1002297](https://cloudbongos.com/builders#/task/1002297)) stays at zero weight until R24 ships. When it is switched on, it obeys the same rule R33 does.

## Consequences

- The hub gains three tables (four after R27), and the feature adds **no new privacy predicate**. The roster and the count compose `accountVisibleSql` and `rollupVisibleSql`. `shown_publicly` is a membership fact, not an account axis, so the owner-signed privacy matrix stays exactly as signed.
- Two consents stand between a builder and every public guild surface: joining (the guild's and theirs) and being shown (theirs). The account-level flags still override both. A guild can never widen what a member's own settings allow.
- A guild's public numbers understate it by design (D5's trade-off), and the map inherits that. The UI copy must say "N of M counted", never a bare total.
- Nothing about admission moves. A project never learns of a private or unshown member unless that member applies, and a guild owner can never cause anyone to be admitted anywhere.

## Rejected

- **All-or-nothing guild stats** and **per-member consent to count hidden numbers**. See D5.
- **M counting every member.** With a filtered roster beside it, the difference reveals how many private members exist, the ADR 0202 D4 connection-count leak.
- **A stored or materialised guild total or rank.** A hide must beat every copy (ADR 0171 D2/D5).
- **A union count of all members' projects.** It reveals shared non-public projects.
- **"Unlisted" as link-reachable.** Slugs are guessable.
- **Self-join to a public guild.** It borrows a guild's reputation without its consent.
- **Carrying members' `shown_publicly` over when a guild widens to public.** That is consent given to a small audience, reused for a large one.
- **A guild-level pre-approved invite.** It lets a guild owner decide admission to someone else's project.
- **A hub guild-applications table with a status.** An admission fact on the wrong side of the boundary (ADR 0201 D1.3).
- **A `role` column.** ADR 0174.

## Deferred (named, not dropped)

- **An officer kind** (D2) and **open-join guilds**: both are additive once someone needs them.
- **Slug rename** with a previous-slug window; **guilds listed on a builder's profile** (public guilds, public roster only, when it is built).
- **A joint record** of work shipped by a guild's engagement on a project (D5's honest limit).
- **Name moderation and impersonation** ("the official … guild"): guild names are user-written public text, so R24 caps lengths and every page escapes them. A reserved-name list or a report path is a separate decision.
- **Per-builder caps** on guilds created or invites sent. The global write limiter stands meanwhile, the ADR 0207 deferral precedent. A real number is the owner's call.
- **Sitemap inclusion** of public guild pages. It belongs to the SEO goal.
