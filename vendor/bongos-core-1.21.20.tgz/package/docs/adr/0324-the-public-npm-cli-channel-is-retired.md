# ADR 0324 — The public npm CLI channel is retired

- **Status:** accepted
- **Date:** 2026-09-22
- **Task:** [task 1004144](https://cloudbongos.com/builders#/task/1004144) (goal 1000091 — working area 5, Module distribution & economy)
- **Deciders:** Lars (Archon) — the owner deleted the package and confirmed the retirement; Claude scoped the consequences and executed the cleanup.
- **Supersedes:** [ADR 0258](0258-the-public-cli-is-a-generated-client-package-not-the-published-core.md) · [ADR 0292](0292-both-install-paths-stay-and-vendoring-is-the-production-one.md) §2
- **Related:** [ADR 0134](0134-private-first-npm-distribution.md) · [ADR 0283](0283-the-core-publishes-publicly-because-access-was-never-the-thing-protecting-it.md) (the public flip that removed this package's original reason) · [ADR 0269](0269-the-cli-session-store-is-host-keyed-at-a-fixed-anchor.md) (cites the package in an example)

## Context

`@cloudbongos/cli` was a generated, server-free npm package — the public front door, so a
newcomer could reach an instance's board with `npx` and no checkout, no credential and no
46 MB core download.

**The owner removed it from the registry on 2026-09-22.** Verified: `npm view
@cloudbongos/cli` answers E404, and `npm access list packages @cloudbongos` returns an
empty scope.

This ADR exists because that reverses a decision the project had already argued and
settled — twice, in opposite directions:

- **[ADR 0258](0258-the-public-cli-is-a-generated-client-package-not-the-published-core.md)**
  established the channel: a generated client package rather than the published core,
  deliberately excluding `claim` and `ship` because "a half-working claim that cannot
  materialize into a checkout is worse than one that explains where to go".
- **[ADR 0292](0292-both-install-paths-stay-and-vendoring-is-the-production-one.md) §2** is
  titled *"`@cloudbongos/cli` STAYS, on a new justification"*. It was written **because**
  task 1003872 proposed removing it once [ADR 0283](0283-the-core-publishes-publicly-because-access-was-never-the-thing-protecting-it.md)
  made the core public and dissolved the original "no private-registry credential" reason.
  0292 agreed the original reason was gone and kept the package anyway, on a measured one:
  roughly half a megabyte for the front door, versus pulling the whole core — a web server
  and a Postgres driver included — to print a task list.

**That measured argument is still true.** Nothing about it was found wrong. What changed is
the owner's decision about carrying a public distribution channel at all, which is a
judgement about what this project wants to maintain and support, not a correction to 0292's
arithmetic. The record should say that plainly rather than retro-fitting a technical fault.

## Decision

### 1. The public npm channel is retired. Nothing in the repo generates or advertises it.

`scripts/gds/build-cli-package.js` and `tests/cli_package.mjs` are deleted. No document
offers `npx @cloudbongos/cli` as a route in.

### 2. The way in is the hall, or a checkout.

A newcomer reaches an instance at its own address — `<origin>/builders` — which needs
nothing installed at all and was always the lower-friction path for *reading* the board.
Writing code still needs a checkout of the project repo, where the full CLI already is.
This is the same answer [ADR 0258](0258-the-public-cli-is-a-generated-client-package-not-the-published-core.md)'s
`CHECKOUT_ONLY` refusal gave for `claim` and `ship`; it is now the answer for every verb.

### 3. The COMPILED binary channel is untouched, and is a different thing.

Two separate artifacts were both called "the bongos CLI", and conflating them would delete
a live surface:

| | retired here | untouched |
| --- | --- | --- |
| built by | `scripts/gds/build-cli-package.js` | `scripts/gds/build-bongos.js` |
| artifact | the `@cloudbongos/cli` npm package | per-platform compiled binaries |
| served by | npm | `src/bongos-downloads.js` → `/downloads/bongos/*`, from `config/bongos-cli.json` |

`/downloads/bongos/*`, `src/bongos-downloads.js`, `build-bongos.js` and
`config/bongos-cli.json` are all unaffected. (Task 1003889 flagged this same near-twin when
it warned "Keep `src/bongos-downloads.js`" while deleting the dev-box download surface.)

### 4. Nothing is republished to fill the gap.

Publishing is the owner's action ([ADR 0258](0258-the-public-cli-is-a-generated-client-package-not-the-published-core.md)),
and no replacement package is planned. If a public channel is ever wanted again, it needs a
new ADR and a fresh justification — 0292 §2's is spent.

## Consequences

**Positive.** One fewer artifact to build, version, redact and publish, and one fewer way for
the repo to describe a thing that does not exist — which it had been doing since the deletion.
It also closes a class: `@bongos/client` (removed 2026-09-09) and now `@cloudbongos/cli` both
outlived their registry entries in the repo's prose, and neither leaves a generator behind.

**Negative.** The zero-install on-ramp is gone. A newcomer with only a terminal can no longer
reach the board without either a browser or a checkout, and the ~0.5 MB versus 46 MB gap 0292
measured is a real cost now being paid. Accepted with open eyes.

**Neutral.** No test fetched the registry, so nothing in CI depended on the package existing;
three tests used its FILES manifest as a stand-in for "what a terminal user can run" and now
read `bin/bongos.js`'s verb table, which is what that set always actually meant.
