# ADR 0182 — Project visibility is TWO axes: a derived publish gate and a stored join door

- **Status:** Accepted
- **Date:** 2026-08-21
- **Task:** [task 1002320](https://cloudbongos.com/builders#/task/1002320) (BONGOS-V1, goal 1000046 — *Project creation — visibility & customization*)
- **Deciders:** IAMMASTERQUA (Archon), Claude
- **Confirms R04–R18** — the full accounting is in *Scope* below, including the two that this ADR deliberately does **not** govern.
- **Bounds — deliberately NOT decided here:** the self-hosted→hub *reporting and trust* mechanics ([task 1002321](https://cloudbongos.com/builders#/task/1002321), R02) · the applications/invite *model* (`docs/specs/<redacted>.md` D2, already decided) · project *authority* (same spec, D1)
- **Related:** [ADR 0141](<redacted>.md) (hub = identity + relay, authority stays local) · [ADR 0112](0112-private-goals-invitations-join-requests.md) (`goals.visibility`, the precedent this copies) · [ADR 0108](0108-instance-composition-configurable-root.md) (the instance IS the project) · [ADR 0174](0174-government-terminology-ranks-not-roles.md) (one word, one meaning)

---

## Scope — what "confirms R04–R18" means, task by task

The task description says this ADR *"confirms R04–R18"*. That is 15 tasks and they do not
all relate to it the same way, so they are enumerated rather than gestured at. **Its
criteria** are `proj-visibility-states`, `proj-join-policy` and `proj-detail-interview`
(the goal's C1–C3); task 1002320 is linked to all three.

**Shape set by this ADR** — these build what it decides, and each should be read against it:

| | Task | Gets from this ADR |
|---|---|---|
| R04 | [1002323](https://cloudbongos.com/builders#/task/1002323) | the 3-value enum + the derived gate + the missing `description` column (D1, D4) |
| R05 | [1002324](https://cloudbongos.com/builders#/task/1002324) | **moves host** — an instance surface, not a hub one (D5) |
| R06 | [1002325](https://cloudbongos.com/builders#/task/1002325) | the feed predicate change + **server-side** stealth redaction (D2a, D3) |
| R07 | [1002326](https://cloudbongos.com/builders#/task/1002326) | which three states render, and that `featured` no longer gates presence (D3) |
| R08 | [1002327](https://cloudbongos.com/builders#/task/1002327) | the hub row is a cache; **unreported ⇒ fail-closed** (D5) |
| R09 | [1002328](https://cloudbongos.com/builders#/task/1002328) | the render mapping, and that it may not be trusted to redact (D2a) |
| R11 | [1002330](https://cloudbongos.com/builders#/task/1002330) | per-state application rules on the already-decided model (D6) |
| R12 | [1002331](https://cloudbongos.com/builders#/task/1002331) | **visibility is the ceiling; join policy may only narrow** (D6) |
| R15 | [1002334](https://cloudbongos.com/builders#/task/1002334) | why skipping the interview is a supported default, not a dead end (D4) |
| R16 | [1002335](https://cloudbongos.com/builders#/task/1002335) | the bar is identity only, and it must name what is missing (D4) |

**Proofs of those shapes** — no new decisions, but their assertions are set here:
R10 ([1002329](https://cloudbongos.com/builders#/task/1002329)) must assert stealth's
**absent fields, not absent pixels** (D2a);
R14 ([1002333](https://cloudbongos.com/builders#/task/1002333)) must cover the
ceiling-vs-narrowing rule (D6);
R18 ([1002337](https://cloudbongos.com/builders#/task/1002337)) must cover
skip ⇒ dark-matter-until-published (D4).

**NOT governed by this ADR**, stated so the omission is a decision rather than a gap:

- **R13** ([1002332](https://cloudbongos.com/builders#/task/1002332)), the owner
  applications review queue — belongs to `docs/specs/<redacted>.md`
  (D1/D2), which already decided the queue, its authority and its storage. This ADR sets
  only which states *accept* an application (D6), never what happens to it afterwards.
- **R17** ([1002336](https://cloudbongos.com/builders#/task/1002336)), rule-based
  recommendations from the project detail — orthogonal. Recommendations concern module and
  governance presets; nothing about them depends on visibility or publishability.

## Context

Goal 1000046 seeded 31 tasks, and R04–R18 each say *"per R01"* — this ADR. Nothing in the goal could start until it landed: at claim time it gated **29 open tasks**, the largest single chokepoint in the repo, and it was itself parked at `backlog` with no dependencies of its own.

The spec its planning task cites — `docs/specs/<redacted>.md` — **was never written**. This ADR is therefore the design of record, not a summary of one.

**What exists today.** `platform_identity_projects` (hub-side, keyed by `origin`) carries `status ('active'|'hidden')`, an Archon-curated `featured` boolean, and `owner_github_id` — explicitly commented *"advisory attribution (not an authority)"*. The public feed reads `featured = true AND status = 'active'`. So today a project's presence on the map is **Archon editorial curation**, and the owner has no control at all. The goal's premise is the inverse: the owner shapes it.

**The apparent contradiction that motivated this ADR.** The goal's own criterion `proj-visibility-states` says *"one of **four** states"* (Public/Private/Stealth/Unlisted). R04's description says *"3-state visibility enum … dark-matter is derived … not a stored 4th state"*. Read as one enum these disagree. They do not disagree; they describe different layers, and conflating those layers is the trap this ADR exists to prevent.

## Decision 1 — Two independent axes, not one four-valued enum

| Axis | Stored? | Set by | Governs |
|---|---|---|---|
| **Publishability** | **Derived** | the identity gate (R16) | whether the project is on the map *at all* |
| **The join door** | Stored: `visibility ∈ (public, private, stealth)` | the project's owner | how it renders, and who may get in |

The four user-facing states are **3 × publishable, plus one derived state that collapses all three**:

```
publishable = false  →  DARK MATTER   (off the map, un-joinable) — whatever the enum says
publishable = true   →  public   → planet      (identified,  anyone may join)
                        private  → star        (identified,  no self-join, applications accepted)
                        stealth  → black hole  (ANONYMOUS,   no self-join, applications refused)
```

**The name `visibility` is kept, and it is a mild lie.** The column does not decide visibility — publishability does. We keep the name because `goals.visibility` (ADR 0112) already established it and one word across both planes beats an accurate name used in one place. This paragraph is the mitigation: **anyone reading `visibility = 'public'` and expecting the orb on the map is reading it wrong**, and the publish gate is the thing to check. R04 must carry that sentence to the column comment.

## Decision 2 — All three stored states are VISIBLE; only the derived state is invisible

This is what makes the 3+1 split honest rather than a workaround: the enum is a *door* policy, and every value of it is on the map. Consequences worth stating because R06/R07/R09 all depend on them:

- **`private` means visible-but-closed, exactly as it already does for goals.** ADR 0112: *"a private goal stays VISIBLE in the goal list but non-members can't self-join."* The project plane inherits that meaning unchanged. A private project is a star you can see and ask to join.
- **`stealth` exposes EXISTENCE but not IDENTITY.** The black hole is the metaphor and it is precise: you see the gravitational effect, not the object. R06/R09 say "stealth is anonymous", and that is a real privacy primitive, not a rendering note.
- **Dark matter is not a state an owner picks.** It is the absence of a met bar. There is deliberately no way to *choose* it, because "unlisted" as a selectable option would compete with `private` and nobody could say which to pick.

### Decision 2a — stealth redaction is SERVER-SIDE, in the feed

A stealth project's `name`, `tagline`, `art_url`, and `origin` **must not leave the server** in the public feed. The feed emits the orb (existence, render type, and whatever aggregate the map needs) and nothing identifying.

This is called out because the naive implementation is to send the row and let the orbs page hide it — which leaks the whole thing to anyone who opens the network tab, and the orbs page is a **static site outside this repo** (R09), so we cannot enforce it there even in principle. Redaction at the boundary is the only version of this that is true. R06 owns it; R10's proof must assert the absence of the fields, not the absence of pixels.

## Decision 3 — Three mechanisms, three owners, one composition rule

`status`, `visibility` and `featured` all touch "does this appear", and they are not the same thing:

| Field | Owner | Meaning |
|---|---|---|
| `status` | system / Archon | operational lifecycle — a deprovisioned project is `hidden` |
| `visibility` | the **project owner** | the join door (Decision 1) |
| `featured` | Archon | editorial promotion |

**Composition:** a project is on the map iff `status = 'active' AND publishable`. `featured` may only **rank or promote among projects already on the map** — it can never put an unpublishable or `hidden` project there.

That is a behaviour change: today's feed predicate is `featured = true AND status = 'active'`, so **featuring is currently load-bearing for visibility at all**, and an owner setting `public` on an unfeatured project would see nothing happen. R06 replaces the predicate; R07 dogfoods it. Without this decision the owner-control premise of the whole goal silently does not work.

## Decision 4 — The publish gate is identity only: `name` + `description`

Per the owner interview (recorded on R16): the bar is a name and a description. **Not** tagline, art, modules, governance, or a completed interview.

The bar exists to keep empty husks off the map — not to enforce completeness. A higher bar would make "skip the optional detail step" a dead end rather than the supported default the goal explicitly wants (`proj-detail-interview`: *"skipping it produces sensible defaults"*).

**The gate must name what is missing, never merely refuse.** A project that cannot be published and is not told why is indistinguishable from a broken one.

*Note for R04:* `platform_identity_projects` has `name NOT NULL` but **no `description` column** (only `tagline`). R04 adds it. Do not repurpose `tagline` — it is the card one-liner and a description is the publish bar; collapsing them means editing your card can unpublish your project.

## Decision 5 — Visibility is owned by the INSTANCE and mirrored to the hub

The hub's `platform_identity_projects` row is a **cache, never the source of truth.**

This follows from ADR 0141 §3 and the admin-console spike's D1 (*the instance IS the project; authority lives on the project instance*), and it resolves what otherwise looks like a gap: `owner_github_id` being "advisory, not an authority" is **correct**, not a hole to be filled. The hub never authorizes a visibility change; it accepts a report from the authenticated `sso_client` and stores it.

Two consequences that redirect seeded work:

1. **R05 (owner set/change visibility) is an INSTANCE surface**, not a hub one. The setting lives in the project's own hall settings, gated by the project's own ranks.
2. **R08 is the sync, not an afterthought.** A hub row whose visibility was never reported is stale, and stale here means *wrong on the public map*. R08's absent-report default must be **fail-closed: unreported ⇒ treated as not publishable (dark matter)**, so a project that has never spoken is off the map rather than exposed by omission.

The *trust* mechanics of that report — how the hub authenticates it, replay, rate — are **R02's** ([task 1002321](https://cloudbongos.com/builders#/task/1002321)), not this ADR's.

## Decision 6 — Per-state join rules, and how they compose with the join-policy setting

The applications *model* is already decided (`docs/specs/<redacted>.md` D2: extend `access_requests` with `kind ∈ ('application','invite')`, no new table). This ADR adds only the per-state rules on top:

| State | Self-join | Applications |
|---|---|---|
| public / planet | permitted | not needed |
| private / star | refused | accepted, owner reviews |
| stealth / black hole | refused | **refused at the door** (the public POST 403s) |
| dark matter | refused | refused — there is no door to knock on |

Stealth's distinction from private is **at the door, not in the queue**: a refused application is never stored, so a stealth project accumulates no queue to leak.

**Two knobs could contradict.** [task 1002817](https://cloudbongos.com/builders#/task/1002817) adds a per-project join policy (`open|closed`) at the same door. Rule: **visibility sets the ceiling; join policy may only narrow it.** A `closed` public project accepts no self-joins; an `open` stealth project still refuses everything. The stricter of the two always wins, and neither can widen the other. Without this, the two settings are a coin-flip decided by evaluation order.

## Decision 7 — The word `stealth` already means something else; product surfaces win, and the collision is tracked

`src/bongos/stealth-gate.js` + `STEALTH_PASSWORD` already mean *an instance-wide pre-launch password wall* — an entire instance made **unreadable**. Project `visibility = 'stealth'` means a project that is **on the public map, anonymously, refusing applications**. These are close to opposites, and ADR 0174 is the standing lesson that one word carrying two meanings costs more than a rename.

**Decision:** the *product* meaning (the owner-facing state, whose orb metaphor is locked by the criterion) keeps the word. The infra gate is the one that should be renamed — to `prelaunch` — but that touches a protected path, an env var, and a live instance's configuration, so it is **not** decided here by an ADR about visibility. It is filed as its own task with the owner's call attached.

**RESOLVED — the rename was taken** (owner, 2026-09-09 backlog review of goal [#1000111](https://cloudbongos.com/builders#/goal/1000111); executed by task [#1003152](https://cloudbongos.com/builders#/task/1003152)). This paragraph is kept rather than rewritten, because the open question is part of the record: what follows is what the rename actually did, not what it promised.

- `src/bongos/stealth-gate.js` → **`src/bongos/prelaunch-gate.js`**; `stealthGate()` → `prelaunchGate()`. The ~16 files carrying the PRODUCT sense are untouched, exactly as this decision says they must be.
- **`PRELAUNCH_PASSWORD` is primary; `STEALTH_PASSWORD` is honoured as a deprecated alias**, with a one-time startup warning when only the old name is set. The env is read in exactly one place, so honouring both is a single expression — and it had to be: `STEALTH_PASSWORD` is set on live today, and a rename that did not read it would be an instant, total outage of the instance. Dropping the alias is a separate, later task, and must not run until the live instance has `PRELAUNCH_PASSWORD` set.
- The submit path is **`/__prelaunch`**, with `/__stealth` still accepted and still exempt, so a form already open when the rename deployed still works.
- **Three identifiers deliberately did NOT move** — the cookie `cb_stealth`, the HMAC label `stealth-v1`, and the legacy path above. The first two are keyed into live cookies: <redacted> either forces every holder to re-enter the password and buys nothing, because neither string is ever read by a human. One is wire format, the other an HMAC message; neither is vocabulary.
- A fitness check in the ADR 0174 family (**check 19d**, `checkPrelaunchVocabulary`) now keeps the word from drifting back into the infra surface, scoped so the product surface's legitimate `stealth` never trips it. Per ADR 0174's own lesson it carries mutation tests: plant a violation, prove the build reds.

The last sentence of this decision is therefore now spent — `stealth` unqualified means the project state, and the infra gate says `prelaunch` in its identifiers as well as in prose.

## Consequences

- R04 lands `visibility` (3-value CHECK, default `public`, precedent `goals.visibility`) **and** the missing `description` column, plus the backfill. Existing rows keep today's behaviour: `visibility='public'`, publishable iff they already have a name and description.
- R06's feed predicate changes from `featured`-gated to `publishable + active`, with stealth rows redacted server-side. This is the single riskiest change in the goal — it is what actually moves control from Archon curation to the owner — and R10 is its proof.
- R05 moves host: instance-side settings, not a hub page.
- R08 defaults fail-closed on an unreported project.
- Anything reading `featured = true AND status = 'active'` as "is this public" is now wrong and must be found. `modules/platform-identity/routes/projects.js` is the known site.
- **R16 makes D3's bound real, and D4's gate reach a second module.** Shipping R16 (task 1002335) surfaced one thing this ADR left implicit. D3 says `featured` may never put an unpublishable project on the map, so `PATCH /projects/:id/featured` now refuses a dark-matter row (409 `not_publishable`, `missing` in the details); un-featuring stays unconditional, since an already-featured husk must remain removable. And D4's "name what is missing" is owed to the owner *before* their project is ever catalogued on the hub — which is the `provisioning` plane, a different module that ADR 0083 forbids from importing `platform-identity`. Rather than let a two-field rule exist twice, the gate is published as a kernel seam port, `project.publishGate` (`modules/platform-identity/publish-gate.js`). `provisioning` resolves it **optionally** and declares no `consumes`: `platform-identity` is hub-only, the public map is a hub concept, and a platform without one must answer "no verdict" rather than invent a local rule — which is the same drift-avoidance argument that produced `publishableSql` in the first place.

- **R06 landed the predicate swap and the redaction, and settled three things this ADR left to the implementer** (task 1002325, `modules/platform-identity/projects-feed.js`). (a) **A black hole carries no stable per-project key.** D2a lists `name`/`tagline`/`art_url`/`origin`, and an id looks harmless beside them — but any identifier that survives a state change lets an observer who kept yesterday's public feed diff it against today's and *name* the project that went stealth. So stealth rows are byte-identical to one another and the feed grew no public id at all; the orbs page keys by position. (b) **The redaction is an ALLOW-list, not a deny-list** — every key nulled except `state` and `orb` — so a column added to the feed later is anonymous without anyone remembering to come back to it, and it NULLS rather than deletes, keeping the feed's "never drop a key" contract. (c) **An unrecognised `visibility` draws as a black hole, not a planet**: this mapping is a privacy boundary, so a fourth enum value added without mapping it must fail closed. Two smaller notes: the route PATH keeps the word `featured` (it is rank:public and CORS-open, already fetched by a static site and other origins — renaming it would break them for nothing, and `ORDER BY featured DESC` is where the flag's D3 ranking job now lives); and `getRollupForBuilder`'s `is_public` was deliberately left on the OLD `featured AND active` predicate rather than widened with the feed, because a stealth project is on the map *anonymously* and naming it in a builder's profile would be the exact leak D2a forbids — how much of a cross-project record may be NAMED is ADR 0171 D2's question, and under-naming is the safe direction meanwhile. (Widened by task 1003558 to on-the-map AND Public; see the ADR 0171 D2 amendment.)

## Alternatives rejected

- **A stored four-valued enum including `unlisted`.** Rejected: it makes "unlisted" a choice competing with `private`, and it lets a project be simultaneously "publishable" and "unlisted" — two sources of truth for one question, which is the bug the derived gate prevents by construction.
- **A separate `published` boolean.** Rejected for the same reason: a boolean can disagree with the identity it is supposed to summarise. Derived cannot drift.
- **Letting `featured` keep gating visibility, with owner visibility layered on top.** Rejected: an owner who sets `public` and appears nowhere until an Archon blesses them has not been given control, and the goal's premise is that they have.
- **Client-side stealth redaction.** Rejected: the orbs page is a static site outside this repo, so the guarantee would be unenforceable by construction.
