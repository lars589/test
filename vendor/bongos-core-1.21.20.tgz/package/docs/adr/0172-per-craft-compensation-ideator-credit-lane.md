# 0172 — Per-craft compensation: the ideator credit lane, separate from cost-plus

- **Status:** Accepted
- **Date:** 2026-08-16
- **Deciders:** Lars (owner / Archon), Claude (Opus 5)
- **Track:** `internal` (Cloud Bongos — economy)
- **Task:** BV1.R171 ([#1002995](https://cloudbongos.com/builders#/task/1002995)) — the foundation of the **Ideator compensation** goal ([#1000067](https://cloudbongos.com/builders#/goal/1000067)).
- **Builds on:** [ADR 0054](0054-session-token-reward-cost-plus.md) (cost-plus session reward), [ADR 0146](<redacted><redacted>.md) (`rewardPolicy` + the `cost-plus-only` mode), [ADR 0023](0023-kind-multipliers-and-idea-bonus.md) (kind multipliers + the 25% idea-promotion slice), [ADR 0120](0120-pay-on-land-and-builder-owned-rebase-gate.md) (pay-on-land).
- **Relates to:** goal 1000062 (three grades of idea — R141/R142/R143 shipped), idea 1000738 (the Board Room).
- **Gates:** IC2 ([#1002996](https://cloudbongos.com/builders#/task/1002996)) · IC3 ([#1002997](https://cloudbongos.com/builders#/task/1002997)) · IC4 ([#1002998](https://cloudbongos.com/builders#/task/1002998)) · IC5 ([#1002999](https://cloudbongos.com/builders#/task/1002999)) · IC6 ([#1003000](https://cloudbongos.com/builders#/task/1003000)).

---

## Context

Cloud Bongos pays **one kind of worker one way**. The equity stream is the
cost-plus session reward ([ADR 0054](0054-session-token-reward-cost-plus.md)):
`round(true_cost_usd × (1 + margin))`, booked when a shipped session lands. On
top of that, [ADR 0023](0023-kind-multipliers-and-idea-bonus.md) pays the
capturer of a promoted idea a **25% slice** of the resulting task's estimate
when it ships, and [ADR 0146](<redacted><redacted>.md)
lets an instance switch to `cost-plus-only`, which **withholds every per-task
estimate payout — the idea slice included** (it is a fraction of a payout that
is now zero, so it "cascades to 0", `credits.js:235`). cloudbongos.com runs
`cost-plus-only`.

Two things are now true at once, and they conflict:

1. The **ABI model** (goal 1000062, the owner's Holy Workshop Trinity brief)
   makes the **ideator** a first-class craft whose *output is a Full Idea* — a
   deliverable, scored on completeness (R142, shipped). The owner wants that
   craft **paid in credits**, on three streams (below).
2. On the live instance those credits **cannot be paid**, because they ride the
   very per-task estimate path `cost-plus-only` exists to withhold.

The owner resolved it with a principle, 2026-08-16:

> *"this should [be] separate from cost plus, an idea-tor should get paid
> differently than an artist and builder."*

Compensation is **per-craft**. A builder earning cost-plus for shipping and an
ideator earning credits for thinking are **not the same reward being tuned two
ways** — they are two different lanes. The `cost-plus-only` switch governs the
*builder estimate* lane; it must not reach across and silence the *ideator*
lane, because that lane is a different craft's pay.

## Decision

### 1. Compensation is per-craft; the ideator credit lane is its own reward, exempt from the `cost-plus-only` gate

The reward model gains a **named lane per craft**, not a single tunable payout:

- **Builder (engineer)** — the cost-plus session reward ([ADR 0054](0054-session-token-reward-cost-plus.md)) plus, where `mode !== 'cost-plus-only'`, the per-task estimate ([ADR 0146](<redacted><redacted>.md)). Unchanged.
- **Ideator** — the **idea credit lane** defined here (three streams, §3). Governed by its **own** policy flag, **never** by `perTaskCredit`.
- **Artist** — a lane of its own, **deliberately left unspecified here** (the artist craft — grading, copy, voice — is scoped in later ABI work). This ADR reserves the *shape* (a named lane) so the artist lane slots in the same way; it does not define the artist's pay.

The rule that makes this real and testable: **no ideator-lane credit is ever
gated on `perTaskCredit`.** `cost-plus-only` withholds the builder estimate and
nothing else.

### 2. `rewardPolicy` grows an ideator dimension; the gate is separate from `perTaskCredit`

`rewardPolicy(rawReward)` (`modules/economy/credits.js`) today returns
`{ marginPct, usdPeg, mode, perTaskCredit }`, where
`perTaskCredit = mode !== 'cost-plus-only'`. It gains an **independent** flag:

```
ideatorCredit: <resolved from reward config; default TRUE>
```

`ideatorCredit` is **not derived from `mode`.** An instance in `cost-plus-only`
still has `ideatorCredit: true` unless it explicitly opts the ideator lane out.
The ideator-credit writers (IC2/IC4/IC5) gate on `config.ideatorCredit`, never
on `config.perTaskCredit` — the same shape as the existing per-task gate at
`credits.js:238`, pointed at a different flag. An instance that wants *no*
ideator pay sets it false; the default pays.

### 3. The three ideator streams (the credit model)

All three book to `credit_log` under **ideator-lane reasons** (namespace
`idea.credit.*`), distinct from `task.shipped`, `task.confirmed`,
`idea_promotion_bonus`, and the session cost-plus. Idempotency keys are named
per stream so a re-grade / re-ship / re-vote never double-pays.

- **Stream 2 — a passing Full Idea pays 5 credits, once** (IC2, buildable now).
  When a Full Idea (R143) clears the completeness bar, book **5** to its author,
  once, `reason='idea.credit.full_pass'`, idempotent on `(idea_id, reason)`. The
  bar is a completeness threshold set in the reward config (default proposed:
  **60/100** — the R142 score at which four of five base fields are
  substantively answered). Buildable today: R142 + R143 shipped.

- **Stream 1 — 5 credits per shipped task under the idea, scaled by idea grade**
  (IC4). As each task descended from an idea (the IC3 lineage) first reaches
  `shipped`, book `round(5 × gradeFactor)` to the idea's author, once per
  `(idea_id, task_id)`, `reason='idea.credit.task_ship'`.
  `gradeFactor = completeness%/100` for a Full Idea; for a **Quick Idea** (no
  completeness score) a flat `QUICK_IDEA_FACTOR` (default proposed **0.6**).
  **This REPLACES the ADR 0023 25% slice** (§4).

- **Stream 3 — a board-room-passed idea pays up to 100 × completeness%** (IC5,
  future). When a Full Idea passes the project's governance vote (the Board
  Room, idea 1000738 — *not yet built*), book
  `max(floor, round(completeness% × 100))` to its author, once per idea,
  `reason='idea.credit.governance_pass'`. Owner floor ~**30**. Consumes the
  Board Room's pass event; invents no parallel vote.

### 4. The ADR 0023 idea-promotion slice is retired in favour of stream 1

The 25% slice (`IDEA_BONUS_FRACTION = 0.25`, `reason='idea_promotion_bonus'`)
and stream 1 are **two rules for the same thing** — "an idea earns when its work
ships." Running both would pay an idea twice on every ship. Stream 1 (IC4) is
the go-forward rule; when IC4 lands it **removes** the 0.25 slice write, so
there is one idea-credit-on-ship path, not two. Until IC4 lands, the 0023 slice
stays (harmlessly zero on `cost-plus-only` today). The switch-over is a single
change inside IC4, guarded so no window pays both.

### 5. Two structural facts the streams depend on (recorded, not built here)

- **Stream 1 needs one idea → many tasks.** `idea_inbox.promoted_to_task_id` is
  a single FK. IC3 adds the many-tasks lineage — **preferred shape: an
  ideas-owned `idea_tasks` join keyed by task id**, so it needs no `ALTER` on
  the protected `tasks` table and the work stays inside the `ideas` module wall.
  Set at promotion and at develop (R146).
- **Stream 3 needs the Board Room.** IC5 waits on idea 1000738.

## Consequences

- **cloudbongos.com can pay ideators on `cost-plus-only`.** The whole reason
  this goal exists. Builders keep earning cost-plus and nothing else; ideators
  earn the idea lane; the two no longer collide. IC6 proves both hold at once.
- **`rewardPolicy` stays a pure function** — one added field, resolved from
  reward config, unit-testable without the `branding()` cache (the ADR 0146
  pattern). No new table: the thresholds/factors (pass bar, quick factor,
  governance floor) are **policy constants in `credits.js`** for the same
  reasons ADR 0023 kept the kind multipliers in code — they deserve a review +
  ADR + commit trail, not a hot-path UPDATE. A future migration can promote them
  to a table if per-instance tuning is wanted.
- **Artist pay is deliberately unresolved.** This ADR commits to the *shape*
  (per-craft lanes) so the artist lane lands the same way; it does not price the
  artist craft. That is later ABI work, and pretending to settle it here would
  be a decision made without the design.
- **The numbers are proposed defaults, not owner-locked.** The pass bar (60),
  quick factor (0.6), and governance floor (30) are this ADR's starting values;
  each is a one-constant change and each downstream task (IC2/IC4/IC5) surfaces
  its own for confirmation. The owner set the *structure* (5 / grade-scaled /
  up-to-100-by-fullness); these fill the gaps the structure left open.
