# ADR 0330 — An ask is answered where it was asked

**Status:** Accepted · **Date:** 2026-09-23 · **Task:** [1004216](https://cloudbongos.com/builders#/task/1004216) · **Goal:** 1000095
**Amends:** [ADR 0187](0187-collab-four-decisions.md) §4a (the Agora deferral) and its §3 consent posture (unchanged, restated)

## Context

`lifecycle_004` shipped a surface where a builder can ask for help and the **asker**
can mark their own row answered. The person being **asked** got no write at all.

So the answer — the only thing the surface exists to produce — happened somewhere
Bongos cannot see: in a session, in a terminal, in somebody's head. The row then
sat open until its author happened to remember it. On 2026-09-23 six help requests
addressed to the owner had been open between four and thirteen days, and every one
of them was answerable; two were answerable in a sentence.

The surface was not under-used. It was half-built, and the missing half was the
half that ends things.

### Why it was half-built

Not an oversight. [ADR 0187](0187-collab-four-decisions.md) §4a put conversation
out of scope and deferred it:

> It is in scope for this goal and it is **BLOCKED**, on task 1002946 (BV1.R166,
> the Agora surface in goal 1000064) … **this goal must not quietly reimplement
> the Agora to get around it.**

That was right at the time. It was enforced, too — `tests/collab_page.mjs`
carried a test named *"there is deliberately NO reply thread — that would
reimplement the Agora"*, which banned `data-reply`, `data-comment`,
`data-thread` and `data-message` from the page.

### What changed

**The deferral lost its addressee.** Verified 2026-09-23 against the live
database: task 1002946 is **abandoned**, and goal 1000064 is **archived**.

The surface that was to own replies will not be built. So the rule was no longer
"wait for the Agora"; it was "an ask stays unanswerable, permanently, to keep a
promise to something that does not exist".

## Decision

### 1. An ask carries a thread of replies, and the thread is append-only

A new module-owned table, `lifecycle_help_request_replies`
(`modules/lifecycle/migrations/lifecycle_011_help_request_replies.sql`): a reply
belongs to one help request, names its author, carries a body, and is stamped.

**The restraint that made §4a right is kept, and it is kept in the schema rather
than in a comment asking nicely.** There is no `updated_at`, no `edited_by`, no
`deleted_at`, no `parent_reply_id`, no reaction table and no mention table — and
a trigger refuses `UPDATE` and `DELETE` outright, so the guarantee does not rest
on the routes that happen to exist today.

That line is the whole argument for why this is not the surface §4a declined:

| An answer surface | A chat surface |
|---|---|
| add a reply; read them in order | edit, delete, nest, react, mention |
| a record of what was said | a medium for talking |

A thing you can edit, nest, react to and address at people is a chat. This is
not that, and it cannot drift into being that without a migration that says so
out loud.

**The foreign key restricts; it does not cascade.** `ON DELETE CASCADE` reads
right — a reply has no meaning without the ask it answers — and it cannot be
true at the same time as append-only: a cascade is an ordinary `DELETE` on the
replies table, the trigger refuses it, and deleting an answered help request
fails outright. (Found by applying the migration to a live Postgres rather than
by reading it; the Consequences section records how.) Nothing deletes a help
request today — it is settled, and no DELETE route exists — so the restriction
forbids something that does not happen, and if it ever must, refusing to destroy
answers as a side effect of removing the question is the right answer for an
append-only record to give.

**Any builder may reply,** deliberately. The board read (`GET /help-requests`)
is already project-wide, so every member can already see every open ask, and a
reply says nothing more private than the ask it hangs under. Restricting replies
to the addressee would also break the common good case: somebody who is not who
you asked turns out to know the answer.

### 2. The addressee may close an ask; withdrawing stays the asker's

`setHelpRequestStatus` scoped its `UPDATE` to `requested_by`. It now admits the
person the request **names** — by id, or through a craft they belong to — for
`answered` only.

Asker-only was coherent while there was nothing to say on the row: the only
person who could know an ask had been dealt with was the one who had gone and
got the answer elsewhere. Once the answer is **on** the ask, a person who has
answered it in the open and still cannot close it is a surface arguing with
itself.

**`withdrawn` does not widen.** Withdrawing means *"I no longer need this"*,
which only the person who needed it can say; letting an addressee withdraw would
hand them a way to make an ask disappear without ever answering it. An addressee
who wants rid of an ask answers it and closes it, in the open, with their name
on both — `settled_by` records which of the two did.

**Consent is untouched.** ADR 0187 §3 stands: being asked assigns nobody
anything. Closing an ask ends a question; it does not accept work.

### 3. `/collab-review` posts a reply, and does not close

The skill previously filed a **new help request back at the asker**, because
that was the only channel that existed. That workaround is deleted, not left
beside the real thing.

It posts the reply and **leaves the ask open** (owner decision, 2026-09-23). An
answer the reader has not read is exactly the kind of thing an unattended run
must stop on, and closing on it would settle a row on words nobody checked.

## Consequences

- **A reply cannot be taken back.** That is the point, and it is worth saying
  plainly: a person posting one is putting something on the record. The page says
  so by having no edit control rather than by warning about one.
- **A help request with replies cannot be deleted** (the decision above). Worth
  recording HOW that was found, because it generalises: the first draft cascaded,
  every unit test passed, and the contradiction only appeared when the migration
  was applied to a real database and an answered ask was deleted. An invariant
  enforced by a trigger and an invariant enforced by a constraint cannot be checked
  against each other by reading either one.
- **A test was replaced, not deleted.** `tests/collab_page.mjs` now asserts the new
  rule *and its limits* — that a reply surface exists, and that the four chat
  affordances do not. Deleting the old test would have removed the only record
  that the restraint was ever deliberate.
- **Two rows, one loop, for now.** An answered ask is closed by a person, not by
  the act of answering. Auto-closing on a reply was considered and declined: a
  reply is often a question back.
- **Reading an unknown ask's replies answers `[]`, not 404**, while posting to one
  does 404. Deliberate: this surface has already had a refusal path that let a
  caller enumerate ids by watching the error change, and a 404 on a GET would
  rebuild that oracle on the cheapest possible request. A write can afford the
  better error; a read cannot.
- **Still no notification.** Replies inherit the pull, not push, posture — nothing
  tells an asker their ask was answered until they open Collab. That gap is
  unchanged by this ADR and is the obvious next thing.

## Alternatives considered

**A single `answer` column instead of a thread.** Cheapest, and unambiguously not
a chat. Declined by the owner on 2026-09-23: an answer frequently prompts a
follow-up, and with one field the follow-up has nowhere to go except a second ask,
which splits one conversation across two rows and two queues.

**Wait for the Agora.** Not available — the task is abandoned and its goal
archived. Waiting would mean waiting forever.

**Let anyone close any ask.** Simpler than the two-party rule. Declined: an ask is
somebody's open question, and a stranger ending it is not a thing that should be
one click away.
