# 0267 — Unanimity, and the revise-and-re-sit loop

- **Status:** Accepted
- **Date:** 2026-09-08
- **Tasks:** [#1003733](https://cloudbongos.com/builders#/task/1003733) (goal [#1000111](https://cloudbongos.com/builders#/goal/1000111) — Government).
- **Amends:** [ADR 0175](0175-the-board-room-full-idea-ratification.md) §3 (the pass-rule set) and [ADR 0191](0191-majority-and-the-author-who-may-not-decide-alone.md) §2 (the same set, and the clock argument in §4). Everything else in both stands — in particular 0191 §3, the author who may vote and may never decide alone, which this decision leans on rather than touches, and 0175 §8, Discord is outbound-only and never a ballot.

## 1. The decision

The owner, 2026-09-08: *"first vote does not pass. A Full idea requires majority,
or unanimous decision making, with revisions until there is unanimous decision
making."* Asked which of the two readings that was, they chose **unanimous from
round one**, and — asked whether a member who never votes should block an idea —
answered **no**, *"this is why we want that timer rule from before implemented."*

So the rule is:

> **A Full Idea is ratified by unanimous agreement.** Everyone who votes must
> vote yes, and at least one member must. One reasoned objection returns it to
> its author, who revises it and puts it back to the board — as many rounds as it
> takes. Being away blocks nothing; the clock is what ends a sitting nobody
> finished.

## 2. Unanimity is two conditions, and the second is the one people forget

`unanimous` joins `first_ratifier`, `consent` and `majority` in `PASS_RULES`. The
four rules are still not a ladder of strictness — they differ on **what silence
means**, which stays the axis that matters (0191 §2):

| Rule | What carries it | **What silence means** |
|---|---|---|
| `first_ratifier` | the first vote cast | an unvoted item **passes** |
| `consent` | anything but a reasoned objection | an empty window **passes unopposed** |
| `majority` | more than half of the **membership** votes yes | absence counts against; an item that never reaches a majority **returns** |
| `unanimous` (new) | nobody who spoke objected, **and somebody spoke** | absence is nulled — it neither blocks nor carries; an unvoted item **returns** |

Unanimity is not "nobody objected". **An empty room agrees to nothing**, so a
sitting that ends with no affirmative voice returns rather than passing. Without
that second condition `unanimous` would collapse into `consent` at expiry, and
the clock the owner asked for would become an auto-ratifier — precisely the trap
0191 §4 identified when it refused to give a deadline to `first_ratifier`.

**There is deliberately no membership denominator.** That is the whole difference
from `majority`, and it is the owner's "silence does not block" written as code:
a member who never votes is not in the reckoning at all. One yes out of four
carries. The cost of that permissiveness is real and is stated here rather than
hidden — an idea can be ratified by one attentive reader on a distracted board —
and it is the price of the deadlock the alternative produces. A unanimity rule
with absence in the denominator is a rule where one person on holiday stops the
pipeline.

## 3. The clock is now safe, and it is not armed by default

0191 §4 established the condition: **a deadline may only be given to a rule whose
expiry means return.** `unanimous` satisfies it, so a project adopting this rule
may set `window_minutes` — and should, because a returned idea is only useful if
the return actually arrives.

The R11 expiry sweep (`modules/government/pollers/board-expiry.js`) already
closes due items through the same `closeItem` a vote uses, so the timed half
needed no new machinery — only a rule it is safe under.

**`BOARD_DEFAULTS` is unchanged: a fresh instance is still the day-one monarchy**
(`rank:archon` · `first_ratifier` · no clock). This is not timidity, it is 0191
§5's finding applied: under any rule carrying the non-author-yes requirement, a
**solo instance cannot ratify its own ideas** — there is no non-author yes
available. Shipping unanimity as the neutral default would hand every new Cloud
Bongos instance an idea pipeline that returns everything its founder writes. The
fail-closed fallback also stays `first_ratifier`, so a malformed constitution
still cannot resolve to a wider or easier board.

**A project adopts this rule the constitutional way — by amendment**, in the
Board Room, which is what 0175 §7 and its owner decision 11 reserve constitution
changes to. Config-by-deploy-flag is still refused: `resolveGovernmentConfig`
keeps its "no env var can change the constitution" property, pinned by test.

## 4. What ends a sitting, and what does not

Two changes to the trigger, both following from the rule rather than added to it:

- **A single yes does not close it.** Unlike `first_ratifier`, a later member
  must still be able to object, so the sitting runs its clock. Full turnout
  closes it early, as under `consent` — by then every position is recorded.
- **A reasoned objection closes it at once.** There is no vote-changing in v1, so
  a non-author `no` fixes the outcome at *returned* whatever the absent members
  do. Holding the sitting open past that point would only delay the feedback the
  author needs in order to revise — and revising is the point of this rule. Same
  reasoning as `majorityDecided`'s unreachable branch.

The ADR 0191 author rule rides both unchanged: an author's cast never ends their
own sitting, their `no` cannot return their own idea, and the affirmative voice
that carries it must not be their own.

## 5. The loop already existed; what was missing was a rule that used it

`POST /api/gds/inbox/:id/resubmit` has re-graded a returned Full Idea and
re-fired the window hook since goal 1000069 — and `latestRejectionForIdea` hands
the author the objection's reason and flagged section on the way back. The board
owes that loop two things, and now pins both by test: a return **closes** the
item (so `government_003`'s partial unique index admits the next window), and a
return **pays nothing** (so a round trip through revision can never earn credits
or ratification karma).

The loop is unbounded on purpose. "Revisions until there is unanimous decision
making" has no round limit in it, and a cap would just be a different way of
killing an idea than the board deciding to.

One honest gap: a **zero-vote** return carries no objection, so the author gets
the mechanical weakest-section flag instead of a human reason. That is the
correct fallback — it is what the sub-bar path already uses — but it means a
generous window and a working summons stay load-bearing, exactly as 0191 §5 said
of majority.

## 6. What this does not do

**It does not change what cloudbongos.com is running today.** The live
constitution resolves to `first_ratifier` / `rank:archon` / no clock, *despite* a
consent amendment that passed on 2026-08-25 — `applyBoardAmendment` wrote the
instance pack and the live resolution never moved. That is a separate defect
(a ratified amendment that does not survive to the next read is a governance
system lying about its own constitution), filed on its own task rather than
absorbed into this one. Until it is fixed, adopting unanimity on this instance is
blocked behind it — which is the same trap 0191 fell into, and worth naming
loudly rather than discovering twice.
