# ADR 0363 — Who decides what is a per-project table, changed only by a passed amendment

- **Status:** Accepted.
- **Date:** 2026-10-02
- **Task:** [task 1004529](https://cloudbongos.com/builders#/task/1004529) (goal 1000125, the Governor City).
- **Builds on:** [ADR 0016](0016-trust-boundary-server-enforced-permissions.md) (authority is resolved server-side, per request, uncached), [ADR 0175](0175-the-board-room-full-idea-ratification.md) (the board and its amendments), [ADR 0179](0179-board-membership-predicate-grammar.md) (the membership grammar), [ADR 0191](0191-majority-and-the-author-who-may-not-decide-alone.md) (the author rule, and why a clock is safe only where silence returns), [ADR 0362](0362-the-governor-docket-is-collected-from-contributed-sources.md) (the docket).

## Context

Before this, every building of a project's government was decided one way. Whoever held that building's fixed permission acted alone through its own page (the rank gate). Only the charter had a board. The reference design (`docs/design/mocks/governor-city/Governments.dc.html`, "Four governments") shows one project decided four ways: one founder, a council, everyone votes, and a board of trustees. Each building is decided by a named seat under one of seven rules (decide alone, first yes, consent, majority, unanimous, sign-off, or vacant). A project starts from one of the four and amends itself as it grows. So "who decides, and how" has to be data a project can change, and it has to change in the only way a constitution changes: the board passing it.

## Decision

**D1 — One row per building, in `government_decision_rules` (migration `government_023`).** The buildings are the docket's nine: charter, rules, disputes, people, planning, automation, review, release and treasury. An instance is one project, so the building is the whole key. A row is `decided_by` plus `rule`:
- `gate`, with no rule, means **as today**: whoever holds the building's fixed permission decides alone. Every building except the charter starts here.
- `board` is the charter's only value. The charter is decided by the constitution's own board under its own pass rule, and is changed by amending the board block, never through this table.
- `nobody` with `vacant` means no one holds the building yet.
- A membership predicate in the board's grammar (`rank:<key>`, `rank:<key>+`, `rank:a,b`) with one of the six sitting rules.

`who` carries the seat in the design's words ("Mira under $50, the council above"). It is display only.

**D2 — The defaults are today.** The migration seeds the nine as-today rows. A missing or malformed row also reads as its default, so the table can never read wider than today. No existing project's permissions change until it passes an amendment.

**D3 — Changed only by a passed amendment, enforced three times.** A change is an amendment of the new kind `decision_rules` (`government_amendments.kind`), filed by `POST /government/board/decision-rules` and decided by the board in force like any amendment. It is written in exactly one place: inside the transaction that closes it as passed (`decision-board.applyPassedDecisionRules`, called from `board.closeItem`'s in-transaction hook). The guard is enforced in three places:
1. The JavaScript guard refuses anything but a passed `decision_rules` amendment that names its own amendment.
2. The SQL write carries the same condition.
3. `government_023`'s trigger refuses any insert or update that does not name such an item, and refuses every delete. This covers a hand-written UPDATE too.

A failed write rolls the close back, so the sitting is retried and is never recorded as passed but unapplied. There is no settings route that writes the table. The proof is in `tests/government_decision_rules.mjs`, which scans for writers and probes the guard.

**D4 — More subjects: one matter per building.** The board voted on three subjects (a Full Idea, a constitutional amendment, a genesis stage). This adds eight more, `rules_matter` … `treasury_matter`, stored in `government_matters`, for eleven in all. `POST /government/board/matters` opens a matter **only** where the building's row names a sitting. Under the defaults every building refuses (`decided_by_gate`), and a vacant building refuses (`no_one_holds_this`). A matter's sitting is snapshotted from the row: the predicate's members and the rule (decide, first and sign-off sit as first-yes; consent, majority and unanimous as themselves). The table's own `rule` rides the snapshot. A clock is set only under majority or unanimous, because under the others expiry would pass a matter nobody read (ADR 0191 §4). **Sign-off is the author rule:** the proposer's own yes never decides. A matter pays no credit and no karma. A passed matter emits `board.matter.passed`.

**D5 — The gate is replaced where the building allows it, starting with People.** The building's own direct act asks `checkActAlone(area, builder)`. As today, the act is allowed and the route's permission is the whole gate. Under decide or first-yes, only a member the row seats may act alone. Under any other rule, or vacant, nobody may act alone, so the act is refused (409 `decided_by_sitting`) and points at the matter route. This build wires People's own acts in this module, giving and taking a custom rank (`POST`/`DELETE /government/assignments`). A People matter may carry that act (`assign_rank` / `unassign_rank`, custom ranks only, the same walls as the route), and it is carried out when the sitting passes. The route pins are unchanged: the permission is still the coarse gate, and the row only narrows who may use it alone.

**D6 — The feed reads the table.** `GET /government/docket` gives each building a `decision` (who, rule, whether as today, and the amendment that set it). A building's sitting carries the rule from the table snapshot. A contributed matter (an access request, an override request) keeps the rule its own route decides it by, because that route's gate still decides it until its module adopts `checkActAlone`. `GET /government/constitution` carries the table as `decision_rules`. A rules amendment is never compared against the board block by the divergence check (ADR 0268).

## The four governments, expressed

Each is a constitution plus rows. `tests/government_decision_rules.mjs` reads the four columns off the design file and checks that every building resolves to the design's glyph:
- **One founder:** monarchy; every building `rank:archon` decide, except People `rank:archon` first and Review `rank:xenos+` sign-off.
- **A council:** board `rank:council` unanimous; Rules and Planning majority; People consent; Disputes decide; Treasury `rank:treasurer` decide; Review vacant; Release and Automation `rank:archon` decide.
- **Everyone votes:** board `rank:xenos+` majority, with the same predicate on most buildings; Review `rank:tester` sign-off; Release `rank:lead` first.
- **A board of trustees:** board `rank:trustee` unanimous; maintainers run Planning, Release (first) and People (consent); Review `rank:reviewer` sign-off.

The council, tester, lead, trustee, maintainer and treasurer seats are the project's own custom ranks. A proposal naming a custom rank that does not exist is refused, because it would seat nobody.

## Consequences

- Owning modules adopt `checkActAlone` on their own direct acts, one at a time: admission and goal join requests (People), goal creation (Planning), report judging (Disputes), settings (Rules), the fence (Automation), criteria (Review), the pin move (Release) and budgets (Treasury). Until then, a row for those buildings decides that building's board matters, and the direct page still decides alone. The docket says so honestly (D6). Widening, where a row lets a seat that does not hold the permission act, is deliberately not done here. It would put the table inside the permission resolver, which is a trust-boundary change of its own.
- An objection on a matter still names a Full Idea section (the vote CHECK is unchanged), the same position as a genesis stage.
- Opening a matter needs `board.item.open` (metic floor). A project where everyone votes still has its matters put up by metics and above.
- Rejected: a settings route for the table (it would let a rank gate rewrite the government); a separate amendments table (a second pass path to keep in step); storing the rows in the instance config file like the board block (a row must be a database fact the trigger can guard).
