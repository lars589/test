# 0334 — The recruiting directory lists a hidden builder by name, and hide changes a row's shape, not whether it exists

- **Status:** Accepted
- **Date:** 2026-09-24
- **Task:** [#1002291](https://cloudbongos.com/builders#/task/1002291) (R15, owner recruiting UI; goal 1000045 C5, now folded into goal 1000110)
- **Relates to:** `docs/specs/<redacted>.md` D2 (owner-signed 2026-08-16), [ADR 0171](0171-profile-rollup-join-and-consent.md) D2, [ADR 0210](0210-scouting-graduates-on-an-instance-asserted-owner-claim.md) D4, [ADR 0215](0215-the-recruiter-sliver-is-a-ceiling-not-a-step.md), [ADR 0217](0217-rank-gates-inviting-not-viewing.md) D1/D2

## Context

R15 asks for an owner recruiting surface with search, a role filter and a sort by track record, and says it must honour the hide flag and the recruiting opt-out. Most of that already existed when the task was picked up. The hall's `/people` page (tasks 1002577, 1003470, 1003110) searches, filters by role and sorts. R14 (task 1002290, ADR 0210) opened it to project owners and made the opt-out remove a builder. The one thing that did not match the owner-signed spec was what "honour hide" does.

The privacy spec's D2 matrix has a row for an account that is active, public and has hidden its cross-project stats. In the recruiter column it says **"listed name-only (if not opted out)"**. The directory did something else: `listScoutingRollup` joins `rollupVisibleSql`, which excludes `hide_stats`, so a hidden builder was dropped completely. In practice hide worked as a second opt-out.

Two things made that a bug and not a harmless extra caution:

- **The Settings copy said the opposite.** A hidden builder's "Discoverable by recruiters" row says *"Because your cross-project record is hidden, they will see your name and your picture, and nothing else"*, and that turning the switch off *"removes you from … the People directory"*. For that builder the second sentence was false, because they were never in the directory.
- **Absence came from ADR 0171 D2, which predates the spec.** ADR 0171 dropped hidden builders from `/people` and `/scouting` before a privacy model existed, and it said *"if 1002785 lands a different privacy rule, its model wins"*. Spike 1002785 then produced the D2 matrix.

## Decision

**The directory answers in two tiers, and the hide flag decides a builder's tier, not whether they are listed.**

| | Who | Carries |
|---|---|---|
| `builders`, the ranked tier | visible AND NOT hidden AND reachable (`scoutingListableSql`, unchanged) | the full rollup row, ranked on track record |
| `name_only` | visible AND hidden AND reachable (`scoutingNameOnlySql`, new) | `github_login`, `display_name`, `avatar_url` and nothing else |

1. **One predicate, flipped.** `scoutingNameOnlySql` is `scoutingListableSql` with the hide term reversed, built the same way. A test proves the two predicates differ only in that term, so no builder can be in both tiers or in neither. Only the recruiting opt-out removes a builder from the directory. It lives in `account-visibility.js` like every other visibility rule.
2. **The existence floor stays.** A private account is never listed, even by name, and even when it opted in to recruiting. That account is the D3 sliver's subject, and the sliver is gated at the archon floor, which the owner kept (ADR 0215 D4, ADR 0217 D2). This ADR does not move that gate.
3. **Presence must not depend on activity.** The ranked tier is built from the activity table, so only builders with a record appear in it. The name-only tier reads the accounts table alone. If it listed only hidden builders who had shipped something, appearing in the list would reveal that fact, and that fact comes from the hidden record.
4. **The only sort key is the login.** The ranked tier is sorted by the record itself, so a hidden row placed among ranked rows would reveal roughly where its record would rank. Name-only rows sit in their own panel in alphabetical order. No sort lens reorders them, a search matches their name, and a role filter never matches them because the role list is part of the hidden record.
5. **The row is a literal whitelist, and the predicate has exactly one reader.** `scouting-name-only.js` builds each row key by key from a statement that selects three identity columns. `scoutingNameOnlySql` admits hidden accounts by design, so a read that joined it and returned a number would leak the very record hide withholds. `tests/effective_visibility_predicate.mjs` therefore pins the predicate to that one file, that file to that one statement, and the statement to those three columns and no rollup table.

These three fields are already public. A hidden builder's public profile page (`GET /profiles/:handle`) shows their handle, login, display name and avatar to anyone. The directory's audience is `project.curate` or a project owner, which is narrower. The only new fact the directory reveals is that the builder has not opted out of recruiting, and recruiters are the audience that setting exists for.

## Consequences

- A hidden builder who is still discoverable now appears on `/people` by name and picture. Recruiters were already promised this, and the Settings copy is now true without any wording change. Turning off "Discoverable by recruiters" removes them from both tiers. `tests/account_privacy_flags.mjs` now requires all three recruiting predicates to include the reach term.
- `GET /scouting` gains a response key and changes nothing that already existed. `builders` still has the same rows and the same shape, and an older client that ignores `name_only` behaves as before. Under the hood the route now runs two reads instead of one. The page still makes a single request.
- Tests that asserted a hidden builder was *absent* from the directory now assert that the builder is *listed by name only*, and that none of their numbers appear anywhere in the response (`tests/profile_route.mjs` R06.3). The real-database proof `tests/profile_rollup_consent.mjs` calls `listScoutingRollup` directly, which is the ranked tier, and is unchanged.
- The creation wizard's invite suggestions (`invite-suggestions.js`, ADR 0251) still read the ranked tier only. A hidden builder has no record to rank, and adding them there would be a new decision, which this ADR does not make.

## Rejected alternatives

- **Keep the exclusion and just fix the copy.** This contradicts the owner-signed matrix row, and it keeps two switches doing the same job. Whether a builder can be found is the reach setting's decision alone.
- **Mix hidden builders into the ranked ledger as trailing rows.** Their position below everyone else would read as a ranking, a role filter would need special cases, and the count, pager and clipping logic would all have to account for two kinds of row.
- **Also list private, discoverable accounts by name.** That is the D3 sliver, held at the archon floor by an owner decision. The directory's door is wider than that, and widening it is exactly what ADR 0217 D2 declined to do.
