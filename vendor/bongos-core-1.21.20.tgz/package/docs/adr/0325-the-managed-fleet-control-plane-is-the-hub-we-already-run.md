# ADR 0325 — The managed fleet control plane is the hub we already run

- **Status:** accepted, **decision 4 superseded by [ADR 0327](0327-a-cloud-host-runs-on-the-owners-account-and-the-key-is-borrowed.md)** (2026-09-22) — decisions 1, 2, 3, 5 and 6 STAND. Decision 4's "one credential … never per-customer" is reversed: each project brings its own platform key, borrowed for standup and never stored. Its description of `/etc/cloudbongos/box.env` as "root-only on the control plane" was also wrong: the file is mode 600 owned by `lars`, not root, and the web tier runs as that same user, so the web tier could read it. **Fixed by [task 1004176](https://cloudbongos.com/builders#/task/1004176) (2026-09-23)** — a systemd drop-in carrying `InaccessiblePaths` makes the file unreadable inside the web tier's mount namespace, which is what §4 always meant even though it is not what §4 said. The runner units load it unchanged. "Root-only" remains the wrong description of the file; "unreadable by the web tier" is the right one.
- **Date:** 2026-09-22
- **Task:** [task 1001948](https://cloudbongos.com/builders#/task/1001948) (goal 1000106 — working area 1, Project creation)
- **Deciders:** the owner's decisions are [ADR 0323](0323-hosting-is-three-shapes-and-we-are-not-the-landlord.md)'s. Claude ran the inventory, and decisions 1–4 and 6 follow from that inventory plus 0323 without a new owner call — each one retires a plan rather than choosing between options. **Decision 5 is a recommendation, not a ruling**, and says so; it is filed for the owner rather than acted on.
- **Supersedes in part:** [ADR 0111](0111-instance-hosting-provisioning-module.md) §5/§7 (the "managed layer is greenfield, deferred, spec-first" sequencing)
- **Depends on:** [ADR 0323](0323-hosting-is-three-shapes-and-we-are-not-the-landlord.md) (the shapes and the platform this operates)
- **Gates:** [task 1004142](https://cloudbongos.com/builders#/task/1004142) (the platform leg) · [task 1001949](https://cloudbongos.com/builders#/task/1001949) (metering) · [task 1001621](https://cloudbongos.com/builders#/task/1001621) (the spend rollup)
- **Filed by this ADR:** [task 1004148](https://cloudbongos.com/builders#/task/1004148) (the $0 cost ledger — decision 6) · [task 1004150](https://cloudbongos.com/builders#/task/1004150) (the subscription roster — decision 5)

## Context

Task 1001948 was written against [ADR 0111](0111-instance-hosting-provisioning-module.md) §5, which described the managed offering as *self-host plus (a) the provisioning module pointed at Cloud Bongos's own infra and (b) a central operator driving the existing `bongos upgrade` channel*, and §7, which deferred it as **"genuinely greenfield (no fleet registry exists)"** behind two gates: R85 (Mercury, the first real second-repo consumer) and R86 (a real `bongos upgrade`).

Both gates are shipped. The premise is not.

**Measuring the call sites first changed the answer, as it did for [task 1004141](https://cloudbongos.com/builders#/task/1004141).** A fleet registry exists, an operator exists, and a fleet update channel exists. Naming them is most of this ADR's content, because a spec that designs what is already running is worse than no spec: it invites a second implementation of each leg.

### What already exists

| ADR 0111 §5 called it | It is | Where |
|---|---|---|
| "a central fleet control plane — greenfield; sits *above* per-instance GDS DBs" | **the hub's own database.** `provisioning_instances` is the fleet registry: one row per instance with its owner, slug, shape, domain, database, port, tier, lifecycle status, cost estimate, onboard mode, settings, module selection, the liveness overlay and the served/available core-version snapshot. `provisioning_intents` is the work queue, `provisioning_events` the audit trail. The control plane has a row of its own, enrolled by `scripts/gds/enroll-control-plane.js` ([ADR 0293](0293-the-owners-deploy-door-is-an-intent-the-control-plane-drains.md) D2), so the operator is *inside* the fleet it operates rather than above it | `modules/provisioning/migrations/` |
| "the operator" | **`scripts/gds/provision.js`** — the single token-holder that drains the intent queue, with an explicit per-action dispatch (`provision`, `teardown`, `domain-attach`, `settings-apply`, `restart`, `disconnect`, `core-upgrade`, `core-upgrade-preflight`) and a refusal for any action it does not recognise | ADR 0111 §2 |
| "fleet oversight" | **`GET /provisioning/fleet`** (the roster plus the box's slot capacity) and **`GET /provisioning/fleet/cost-ledger`** (per-instance and total monthly estimate), both gated on `provisioning.fleet.manage`, the same atom as force-teardown | `modules/provisioning/routes/provisioning.js` |
| "operator drives `bongos upgrade` across the fleet (same channel)" | **two channels, both shipped.** The owner's per-instance door ([ADR 0293](0293-the-owners-deploy-door-is-an-intent-the-control-plane-drains.md)) previews a target version and drives the proven `bongos upgrade` path with its health gate and auto-rollback; the unattended patch-only sweep (`core-update-subscription`, [ADR 0136](0136-update-channel-subscription-policy.md)) takes the newest published patch for each opted-in instance every 15 minutes | `scripts/gds/provision-core-upgrade.js`, `.claude/scheduled-tasks/core-update-subscription/subscribe.js` |
| — (not in §5) | **observation**: a ~5-minute liveness sweep that probes each active instance and writes only its overlay columns, with edge-triggered Discord notices, plus a fleet-wide core-version snapshot after every drain | `modules/provisioning/pollers/` |

The gates §7 named have both been paid: Mercury proved the two-repo path, and `bongos upgrade` is not only real but is what the deploy door drives.

## Decision

### 1. There is no greenfield fleet control plane to design, and none will be built

The hub *is* the fleet control plane. The registry is its own table, the operator is its own runner, and the trust boundary between them is [ADR 0111](0111-instance-hosting-provisioning-module.md) §2, unchanged: the internet-facing web tier only ever enqueues an intent and holds no cloud token.

This retires ADR 0111 §5's "sits *above* per-instance GDS DBs" framing. It never needed to sit above them: [ADR 0100](0100-two-repo-instance-model.md) §3 locks each instance's database to its own repo, and the operator has never needed to read one. It needs the roster, which is a hub table, and a shell or an API on the platform, which is the runner's.

### 2. The one thing genuinely missing is a platform leg, and it is task 1004142's

After [ADR 0323](0323-hosting-is-three-shapes-and-we-are-not-the-landlord.md), a `cloud-host` is stood up on Render, and `grep -rl 'RENDER_API\|render\.com' scripts modules src` returns nothing: every standup leg the runner has writes a systemd unit, a unix account, a Caddy snippet or a `createdb`. That is the whole of the managed layer's residue, it is already scoped, and **this ADR deliberately specifies none of it** — a second spec for one implementation is how two drift.

### 3. The fleet the operator DRIVES and the fleet it OBSERVES are different populations

`byo-host` is in the registry and is not operated: nothing is pushed to it, and its liveness is the [ADR 0252](0252-the-self-hosted-visibility-report-is-a-pull-and-auto-appear-buys-a-retraction-lever.md) pull against an owner-supplied origin. It is already excluded from settings-apply and restart for the same reason `dedicated` was, and [task 1004141](https://cloudbongos.com/builders#/task/1004141) made the provision leg a no-op for it.

**Every operator surface states which population it is counting.** A roster that silently mixes them reports a fleet-wide upgrade as complete while an unknown number of instances were never asked, which is indistinguishable from success.

### 4. The operator holds exactly one credential, and it is its own

[ADR 0323](0323-hosting-is-three-shapes-and-we-are-not-the-landlord.md) D6 settled that Bongos stores environment-variable NAMES and never values, so that it is not the custodian of other companies' credentials. That rule is about the *customer's* secrets and is unchanged here.

The managed layer needs one credential of its own — the platform account token that creates a `cloud-host` — and it belongs where every other operator token already lives: root-only on the control plane (`/etc/cloudbongos/box.env`), read by the runner, never by the web tier, never in the database, and never per-customer. A stolen builder token still cannot spin anything up; it can only ask.

### 5. The subscription roster should move into the registry — recorded, not built here

Every fleet fact lives in `provisioning_instances` except one: which instances take unattended patch upgrades, which lives in `config/update-subscriptions.json`, a file that ships empty and is edited on the box. It is the operator's own arming switch and works, but it is the only fleet fact the roster route cannot report and the only one a restored backup can lose independently of the rows it describes.

This ADR records the direction and files it as [task 1004150](https://cloudbongos.com/builders#/task/1004150) rather than building it, because it is a migration plus a route change on a surface [task 1004142](https://cloudbongos.com/builders#/task/1004142) is about to rewrite.

### 6. Metering is now real work, and the cost ledger is currently wrong

`costEstimateUsd` returns **0** for `standalone` — correct when a project was a process on a box we already paid for, and wrong the moment it becomes a ~$14/month Render service. Until it is fixed the fleet cost ledger reports \$0 for every project the platform is about to be billed for, and it reports it with no error.

That is a defect, not a deferral, and it is filed as [task 1004148](https://cloudbongos.com/builders#/task/1004148). The metering and invoicing track ([task 1001949](https://cloudbongos.com/builders#/task/1001949)) and the spend rollup ([task 1001621](https://cloudbongos.com/builders#/task/1001621)) stay separate work, as [ADR 0323](0323-hosting-is-three-shapes-and-we-are-not-the-landlord.md) already says.

## Consequences

- **1001948 closes as a spec that deletes most of its own scope.** The honest output of a spike whose premise was stale is the inventory that retires it, plus the named residue — not a design for the four legs that were already running.
- **No fleet-wide "upgrade everything" button.** Both existing channels are per-instance by construction: the owner's door moves one pin with a health gate and auto-rollback, and the patch sweep walks the opted-in roster one at a time and refuses to overlap runs. A single action that moves the whole fleet is the shape most likely to take every customer down at once, and nothing about the managed offering needs it.
- **The hub is the single point of failure, visibly.** With projects on Render, what is lost with the droplet is the control plane's own database — which is what makes offsite backups ([task 1002214](https://cloudbongos.com/builders#/task/1002214)) the highest-consequence open item in this goal, exactly as ADR 0323 said.
- **AGPL posture unchanged.** [ADR 0111](0111-instance-hosting-provisioning-module.md) §5's one-sentence rule survives its own table: self-host and managed run the same artifact and the same module, and the only differences are whose credentials the operator holds and who operates it. Nothing here is an open-core layer.

## Alternatives considered

- **Build the separate fleet control plane ADR 0111 §5 described.** Rejected: it would be a second registry beside `provisioning_instances` and a second operator beside `provision.js`, with the same rows in both and no mechanism keeping them equal. The measurement is the argument — every leg §5 listed already has an owner named in the table above.
- **Spec the Render integration here.** Rejected as duplicate scope. [Task 1004142](https://cloudbongos.com/builders#/task/1004142) carries it with those files open; a spec written a task earlier would be read as authority over code it never saw.
- **Read per-instance databases from the hub for fleet reporting.** Rejected. [ADR 0100](0100-two-repo-instance-model.md) §3's lock is what makes an instance's data its own, and the operator has never needed it: the roster, the intents and the liveness overlay answer every question the fleet view asks, from the hub's own tables.
- **Keep deferring the whole managed layer** (ADR 0111 §7's posture). Rejected: its two gates are shipped, and the deferral is now the reason the cost ledger reads \$0 for a fleet about to cost real money.
