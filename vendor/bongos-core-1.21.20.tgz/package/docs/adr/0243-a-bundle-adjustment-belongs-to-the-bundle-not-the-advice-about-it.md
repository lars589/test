# 0243 — A bundle adjustment belongs to the bundle, not to the advice about it

- **Status:** Accepted
- **Date:** 2026-09-03
- **Tasks:** [#1002341](https://cloudbongos.com/builders#/task/1002341) (this decision — BV1.R22)
- **Goal:** [#1000046](https://cloudbongos.com/builders#/goal/1000046) — Project creation, criterion
  `proj-module-select` ("during setup a default set of modules is pre-selected…")
- **Related:** [ADR 0237](0237-a-starter-bundle-is-a-preset-over-the-always-on-core-keyed-by-declared-type.md)
  (R19 — the per-type presets, and the file that said the bundle layer "is a declaration and not a rule
  engine"), [ADR 0239](0239-a-recommendation-is-a-table-that-carries-its-own-reason.md) (R17 — the rule
  engine, and the `TEAM_SHAPE_RULES` table this moves), [ADR 0240](0240-a-skipped-module-picker-stores-nothing-and-resolves-the-bundle-on-read.md)
  (R20 — the picker, the nullable `modules` column, and §2's "one function, called twice" property this
  is written to preserve), [ADR 0083](0083-modular-architecture-strangler-build-plan.md) (the one-way
  import rule)

## 1. The problem

R17 built a rule engine and R20 built a picker, and nothing connected them. The
picker preselected `bundleForProjectType(type).bundle` — the type's raw preset —
while `GET /provisioning/recommendations` separately applied `TEAM_SHAPE_RULES`
to that same preset and returned a different, better answer that no surface
rendered. R22 is the join: **surface the recommended modules inside the picker.**

Doing it the obvious way breaks the property R20 was built on. ADR 0240 §2:

> Skipping is safe because the preselect and the fallback are the same
> declaration. […] Not two lists kept in agreement — one function, called twice.

If the picker applies the team-shape rules and `effectiveModules` does not, then
an owner who answers the interview, sees the panel preselect `discord`, and skips
the picker gets a project **without** `discord`. The panel's promise — "skip it
and you get the suggested set below" — stops being true at exactly the moment the
interview is answered, which is the moment it starts mattering.

## 2. The rules move to the bundle layer

`TEAM_SHAPE_RULES` leaves `recommendations.js` for `starter-bundles.js`.
`recommendations.js` re-exports it, so its public surface is unchanged.

The reasoning is a distinction, not a preference. **A bundle adjustment is not
advice about the bundle — it IS the bundle, once the owner has answered.** The
three tables R17 shipped together are not the same kind of thing:

| table | what it produces | applied? | home |
|---|---|---|---|
| `TEAM_SHAPE_RULES` | the modules a project actually ends up with | **yes**, on read | `starter-bundles.js` |
| `GOVERNANCE_RULES` | a preset name + one sentence, `applied: false` | never | `recommendations.js` |
| `INVITE_RULES` | a `seeking` seam for R28 to fill | never | `recommendations.js` |

Governance and invites are genuinely advice: nothing in the system silently ends
up living under a governance preset. A module set is the opposite — it is what a
project *has*, resolved at read time for every row that never answered the
picker. A rule that decides that belongs where the resolution happens.

So: `adjustBundle` and the new `bundleForAnswers(type, teamShape)` sit at the
bundle layer, `effectiveModules` calls `bundleForAnswers` instead of
`bundleForProjectType`, and `recommendationsForDetails` calls the same resolver.
One function, still called twice — now with the interview's answer inside it.

## 3. `effectiveModules` reads `detail.team_shape` off the row

The fallback needs the interview's answer, and the answer already lives on the
row (`detail`, `provisioning_013`). It is read **straight off the row**, not
through `provisioning.js`'s `normalizeProjectDetail`, for two reasons:

- Importing it would point `starter-bundles.js` **up** at the module that
  requires it — `recommendations.js` already imports `PROJECT_DETAIL_VOCAB` from
  `provisioning.js`, and the bundle layer sits below both.
- It would buy nothing. An off-vocabulary shape matches no rule and adjusts
  nothing, which is precisely the answer the normalizer would have produced.

`RULED_TEAM_SHAPES` is derived from the rule table itself for the same reason.
`tests/provisioning_recommendations.mjs` pins it against `PROJECT_DETAIL_VOCAB`
so a fourth interview answer cannot arrive unhandled.

`effectiveModules` also gains `adjustments` — why the unanswered set is what it
is, in the owner's own words. It is `[]` for a `chosen` set: an owner's own
toggle needs no reason given back to them.

## 4. The whole answer table arrives in one read

`GET /provisioning/starter-bundles` already served `core`, `bundles` and
`optional` together, because (ADR 0240 §4) a picker that fetched its preselect
and its catalog separately could preselect a key it has no row for. Each bundle
now also carries `byTeamShape` — the same bundle re-resolved for every answer the
rules can fire on, each with the `adjustments` that got it there.

It rides this payload rather than a second read of `/provisioning/recommendations`
for the reason `optional` does. The owner flips the type question and the
team-shape question freely on two **earlier** panels; re-preselecting must not
cost a round trip, and a round trip it did pay could land after they had moved
on, or paint a module the panel has no row for. Five types by three ruled shapes,
plus each type's no-answer resolution, is twenty small rows — the whole preselect
table in one read of one declaration, computed purely.

## 5. The effect comes back with the cause

`PATCH /provisioning/instances/:id/detail` now returns `modules:
effectiveModules(updated)` alongside the `publish` verdict it already returned,
and for the same reason. Changing `team_shape` **moves the modules** of any
project whose owner never answered the picker (`source: 'bundle'`). An owner who
edits one answer and is told nothing about the other thing it changed would have
to go looking. A project with `source: 'chosen'` is unmoved and says so.

## 6. The panel says why

The picker renders one line per adjustment that actually fired, above the
always-on clause. ADR 0239 already made every rule carry its own `reason`
sentence; this is the first surface that shows one.

Two rules on when it appears, both from ADR 0239's delta principle:

- **Only rules that changed something.** A rule whose module the bundle already
  carried records nothing — "we switched discord on because you said community"
  over a module a game would have had anyway is a claim the owner can check and
  find false.
- **Only before the owner has answered.** Once `state.modules` is set, the
  reasons go away: a reason given back for a toggle they flipped themselves reads
  as the panel arguing with them.

The block wears `.reassure`'s weight deliberately. This is the panel explaining
itself, never a thing to act on, so it must not compete with the toggles it is
explaining. A preselect an owner cannot see the reason for is one they have to
audit, which ADR 0237 calls worse than no preselect at all.

## 7. Consequences

- **An adjusted bundle is returned in CATALOG order**, not append order.
  `normalizeModuleSelection` stores a chosen set that way and the picker
  re-derives its toggles that way, so an adjusted bundle that appended would make
  the same set of modules read as a different list depending on whether the owner
  answered the picker or skipped it.
- **A stale client degrades to the R20 answer.** A payload without `byTeamShape`,
  or a team shape no rule fires on, falls through to the unadjusted bundle — the
  answer this panel gave before R22, which is never wrong, only untailored.
- **The rules now run on every read of a bundle-sourced row**, not just on the
  recommendations route. They are pure, frozen and three rows long, so this costs
  nothing; it is noted because the blast radius genuinely grew.
- **Still no new storage.** ADR 0240's three-valued column is untouched, and a
  skipped picker still stores nothing. The adjustment is resolved, never written.

## 8. Rejected

- **Leaving the rules in `recommendations.js` and having the picker call
  `/recommendations`** — the two-lists-by-hand failure ADR 0240 §2 exists to make
  impossible, plus a round trip on every keystroke of two earlier panels that
  could land after the owner moved on.
- **Teaching `effectiveModules` to import `normalizeProjectDetail`** — points the
  bundle layer up at the module that requires it (ADR 0083's one-way rule), to
  buy an answer it already has.
- **Storing the adjusted bundle when the owner skips** — ADR 0240 §7 rejected
  this for the raw preset and every word still applies: it writes down an answer
  nobody gave, and freezes today's rules onto a project whose owner never
  expressed a view.
- **Moving governance and invites down with the bundle rules** — they are never
  applied, so there is no resolution for them to stay in agreement with. Moving
  them would be tidiness at the cost of the distinction that makes §2 true.
- **A reason line per matched condition rather than per actual change** — ADR
  0239's delta rule, restated at the surface that renders it.
