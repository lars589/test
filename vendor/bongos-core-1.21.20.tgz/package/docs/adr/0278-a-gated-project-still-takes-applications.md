# ADR 0278 — A gated project still takes applications, and the exemption is scoped to the verb

- **Status:** Accepted
- **Date:** 2026-09-11
- **Tasks:** [task 1003525](https://cloudbongos.com/builders#/task/1003525) (this decision + the applicant's poll), with the apply write itself in [task 1003624](https://cloudbongos.com/builders#/task/1003624).
- **Goal:** [#1000106](https://cloudbongos.com/builders#/goal/1000106) — Working area 1, Project creation.
- **Decider:** the owner, 2026-09-11. The question was raised as an owner decision by task 1003525's own body and by [ADR 0192](0192-platform-visibility-member-door.md) §3, and is answered here rather than by whoever held the task.
- **Extends, does not amend:** [ADR 0192](0192-platform-visibility-member-door.md) (the member door and its exempt list), [ADR 0194](0194-joinability-one-door-decision.md) (the join door), [ADR 0209](0209-one-budget-for-the-account-existence-oracle.md) (one budget across the two account-existence reads; the response-collapse question, still open).

## Context

A project's owner sets two things on the hub independently:

- **who may SEE it** — `project.platformVisibility`, `public` or `gated` (ADR 0192);
- **who may JOIN it** — `project.joinability`, `open`, `apply` or `invite_only` (ADR 0194).

Set both to their middle values — members-only *and* apply-to-join — and the
project took no applications at all. `platform-visibility-gate.js` mounts ahead
of every surface and refused each cookie-less request with `401` before the
public `POST <api>/access-requests` could answer, because that write was not on
the exempt list. The two settings composed into **"nobody can apply"**, a state
the owner never chose and no surface offered them.

Nothing lied about it, which is why it survived: the hub's join box reported the
project's own relayed `401` honestly as `members_only`
(`my-projects.js joinRelayOutcome`), and the hall's landing — where the apply
form lives — is itself behind the door. The composition was simply unreachable.
Found by the R14 proof ([task 1002333](https://cloudbongos.com/builders#/task/1002333)).

## The question, and why it was the owner's

ADR 0192 §3 fixed the exempt list at "the door, the manifest, the probes and the
downloads — and nothing wider", and named the cost of the one subtree it exempts
whole (`auth/*`). Widening it is a judgement about what a members-only project
owes a stranger, not an engineering detail, so §3 left it and task 1003525 asked
it directly: **may a gated project take applications from outside?**

The alternative was coherent and was genuinely on the table: gated means gated,
and the fix is to stop offering a door that cannot work — say so in the manage
page's joinability blurb, and hide *Apply to join* while visibility is gated.

## Decision

**Yes. A gated project still takes applications, and both halves of that are
exempted — each scoped to one path and one verb.**

1. **`POST <api>/access-requests` is exempt** (task 1003624). The application
   itself. It grants nothing: an application is a row in a queue the owner still
   reviews (ADR 0201), it carries its own per-IP and per-login limits, and it is
   public on every non-gated project already.

2. **`GET <api>/access-requests/status` is exempt** (task 1003525). Without it
   the answer is half an answer. `bongos login` cannot re-poll the device flow
   after a `not_approved` — the `device_code` is spent — so it polls this route
   instead and restarts sign-in once admitted. Exempting only the write would
   let an applicant file a request and then wait on an approval they can never
   observe.

3. **The exempt list learns about verbs, and the new entries use them.**
   `EXEMPT` entries may now be `{ re, methods }` beside the existing bare
   `RegExp`s, and `isExempt(path, method)` takes the method as an OPTIONAL second
   argument that **fails closed** for a scoped entry when no verb is given — so
   the existing one-argument static callers (`tests/version_literals.mjs`,
   `tests/prelaunch_gate.mjs`) are unchanged and cannot accidentally widen.

   The verb is load-bearing, not tidiness. The bare `GET` on
   `<api>/access-requests` is the **owner's queue**
   (`requireBuilder` + `access_request.review`) — the surface that lists
   would-be builders by name, with their vouch state. A path-only exemption
   would have silently removed the member door from in front of it, leaving only
   its own rank check where there had been two layers. `…/invite` and the
   per-row review routes sit one segment over and stay gated for the same reason.

## Consequences

- On a gated + apply project a stranger can reach exactly two routes: file an
  application, and ask after their own. Every other surface still meets the door.
- **This opens no oracle the gate was closing.** The boolean twin of the status
  route, `GET <api>/auth/web/admission-status`, is *already* reachable on a gated
  project inside the `auth/*` subtree ADR 0192 §3 exempts whole — §3 records that
  cost in as many words. The two routes deliberately share ONE per-IP budget
  (`accountExistenceReadRateLimit`, ADR 0209) precisely so neither can be
  alternated against the other for double the rate, and that stays true here.
- **What it does add is applicant detail**, and this is the honest cost: over the
  twin's bare `admitted`, the status route distinguishes `pending` / `dismissed` /
  `none`. Whether *that* answer should collapse is ADR 0209's open owner question,
  filed as a blocker against [task 1003339](https://cloudbongos.com/builders#/task/1003339).
  It is unchanged by this decision — the question was already live on a public
  project, and a gated one now reaches the same route under the same budget.
- **The hub needed no change.** `joinRelayOutcome` maps the *relayed* status
  (`401` → `members_only`), so the moment the project stops answering `401` the
  hub relays the project's real answer — the door refusal, the `409`, or the
  receipt — with no second edit.
- A project whose pinned core predates this keeps the old behaviour and refuses
  applications; like every `project.*` setting it is applied by the pin, not by
  the hub's row (ADR 0190).

## Rejected

- **"Gated means gated" — no exemption, and hide the apply door instead.** The
  coherent alternative, and the owner's call went the other way. It would have
  made the two settings honest by removing a choice rather than by honouring it.
- **Exempting the path without the verb.** One line shorter and it hands the
  owner's applicant queue a demotion from two layers to one. The queue's own
  `requirePermission` would still hold, which is exactly what makes the loss easy
  to miss.
- **Exempting the write alone**, leaving the poll gated. Cheaper, and it produces
  an applicant who has applied and cannot be told they were admitted.
- **Collapsing the status response here**, while the route was already being
  touched. It is ADR 0209's deferred owner question with its own evidence and its
  own blocker; answering it as a side effect of a visibility fix is how a
  deferred decision gets made by accident.
