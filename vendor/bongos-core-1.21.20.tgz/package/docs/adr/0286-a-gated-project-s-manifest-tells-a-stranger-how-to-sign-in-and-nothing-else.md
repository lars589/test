# ADR 0286 — A gated project's manifest tells a stranger how to sign in, and nothing else

- **Status:** accepted
- **Date:** 2026-09-15
- **Task:** [1003652](https://cloudbongos.com/builders#/task/1003652) (goal 1000106), from idea 1000845. Closes the item [ADR 0192](0192-platform-visibility-member-door.md) deferred as "projecting the manifest down when gated".

## Context

A gated project (`platformVisibility: 'gated'`, ADR 0192) refuses strangers on every surface except a short exempt list. `GET /api/*/instance` is on that list for two reasons. A stranger reads it to learn how to sign in, and the platform's runner reads it cookie-less after a settings restart to confirm the value was consumed (`provision-units.js` `settingsConsumed`), including the push that turns the gate on.

The route still answered with the **full** manifest: every branding string (company, tagline, palette, rank labels), the module roster, the rank ladder, dev-box availability, and the repository's `owner/repo/branch/url`, even when the owner had made that repository private.

## Decision

The owner's call: **sign-in basics only.** When the project is gated **and** the caller has no live, non-deactivated session (cookie or Bearer, the same `resolveSession` lookup the member door uses), `routes/instance.js` answers with `strangerManifest()`:

```
{ schema, name, brand: { identity: { productName }, project }, auth, admission }
```

| Kept | Why |
|---|---|
| `schema` | `bongos login` refuses any other id, so the value stays `instance-manifest/v1`: the stranger shape is a subset, and every kept field means what it means in the full manifest |
| `name`, `brand.identity.productName` | the door and the CLI name the project |
| `auth` including `idp` | the CLI routes device-flow and web sign-in through the hub from `auth.idp` |
| `admission` | `bongos login` tells an applicant invite-only from open |
| `brand.project` | the runner's settings read-back; the hub's `projects.html` (`platformVisibility`); `platform-identity/visibility-pull.js` (`visibility`); `bongos login` (`joinability`) |

- **Members** get the full manifest.
- **A session lookup that fails** gets the stranger answer rather than a 500. The manifest is how the door gets opened, and an unknown identity must not see a member's answer.
- **Every gated response** is sent with `Cache-Control: private, no-store` and `Vary: Cookie, Authorization`: one URL, two answers by identity. The route is exempt from the gate, so the gate's own `markPrivate` never runs on it.
- **Ungated projects** are unchanged.

## Alternatives considered

- **Gate the manifest like every other surface.** Rejected: the door could not be opened, and the runner could not confirm the push that gates the project.
- **A separate `/instance/sign-in` endpoint.** Rejected: two routes to keep in agreement, and every shipped CLI already reads `/instance`.
- **Project down for everyone, gated or not.** Rejected: an ungated project is public by the owner's choice, and the CLI's `devBox` and module checks read the full shape.

## Consequences

- **+** A stranger to a gated project no longer learns what it runs, how its ranks are named, what it looks like, or where its code lives.
- **−** `cli-lib.js` `devBoxEnabledInManifest` fails open (assumes a box exists) when `modules` is missing. That only happens on a session-less fetch; the CLI sends its bearer, so a signed-in member reads the real roster.
- **−** A gated project's manifest can no longer be cached at an edge. It is one small JSON read per sign-in.
