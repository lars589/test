# ADR 0272 — A craft is an identity, not a toolchain: `artist` becomes core

**Date:** 2026-09-09
**Context:** BONGOS-V2, goal [1000111](https://cloudbongos.com/builders#/task/1003719) (Working area 7 — Government), task [1003719](https://cloudbongos.com/builders#/task/1003719), re-filed from task 1002908 under [ADR 0265](0265-work-with-no-goal-and-the-order-the-cut-needs.md). Supersedes the R59 (task 1198) decision that `artist` rides the `art-pipeline` module. Neighbour of [ADR 0098](0098-public-mirror-publish-manifest.md) (the publish manifest) and task 1003487 (module-contributed disciplines).
**Status:** Accepted.

## Problem

Reported from Discord `#bugs` on 2026-08-15, verbatim: *"cant save preferences of role types in account page"*.

Reproduced live on cloudbongos.com 2026-09-09:

```
GET   /api/gds/me                 → preferred_disciplines: ["artist","ideator"]
PATCH /api/gds/me/disciplines     → 422 invalid_discipline  { bad: ["artist"] }
```

The API hands a builder a value and then refuses to accept it back. A builder could not save their own stored profile.

`db.updateBuilderDisciplines` validates against `modules.enabledDisciplines()` — core disciplines plus every enabled module's `contributes.disciplines`. R59 put `artist` in the module half, on the reasoning that the craft existed to produce the game's pixel art and so belonged to `art-pipeline`.

**That gate had quietly stopped existing.** `art-pipeline` was never converted to a discovered module: there is no `modules/art-pipeline/module.json`, so nothing anywhere declares `contributes.disciplines: ['artist']`. Measured on a full repo checkout, with the art pipeline present on disk:

```
enabledDisciplines() → ["engineer","ideator","ui"]
```

So `artist` was offered by **no instance in any configuration** — not a vanilla one, not a full checkout, not production. It is also unreachable by construction on a *published* core: [ADR 0098](0098-public-mirror-publish-manifest.md)'s manifest excludes `modules/art-pipeline/` outright for a hard copyright reason (it carries ripped reference maps), so no registry install could ever carry that manifest even if someone wrote one.

Meanwhile the craft stayed first-class in every other core surface:

| Surface | Accepts `artist`? |
|---|---|
| `builders.preferred_disciplines` CHECK (migrations 086, 176) | yes |
| `tasks.discipline` (`task-classifier.VALID_DISCIPLINES`) | yes |
| Help-request craft roster (`help-requests.HELP_CRAFTS`) | yes |
| `modules.enabledDisciplines()` | **no** |

A *task* could be an artist task, and a builder could address a help request to the artist craft — but a *person* could not be an artist.

**Why the tests were green over it.** `tests/modules.mjs` did assert the artist leg, behind a guard: `if (!EFFECTIVE['art-pipeline']) return;`. Since the module has no manifest, that check was always false and the only real assertion skipped itself. The suite passed by not running.

## Decision

**`artist` moves into `CORE_DISCIPLINES`**, which becomes `['engineer', 'artist', 'ideator']` — the migration 176 enum order. Modules still contribute their own (`ui-design` → `ui`), unchanged.

The principle: **a craft is an identity, not a toolchain.** It names who a builder is and what work routes to them. An instance can have people who consider themselves artists without shipping a pixel-art pipeline — just as it can have engineers without shipping any particular build tool. Binding the identity to the presence of one optional module's code was the category error, and the copyright exclusion makes that binding permanently unsatisfiable on the only distribution channel instances actually use.

The offered set is now a superset of what the DB CHECK accepts, which is the invariant that was violated: **anything the database will store, some instance shape must be able to offer.** `tests/modules.mjs` pins exactly that, over the widest possible module set, with no skip guard.

## What was rejected

- **Enable `art-pipeline` on cloudbongos.com.** Impossible, not merely undesirable: the module is not in the published package, and `src/modules.js` throws at boot when a config enables an absent module. The owner's intent ("artist should exist here") could not have been delivered this way.
- **Write the missing `modules/art-pipeline/module.json`.** It would work only in a full repo checkout and never on a published instance, re-creating the same invisible divergence one layer down.
- **An instance-declared discipline list in `config/modules.json`.** More architecturally tidy on paper — which crafts an instance recognises is host context ([ADR 0062](0062-medusa-instance-model-decoupling.md) §7) — but it puts the fix in the *instance* repo, leaving the core's own DB CHECK still describing a craft the core cannot offer. It also would not have fixed the vanilla case, where the craft is equally unofferable.
- **Strip unofferable crafts from stored rows.** This deletes a builder's stated identity to make a validator's mistake look consistent. The owner was asked and chose that artists should exist here.

## Consequences

- **Every instance now offers `artist`**, including vanilla ones with no art tooling. That is the intended reading of the principle above, and it costs nothing: the DB has accepted the value since migration 086, and an instance that has no artists simply has no one selecting it.
- **Existing stored values round-trip again.** No migration or backfill: the rows were always valid per the CHECK: only the validator disagreed. Builders holding `artist` (the owner among them) can save their profile without losing it.
- **The copyright exclusion is untouched.** `modules/art-pipeline/` stays out of the published core; nothing here moves art *tooling* anywhere.
- **The R59 rationale is formally retired.** Its premise — that the craft exists to serve the game's pixel art — no longer holds: `modules/game/` is likewise excluded from the published core, while the craft remained wired into help requests, task classification and the DB.
- **Not yet visible to users.** cloudbongos.com serves core 1.19.608; this reaches builders only when the instance pin moves (gate 3 of [ADR 0137](0137-upstream-publish-policy-manual-owner-gated.md)).
