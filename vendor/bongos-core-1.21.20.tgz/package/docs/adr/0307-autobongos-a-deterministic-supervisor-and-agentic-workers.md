# ADR 0307 — Autobongos: a deterministic supervisor, agentic workers

**Status:** accepted · **Date:** 2026-09-17 · **Task:** [task 1003900](https://cloudbongos.com/builders#/task/1003900) (goal 1000119 — BONGOS-V2)

**Related:** [ADR 0153](0153-sequential-chain-runner.md) (the halt matrix and the halt-don't-skip rule this reuses wholesale) · [ADR 0024](0024-multi-agent-system-architecture.md) (the MAS the autonomy gate belongs to) · [ADR 0055](0055-server-mediated-branch-publish.md) (server-mediated publish — why the machine holds no push credential) · [ADR 0043](0043-git-ssh-trust-boundary-and-rank-floor-on-permission-paths.md) (the protected-path set the fence reuses) · [ADR 0308](0308-an-eleventh-working-area.md) (the working area this work lives in)

## Context

The owner has an always-on Windows PC and a Claude subscription whose capacity
is mostly unused overnight. The ask was an orchestration loop that works the task
queue unattended inside goals the owner has allowlisted.

Most of that loop already exists, wired to the wrong trigger:

- **`scripts/gds/sequence.js`** resolves a chain and evaluates a ten-reason halt
  matrix — entirely from facts on the task row, no model judgement (ADR 0153).
- **An open blocker linked to a task makes `claimTask` throw `OPEN_BLOCKER`**
  (`modules/lifecycle/db-claims.js`). That is already a "put this work on hold"
  state, and `/blocker-review` is already the owner's morning queue.
- **`modules/grading/grader-subagent.js`** is a proven headless `claude` spawn
  seam, already Windows-aware (it routes through `cmd.exe` and hides the console).
- **`.claude/scheduled-tasks/overnight-builder/`** runs this loop today.

Two things are genuinely missing. The trigger is a cron schedule rather than the
subscription's own capacity, so a run either wastes a fresh window or dies
half-way through a spent one. And the **supervisor is itself a Claude session**,
which spends a full context boot per night on work that is entirely mechanical.

## The decision

### 1. The supervisor is a program; only the worker is a session

Picking, claiming, metering, verifying and recording are deterministic and stay
in code. One task at a time is handed to one headless session. This is the whole
architectural difference from `overnight-builder`, and it is what makes the loop
auditable: every branch the supervisor takes is a branch someone can read.

### 2. The gauge is the statusline's `rate_limits`, and it cannot be read cold

Claude Code feeds a statusLine hook `rate_limits.five_hour.{used_percentage,
resets_at}` and `rate_limits.seven_day.{…}` — the only structured read of
remaining subscription capacity. Anthropic's own note on the field says it is
*"only present for subscribers after first API response"*, so there is no way to
ask "how much is left" before starting. The mechanism is therefore a statusline
script that **persists both windows on every session**, and a reader the
supervisor consults between tasks. A gauge file older than its freshness window
is *unknown*, never *headroom*.

The reserve is time-aware, because the runner and the owner draw on the **same**
five-hour window: near zero overnight, a real floor during the owner's working
hours. The seven-day window is the binding one across a heavy week, and is paced
against rather than spent greedily.

### 3. One session per task, not a batch

The original sketch pulled "a string of sequential tasks estimated to fit the
remaining limits". Rejected, for three reasons. The estimate does not exist —
tasks carry human-minutes, not token spend. A successor cannot be claimed until
its predecessor ships (ADR 0153 §2), so "walk a string" and "take the next one"
produce the identical order anyway. And because each ship merges to main, a
**fresh session per task is also more correct** than a long one holding a
checkout that goes stale behind main.

So v1 **meters rather than estimates**: work one task, re-read the gauge, decide
again. The estimate becomes a learned number once the ledger has data.

### 4. Completion is read from the ledger, never from the session

A session exiting is not a task shipping, and the result envelope makes the
confusion easy: a worker that stopped dead needing a decision returns
`subtype: "success"`, structurally identical to one that finished. This project's
worst incidents are all this shape — branches never pushed, tasks parked at
`confirmed` with no code, a ship that timed out *after* its merge landed.

After every worker the supervisor reads the task's status back from Bongos and
confirms the artifact. Anything not actually shipped releases the claim and files
a blocker, which also removes the task from the claimable pool so the loop does
not pick it straight back up.

Two things the implementation settled (`scripts/gds/autobongos-verify.js`, task
1003903). The mid-ship shapes are **not new names**: `strand-watch.js` already
called them `unprovable` / `unlanded` / `ungraded` and `/strand-fix` routes on
those strings, so `classifyStrand` is called directly and only its thresholds are
zeroed — the board sweep may wait an hour, the supervisor may not, because the
session that was supposed to finish has already exited. And the release must come
**before** the link: `linkBlockerToTask` parks a task only from `ready`, and
releasing is what puts it there, so linking first writes an edge that parks
nothing and the release then hands the task straight back to the loop.

### 5. There is no terminal stop — only speeds

On an always-on machine a stopped daemon is silently worthless. Three straight
failures drop the runner to a **probing** state: no new work, a growing wait,
then exactly one task; a success returns it to full speed. Failures are
classified, because the right response differs — transient (instance
unreachable, grader outage, rejected push) heals by waiting; systemic (expired
token, full disk) will not, but cheap probing means it resumes the moment someone
fixes the cause; and a queue where *every* task halts is not a runner failure at
all, and is reported as an unworkable queue. A new signal — main moved, a blocker
resolved, the allowlist changed — jumps the remaining wait.

The only true stop is the **server-side** kill switch — and even that is a speed:
the runner keeps asking, cheaply, so flipping the switch back on is enough to
start it without touching the machine.

Two things the implementation settled (`modules/autonomy/cadence.js` and the
`--forever` loop, task 1003904), both learned by running it rather than reading
it. Boot reconciliation needs a **heartbeat**: the ledger cannot tell a live run
from a dead one — both are a held claim — and releasing one a worker is building
against strands its work exactly as badly as leaving one locked. And it must
match the **exact worktree name the runner generates**, not an `autobongos-`
prefix: the loose form matched a human's hand-named tree and released their live
claim out from under them, twice, during the task that added it.

### 6. The fence, and where it is enforced

The allowlist of goals lives in the database and is edited from the hall, never
in a file on the machine — a file there is editable by anything running there,
and the premise is a machine nobody is watching. It combines with the existing
protected-path exclusion (ADR 0043), so permission, migration, infrastructure and
deploy-pipeline work never reaches an unattended worker.

The machine holds **no push credential at all** (the dev boxes were built this
way deliberately — ADR 0055), so the only road to main is the server-mediated
ship pipeline and its server-side grade. That grade is the *only* review between
an unattended worker and main, so **a grader outage stops the runner** rather
than downgrading it to shipping unreviewed.

Three things the implementation settled (`modules/autonomy/fence.js`, task
1003908). The kill switch is `autonomy.fence.manage`, declared **`system: true,
floor: 'archon'`** in the permission catalog, because a switch the runner could
be granted the power to flip is not a switch — the catalog's own invariant
forbids granting a system key to a lower rank, and that invariant is what makes
it a stop button. `--goal` and `AUTOBONGOS_GOALS` are kept but **demoted to a
narrowing filter**: they intersect with the database allowlist, so a setting on
the runner host can take a goal away and can never add one. And an **unknown**
grader state refuses exactly as a bypassed one does — "I could not tell" must not
resolve to "go ahead" when the thing being checked is the only review there is.

The protected-path gate reads the task's **declared** `touches[]`, which is a
claim by whoever filed the task and not a fact about what the work will edit. That
is acceptable only because it is the outer of three layers — the grader's
permission-path pre-pass and the post-push main audit both read the real diff,
server-side, where the machine cannot reach. Treating it as sufficient on its own
would be the bug, and the file says so where someone might be tempted.

### 7. Workers run with blanket `bypassPermissions`

`--permission-prompt-tool` exists and is print-mode only, so routing every
permission request back to the supervisor was available and was **rejected**: it
round-trips every tool call through one process, so a slow or crashed supervisor
stalls every worker, and it buys a thousand weak gates in place of the one that
matters. The boundary that matters is the push to main, and §6 already holds it.

### 8. Gate before, record after — and no conversation in between

This is the posture the owner chose, and it is the one part that was **tested
before it was decided**.

A worker was given an ambiguous task and told, in plain terms, to stop and ask
rather than guess. It did not. It settled the retry count, the backoff base,
which status codes to retry and whether to retry network errors — four genuine
judgement calls — and wrote them into the file. That is not misbehaviour; it is
what a competent engineer does without interrupting anyone. But it means **a
design that waits for workers to raise their hands will see very few hands, while
the decisions still get made.**

So:

- **Before** — the halt matrix refuses ambiguous work at *pick* time, mechanically
  (thin spec, protected path, `kind='decision'`, needs a migration). Those tasks
  never reach a worker.
- **After** — the worker's structured verdict must include the calls it made that
  its task description did not determine. They land in the morning digest, where
  the owner reviews them sitting on a branch behind a grader.
- **In between** — nothing. Mid-flight injection is the exception path for hard
  blocks, not the main road.

Handing a decision back to a live worker *does* work and was verified — pinning
the session id at spawn and resuming it later returns the session with its
context intact, and cheaply, because the context comes back from cache. That
capability is kept for hard blocks and deliberately not built into a
question-answering apparatus.

## What this deliberately does not build

- **Mid-flight question answering** — no question tiering, no citation-enforced
  answering agent, no resume caps. Removed on the owner's instruction as
  unneeded complexity, and §8 is why it is not load-bearing.
- **Portability.** v1 targets one machine and one instance. Designing for hosts
  we do not have, against numbers nobody has measured, would fix the metering
  design before there is data to fix it with.
- **Per-task cost estimation.** See §3 — metering first, estimates later.

## Alternatives rejected

- **A budget-capped worker** (`--max-budget-usd`). Caps API dollars, which on a
  subscription is not the constraint. The real runaway risk is a session spending
  the whole window on one task, so the bound is **wall-clock**.
- **Extending `overnight-builder`.** It walks the whole backlog by priority on a
  cron, supervised by a model. This is limit-triggered, allowlist-scoped and
  supervised by a program. Different trigger, different scope, different cost.
- **A terminal stop after N failures.** The first draft of this loop had one; on
  an always-on host it is indistinguishable from the machine being off. §5.

## Consequences

- The supervisor is testable the way a program is testable. Its decisions are not
  a transcript.
- The runner competes with the owner for the same five-hour window, so the
  reserve is a product decision, not a politeness.
- Every declared decision in the digest is a sentence the task description should
  have contained. The list is a spec-quality signal, and acting on it lowers
  future halts.
- The Windows host has **no precedent in this repo** — all prior autonomy ran on
  Linux droplets, and that infrastructure is being torn down under goal 1000091.
  It is the bucket most likely to overrun.
