# ADR 0335 — An invite is a pre-approved row on the project's own instance, and `project.recruit` says who may send one

- **Status:** accepted
- **Date:** 2026-09-24
- **Task:** [task 1002813](https://cloudbongos.com/builders#/task/1002813) (R1 of the project admin console wave, goal 1000110 — BONGOS-V2)
- **Deciders:** the three decisions come from the spike ([task 1002786](https://cloudbongos.com/builders#/task/1002786), [`docs/specs/<redacted>.md`](../specs/<redacted>.md), 2026-08-14). The spike asked the owner for one sign-off: what "widenable to metics" means. The owner answered on blocker 1000122, and [ADR 0217](0217-rank-gates-inviting-not-viewing.md) D1 records the answer: a per-project invite floor that defaults to archon and is set by that project's own archons. This ADR does three things. It records the decisions, reconciles them with what has shipped in the six weeks since, and says what each build task still has to build.
- **Followed by:** [ADR 0353](0353-a-hub-invite-is-a-notice-of-the-projects-own-invite.md) — R6 (task 1002818): the hub's invite row became a notice the project writes, the hub-side accept was retired, and the wizard's invite step hands the owner to the project's hall. The "Until R6 lands" item below is closed by it.
- **Supersedes:** only the "Invitations (deferred slice)" paragraph of [ADR 0141](<redacted>.md) §5. The rest of ADR 0141 stands.
- **Revises:** [ADR 0210](0210-scouting-graduates-on-an-instance-asserted-owner-claim.md), [ADR 0215](0215-the-recruiter-sliver-is-a-ceiling-not-a-step.md) and [ADR 0248](0248-a-hub-project-s-owner-is-the-provisioning-row-carried-on-a-port.md) predicted that `project.recruit` would replace `project.curate` on the hub's recruiting doors. D3.6 revises that prediction.
- **Related:** [ADR 0016](0016-trust-boundary-server-enforced-permissions.md), [0108](0108-instance-composition-configurable-root.md), [0112](0112-private-goals-invitations-join-requests.md), [0151](0151-governance-permissions-as-atom-ranks-as-roles.md), [0157](0157-archon-is-rank-and-identity-only.md), [0182](0182-project-visibility-two-axes.md), [0194](0194-joinability-one-door-decision.md), [0201](0201-cross-project-application-vouched-row-live-record.md), [0247](0247-the-join-door-is-one-composed-answer-and-dark-matter-has-no-live-verdict-yet.md), [0328](0328-a-hosted-projects-authority-is-its-membership-row-not-its-owner-column.md)

## Context

The spike found two membership planes that do not talk to each other:

- The **goal plane** (ADR 0112) is per-instance and complete.
- The **project plane** was half-built. An application was an `access_requests` row on the target instance. The only outbound invite lived on the hub, and accepting it let nobody in.

Six weeks of shipping since then have changed what is left to build. Checked against `main` on 2026-09-24:

| What the spike found | What live code does now |
|---|---|
| An archon cannot invite someone who has not applied. | The instance has `POST /access-requests/invite` ([task 1003044](https://cloudbongos.com/builders#/task/1003044)), gated by `access_request.review` (archon). It writes a `status='invited'` row, so the invitee's first sign-in admits them. If that login already has a pending application, the route approves that row in place. |
| No rescind. | `PATCH /access-requests/:id` rescinds (`invited → dismissed`) as long as the login has no builder row yet (ADR 0201 D4.2). |
| Nothing records who invited or why, and a sender has no list of their invites. | **Still true.** An invite row looks exactly like an approved application. `resolved_by_builder_id` names the inviter only until a rescind overwrites it. The route takes no note. |
| No join policy anywhere. | The join door is now composed: `open \| apply \| invite_only \| locked`, from visibility, join grant and joinability (ADR 0194, ADR 0182 D6, ADR 0247; task 1002331, task 1003044). A closed door refuses the public application POST, and the sign-in gate reads the same door. The hub's join relay says *"This project is invite-only — ask its owner for an invite; once invited, sign in to it."* The owner sets this on the hub's manage page, and a restart applies it (no deploy). |
| The hub invite is `project.curate`-only, and nothing calls it. | `POST /projects/invite` now admits a `project.curate` holder **or** the project's own owner (`invite-authz.js`, task 1003580). The creation wizard's invite step calls it (task 1002346). It still pre-seeds a `pending` hub row. Accepting that row (`resolveInvite`) flips it to `member`, but no instance reads hub membership to decide who may enter. **So a real button now leads to the dead end the spike found.** |
| `project.recruit` is proposed. | **Still unminted.** Five places wait for it: ADR 0201 D3.2 (the queue's read half); ADR 0210 and ADR 0248 (the `project.curate` half of the hub's owner-or-rank doors); ADR 0215 D4 and ADR 0217 D2 (the hub recruiter sliver, held at `requireRank('archon')` as the documented holdout in `tests/government_require_permission.mjs`); and task 1003362 (the per-project invite floor). |

## Decision

### D1 — Authority lives on the project's own instance. The instance *is* the project.

Every project is its own instance with its own `builders.rank` (ADR 0108). That makes "per-project recruit rules" and "per-instance governance" the same thing. The problem of scoping a governance grant to one project goes away.

The hub keeps the role ADR 0141 gave it:

- identity (§1)
- the join relay into the project's own public POST (§3)
- the statusless application echo (ADR 0201 D1.3)
- notifications
- links

The hub **never writes a project's admission row and never holds a verdict.** `tests/project_admin_console_model.mjs` checks that no `platform-identity` source writes to `access_requests`.

This decides where things live. The console is a hall page on the project's instance (R4). The apex only links to it (R7).

ADR 0328 does not contradict D1. It answers a different question: who may act on a project's hosting row on the hub (`provisioning_instances`). A hub membership row has no say in who may enter the project.

### D2 — A recruit invite is a pre-approved `access_requests` row, and signing in is the acceptance act

There is no new table. The sign-in gate (`hasInvitedAccessRequest` → `firstTimeAdmissionBlocked`) already reads `access_requests`, so an invite is simply a row that gate reads, and the gate does not change. The row gains the ADR 0112 discriminators, added without changing anything that exists:

1. **`kind ∈ ('application','invite')`, NOT NULL, default `'application'`.** The public POST keeps writing applications through the default, and the invite route writes `'invite'`. If an invite approves a pending application in place, the row stays `'application'`: it was an application, and its history should say so.
2. **`created_by` → `builders(id)`, set on invite rows only.** This is the inviter. It needs its own column because a rescind overwrites `resolved_by_builder_id` (ADR 0201 D4.2 records whoever acted last). Without it, a rescinded invite forgets who sent it.
3. **`note` needs no new column.** The existing column holds the inviter's note on an invite row, and `kind` says whose words they are.
4. **The backfill is exact.** The current invite route sets `resolved_at = now()` in the same statement whose default fills `created_at`, so every row it wrote has `created_at = resolved_at`. No approved application can match that, because an application is always resolved after it was filed. So the migration sets `kind='invite'` and `created_by = resolved_by_builder_id` on `status='invited'` rows where `created_at = resolved_at`. The one case it cannot catch is a direct invite that was later rescinded, because the rescind changes `resolved_at`. That row stays `'application'`, which makes it look like a declined application. It admits nobody either way. The only effect comes after R3: a recruiter who holds `project.recruit` but not `access_request.review` and re-invites that login gets the D3.4 refusal, so a reviewer has to send the invite. That leaves the door stricter, never looser, and applies only to invites rescinded before R2 ships.
5. **`kind` and `created_by` never enter an admission read.** This is the same rule `core_230` set for the vouch column. An invite and an approved application admit through the identical `status = 'invited'` read. `tests/project_admin_console_model.mjs` checks this. **Amended by [ADR 0356](0356-a-recruit-invite-expires-30-days-after-it-is-sent-read-time.md) (task 1002969):** `kind` now enters admission in one place, the invite expiry, which can close an invite's door after 30 days and never opens one. `created_by` still never enters.
6. **Expiry is not part of this.** The 30-day read-time expiry (ADR 0201 D4.3) covers every invited row, whatever its `kind`. Task 1002969 owns it.

### D3 — One new grantable atom, `project.recruit` (floor archon), says which rank may recruit; the verdict stays with `access_request.review`

1. **Shape.** `system: false`, so it can go into a custom rank, which is how spec D3 handles "let this one person recruit". `floor: 'archon'`. It is not a substrate key and has no principal. A `government_NNN` grant migration seeds it to the archon rank, in the same shape as `government_016`; the seed drift guard requires that migration. `tests/project_admin_console_model.mjs` checks this shape as soon as the atom exists.
2. **Widening uses the governance tab that already exists.** On that project's instance, an archon calls `PUT /government/ranks/:rankKey/permissions/:permissionKey` (gated by `government.manage`, archon). The spec wrote this as `/governance/roles/…`; the path above is the live one. **This is the per-project invite floor the owner asked for** (ADR 0217 D1): it belongs to the project, defaults to archon, and only that project's archons can move it.
3. **What each atom guards on an instance.**

   | Surface | Atom |
   |---|---|
   | `POST /access-requests/invite`, the outstanding-invite list, and rescinding a `kind='invite'` row | `project.recruit` |
   | `GET /access-requests` (the queue read, which ADR 0201 D3.2 calls the "read half") | `project.recruit` |
   | `PATCH /access-requests/:id` (approve, decline, or rescind any row): the verdict | `access_request.review`, unchanged. ADR 0157 classes it as identity. |
   | The Discord approval reaction (`modules/discord/discord-approvals.js`) | Unchanged. It is a pending-only verdict path at archon rank. |

   An archon holds both atoms by default. A custom rank meant to review applications needs both: `access_request.review` on its own can rule on a request by its id but cannot list the queue.
4. **Inviting is admitting, so the line between the two atoms needs one clause to be real.** An invite writes the row the gate reads, so a recruiter can admit any login they choose. That is exactly the power the owner hands out by widening the floor. What a recruiter must not do is rule on someone who *asked*, and today's invite route does both kinds of ruling: it approves a pending application in place, and it re-admits a declined applicant (the PATCH refusal deliberately points callers at it). So the rule is: **when the caller holds `project.recruit` but not `access_request.review`**, the invite route refuses with a 409 that points to the queue if the login has a pending application, or if its latest application was dismissed. A caller who holds both keeps today's behaviour. Without this clause, "the verdict stays archon" would be a label on a door another route already opens. The 409 does tell a recruiter that the login applied, but a recruiter can already read the queue (row 3 above).
5. **The hub is an instance too, so its own copy of the atom governs its own recruiting.** The hub's recruiter sliver (`GET /scouting/:handle`) moves from `requireRank('archon')` to `requirePermission('project.recruit')`. At floor archon, nothing changes for users. It stops being the holdout listed in `RETAINED` in `tests/government_require_permission.mjs`, which is what that entry and ADR 0215 said the console wave would do.
6. **The hub's directory and the hub's invite keep `project.curate`.** ADR 0210, 0215 and 0248 expected `project.recruit` to replace the `project.curate` half of those owner-or-rank doors. For the directory (`GET /scouting`) that would be wrong. The directory shows public, consented records, and ADR 0217 D1 puts those on the *viewing* side of its line. Swapping a metic-floor atom for an archon-floor one would put a higher gate on a viewing surface, which is the one change ADR 0217's standing invariant forbids. The hub invite lets nobody in, so a stricter gate on it would protect nothing; R6 changes what it is.
7. **Task 1003362 asked which invite surface the owner's floor gates. The answer is the instance's `POST /access-requests/invite`, not the hub's `POST /projects/invite`**, because only the instance row lets anyone in.

## What each build task builds now

| Task | What it builds | Already true — do not rebuild |
|---|---|---|
| **R2** · [task 1002814](https://cloudbongos.com/builders#/task/1002814) | The D2 migration: `kind`, `created_by`, and the exact backfill. The invite route writes `kind='invite'`, `created_by` and an optional `note`. A list of outstanding invites (`kind='invite'`, `status='invited'`, and no builder row yet). **Everything stays gated by `access_request.review`**, because the new atom does not exist yet. Tests extend the access-requests suite. | Inviting a login that never applied, signing that login straight in, and an archon rescinding the invite before first sign-in (through `PATCH`). Its done-when narrows to three things: an invite row can be told apart from an approved application, it keeps its sender through a rescind, and the sender can list their outstanding invites. |
| **R3** · [task 1002815](https://cloudbongos.com/builders#/task/1002815) | Mint `project.recruit` in the D3.1 shape, with its grant migration. Move the D3.3 surfaces onto it, adding a rescind route for recruiters that acts only on `kind='invite'` rows (reviewers keep `PATCH`). Add the D3.4 clause. Swap the hub sliver and remove its `RETAINED` entry (D3.5). Pin the new gates in `route-rank-check.js`. Update the catalog `guards` text for both atoms. Add a widening proof: grant metic on a test instance and a metic can invite; revoke it and they get a 403. **R3 lands after R2** because the clause and the recruiter rescind both read `kind`, so it needs a dependency on task 1002814. | The governance grant/revoke routes and the tab. |
| **R5** · [task 1002817](https://cloudbongos.com/builders#/task/1002817) | **Nothing — it has already been delivered.** "Closed" is joinability `invite_only` or join grant `view`. The application POST refuses with copy that does not say which setting closed the door. The hub relay tells the applicant why. Changing the setting needs a restart, not a deploy. Close R5 as merged into task 1002331. | All of it: task 1003044, task 1002331, ADR 0247. |
| [task 1003362](https://cloudbongos.com/builders#/task/1003362) | **Folds into R3.** Its done-when maps one-to-one onto D3.2. The ADR it asks for (the split between inviting and viewing) is ADR 0217, and D3.7 answers its surface question. A separate per-project setting would be exactly the rival knob that task warns against. Merge it into task 1002815. | — |

The other three tasks keep their scope, with two notes:

- **R4** ([task 1002816](https://cloudbongos.com/builders#/task/1002816)) shows the join door **read-only**, with a link to wherever it is set. For a hosted project, that is the hub's manage page. R4 must not create a second place to store it.
- **R6** ([task 1002818](https://cloudbongos.com/builders#/task/1002818)) now owns a dead end that real users can reach: the wizard's invite step. Whatever R6 builds, the project's instance decides admission using its own `project.recruit` check. The hub may carry the inviter's *identity*, using the audience-scoped signed assertion from ADR 0141 §1, which already exists. It never carries the verdict.
- **R7** ([task 1002819](https://cloudbongos.com/builders#/task/1002819)) is unchanged.

## Alternatives considered

- **A new invitations table**, shaped like ADR 0112's `goal_membership_requests`. Rejected: the gate already reads `access_requests`, so a second table would mean a second admission read to keep in sync.
- **Keep the hub's pending membership as the invite**, as ADR 0141 §5 had it. Rejected: the hub holds no authority, so accepting that invite lets nobody in. That is the dead end this ADR retires.
- **No new atom; widen `access_request.review` instead.** This is tempting: that atom is already `system: false` and grantable per instance, and task 1003362 asks for no rival knob. Rejected for three reasons. Widening it would hand out the verdict along with the invite, when the owner asked for a floor on *inviting* only. ADR 0157 classes the verdict as identity. And five earlier decisions already name `project.recruit` as the recruiting atom.
- **A per-project settings row for the invite floor**, reading task 1003362 literally. Rejected: governance grants are already per instance, and D1 makes an instance a project. A settings row would be a second answer to the same question.
- **Let a recruiter's invite approve applications, as the route does today.** Rejected: the verdict floor would become a label (see D3.4).
- **Make `project.recruit` a `system: true` atom.** Rejected: that would keep it out of custom ranks, which is how the spec handles letting one particular builder recruit.
- **Swap `project.curate` for `project.recruit` on the hub directory**, as ADR 0210 and 0215 predicted. Rejected: it would raise a gate on a viewing surface (see D3.6).

## Consequences

- ADR 0141's Status line now says its §5 invitations paragraph is superseded here. §1–§4 and the §5 catalog/Explore paragraph still stand.
- The prediction in ADR 0210, 0215 and 0248 is revised for the hub directory and the hub invite. The sliver half of it is kept, and R3 carries it out.
- Two new invariants, both checked in `tests/project_admin_console_model.mjs`: `kind` and `created_by` never enter an admission read, and no hub source writes a project's admission row. The same file checks `project.recruit`'s shape once R3 mints it.
- This ADR changes no running behaviour. R2 costs one additive migration. R3 costs a grant migration and the gate moves.
- **Still open, and owned elsewhere:**
  - Until R6 lands, the wizard's invite step creates a hub invite that lets nobody in.
  - The 30-day invite expiry is task 1002969.
  - The private-account sliver inside the instance's own application queue remains limited by ADR 0201 D2.7: the hub cannot check an instance's permission from a cross-origin browser request.
