# ADR 0216 — A fake-pool interpreter must FAIL LOUDLY on what it cannot model; the refusal is uniform, the interpreters stay separate

- **Status:** accepted
- **Date:** 2026-08-29
- **Task:** [task 1003354](https://cloudbongos.com/builders#/task/1003354) (folding in idea 1000877, raised by the adversarial review of [task 1002968](https://cloudbongos.com/builders#/task/1002968))
- **Relates to:** [ADR 0202](0202-connections-graph-and-bounded-degree.md) D4 and [ADR 0213](0213-platform-terms-acceptance-is-the-hubs-own-witness.md) (the predicates these interpreters stand in for), [ADR 0215](0215-the-recruiter-sliver-is-a-ceiling-not-a-step.md) D7 (where the structure guard was first written), [ADR 0091](0091-bounding-the-kernel-and-db-carve.md) §2 (deliberate duplication across a boundary)

## Context

Nine test files in this repo carry a **fake pool** — an in-memory Postgres substitute whose row filter is derived from *each statement's own `WHERE` text* rather than hand-written. That design is deliberate and good: it is what makes a proof like `tests/connections_ownership.mjs` say something about the real query instead of about a canned response. Delete `addressee_github_id = $2::bigint` from the real SQL and the fake genuinely stops applying it, so a stranger's row genuinely moves and the test genuinely reds.

The design has one failure mode, and it is silent: **a term the interpreter does not recognise is simply not applied.** A predicate the fake cannot read degrades to *no* predicate, the boundary becomes vacuous, and every assertion above it keeps passing. Each file already understood a piece of this and guarded it:

- an unread `$N` placeholder throws (all nine);
- a literal comparison on an unknown column throws (four);
- an unmodelled `IS [NOT] NULL` throws (two, added by [ADR 0213](0213-platform-terms-acceptance-is-the-hubs-own-witness.md)).

Every one of those guards is a **term** guard, and three separate reviews found the same thing: the term list is not the predicate.

**The missing term.** ADR 0213 made consent two columns — `profile_state = 'active' AND terms_accepted_at IS NOT NULL`. `tests/scouting_owner_access_and_reach.mjs` modelled the first and not the second. A `NULL` test is a *third syntax*: the placeholder sweep scans `$N`, the literal sweep matches `col = '…'`, and neither can see `IS NOT NULL` at all. So the term was dropped in silence and the suite reported **17 passed, 0 failed** while modelling a predicate the database no longer had — inside a file whose own header states that exact failure is impossible.

**The rewritten joiner.** The adversarial review of task 1002968 found the deeper one. An interpreter that COLLECTS the terms it recognises and `AND`s them **re-imposes an `AND` the SQL may no longer contain.** Rewrite a predicate's `AND` to `OR` and Postgres serves every *active* account on the platform — private ones included — or lets any builder revoke any session by id; the term-collecting fake answers exactly as it did before, and every isolation and 404 assertion in the file stays green. Task 1002968 fixed the three copies it owned and filed the rest as idea 1000877.

**Recognition is not application.** ADR 0213's own first draft checked only that the column *name* was recognised, and a mutation deleting the filter still passed. It needed a second set to prove the term had been turned into a filter — which is bookkeeping that can itself go stale.

The common shape of all three is one sentence: **the interpreter silently answered a question it was not asked.**

## Decision

### D1 — The governing rule: an interpreter that cannot model a term must REFUSE the statement, never ignore the term

This is the rule the fake-pool pattern always implied and never stated. It is not "model every term" — a test fake is allowed to be incomplete. It is that **incompleteness must be loud.** A statement carrying anything this interpreter cannot faithfully reproduce is an error thrown at the test, not a filter quietly dropped from the answer.

Refusing is safe in a way ignoring is not, and the asymmetry is the whole argument: a refusal fails the build *today*, in the session that changed the SQL, with the unreadable text in the message. A silent drop fails nothing, ever, and the proof above it becomes decorative without anyone learning that it did.

### D2 — The mechanism is a CONSUMING parse with a pure-conjunction residue check

Term guards cannot express D1, because a guard has to know a term exists before it can complain about it — and the whole problem is the terms nobody thought of. So the interpreter is inverted: instead of listing what it recognises, it accounts for **everything the clause contains**.

Each recognised term is matched, modelled, and **spliced out of the text**. Whatever survives is exactly the part the interpreter did not understand, and it must be nothing but whitespace, parentheses and `AND`:

```js
if (!/^[\s()]*(?:AND[\s()]*)*$/.test(residue)) throw new Error(`fake pool: unmodelled boolean structure …`);
```

That single check subsumes every term guard that came before it and closes all three defects at once. An unmodelled `IS NOT NULL` survives in the residue. An `OR`, a `NOT`, a `CASE` survives in the residue. And **recognition can no longer come apart from application** — a term the interpreter recognised but did not apply is, by construction, still there — which retires ADR 0213's `modelled`-set bookkeeping rather than maintaining it.

A legitimate `OR` — the handle rename window, connections' either-side clause, the session-expiry disjunction, the rescind transition guard — is consumed as a **whole unit**, which is both how it survives the check and how it stays honest: a matcher that tore one in half would leave a dangling `OR` and be refused.

Two term guards are kept in front of the structure guard, not because they add coverage but because they add a **better error**: an unreadable `$N` or an unknown column is reported as the thing it is, rather than as leftover text.

### D3 — The interpreters stay SEPARATE; only the refusal is uniform

Nine copies of nearly-identical machinery is the shape that normally demands extraction, and it was considered and rejected. Task 1002968 concluded these are independent by construction; this ADR agrees, with the reason written down:

**What differs is the term vocabulary, and it differs completely.** These interpreters stand in for different tables — `platform_identity_accounts`, `platform_identity_connections`, `builder_sessions`, `access_requests`, `platform_identity_application_echoes`, `<redacted>` — and share almost no term. A shared registry would have to accept every table's vocabulary, which makes it a small SQL engine: more code than the copies it replaces, harder to reason about, and a new place for a bug to hide *behind* the guard rather than in front of it. It would also couple unrelated proofs — a session-revoke test would fail to a change in a connections matcher.

**What must never differ is the refusal**, and that is three lines and one regex. So the discipline is: identical guard, identical error message, in every copy — and each copy carries its **own calibration test** pinning the four refusals (unknown literal, unread placeholder, unmodelled `NULL` test, `OR`) plus a `doesNotThrow` over the real composed predicate, so the guard is a filter on the unreadable and not a blanket refusal.

That per-file calibration is the anti-drift mechanism a shared helper would otherwise have provided, and it is strictly better at the job: a shared helper proves the guard exists *somewhere*; a calibration test in each file proves the guard is *reached* by that file's own statements.

### D4 — A modelled term proves nothing until a fixture makes it observable

The corollary, learned twice in one session. Modelling `terms_accepted_at IS NOT NULL` while every fixture carries an acceptance is a filter that filters nothing: delete the term from the real predicate and the answer does not change, so the mutation does not bite and the proof is cosmetic.

Every axis a predicate carries therefore needs **one fixture that differs on that axis alone**. Three were added here — a pre-terms account in the scouting directory and in the real-DB rollup proof, and a pending membership in the application echo — each differing from the control in exactly one column, so the mutation that deletes the term has somewhere to land.

Where a file deliberately does *not* carry such a fixture because another file owns that matrix, the comment says so. An absence that is a decision reads differently from an absence that is an oversight, and only the first survives the next reader.

### D5 — Every copy is verified BY MUTATION, against the real source

No copy was accepted on green. For each, a term was deleted or an `AND` rewritten to `OR` **in the real module**, the file was required to go red, and the source was reverted. Ten mutations, ten reds, every one of them a 0-failure pass before this work:

| mutation (in real source, reverted) | file | before → after |
|---|---|---|
| `accountActiveSql`: delete the acceptance term | `scouting_owner_access_and_reach` | 0 → 2 failed |
| `accountVisibleSql`: `AND` → `OR` | `scouting_owner_access_and_reach` | 0 → 10 failed |
| `accountActiveSql`: delete the acceptance term | `effective_visibility_predicate` | 0 → 2 failed |
| `accountVisibleSql`: `AND` → `OR` | `effective_visibility_predicate` | 0 → 8 failed |
| `accountVisibleSql`: `AND` → `OR` | `profile_privacy_owner_view` | 0 → 3 failed |
| `listRecentApplications`: `AND` → `OR` | `application_echo` | 0 → 1 failed |
| `listMembershipsForAccount`: `AND` → `OR` | `application_echo` | 0 → 6 failed |
| `listMembershipsForAccount`: delete the pending term | `application_echo` | 0 → 3 failed |
| `acceptConnection`: `AND` → `OR` | `connections_ownership` · `profile_connections_ui` | 0 → 4 · 0 → 1 failed |
| `revokeSessionForBuilder`: `AND` → `OR` | `own_session_revoke` | 0 → 4 failed |
| `listActiveSessionsForBuilder`: delete `revoked_at IS NULL` | `own_session_revoke` | 0 → 2 failed |

## Consequences

- **Nine fake pools now refuse what they cannot read.** `tests/recruiter_sliver_boundary.mjs` (where the pattern originated), `effective_visibility_predicate`, `profile_privacy_owner_view`, `scouting_owner_access_and_reach` (both of its filters), `connections_ownership`, `profile_connections_ui`, `own_session_revoke`, `application_echo`, `application_lifecycle`. `canonical_profile_url` is deliberately untouched: its residue must be **empty**, which is strictly stronger, so it already refuses an `OR`.
- **Adding a term to a shared predicate now BREAKS the tests that model it**, loudly, in the session that adds it — instead of being silently absorbed. That is the intended cost and the entire point: ADR 0213 tightened `accountActiveSql` and five proofs absorbed the change without noticing.
- **`own_session_revoke.mjs` had no calibration test at all** and three silently-permissive paths, including a clause with no readable term yielding an empty filter that matched every row. On a table where the predicate *is* the own-scope boundary.
- **`application_echo.mjs` was deleting a term before interpreting it** — `membership_kind <> 'pending'` was `.replace`d out of the clause, so dropping it from the real query would have been invisible (the replace would simply no-op). Stripping a term you do not want to model is the same defect as ignoring one; the term is modelled now.
- **A residue check must strip the statement's tail** (`ORDER BY`, `RETURNING`, `LIMIT`) and consume table aliases, or it refuses correct statements. Both were found by the guard failing honestly on real SQL, which is the guard working.

## Alternatives rejected

- **One shared interpreter module.** D3. The vocabulary is per-table and shares almost nothing; the shared thing would be a small SQL engine, and it would couple unrelated proofs.
- **A fitness check asserting every fake pool carries the guard.** Tempting, and it would catch a *new* copy written without one. Rejected for now: it would have to identify "a fake pool" by heuristic, and a heuristic gate over test internals is a maintenance surface with a false-positive cost. The per-file calibration tests hold the copies that exist; a tenth copy written without one is a review question. Recorded here as the known gap rather than papered over.
- **Keeping the `KNOWN_NULL_TESTS` + `modelled` pair alongside the structure guard.** Strictly weaker and now redundant: an unapplied term is still in the residue. Two sets to keep in sync, for nothing.
- **Parsing the boolean tree properly.** A real parser would let the fake *model* an `OR` rather than refuse it. That is a worse trade for a test double: refusing is a one-line invariant, and no statement in this repo needs a disjunction the unit-consumption approach cannot handle.
- **Accepting green as verification.** The failure this ADR exists for is invisible to a passing suite, by definition. D5.
