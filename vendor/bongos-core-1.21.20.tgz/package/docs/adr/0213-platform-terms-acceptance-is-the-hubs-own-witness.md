# ADR 0213 — The platform T&C acceptance is the hub's own witness, written once, and consent becomes two columns

- **Status:** accepted
- **Date:** 2026-08-29
- **Task:** [task 1002913](https://cloudbongos.com/builders#/task/1002913) (goal 1000045 — Public builder profiles)
- **Relates to:** [ADR 0141](<redacted>.md) §4 (which deferred cross-project-aggregation consent to "the platform T&C" and conditioned the scouting view on it), [ADR 0171](0171-profile-rollup-join-and-consent.md) D3 (fail-closed `profile_state`, and the sentence that reserved this task's place), [ADR 0016](0016-trust-boundary-server-enforced-permissions.md) (cross-project numbers are descriptive, never authority), [ADR 0205](0205-federated-checkin-needs-the-hubs-own-signin-witness.md) D3 (the hub's own sign-in witness; `ensureAccount` vs `upsertAccount`), [ADR 0210](0210-scouting-graduates-on-an-instance-asserted-owner-claim.md) (the directory this consent covers), [ADR 0202](0202-connections-graph-and-bounded-degree.md) D4 (the shared effective-visibility reader), `docs/specs/<redacted>.md` (the "already carries platform T&C consent" premise), `docs/specs/<redacted>.md`

> **0211 and 0212** are held by sessions in flight; this ADR takes 0213 rather than race them (the ADR 0199 / 0202 / 0207 / 0210 precedent).

## Context

ADR 0141 §4 shipped the cross-project scouting rollup with a promise attached: consent for aggregating a builder's work across every hosted project *"is handled by the platform T&C, tracked separately, out of scope here"*, and the view *"must stay Archon-internal until [it] lands"*. ADR 0171 then superseded the gating half — goal 1000045's owner decision made the data public by default with a self-serve hide — and D3 built the consent boundary the decision needed, describing `profile_state='active'` as the state an account reaches when *"a human is demonstrably at the hub (**and where T&C acceptance can later be captured, task 1002913**)"*.

Both ADRs, in other words, wrote their consent story around an artifact that did not exist. The public-profiles spec states the premise plainly — profiles are public by default because that is *"tied to having a platform account, which already carries platform T&C consent"* — and the profile-page spec had already flagged, in as many words, that **that premise is not currently true**.

Three things were found on picking the task up, and they changed its shape:

1. **A `/terms` page already exists.** Task 1003251 landed `public-landing/terms.html`, routed and server-stamped. The task brief (written before it) says no T&C document exists anywhere in the tree; that is now stale. What does not exist is the *content* ADR 0141 deferred to it: the page covers accounts, code ownership, fair use and liability, and says nothing whatsoever about work crossing between projects. `/privacy` is silent on it too.
2. **The `scouting.js:6` reference the task points at is gone.** Task 1002290 rewrote that header for ADR 0210; it now describes consent as enforced by `scoutingListableSql`. So the last in-tree pointer to the missing artifact had already been overwritten — the debt was becoming invisible rather than getting paid.
3. **The un-gating this artifact was supposed to unlock has already happened**, via ADR 0171 and ADR 0210. Nothing waits on this ADR to widen. What waits on it is the *honesty* of a premise every public surface already rests on.

## Decision

### D1 — The acceptance record is the hub's own evidence, never a caller's claim

`platform_identity_accounts` gains `terms_accepted_at timestamptz` and `terms_version text` (migration `platform_identity_019_terms_acceptance.sql`). Both are written by exactly one statement: `upsertAccount`'s `activate` branch. That branch has exactly one caller — `GET /sso/authorize` — where `activate: true` is a **source literal** and every other field comes from the hub's own `resolveSession` result, gated by `sessionUsableForFederation`.

This is deliberately the ADR 0205 D3 property, reused. An acceptance record a caller could assert is evidence of nothing; the only thing that makes the record mean "this human accepted" is that no request-controlled value can reach the statement that writes it. `ensureAccount` — the federated check-in / device-poll path, which takes an *unproven* `github_id` from a request body — writes NULL, exactly as it writes `provisional`.

> **Amended 2026-09-25 ([task 1003353](https://cloudbongos.com/builders#/task/1003353); [blocker 1000124](https://cloudbongos.com/builders#/blocker/1000124)) — what "the hub's own sign-in" means.** `GET /sso/authorize` is reached when a builder uses their platform account to sign in to a **project**; the only builder of that URL is a child instance's `idpAuthorizeUrl`. Signing in to the hub itself creates a hub session and never touches `platform_identity_accounts`, so it records no acceptance. `/terms` said "signed in here"; it now names a project sign-in. The owner chose to also capture the hub's own sign-in ([task 1003361](https://cloudbongos.com/builders#/task/1003361)), which will make this a second capture point rather than a wording fix. Two smaller corrections to the text above: the device poll does not go through `ensureAccount`, it is a non-activating `upsertAccount`, and so is `PATCH /me/handle`; `ensureAccount` is the federated membership check-in alone. The outcome was always the same (neither writes an acceptance), and both paths are now executed in `tests/terms_acceptance.mjs` rather than asserted as text.

> **Amended 2026-09-30 ([task 1004265](https://cloudbongos.com/builders#/task/1004265)) — a project sign-in *in the browser*.** The CLI's project sign-in (`POST /sso/device/poll`) also uses the platform account, and it stays **non-activating on purpose**. The person approves it on GitHub's device page, never on a hub page, so these terms are never in front of them — and the same branch that stamps the acceptance also flips `profile_state` to active, which ADR 0171 D3 reserves for the one path "where a human is demonstrably at the hub" — and D3 names the device poll as `provisional` in so many words. Stamping it would record consent nobody was shown and re-decide D3 by implementation convenience. `/terms` therefore names a project sign-in **in your browser**, and says that a command-line sign-in records nothing and why, so a CLI-only builder is not left guessing why they are unpublished. `tests/terms_acceptance.mjs` §3 drives the real device-poll route (no acceptance, still provisional, the non-activating literal, a forged body refused before any write) and a later browser sign-in stamping that same account. The "next hub sign-in" wording under D4 is left for task 1003361, which makes it true.

### D2 — Written once. The first acceptance is the one that stands

The conflict branch writes `COALESCE(platform_identity_accounts.terms_accepted_at, now())`. Signing in again re-reads the terms but does not restamp them, so the column keeps meaning *when consent was given* rather than *when this account was last seen*. `terms_version` is COALESCE'd the same way and always written in the same statement, so the pair cannot diverge.

### D3 — Consent is two columns, and the shared predicate is where that is enforced

`account-visibility.js` — the sole owner of every effective-visibility answer (ADR 0202 D4) — now spells the consent axis as `profile_state = 'active' AND terms_accepted_at IS NOT NULL`, in both its SQL and JS forms. `accountVisibleSql`/`isAccountVisible` compose from it rather than restating it, so the rollup, directory and connections predicates inherit the change without any of them naming the new column.

Writing it here rather than at the call sites is the whole point: both halves are stamped by the same statement, so for any account activated after this ADR they can never disagree — and requiring both in the predicate is what makes that structural instead of a promise. It is also what stops a row that predates the terms from publishing on a premise that was never true.

`tests/effective_visibility_predicate.mjs` extends its sole-owner rule to the new column, in the `${q}`-prefixed form the owner actually emits — the form the reach-COALESCE hole (task 1002290) taught us to pin rather than the bare spelling nobody writes.

### D4 — No backfill. Existing accounts re-accept on their next hub sign-in

Accounts that are already `active` get `terms_accepted_at IS NULL`, because no platform T&C covering cross-project aggregation has ever been shown to anyone and inventing a timestamp would fabricate the very artifact this task exists to make real. Under D3 they are therefore not publicly visible until their next hub-session authorize, which stamps them.

This is ADR 0171 D3's own backfill rule applied to its own sentence (*"all existing accounts start provisional and lazily upgrade on their next hub-session authorize"*), and it is what P03 ratified ([task 1002799](https://cloudbongos.com/builders#/task/1002799), owner, 2026-08-16): no backfill activation, on the rationale that a builder passes through the hub anyway. **This is the one consequence with a visible product effect, and it is on [blocker 1000123](https://cloudbongos.com/builders#/blocker/1000123) for the owner** — grandfathering is one line in the migration if they prefer it.

> **Amended 2026-09-25 ([task 1003360](https://cloudbongos.com/builders#/task/1003360) / `<redacted>`) — D4 is reversed, D2 narrowed.** The owner chose to grandfather ([blocker 1000123](https://cloudbongos.com/builders#/blocker/1000123); the decision is recorded in [ADR 0217](0217-rank-gates-inviting-not-viewing.md) D3) and to mark it. A third column, `terms_accepted_source` (`signin` | `grandfathered`, CHECK-constrained), records HOW an acceptance was given. Migration 024 marks every acceptance already on record `signin`, then stamps each `active` account without one as `grandfathered` at the moment it ran, with the version then in force; it runs once, in the transaction that creates the column, and never touches `profile_state`. D2 now reads "the first acceptance **a human gave** stands": the conflict branch still COALESCEs, except that a `grandfathered` row is replaced outright, so a grandfather gives way to its owner's own acceptance at their next hub sign-in, and every sign-in sets the source to `signin`. The replacement is keyed on the marker, not on "no `signin` recorded": an acceptance with no source (the pre-024 code can write one in the deploy window) is a real sign-in and keeps its date. No runtime code writes `grandfathered`; `tests/terms_acceptance.mjs` fails any server file that does, and any second acceptance write site. D3's predicate is unchanged — it asks whether an acceptance exists, never its source — so the ledger distinguishes the two and visibility does not. `/terms` says so.

### D5 — Re-acceptance on a later revision is out of scope, and visible rather than silent

Because the version is recorded and never overwritten, publishing a new `TERMS_VERSION` leaves every row naming the text it actually agreed to, so the platform can see who has not accepted the new one. What to *do* about that — re-prompt, re-gate, or nothing — is a product flow, not a storage shape, and is not built here.

### D6 — The wording is the owner's, and only the wording was left pending

The mechanism ships complete. The text of the new section is a draft on [blocker 1000123](https://cloudbongos.com/builders#/blocker/1000123); `TERMS_VERSION` is date-stamped and asserted to match the page, so changing the wording is an edit to two strings.

## Consequences

- The premise the public-profile surfaces rest on becomes true for every account activated from here, and fail-closed for every account that predates it.
- ~~**Every currently-`active` account is unpublished until its next hub sign-in** (D4).~~ Superseded by the grandfather (amendment under D4): nothing went dark after migration 024.
- `platform-identity.js` sat at 1497 lines against a hard `oversized_file_count: 0` ratchet, so the write-side SQL lives in a new `terms-acceptance.js` — the fifth instance of the "new file beside it" precedent (`account-visibility.js`, `application-echo.js`, `routes/connections.js`, `src/bongos/routes/my-sessions.js`). The file now measures exactly 1500 and **has no headroom left**; the next change to it must shrink it.
- The read/write split is load-bearing: `terms-acceptance.js` owns only statements that SET the columns, `account-visibility.js` owns the one that TESTS them. The guard's spelling rules deliberately do not match writes, which is what lets both files exist without one of them being a drift copy.
- *(Superseded by the grandfather, amendment under D4: after migration 024 every `active` account has an acceptance, so the case below no longer arises.)* **Settings will read wrong for a legacy account under D4** until someone closes it: `GET /me/cross-project` returns `profile_state` raw and the Settings consent note branches on it alone, so an account that signed in before the terms existed reads "active" while its profile is published nowhere. One own-scope boolean plus a copy change fixes it - filed as idea 1000875, and it disappears entirely if the owner grandfathers on blocker 1000123.
- `docs/specs/<redacted>.md`'s standing note that the consent premise "is not currently true for every account" is now addressed rather than outstanding.

## Rejected alternatives

- **A separate `platform_identity_terms_acceptances` table (one row per acceptance).** Correct if acceptance were an event stream — re-acceptance across versions, audit history. It is not one yet (D5), and a table whose only reader is a per-account NULL test is a join the visibility predicate would have to grow. Two columns, one statement, no join.
- **A click-through gate on `/sso/authorize`.** An explicit "I accept" button is stronger evidence than "by signing in you agree". It also puts an interstitial in the middle of a federated redirect that exists to be invisible, and it changes a sign-in flow two other live tasks were editing. The page now states the terms and the sign-in records acceptance of them; upgrading to an explicit gate is additive and does not invalidate any record written under this ADR.
- **Backfilling `terms_accepted_at` for already-active accounts** (D4) — records a consent that never happened, which is exactly the fiction this task exists to end. Offered to the owner as the alternative it is, not taken silently.
- **Deriving `profile_state` from `terms_accepted_at`** (dropping the column). The two facts are genuinely different — the hub witnessed a human, and that human accepted a text — and D5's revision case needs them separable.
- **Putting the acceptance predicate in `terms-acceptance.js`.** It would have made that file a second owner of an effective-visibility answer, which ADR 0202 D4 forbids and the structural guard fails.
