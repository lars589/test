# ADR 0326 — An upgrade may ADD a deny rule to a file the instance owns

- **Status:** accepted
- **Date:** 2026-09-22
- **Task:** [task 1004156](https://cloudbongos.com/builders#/task/1004156) (goal 1000090)
- **Deciders:** the owner, asked directly. The question is theirs because it narrows a rule the project drew on purpose; the implementation follows from the answer.
- **Amended:** 2026-09-22 by [task 1004158](https://cloudbongos.com/builders#/task/1004158) — the two shelf rules became starter-only; the top-up asks for the credential half alone. See the amendment note in *Decision* below.
- **Amends:** [ADR 0121](0121-greenfield-vs-brownfield-onboarding-adopt-existing-repo.md) §2 — which already licensed "merge **or** leave-and-report" for a pre-existing file; this names the one merge that is provably safe, and extends it from `--adopt` to every materialize
- **Related:** task 1003962 (the allow-only starter) · task 1003966 (the deny half) · [task 1004155](https://cloudbongos.com/builders#/task/1004155) (the core's own list) · task 1004023 (an unparseable settings.json is copied through, not mangled)

## Context

Task 1003966 gave the package-only instance starter its deny rules: no reading `.env` files, keys, or session tokens, and no `git stash`. It reached nobody who was already here.

The starter is written **only when `.claude/settings.json` is absent**. `bongos upgrade` materializes from the published package, which excludes `.claude/settings.json` on purpose (it is topology, not core), so an upgrade *always* takes the starter branch, *always* finds a settings.json already there, and left it alone. Every instance that took the allow-only starter from task 1003962 — the live one included — therefore kept it forever, and its local agent could still read keys and session tokens.

That was not an oversight. Task 1003962 drew the line deliberately: *"rewriting a file the instance owns is the line task 1003962 drew."* The prior session log recorded the remedy as manual — re-run `bongos init`, or delete the file so the next materialize writes a fresh starter.

The problem with a manual remedy for a security gap is that it protects the instances whose owners read release notes, which is not the set of instances that needs protecting.

## Decision

**`bongos upgrade` adds a missing starter deny rule to an instance's own `settings.json`, and names each rule it added in the run output.**

The argument is that a deny rule is **monotonic in the safe direction**. An allow rule widens what the local agent may do, so writing one into a file the instance owns could hand an agent authority its owner never granted. A deny rule can only narrow. Appending one therefore cannot make any instance less safe than it was a moment earlier, whatever the file already said — which is what makes this the one merge worth doing without asking per-instance.

"Never clobber" survives in the sense that was always load-bearing: **nothing the instance wrote is removed, reordered, or rewritten.** Their allow rules, their own deny rules, their `ask` list, their hooks, their env, and every key outside `permissions` come back exactly as they were. New rules are appended after the ones already there.

### The one rule the monotonicity argument does not fully cover

The credential rules are pure safety: nothing an instance legitimately does requires reading its own session token from inside an agent session. **The two shelf rules (`Bash(git stash:*)`, `PowerShell(git stash:*)`) are different in kind** — they guard a *workflow*, not a secret. They are in the top-up set anyway, because task 1004156's done-when says an old instance ends up with *the starter's* deny rules and because for an instance they are the only layer that exists (the `git-guard` hook is topology and does not ship).

The consequence is worth stating plainly rather than discovering: an instance whose builders used the repo-global shelf as a set-aside fallback will find it blocked after its next upgrade, and — no provenance, deny beating allow — cannot re-enable it from `settings.json`. Every added rule is named in the run output, so this is visible when it happens. If it ever bites, excluding the two shelf rules from the top-up set (keeping them starter-only) is a one-line change.

> **AMENDED 2026-09-22 — the exclusion above was taken** ([task 1004158](https://cloudbongos.com/builders#/task/1004158)). Not because it bit, but because the owner, shown the trade-off, judged the asymmetry the wrong way round: the core should not silently withdraw a workflow an instance cannot give itself back, when what it buys is a guard against a *shared-state* hazard the instance may not even have (the stack is repo-global across worktrees, so a single-worktree instance is not exposed the way this repo is). `starterDeny` is now `credentialDeny` plus the shelf rules; the top-up asks for `credentialDeny` alone.
>
> **Two things this does not change.** A *fresh* instance still gets both shelf rules — there they are a visible default, present from the first commit and editable before any workflow has grown around it, which is the difference in kind the section above is really about. And because the top-up only ever appends, **an instance that already took them keeps them**: live `cloudbongos.com` gained both in its 0→20 run and its builders stay blocked until someone hand-edits that file. This amendment is forward-looking only, and deliberately so — an upgrade that started *removing* rules would give up the directionality the whole decision rests on.

### What is deliberately NOT done

- **No provenance, and so no memory of a deletion.** An owner who deliberately removes a rule we add will get it back on the next upgrade, and because deny beats allow in Claude Code's permission order they cannot override it with an allow rule either. We considered recording what we added so a later deletion could be read as intent. It was rejected as speculative machinery for a case nobody has hit: the rules in question are "do not read credentials" and "do not `git stash`", and an instance that genuinely needs one lifted is a conversation, not a config toggle. Revisit if it is ever a real complaint.
- **A file we cannot parse is left byte-for-byte alone** and reported, the same posture task 1004023 took when the core's own settings.json would not parse. So is one whose `permissions` or `permissions.deny` is not the shape we expect. A half-understood rewrite of a permissions file is worse than the gap it closes.
- **The allow half is never topped up.** Only deny. The whole safety argument is directionality, and it does not survive being applied to a rule that grants.

## Consequences

- An instance materialized before task 1003966 is protected on its next upgrade, with no action from its owner and nothing of theirs lost.
- `materializeClaude` gains `summary.settingsDenyAdded` (the rules added) and `summary.settingsDenyUncheckable` (why a file was skipped). Both are also printed through `log()` — `upgrade.js` does not iterate `summary.notes`, so a note alone would never reach the operator's terminal.
- **The top-up is reported in `writtenPaths` on the real run only, never on the dry run.** That list doubles as the set `bongos upgrade`'s clean-tree pre-flight *ignores* (task 1004122), and the waiver is justified by "materialize overwrites these unconditionally, so whatever they hold now is discarded either way" — which is exactly not true of a top-up, the one path here that preserves existing content. Listing it in the preview would stop an owner's half-finished edit to `settings.json` from halting the bump, and `--commit-pin` would then commit and push it unreviewed. Omitting it from the preview keeps that safety property; reporting it on the real run still hands it to `persistPin`, so the pin commit carries the added rules and the next upgrade does not read them as a human's stray work.
- A read that throws (a directory at that path, a locked or root-owned file) is caught and reported as uncheckable. This step runs *after* the pin moved and the migrations ran, so an uncaught throw would leave a half-applied upgrade.
- The test that asserted an instance's settings.json comes back **byte-identical** is superseded by a strictly stronger one: every rule it had is still there, unmoved, and it gained only deny rules. The weaker spelling was what froze the gap in place.
