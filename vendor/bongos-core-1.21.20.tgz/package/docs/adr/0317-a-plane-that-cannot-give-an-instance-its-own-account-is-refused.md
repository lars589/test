# ADR 0317 — A plane that cannot give an instance its own account is refused, not given a shared uid

**Status:** accepted · **Date:** 2026-09-20 · **Task:** [task 1004018](https://cloudbongos.com/builders#/task/1004018) (goal 1000106 — BONGOS-V2)

**Related:** [ADR 0281](0281-an-instance-identity-is-its-own-unix-account-and-pg-role.md) (the per-instance account this one guards) · [ADR 0315](0315-a-plane-with-no-proxy-is-refused-not-given-a-no-op-ingress.md) (the sibling refusal, and the ordering this one extends) · [ADR 0306](0306-instance-supervision-is-a-seam-with-systemd-as-the-default.md) (the supervision seam that deferred this question here) · [ADR 0128](0128-provisioning-runner-privilege-and-db-auth-model.md) (the `PROVISION_SUDO` escalation the probe tests)

## Context

ADR 0281 made an instance's identity its own unix account: provisioning step 1c runs
`ensureInstanceUserCmd` → `useradd --system`, and the unit's `User=`/`Group=` is what
stops one co-tenant instance reading a sibling's `/proc/<pid>/environ` — where every
instance's `EnvironmentFile` carries its GitHub App private key and its OAuth client
secret. That was audit finding B3, and closing it is the whole point of the account.

`useradd` needs uid 0. The self-host image is `node:22-bookworm-slim`, runs `USER node`,
and installs `postgresql-client bash tini curl ca-certificates git` — **no sudo**. On that
plane the account cannot be created at all, and ADR 0306 named this as the piece its seam
does not cover: *"`useradd` cannot run under `USER node` — that is task 1004018."*

**Two failure shapes, neither of them honest.**

- **Today it crashes, late.** `boxExec(ensureInstanceUserCmd(...))` is not `allowFail`, so
  step 1c throws — *after* the capacity, ingress and wiring preflights have passed, after
  the status flip to `provisioning`, and after the standalone shape has already pulled its
  repo and run `npm ci`. The runner records a crash where the honest answer is a refusal,
  and it records it with the box half-changed.
- **Tomorrow it goes quiet.** ADR 0315 refuses a proxyless plane, so a compose self-host
  currently stops at the ingress question and never reaches step 1c. That is coincidence,
  not protection: 0315 says in its own consequences that *"a future ADR that adds [a front
  door] replaces this refusal rather than extending it."* The moment someone gives the
  container a published port, the identity gap is live again — and `provision-process.js`'s
  supervisord program block writes `user=<instanceUser>` for an account that was never
  created, which supervisord reports as a program that will not start rather than as a
  security regression.

The task asked for a posture, and it is worth naming the one that was rejected: *accept
that a self-host container is single-tenant and document that instances there are not
isolated.* It buys a working container standup by re-opening B3, and an operator has no
way to see which posture their box is running.

## Decision

**A plane where the runner cannot become root is refused before anything is attempted, and
the refusal names what a shared uid would cost.**

`accountPlaneGap(exec, { privileged })` in `scripts/gds/provision-repo.js` — beside the
account it guards — probes with `${sudo}sh -c 'test "$(id -u)" = 0'`. It returns `null`
when the runner reaches root, or a string naming the missing privilege.
`accountPreflight({ exec, apply, log, shape, privileged })` wraps it with the narration
its sibling preflights carry, and `provisionInstance` returns `{ok:false, error: 'Account
preflight failed: …'}`.

**The probe runs the same escalation the mutation will,** so a pass is evidence rather than
inference: `privileged` (i.e. `PROVISION_SUDO=1`) renders `sudo sh -c …`, exactly the
prefix `ensureInstanceUserCmd` will use a few steps later.

**`sh -c`, not a bare `test`, and that is load-bearing.** Under sudo the *outer*,
unprivileged shell would expand `$(id -u)` before sudo ever ran, and the probe would
cheerfully answer about the wrong user — passing on precisely the plane this refuses. The
command substitution has to happen inside the escalation. For the same reason there is no
pipeline: a pipeline's exit status is its last stage's, which would erase the distinction
below.

**A shell that ran and answered is the only failure that proves the plane cannot.** Under
remote exec `boxExec` is `ssh <host> bash -s`, so a briefly-unreachable co-hosting box
throws here too — and answering that with "this plane cannot create accounts, provision
elsewhere" would be a confident wrong diagnosis burning the intent's retry budget on a
network blip. Exit 1 (`test` said no) and 127 (`sudo` is not installed) are read as proof;
ssh reports its own failures as 255, so both still mean what they say across the hop.
Anything else returns *"could not confirm the runner can create a per-instance unix
account on this plane"* with the real cause leading. This is ADR 0315's rule, applied to a
different question.

**The refusal is ordered third, after capacity and ingress and before ADR 0303's wiring
check.** Those first three are questions about the *plane* — has it room, has it a proxy,
can it hand out an identity — and 0303's is the one question about *this instance's*
domain. ADR 0315's capacity → ingress → wiring order is extended, not rearranged: all four
still return before anything on the box changes.

**No container-shaped identity model, and no "single-tenant" acceptance.** The symmetry
with ADR 0306 would be a seam with a container implementation. There is nothing to put in
it: a per-instance account inside the container needs the image to run privileged, a
container-per-instance needs a docker socket and an orchestrator that does not exist here,
and unprivileged user namespaces are not reliably available. The honest encoding of "this
plane cannot give a child its own identity" is a refusal — the same reasoning ADR 0315
used to reject a no-op ingress backend.

## Consequences

- **A compose self-host still cannot provision a child instance — and now it says so for
  its own reason, not by accident.** This refusal does not depend on ADR 0315's firing
  first, so giving the container a front door later cannot silently re-open B3. Whoever
  builds that front door has to answer this question too, and the error text is where they
  will find it.

- **The failure moved from step 1c to the preflight.** A plane without root used to hard-
  error after the status flip and, for a standalone, after a repo pull and an `npm ci`.
  It now returns `{ok:false}` before any mutation, which is the pending-retry path an
  environment problem earns rather than the crash it was getting.

- **One extra `sh -c` per applied standup.** Read-only, no mutation, and it runs after the
  capacity measurement, so a full box still refuses without it. A dry run never probes, and
  a dedicated droplet is skipped — cloud-init runs as root there, and ADR 0281's account
  steps are baked into its user-data unchanged.

- **The live box is untouched.** The control-plane runner unit sets `PROVISION_SUDO=1`, so
  the probe renders `sudo sh -c …`, passes, and every command after it is byte-identical.
  The regression is pinned by a test that provisions a root-reaching plane and asserts
  `useradd --system` still runs, after the probe.

- **Root, but no `useradd`, is deliberately not covered.** An Alpine-style plane with
  `adduser` instead would pass the probe and fail at step 1c as it does today. The gap this
  ADR closes is privilege, which is the one the planes we actually run exhibit; inventing a
  second probe for a plane nobody has would be speculation, and it would fail loudly rather
  than quietly in any case.

- **Teardown is not covered,** for ADR 0315's reason: a refusal on the teardown path would
  strand a row instead of cleaning it.

- **This is a capability question, not a configuration knob.** There is no
  `PROVISION_ALLOW_SHARED_UID`. A runner either reaches root on this plane or it does not,
  and an operator who wants provisioning to proceed needs privilege, not a flag that says
  to pretend.

## Alternatives considered

- **Accept it: document a self-host container as single-tenant with instances sharing one
  uid.** Rejected. It is a silent downgrade of the exact vector ADR 0281 closed, visible
  nowhere on the running box, and "single-tenant" is not what a container hosting several
  child projects is. A posture an operator cannot observe is not a posture.

- **An identity seam with a container implementation** (mirroring ADR 0306). Rejected: no
  implementation exists to put behind it. A seam whose second backend is "do nothing" is
  the no-op backend ADR 0315 already rejected, wearing a seam's clothes.

- **Probe `useradd --help`, or `command -v useradd`.** Rejected on the mechanism: both
  succeed as an unprivileged user on the very image this refuses. They test the binary; the
  missing thing is the privilege to run it.

- **`${sudo}id -u` and compare the output to `0`.** Rejected: it decides on captured stdout
  rather than on exit status, which every sibling preflight and every provisioning test
  fake treats as the contract — the fakes answer commands with an empty `stdout`, so the
  probe would have failed on hermetic planes that are fine, and the fix would have been to
  teach a dozen harnesses about one probe.

- **Run the probe inside `ensureInstanceUserCmd` and let step 1c refuse itself.** Rejected:
  it keeps the refusal after the status flip and after the standalone repo sync, which is
  most of what makes the current failure a bad one.
