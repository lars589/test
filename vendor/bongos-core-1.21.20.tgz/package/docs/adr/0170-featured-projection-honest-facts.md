# 0170 — The featured projection tells time honestly: `created_at` in, `updated_at` out, owner from the project's own archon

- **Status:** Accepted
- **Date:** 2026-08-14
- **Task:** [#1002778](https://cloudbongos.com/builders#/task/1002778) (goal 1000061 — the front door and the project hub)
- **Extends:** the C6 honesty rule ([`docs/design/projects-hub-direction.md`](../design/projects-hub-direction.md) §7) and the self-report enrichment pattern of task 1002771 (`project-stats.js`).

## Context

Task 1002778 enriches the hub's project card with real metadata. Its brief listed `updated_at` under "already available, no new plumbing: add it to the public projection", and offered two owner options: "resolve it to a real login + avatar via the project's own API, or omit the field until it can be answered." Implementation surfaced facts that changed both calls, and this ADR records the deviations so they are decisions, not drift.

## Decision

**1. `created_at` joins the public `/projects/featured` projection, labelled "Listed" — never "Created".** The column is set once by `DEFAULT now()` on INSERT and never touched again: it is the moment the hub first catalogued the row, not when the project began (Example predates its row by months). The card wears the honest label, and the C6 card test bans the word "Created" outright.

**2. `updated_at` stays OUT of the projection, deviating from the task brief.** Reading the code showed the column is bumped by `upsertProject`'s ON CONFLICT branch — which fires on **every client re-registration and secret rotation** — and by `setProjectFeatured`, the Archon's own curation toggle. As a public "last updated" it would claim project activity while actually reporting curation noise: a project's timestamp would refresh because someone clicked "feature". Publishing it would be the same class of lie the em-dash rules exist to prevent. The projection test now pins the SELECT list itself (`updated_at` may sort, never project; `SELECT *` is banned — the route is CORS-open and rank:public, so a star projection would leak `owner_github_id` and `status`).

**3. The owner fact is the project's own archon row — `owner_github_id` stays unread.** The catalog's `owner_github_id` calls itself "advisory attribution (not an authority)" in its own migration, is NULL on most live rows, and the design contract forbids reading it. But the leaderboard payload `project-stats.js` already downloads for the builders count carries `rank`, `github_login`, and `avatar_url` per row — and this platform's own vocabulary defines the archon as the instance's owner (`selfRel()`: "Archon is the instance's owner"). So the enrichment surfaces the archon row's login + avatar: the project's own authority answering for itself, zero extra requests, the 2-fetch-per-origin pin intact. Values are type-checked and length-capped server-side (third-party payload), and the avatar URL is scheme-checked again client-side before it becomes an `<img>`.

## Consequences

- Every card fact is something some authority actually asserted; unknowns hide rather than dash. A "last updated" fact can return later if a project's **own** API ever reports real activity recency (e.g. newest `shipped_at` from `/public/recent-shipped`) — that would be a third fetch and needs the test pin moved deliberately.
- On a multi-archon instance the top-credits archon is named; a zero-credit archon on a page-capped leaderboard can fall off, which renders as **no owner shown**, never a wrong one.
- The hub republishes a login the source project already serves unauthenticated at `/api/bongos/public/leaderboard` — aggregation, not new disclosure (grader-reviewed).
