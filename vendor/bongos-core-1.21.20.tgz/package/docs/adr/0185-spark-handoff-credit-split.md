# 0185 — The spark-handoff credit split: 70% developer, 30% spark author

- **Status:** Accepted
- **Date:** 2026-08-22
- **Tasks:** [#1002923](https://cloudbongos.com/builders#/task/1002923) (BV1.R147, goal 1000062 — three grades of idea). Completes the spark chain: [#1002920](https://cloudbongos.com/builders#/task/1002920) (the mark), [#1002921](https://cloudbongos.com/builders#/task/1002921) (the queue), [#1002922](https://cloudbongos.com/builders#/task/1002922) (the pickup)
- **Extends:** [ADR 0172](0172-per-craft-compensation-ideator-credit-lane.md) — the ideator credit lane. That ADR built the streams and paid `captured_by`; this one decides what happens when `captured_by` is not the only person who made the idea.
- **Related:** ADR 0023 (the original idea-promotion slice), 0146 (reward-mode machinery), 0054 (cost-plus)

## Context

ADR 0172 shipped the ideator credit lane: stream 1 pays 5 credits (scaled by idea
grade) for every task shipped under an idea, stream 2 pays 5 credits once when a
Full Idea clears the completeness bar. Both paid `idea_inbox.captured_by` — the
person who filed the idea — because at the time that was the only person an idea
had.

Goal 1000062 then built the **spark handoff**. An author marks a quick idea as a
Big Idea Spark ("I have the spark but not the full picture, someone develop
this" — R144); that mark is the consent that makes cross-builder development
fair. The spark becomes browsable (R145), and another builder develops it into a
Full Idea in place, preserving the original author while being recorded as its
developer (R146, `ideas_grades.developed_by`).

That created a person the credit model had no answer for. Two builders now make
one Full Idea: one had the thought, one wrote the five fields. Both streams still
paid only the author.

**R146 therefore deliberately shipped paying nothing at all.** Not an oversight —
a refusal to guess. `awardIdeaFullPassCredit`'s idempotency predicate is
`(builder_id, reason)`, so a payment to the *developer* would **not** have blocked
a later payment to the *author*: the same idea would have paid twice. Choosing a
recipient at that call site was not merely premature, it was unsafe. The develop
route left the money alone and named this task as the owner of the decision.

The result was a real gap in the meantime: a developed Full Idea that cleared the
bar received stream 2 **never** — the only path that could pay it was the author
resubmitting their own idea.

## Decision

### 1. 70% to the developer, 30% to the spark author — on both existing streams

The owner's call, 2026-08-22. The developer takes the larger share, and the
reasoning is behavioural rather than sentimental: **developing someone else's
spark is the scarce act the queue depends on.** At an even split, developing a
spark pays half what authoring your own Full Idea pays for the same writing work,
so the rational move is always to write your own and the R145 queue stays a list
nobody reads. The majority share is what makes the pickup surface function.

The author is not left thin. They keep 30% of every split **and** their share of
stream 1 on every task shipped under the idea, for as long as the idea keeps
producing work. The thought keeps earning; it simply stops being the only
contribution the ledger recognises.

One ratio, applied to **both** streams — the immediate pass credit and the
trailing per-task credit — so there is a single rule to explain rather than a
table of cases. Stream 3 (the board-room payout, [#1002999](https://cloudbongos.com/builders#/task/1002999),
not yet built) inherits the same helper when it lands.

### 2. A policy constant in `credits.js`, not a table

`IDEA_DEVELOPER_SHARE = 0.70` sits beside the pass bar and the quick factor, per
ADR 0172's own consequence ("thresholds/factors are policy constants in
`credits.js`", following the ADR 0023 precedent). A share of someone's earnings
deserves a review and a commit, not a runtime edit. It is one constant, so a
project that wants a different balance changes one line — which is the recorded
owner philosophy for this goal: a simple base, designed to be altered.

### 3. The economy module decides who is paid — the caller no longer can

`awardIdeaFullPassCredit` now reads `captured_by` and `developed_by` from the
database itself (`ideaCreditParties`) instead of trusting the `authorId` its
caller passes; the argument survives only as a fallback for an idea the lookup
cannot see. `awardIdeaTaskShipCredit` already read the idea row and simply selects
`developed_by` alongside.

This is the structural half of the decision, and it is what makes R146's caution
unnecessary going forward. The reason the develop route could not safely pay was
that *the recipient was chosen at the call site*. With the payees derived in one
place, no caller can direct money at the wrong builder, and the develop route now
books the split like any other path — **it hands over an idea and a score, never
a recipient.**

### 4. Three arithmetic properties, each a real bug if missed

`splitIdeaCredit` is pure and carries them:

- **The total is conserved.** The developer's share is rounded and the author gets
  *the remainder*. Rounding both independently pays 6 credits out of a 5-credit
  payout (`round(3.5) + round(1.5) = 4 + 2`).
- **A self-developed idea collapses to one payee.** R146 deliberately permits an
  author to develop their own spark. Emitting two rows for one builder would not
  double-pay — it would **under**-pay, because the idempotency predicate is
  `(builder_id, reason)` and the second insert is silently refused, so the builder
  would receive one of their two shares. The comparison normalises with `String()`
  because `bigint` columns arrive as strings: a type mismatch must not become a
  phantom second payee.
- **Zero-value rows are dropped.** A 1-credit payout splits to 1/0; a 0-credit
  ledger row reads like a payment that was not made.

Ids otherwise pass through **unconverted**. `builder_id` is a `bigint`, so
`Number()`-ing it risks precision on a large id and would change the value type
the pre-R147 code fed straight into the `INSERT`.

### 5. `builder_id` in the idempotency predicate is now load-bearing

It entered as an index optimisation — narrowing the `NOT EXISTS` to one builder's
rows via `idx_credit_log_builder` instead of scanning a growing `credit_log` (the
R143/IC2 grader finding). Under a split it is also **correctness**: two payees are
booked under one `reason`, so a reason-only predicate would refuse the second.
A partially-booked split therefore completes on the next call, and `credited`
reports only what was newly booked.

## Consequences

- **The spark queue has a reason to be picked up.** The chain R144 → R145 → R146
  now ends in a payment rather than in attribution alone.
- **A developed Full Idea gets stream 2 at develop time**, closing the gap R146
  left. It is fail-open: the development has already committed, and a credit-lane
  hiccup must never roll back somebody's work.
- **One place decides who earns from an idea.** Future callers inherit the split
  for free and cannot get the recipient wrong.
- **Not decided here:** stream 3's split (it ships with the Board Room, task
  1002999) and whether `origin='develop'` in `ideas_task_lineage` belongs to
  whoever promotes a *developed* idea into a task. ADR 0172 §5 says the lineage
  row is "set at promotion and at develop (R146)", but R146 creates no task —
  developing a spark produces a Full Idea, not work — so that origin is still
  unwired, deliberately, rather than invented. It changes who stream 1 pays, so it
  deserves its own decision.
