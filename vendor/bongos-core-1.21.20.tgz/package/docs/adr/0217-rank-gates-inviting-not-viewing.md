# ADR 0217 — Rank gates INVITING, not VIEWING: the owner's answers to the account-security review's five blockers

- **Status:** accepted
- **Date:** 2026-08-29
- **Task:** [task 1003358](https://cloudbongos.com/builders#/task/1003358) (ledger close-out, goal 1000045 — Public builder profiles)
- **Blockers answered:** [1000121](https://cloudbongos.com/builders#/blocker/1000121), [1000122](https://cloudbongos.com/builders#/blocker/1000122), [1000123](https://cloudbongos.com/builders#/blocker/1000123), [1000124](https://cloudbongos.com/builders#/blocker/1000124), [1000126](https://cloudbongos.com/builders#/blocker/1000126)
- **Relates to:** [ADR 0210](0210-scouting-graduates-on-an-instance-asserted-owner-claim.md) D2 (the instance-asserted owner door), [ADR 0215](0215-the-recruiter-sliver-is-a-ceiling-not-a-step.md) D4 (the sliver's archon floor), [ADR 0213](0213-platform-terms-acceptance-is-the-hubs-own-witness.md) (the consent axis), [ADR 0209](0209-one-budget-for-the-account-existence-oracle.md) (the account-existence oracle), [ADR 0201](0201-cross-project-application-vouched-row-live-record.md) D3 (the `project.recruit` atom belongs to the console wave), [ADR 0016](0016-trust-boundary-server-enforced-permissions.md) (cross-project numbers are descriptive, never authority)

## Context

The 2026-08-29 account-security batch shipped fourteen tasks into goal 1000045 and left five questions it deliberately refused to answer for itself. Four were audience or consent decisions with visible product consequences; one was a legal page saying something the code did not do. All five went to the owner as blockers rather than being guessed, and this ADR records what came back.

They are recorded together because **four of the five turned out to be the same question**, and the owner's answer to one of them reframed the rest. That reframing is the decision worth keeping; the individual answers follow from it.

## Decision

### D1 — Rank gates the ability to INVITE. It does not gate the ability to VIEW.

Blocker 1000122 asked whether a project's other archons should count as project owners on the platform, so that a founder's delegates could reach the recruiting directory. It framed the choice as *widen the `owner` claim* versus *hand out `project.curate` by hand*. The owner declined both framings:

> "I think that rank should only gate the ability to invite, not the ability to view a community page. The community page in my mind will be more than just for scouting, it will be a place for people to view the achievements of others across projects. However the ability to invite said builders would be rank gated."

This is a cleaner line than either option offered, and it settles more than it was asked about. Seeing what someone has built across projects is **not** a privileged act — that data is public by consent, and the platform T&C already promises it is visible "at your handle's page, in the people directory, to project owners looking for people to work with, and to search engines". Reaching out to that person **is** an act with a cost to them, and that is where a floor belongs.

The delegation problem that prompted the blocker dissolves under this line rather than being solved by it. A founder does not need their teammate re-labelled an owner in the platform's vocabulary; they need their teammate able to invite. So:

**`membership_kind` is NOT widened.** `membershipKind()` in `src/bongos/auth-admission.js` continues to report `owner` for the instance's `FIRST_ADMIN` login alone. The wire contract every federated instance speaks is unchanged, the My Projects `owned` / `building on` split keeps its current meaning, and the cross-version window in which older and newer releases would have disagreed never opens. [Task 1003350](https://cloudbongos.com/builders#/task/1003350), which existed to build the widening, is abandoned.

**A per-project INVITE rank floor is built instead, defaulting to `archon`** ([task 1003362](https://cloudbongos.com/builders#/task/1003362)). It is that project's own rank ladder, set by that project's own archons — which is strictly better than the alternative the blocker offered, where a founder had to ask the platform for a `project.curate` grant per teammate. The floor is the project's; the platform holds no rank of its own for a project (ADR 0016).

**Viewing gains no rank gate**, and the surface it applies to is a new one: a cross-project achievements page ([task 1003363](https://cloudbongos.com/builders#/task/1003363)). Per the owner it **lives on cloudbongos.com, not the builders' hall variant** — so it is an apex page under `public-landing/`, inside the `apex-only` region that `stripApexOnly()` removes from child projects, not a `modules/hall-ui/` surface.

One thing that must not be conflated as that page is built, and it is the whole risk of it: **public consented profile data and the pre-accept recruiter sliver of a private account are different material.** The first is the page's subject. The second stays at the archon floor (D2 below) and must not leak onto the page in any form — not as a row, not as a facet count, not as a search-result absence that reveals presence.

### D2 — The recruiter sliver keeps its archon floor, and the floor is now the *consistent* answer rather than the merely safe one

Blocker 1000126 asked whether the D3 pre-accept sliver — the first surface that discloses a **private** account — should keep spec D3's declared archon floor, or reuse the wider door `/scouting` already has (`project.curate` at metic, OR any project owner). It shipped at the archon floor as the conservative reading, with the audience question filed rather than taken (ADR 0215 D4).

**The owner kept the archon floor.** No code changes; the swap remains one line in `modules/platform-identity/routes/scouting.js` if the console wave's `project.recruit` atom later says otherwise, and `tests/recruiter_sliver_boundary.mjs` continues to pin it.

What changed is the *reason*. ADR 0215 D4 held the floor defensively — narrowing after people have been disclosed is not recoverable, so hold and ask. Under D1 the floor is positively correct: the sliver is a recruiting disclosure of an account that asked not to be publicly visible, which is squarely on the **inviting** side of the line, and the invite floor the owner asked for **also defaults to archon**. The two answers agree, and they agree for the same reason. `project.recruit` — floor archon, widenable per instance through the governance tab — remains the right eventual home, and the per-project invite floor of D1 may well *be* that atom rather than a rival knob; whoever builds 1003362 must check that before shipping a second mechanism answering the same question.

The tension ADR 0215 D4 recorded against goal 1000045 C5 ("project owners, not only Archons, browse builder profiles to recruit") is resolved rather than merely noted: C5 is about **browsing**, which D1 makes ungated. It was never about disclosing private accounts.

### D3 — The platform T&C is corrected in words now and in behaviour next, and existing accounts are grandfathered with the grandfathering on the record

Blockers 1000123 and 1000124 are the consent pair, and 1000124 corrects 1000123 — read in that order.

**The words (1000124).** `/terms` said acceptance is recorded "by signing in here", but the stamp is written by exactly one statement reachable only through `GET /sso/authorize`, which a **child project** reaches by redirecting a browser to the hub. A builder who signs in at cloudbongos.com and never joins a project was never stamped — and because `terms_accepted_at IS NULL` makes `isAccountActive` false, their profile was invisible everywhere and their connections denied, permanently, under the no-backfill rule. The page was promising that builder the opposite of what they got.

The owner chose **both halves**: correct the sentence immediately ([task 1003353](https://cloudbongos.com/builders#/task/1003353)) so the page stops making a false promise while the real fix is built, and then **record acceptance at the hub's own sign-in too** ([task 1003361](https://cloudbongos.com/builders#/task/1003361)), closing the gap rather than wording around it. The second capture point goes through the existing `platform-identity.hub` seam rather than a core-to-module import, so child instances see no behaviour change.

**The grandfathering (1000123).** Nobody had an acceptance on record, because until ADR 0213 there was nothing to accept. The choice was to fail closed — existing public profiles go quiet until each builder next signs in — or to grandfather them. The recommendation was to fail closed, on the reasoning that grandfathering *records a consent that did not happen*, which is the precise fiction ADR 0213 exists to end.

**The owner chose to grandfather** ([task 1003360](https://cloudbongos.com/builders#/task/1003360)), having been shown that cost. Nothing goes dark.

The ledger is not allowed to absorb that cost silently, and on the follow-up the owner agreed: a grandfathered acceptance is **marked as grandfathered** — queryably distinct from one a human gave, via a recorded source rather than a magic timestamp — and `/terms` **says so**, adding a sentence that accounts existing before this version were accepted on their behalf at the date it took effect.

That combination is the decision worth recording. ADR 0213's honest property is not "every acceptance was a sign-in"; it is **the record never claims more than what happened**. Grandfathering with a marker and a disclosure keeps that property. Grandfathering silently would have broken it, and would have been the cheaper thing to build.

### D4 — `/access-requests/status` collapses to one `not_admitted` answer, and the CLI copy is fixed in the same change

Blocker 1000121 asked whether the route should stop distinguishing `pending` / `dismissed` / `none` to an unauthenticated caller. **The owner chose to collapse it** ([task 1003359](https://cloudbongos.com/builders#/task/1003359)) — the recommendation, and the fix ADR 0209 had already named in its own "When to revisit" section. The response becomes `admitted` plus a single `status` of `member` | `invited` | `not_admitted`.

Two things must stay true as it lands, and both are in the task.

**It does not close the oracle, and the work must not claim it does.** `admitted: true` still means "member or invited" on both routes, and that is the fact worth having for targeting. The task 1003339 rate limiter is what reduces enumeration. What collapsing narrows is what leaks about **applicants** — that someone applied here, and that we turned them down, which is not our fact to hand to anonymous callers.

**The cost is paid in the same change, not deferred.** `scripts/gds/login.js` is the only place in the entire codebase that tells a declined applicant they were declined. Collapsing makes that branch unreachable, so without a copy fix a declined person would watch dots for thirty minutes and then be told to re-run `bongos login` "once an Archon has approved you" — an approval that is never coming. Rewriting that timeout copy to be honest and non-promising is part of the same task, and it is better copy for the genuinely-pending case too.

## Consequences

- Four blockers that gated real work are answered, and the work is filed: 1003359, 1003360, 1003361, 1003362, 1003363, plus 1003353 auto-promoted from `blocked` to `ready` when 1000124 resolved.
- One shipped task is abandoned rather than built (1003350). The delegate widening it carried is not wanted; the wire contract stays as it is.
- `security_report` 1000027 — the live SSO check-in identity hole — is marked **fixed**, its fix having been live since core 1.19.417. It was deliberately held open while the hole was still serving, so that the ledger would not claim a fix before one existed.
- `verifyHubAssertion`'s purpose-confusion weakness moved from a line in ADR 0208 D2 and a to-do on task 1002285 to a filed security report (1000028, medium, latent). It has no call sites today and becomes an admission bypass the moment ADR 0201 D2.1's application vouch is minted, so the fix must land **before** the feature that arms it.
- **A new invariant to hold the line D1 draws:** any future gate added to a viewing surface, and any recruiting or invite surface added below the archon floor, contradicts this ADR and needs one that supersedes it. The community page (1003363) is the first surface built under it and is the one to watch — it is where the temptation to re-gate viewing, or to let a private account's sliver ride along with public rows, will actually arise.
