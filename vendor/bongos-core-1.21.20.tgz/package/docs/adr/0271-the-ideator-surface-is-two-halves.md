# 0271 — The ideator surface is two halves: Bongos owns the prose, the harness owns the chrome

- **Status:** Accepted
- **Date:** 2026-09-09
- **Tasks:** [#1003506](https://cloudbongos.com/builders#/task/1003506) (this record and the prose half). Promoted from idea 1000732 (owner, 2026-08-16).
- **Goal:** [#1000095](https://cloudbongos.com/builders#/goal/1000095) — Working area 6 (Governor / Builder / Artist / Ideator experience), criterion `wa6-kernel-and-packs`.
- **Builds on:** [ADR 0264](0264-the-ten-working-areas.md) §1 (the area and its owner), [ADR 0016](0016-trust-boundary-server-enforced-permissions.md) (the trust boundary — why the permission prompt was never the gate), [ADR 0104](0104-trust-gds-api-channel-in-auto-mode.md) (the existing bypass posture on dev boxes).
- **Answers** the ideator half of the argument the `artist-mode` criterion answered for artists with the Studio (goal [#1000074](https://cloudbongos.com/builders#/goal/1000074)).

## 1. The decision

The ideator's complaint — *"there is really no need for an ideator to see all the
text and technical work being done, or even the inner Bongos logic"* — is two
problems wearing one sentence, and they have different owners.

**The prose half is Bongos's, and it ships with this record.** What Claude *says*
is reachable from configuration Bongos already owns and already injects. Three
pre-existing seams carry it; nothing new was plumbed:

| Axis | Seam | Behavior |
|---|---|---|
| per-**person** | `interaction-prefs.machinery` (`builder-settings`) | new field, `show` (default) \| `quiet`. Rides the live Conductor injection rail. |
| per-**role** | the `ideator` directive in `scripts/gds/discipline-modes.json` | a claimed ideator task opens a quiet session regardless of the person's setting. |
| per-**session** | `/ideate`'s new *"be quiet about the machinery"* section | the directive names `/ideate` as the only place the ideator experience is defined, so the contract has to live there too. |

**The chrome half is the harness's, and it is deferred to a spike rather than
guessed at.** Tool-call blocks and thinking blocks are drawn by the client, and
**no instruction Bongos injects can suppress them** — an injected contract is
content, not display configuration. But that does *not* make the chrome
unreachable, and this ADR was nearly written on the opposite, wrong assumption.
Two real levers exist (§4), and choosing between them needs a version-pinned
observation this record does not have. So the chrome half is **filed as a spike
plus an implementation task** — not attempted here, and not declared impossible.

**Bypass is explicitly NOT shipped as an ideator default**, rejecting that part
of the originating idea. §3 — and the reason is now partly technical, not only
prudential.

## 2. Why not a room, and why not wait for declared roles

**Why not a hall room (the Studio's answer).** Goal 1000074 answered the artist
half of this same argument with a place: *"a place an artist wants to be, not a
form."* `/builders/studio` is that room, and it is right for an artist, whose
craft has artifacts a room can hold. It cannot answer the ideator's version,
because **the ideator's complaint is about the surface of the Claude session,
which the hall does not render.** The Studio still earns its keep here as
precedent — the mode marker on the document root, and the discipline of a room
that writes nothing and links out to where the craft is done — but it is not the
vector. A room would have been a satisfying deliverable that missed the ask.

**Why this did not wait on per-session declared role.** The task recorded a
dependency on idea 1000729 (declared role), whose tasks
([#1002991](https://cloudbongos.com/builders#/task/1002991),
[#1002992](https://cloudbongos.com/builders#/task/1002992)) sit behind
[#1002989](https://cloudbongos.com/builders#/task/1002989) →
[#1002990](https://cloudbongos.com/builders#/task/1002990). That dependency is
**softer than it was filed.** The craft axis already exists: `discipline` is a
column on every task and `claim.js` already forks on it (task 1267), through the
file whose own documentation says *"to give a discipline its own experience
later, add an entry here."* The role-derived half could therefore ship today
through the seam built for exactly this.

When declaration lands, this contract **moves without being re-decided**: the
same sentence relocates from the claim directive into the composed Ideator pack,
and the per-person field stays put. Nothing here has to be undone.

## 3. Bypass: the idea's own caution, resolved against it

The idea proposed *"recommend bypass"* and then flagged the trade-off itself. The
flag wins, for three reasons in increasing order of force:

1. **The least technical role is the worst audience for removing confirmations.**
   Shipping bypass *to ideators specifically* concentrates the one change that
   removes review on the people least equipped to review.
2. **The permission prompt was never the gate.** [ADR 0016](0016-trust-boundary-server-enforced-permissions.md)
   is load-bearing: authority is `builders.rank`, checked server-side per request
   with no caching. The client prompt is a speed bump, not a boundary. The
   protected-path globs and pre-push hook are what actually bound a sub-Metic
   session — and an ideator is typically sub-Metic, so that narrowing is *already
   in force*. Bypass would add exposure without adding capability.
3. **A project cannot ship it anyway.** The harness deliberately refuses it:
   `permissions.defaultMode: "bypassPermissions"` set in a project's
   `.claude/settings.json` or `.claude/settings.local.json` **does not take
   effect — the session starts in Manual mode instead.** (`auto` is restricted
   the same way.) Only user-level, `--settings`, or managed settings can select
   it. So "ship bypass as an ideator default" is not merely unwise; it is
   unavailable through the only channel Bongos can commit into a project repo.
   Where bypass *is* the default today it was written into the machine's own user
   settings — which is exactly what the dev box does (task 1251, ADR 0104).

The ideator's problem is the noise, not the prompt. This ADR treats only the
noise. Any future bypass default for a craft must arrive with a *narrower*
capability set, not a broader one.

## 4. The chrome half: two real levers, and what we do not yet know

Recorded so the follow-on spike starts from evidence instead of repeating the
search. Both are documented harness features, not speculation.

**Lever A — shipped harness defaults.** The client already has a quiet mode:

- **`/focus`** renders "only your last prompt, a one-line tool-call summary with
  edit diffstats, and the final response" — very close to the owner's literal
  ask. The `viewMode` setting is documented as the key that presets it.
- **`alwaysThinkingEnabled: false`** stops thinking being generated at all
  (settable from any settings file), so there is nothing to render. Thinking is
  already collapsed to a stub by default; `showThinkingSummaries` controls that
  stub.
- Chrome trims confirmed committable: `showTurnDuration`, `spinnerTipsEnabled`,
  `prefersReducedMotion`, and a custom `statusLine` — which has the useful side
  effect of suppressing most footer keyboard hints.
- The built-in **`Concise` output style** ("leads with the result, skips preamble
  and narration") is prior art for the prose contract in §1, and preserves error
  reports and destructive-action confirmations the same way our contract does.

  *Not chosen for the role axis* because `outputStyle` is a whole-session
  setting: committing it would re-pitch every engineer session in the repo too,
  and an output style that omits `keep-coding-instructions` drops the built-in
  engineering instructions entirely. A role-scoped injected contract is the
  narrower instrument.

**Three things Lever A does not settle, which the spike must:**

1. `/focus` is **fullscreen-renderer only** (a research preview), so presetting
   it implies presetting `tui` as well.
2. Whether `viewMode` is settable from a **committed project** file is
   **unverified**. Nothing should be built on it until `/config --help` is
   checked against the pinned client version — a version-pinned observation beats
   a docs page for this.
3. Thinking suppression is **model-dependent**: on some models the toggle,
   `alwaysThinkingEnabled`, and `MAX_THINKING_TOKENS=0` have no effect at all.

**Lever B — an app-owned surface (vector (b) of the original idea).** Headless
mode emits no client chrome by construction: `claude -p --output-format
stream-json` yields a documented event stream (`system`/`init`, `assistant`,
`stream_event` carrying a `content_block_start` of type `tool_use`, and a
terminal `result` with final text, cost and `permission_denials`). The documented
streaming-UI pattern is precisely the owner's ask — show a working indicator on a
`tool_use` block, drop everything else, render on the result. This is the only
lever **fully in Bongos's control and model-independent**, and it is where the
desktop app would render the ideator's real interface.

**Bias for the spike:** prefer Lever B for the durable surface, and use Lever A
only for what it can do cheaply today. Lever A rests on a research-preview
renderer, an unverified setting, and per-model thinking behavior; Lever B rests
on a stable documented interface.

## 5. Consequences

- The default is `show`, so **no existing builder's experience changes.** The
  contract injects only when a builder opts in or claims an ideator task —
  consistent with the inject-only-when-non-default discipline the wandering and
  interaction knobs already follow.
- The field needs **no UI work from this task**: `fieldCatalog()` is generic, so
  `machinery` appears on `GET /me` and in `PATCH /me/interaction` validation
  automatically, and whatever settings UI [#1002514](https://cloudbongos.com/builders#/task/1002514)
  builds renders it for free.
- **Quiet must never hide a failure.** Both the injected contract and the
  `/ideate` section carry that exception explicitly, and a unit test asserts the
  contract string still contains it — this is the failure mode most likely to be
  reintroduced by a later "tidy the wording" edit.
- `tests/interaction_prefs.mjs` stopped asserting a bare field **count** (which
  every new field broke) and now asserts the field **set** against `FIELD_KEYS`.
- The chrome half stays visibly unfinished, which is the honest state. It is
  filed with its evidence, not silently dropped.
- **One correction to the record:** task [#1002514](https://cloudbongos.com/builders#/task/1002514)
  states that `contractFor()` "has ZERO consumers." That is **stale** — the
  Conductor hook relays the interaction contract as advisory 8 (task 2010,
  `.claude/hooks/conductor.js`). Its *no UI* half is still accurate.

## 6. Recorded objection: the grade panel's verdict, and this record's answer

The ship-time grader panel **failed** this task — one blocker, two majors — and the
task was confirmed over that verdict by the area owner rather than re-graded. The
disagreement is recorded here rather than left in a grade card, because it is a
disagreement about *scope*, and the next reader deserves both sides.

All three findings rest on the same move: the work was judged against the task
description's **literal asks**, which §1 and §3 above override deliberately and
with argument. That is a legitimate lens — a grader *should* ask "did you build
what was asked" — but the task's own text forecloses it: *"Deciding between (a),
(b) or both is the first task, not an implementation detail. Do not start by
trying to patch the terminal."*

**Finding 1 (blocker) — "no working-indicator / simplified rendering surface was
built; the literal 'show a working icon' ask is entirely unimplemented, deferred
to an unfiled follow-on spike."**

The first half is **true and intended**: §1 splits the ask and defers the chrome
half; §4 records the two candidate levers and the bias between them. The second
half is **factually wrong** — the spike is filed as
[#1003765](https://cloudbongos.com/builders#/task/1003765), the app-rendered
surface as [#1003766](https://cloudbongos.com/builders#/task/1003766) with a
dependency edge on the spike, and both are linked to `wa6-kernel-and-packs`. Both
were filed *before* the grade ran. "Unfiled" was the load-bearing word in a
blocker-severity finding, and it was not checked.

**Finding 2 (major) — "the ask to hide thinking/tool-call chrome is unaddressed at
the rendering layer; the ADR itself concedes this is unfinished."**

Accurate, and the concession is deliberate (§1, §4). Recorded as an open half with
its evidence and a named bias, not as a silent omission. Shipping a chrome
mechanism on this task would have meant building on `viewMode`'s unverified
committability and a research-preview renderer — §4's three open questions exist
precisely so that does not happen on a guess.

**Finding 3 (major) — "the description asked to recommend bypass (paired with
narrower blast radius); the shipped decision reverses this entirely rather than
delivering the paired mitigation the CAUTION section suggested."**

This is the substantive one, and the answer is that **the pairing was not
available**. §3.3: `permissions.defaultMode: "bypassPermissions"` set in a
project's `.claude/settings.json` or `.claude/settings.local.json` *does not take
effect* — the session starts in Manual. There is no channel by which a project
repo can ship a bypass default to be mitigated. And the "narrower blast radius"
the CAUTION asked to pair it with **already exists**, server-side and
independently of the prompt: rank checked per request ([ADR 0016](0016-trust-boundary-server-enforced-permissions.md)) plus the
sub-Metic protected-path globs. So there was no mitigation left to deliver and
nothing to attach it to. Rejecting was the honest reading of the CAUTION, not a
reversal of it.

**Why confirmed rather than re-graded.** `--regrade` is the documented way to
answer a grade with evidence, but it cannot carry this answer:
[#1003702](https://cloudbongos.com/builders#/task/1003702) records that
`ship.js --regrade` silently discards `--notes`, *"so an evidence-based grade
blocker can never be answered."* Re-running the panel would have re-litigated a
decision this record argues at length, with the rebuttal dropped on the floor. The
Archon override plus this section is the honest path while 1003702 is open.

**What would change this record's mind.** If the 1003765 spike finds `viewMode`
committable from a project file on the pinned client, Lever A becomes a real
shipped-default option and §4's bias should be revisited. Nothing in the grade
findings bears on that question.
