# 0184 — A ship must account for itself: `shipTask` requires a land proof or a declared no-artifact

- **Status:** Accepted
- **Date:** 2026-08-19
- **Tasks:** [#1002483](https://cloudbongos.com/builders#/task/1002483) (goal 1000024, build-pipeline integrity). Carried forward from blocker 1000047
- **Extends:** [ADR 0120](0120-pay-on-land-and-builder-owned-rebase-gate.md) — pay on land. This makes "land" checkable at the write.
- **Related:** ADR 0055 (server-mediated publish), 0137 (land → release → deploy are three gates), 0082 (generated-file conflict resolver); tasks 1313 / 1547 / 1002615 / 1002724 (the per-task land proof), [#1002478](https://cloudbongos.com/builders#/task/1002478) (the no-artifact dead end)

## Context

`db.shipTask` is the confirmed→shipped flip. Since ADR 0120 it is also **where the credit is booked**.
Its only precondition was:

```sql
UPDATE tasks SET status = 'shipped' … WHERE id = $1 AND status = 'confirmed'
```

Nothing about whether any code reached `main`.

The two **automated** paths each proved the land before calling it — the reconciler sweep and
reconcile-on-read both run `landProvenForTask` and refuse without a proof. The **manual** route,
`POST /tasks/:id/ship`, called `shipTask` with nothing. It is `requireBuilder` +
`gateTaskOwnership(allowSupervisor: true)`, so a task confirmed with no pushed code could be flipped
to shipped by its claim holder, or by **any Metic+ running `/merge-mode`**, and it would book its
`task.shipped` credit.

Blast radius was genuinely small — it takes two deliberate steps, the automated healers refuse, and
ADR 0120 made strands loud and gated the builder's next claims. That is exactly why it kept being
deferred. **And why it needed a decision rather than another deferral:** it had resurfaced as a
blocker repeatedly, and its tracking task ([#1000900](https://cloudbongos.com/builders#/task/1000900))
was closed in June on a rationale asserting task 1001547 had delivered a confirm-time gate. It had
not — blocker 1000047's own final update says so explicitly, and the code agreed with the blocker, not
with the closure note. So the hole was untracked for two months **because a record was wrong**, which
is the same failure this ADR's gate is about: a ledger entry nobody could check.

## Decision

### 1. The gate lives at the WRITE, not at the route

`shipTask` requires a `landAssurance` and is **fail-closed** — no assurance, no ship, thrown before
any pool use.

Gating only `POST /tasks/:id/ship` was the cheaper option and was rejected: it leaves the invariant
unenforced at the layer that actually moves the ledger, so the next caller added anywhere reopens it
silently. There are three call sites today; the point is that there is no way to add a fourth that
ships without accounting for it.

### 2. Two kinds, and the second one is why this doesn't make things worse

```
proof        the caller verified THIS task's own commit is on main
no_artifact  a deliberate DB-only ship, declared and recorded
```

A no-artifact ship is an **explicitly supported shape** — CLAUDE.md's "Direct DB writes are work too"
— and task 1002478 documents that it is already a dead end below Archon. A naive land-proof gate would
have made that strictly worse, which 1002483 warned about in as many words: *solve them together or
they will fight.*

Naming `no_artifact` as a **kind** is the resolution. A DB-only ship stops being an absence the gate
has to be talked out of and becomes a recorded answer: the builder declares it, says what was
delivered, and the ledger keeps both. That is a small step toward 1002478 rather than away from it.

### 3. Every assurance carries a reason, and the reason is audited

Both kinds require non-empty prose, capped at 500 characters, written to `audit_log` after the
transaction commits. The ledger should say **why** a ship was allowed, not merely that it happened —
which is precisely what was missing when this hole went unnoticed.

The audit write is post-commit and best-effort by construction (`insertAuditLog` uses the module pool,
not the transaction's client). An audit miss must never roll back a landed ship — the same posture
`src/bongos/middleware/audit.js` already takes.

### 4. The CLI declares its own empty ships

`scripts/gds/ship.js` POSTs `/ship` with an empty body after a `--db-only` / `--allow-empty` land. Left
alone, this gate would have refused exactly the flow CLAUDE.md calls supported — turning a correctness
fix into a regression for every builder shipping DB-only work. The deliberate-empty land sites now mark
themselves, and the CLI sends the declaration.

## Consequences

- **A confirmed-but-unpushed task can no longer be manually shipped or paid.** The refusal names both
  remedies: push the branch and let the reconciler land it, or declare the no-artifact ship.
- **The hall's task page ships through the same route** and will now receive a `409
  ship_land_not_proven` for an unprovable task. That is the correct behaviour — the UI should not be
  able to phantom-ship either — but its error rendering was not reviewed here and may show the refusal
  poorly. Worth a look.
- **`shipTask`'s signature changed.** Three production call sites and four test files were updated. Any
  out-of-repo caller breaks loudly rather than shipping blind, which is the intended direction.
- **A STALE `ship.js` against an updated server cannot complete a DB-only ship.** The CLI is what sends
  the `no_artifact` declaration; an older checkout POSTs an empty body and collects
  `409 ship_land_not_proven` on a task that has no commit to prove. The refusal names exactly what to
  send, but the old CLI will not send it, so the remedy is to update the checkout (or re-send by hand).
  Bounded rather than open-ended — the CLI travels with the core, so on the monolith and on a consumer
  instance the two move together; the skew window is a builder running a stale clone or dev box. Worth
  knowing before the first report, because the symptom ("I cannot ship my DB-only task") does not
  obviously point at a version skew. **Note this affects ONLY no-artifact ships:** a normal ship is
  proven server-side from git and needs nothing from the CLI.
- **This does not gate CONFIRM.** A codeless confirm is still accepted; what it can no longer do is
  reach `shipped` and book a credit. Gating confirm is a separate question — confirm means "verified",
  not "landed", and conflating them would break the legitimate confirm-then-land sequence.
- **Rejected — option (c), record the residual as tolerable.** Defensible on blast radius, and it was
  genuinely close. It lost because the residual had already survived one incorrect closure and several
  blocker filings; a decision to accept it would have been the fourth record asserting this was
  handled, with nothing checkable behind it.
