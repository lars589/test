# ADR 0355 — A soft limit is a rule with a reason, and nobody enforces it

- **Status:** accepted
- **Date:** 2026-09-30
- **Task:** [task 1004416](https://cloudbongos.com/builders#/task/1004416) (BV2.PS02, goal 1000121)
- **Interacts with:** [ADR 0239](0239-a-recommendation-is-a-table-that-carries-its-own-reason.md) (a recommendation is a table that carries its own reason), the spec [`docs/specs/<redacted>.md`](../specs/<redacted>.md) decision D6

## Context

The new startup flow asks seven "planet physics" questions before any technical setup: state, geography, ages, entity, builders, rewards and framing. The answers carry legal weight. An individual has no shares to give, cash payouts to EU builders are not available yet, and 13 to 15 year olds join non-monetary tracks only. Spec decision D6 says the flow should grey or hide options that clearly do not apply, each with a line saying why. It also says nothing enforces these limits yet, and no screen may claim otherwise.

The flow also needs a stop screen: a project whose description is something Cloud Bongos will not help build is stopped before anything is created. The real classifier is out of scope.

## Decision

**D1: The answers are more `detail` keys.** They ride the provisioning `detail` jsonb under the same contract as `team_shape`: no defaults, an unknown value refused loudly at the route, and `null` to un-answer. Two new kinds of question join the closed single answer. A `many` question takes a list of members, stored de-duplicated in the vocabulary's order. A `count` question takes a whole number in a range. `PROJECT_DETAIL_QUESTIONS` is the whole contract. `PROJECT_DETAIL_VOCAB` stays the closed answer lists, so every existing reader and the `options` reply keep their shape. The country is a closed ISO 3166-1 list rather than a two-letter pattern, so a typo like `ZZ` is refused instead of stored.

**D2: Answers must agree only within one request.** The main kind of work must be one of the existing kinds, and the region must be inside the country, when both arrive in the same body. A merge patch may change one half now and the other later, and refusing a write because it disagrees with a stored answer would make the order of edits matter.

**D3: The soft limits are one declarative table, and every resolution says `enforced: false`.** Each rule has a `when` (data, never a function), the options it names, an effect (`hide`, `grey` or `note`) and an owner-facing reason. Because conditions are data, a test can check every rule against the vocabulary, and a browser could evaluate the same table. An unanswered key never matches, so no rule fires on an answer nobody gave. `note` exists because some options apply only in part: cash is still available to builders outside the EU, so greying it would be wrong. The resolution rides every owner read of a project and the `PATCH …/detail` reply. A test fails any reason worded as if the limit were enforced.

**D4: Screening is a seam with a deliberately small rule set.** `screenProject(texts, rules)` takes the project's own words and returns `{ stop }`. The real classifier replaces the rules or the function body, and no caller changes. A keyword rule that stops an honest project is worse than one that misses a bad one, so each rule names something no legitimate project is built to be. An `unless` lets a defensive project through (a ransomware detector, a phishing-awareness course). A stop is a 422 `screened_out` with the canvas's own sentence. Nothing in the reply names the rule, because a gate that says which rule it tripped teaches a caller how to reword around it. Whoever answers "contact us" reads the description itself.

**D5: The screen runs on the edit route too.** The stop happens on create before any row or intent exists. `PATCH …/detail` screens a new description as well. Otherwise a project could be created with no description and given the stopped one straight afterwards.

## Consequences

- No migration: `detail` is a dumb jsonb store, so new questions cost none.
- The age tiers and payout geography are stored facts, not policy. Server-side enforcement is a later goal, and it will read these keys.
- The screen's false positives are the risk to watch. Until the classifier exists, a rule should be added only when it cannot plausibly describe an honest project.
