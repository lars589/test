# ADR 0309 — Module enablement is a database row, above the committed pack and below env

**Status:** accepted · **Date:** 2026-09-18 · **Task:** [task 1002857](https://cloudbongos.com/builders#/task/1002857) (goal 1000091 — BONGOS-V2)

**Related:** [ADR 0107](0107-module-upstreaming-contribution-to-core-catalog.md) §9 (the Modules tab that ships the toggle) · [ADR 0016](<redacted>.md) (why an HTTP handler may not write to `main`) · [ADR 0083](<redacted>.md) (the module contract this resolves)

## Context

The hall's Modules-tab toggle wrote `config/modules.json` and reloaded the
in-process cache. The effect was immediate, so the toggle looked like it worked.

`config/modules.json` is the **committed instance pack**, and the pull-deploy runs
`git reset --hard origin/main`. An operator's toggle therefore reverted on the
next deploy unless somebody remembered to commit it — and reverted *silently*, so
a module an operator had deliberately turned off could come back on hours later
with nothing to connect the two events. That is worse than a toggle that refuses:
a control that reports success and then quietly undoes itself teaches people not
to trust the panel.

The route's own header recorded the trade-off and named the follow-up; this is it.

## The decision

**Enablement lives in `module_enablement_overrides` (migration `core_248`), read
as one precedence layer inside `resolveModules`.** The resolution order becomes:

    neutral pack  →  instance pack  →  DB override  →  env  →  registry default

Three things in that line are the actual decision.

### 1. Above the committed pack

Outranking the file *is* the point. The pack is what `git reset --hard` restores
on every deploy, so an override that sat below it would be erased by the very
event it exists to survive.

### 2. Below env

`<PREFIX>_MODULE_<KEY>` stays the highest layer, because it is the **incident
knob**. An operator must be able to force a module off on one box without a
working database. If the database outranked env, the failure mode would be "the
module I am trying to kill is being switched back on by a row I cannot reach to
delete" — which is the kind of thing that turns an incident into an outage.

### 3. Not an auto-commit

The other way to make the toggle durable is for the handler to commit and push
`config/modules.json` to `main`. That was rejected, and remains rejected: it would
make an HTTP request a writer on `main`, bypassing the ship/grade/deploy pipeline
and the [ADR 0016](<redacted>.md) trust boundary. Durability
belongs in the database, where this instance's live state already lives.

## The two design points the task left open

### The scope key is the instance pack path

One deployed checkout can run **two instances against one database**,
differentiated only by `BONGOS_MODULES_FILE` / `BONGOS_BRANDING_FILE`: the default
instance on `config/modules.json`, and a vanilla sibling on
`config/modules.neutral.json`. A single global row per module would let one
sibling's toggle flip the other's module.

The scope key is therefore the **resolved instance pack path, relative to the
instance root, posix-separated** — chosen because it is not an invented
identifier: it is precisely the axis those two processes already differ on, so it
cannot say "same instance" where `loadModules` says "different pack". Normalising
it keeps the key stable across a moved checkout, an absolute-vs-relative env
value, and Windows vs Linux. `resolveInstancePackPath()` was extracted so the key
and the read share one ladder rather than two copies that drift.

### The DB is read into a snapshot, never inline

`loadModules()` is synchronous, behind a lazy cached singleton every caller
reaches through `modules()`. Making it async would ripple into effectively every
consumer of a module flag.

So the database is never read on the resolution path. `src/bongos/module-overrides.js`
reads the overrides **once per refresh** and hands `src/modules.js` a plain
snapshot, which the pure resolver treats as one more injected layer. There are
exactly two refresh points, because there are exactly two moments the answer can
change: **server boot**, and **a write through the route**.

The boot read is awaited *before* `buildPlatformApp()`, because routes mount from
the resolved module set — an override that landed after construction would not
change what is mounted until the next restart, which is the same complaint in a
new costume.

## Consequences

**An unreachable database changes nothing.** Every read here swallows its error
and leaves the snapshot alone, and an empty snapshot means *no opinion*, not
*everything off*. An instance that cannot reach its database resolves modules
exactly as it did before the table existed — on the packs and env alone. This is
what keeps the awaited boot read a best-effort improvement rather than a boot-time
dependency: it buys a better answer when the database is there, and never
withholds the server when it is not.

**Writes are not forgiving, deliberately.** `setOverride` throws. A toggle that
reported success while persisting nothing would be the original bug with better
manners.

**The winning layer is now visible.** `GET /modules` reports `enabled_source` per
module (`neutral` / `instance` / `override` / `env` / `spend-refusal` / `default`),
the override's author and timestamp, and the process's scope key. Without it,
"why is this module on?" costs a shell and a grep — and with two precedence layers
added since the tab was built, the question got harder, not easier. `sources` is
attached non-enumerably so no existing consumer of the boolean map sees a new key.

**One regression, caught in review and worth recording.** Wrapping the boot in an
`async` IIFE turned `buildPlatformApp()`'s fatal throw — an enabled module
consuming a port nothing provides — into a promise rejection, which the
unhandled-rejection backstop deliberately *survives*. The server came up
half-wired and said nothing, which is exactly what that throw exists to prevent.
The boot now rethrows from `process.nextTick`, restoring the uncaught exception
Node already prints raw and exits non-zero on. Pinned by
`tests/platform_boot.mjs`'s task 1003820 case.
