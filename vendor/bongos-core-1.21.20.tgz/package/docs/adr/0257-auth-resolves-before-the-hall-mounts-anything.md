# ADR 0257 — Auth resolves before the hall mounts anything, and a widget's boot read may never navigate

- **Status:** accepted
- **Date:** 2026-09-06
- **Task:** [task 1003673](https://cloudbongos.com/builders#/task/1003673) (BONGOS-V1, goal 1000063 — *The front door*)
- **Deciders:** Claude, under the Archon's standing scope
- **Related:** [ADR 0050](0050-device-flow-admission-invite-gated-by-default.md) (admission is invite-gated by default — the posture this defect made unusable) · [ADR 0194](0194-joinability-one-door-decision.md) + [ADR 0247](0247-the-join-door-is-one-composed-answer-and-dark-matter-has-no-live-verdict-yet.md) (the door the landing form renders) · [ADR 0062 §4](0062-medusa-instance-model-decoupling.md) (the hall-widget registry)

---

## Context

An owner stood up an instance, invited a colleague, and watched them sign in with
GitHub. They got *"Sign-in failed — this account is not approved yet. New here?
Request access first"*, whose one button goes to `/builders`. The owner then went
looking for the approval queue and found nothing to approve: `GET /access-requests`
answered `{"requests": []}`, and the hall hides the Access-requests panel when the
queue is empty. Both halves are working as designed — **signing in does not file a
request**; only the landing page's *Request access* form does.

The landing page could not be reached. A signed-out visitor to `/builders` was
bounced to GitHub, refused as a first-timer, and pointed back at `/builders` to be
bounced again. A closed loop, and the form sat inside it. Every invite-only
instance — the default posture since ADR 0050 — therefore had **no way to admit its
first builder**, and the symptom pointed at the approval UI rather than at the door.

Reproduced against `main` (not only against an old pin) by serving
`modules/hall-ui/public` statically with every authenticated route answering 401:

```
GET /api/bongos/me            401   (soft — builders.js would renderLanding())
GET /api/bongos/goals         401   -> window.location.assign(/auth/web/start)
GET /api/bongos/auth/web/start      the dead end
```

`builders.js` was already careful: `/me` is read with `softAuth`, and a 401 there
renders the landing rather than bouncing. But its `DOMContentLoaded` handler called
`mountHallWidgets()` **first**, synchronously. `goals.js`'s `mount()` reads `/goals`
through a `getJSON` with no `softAuth`, and that helper answers 401 by *navigating*.
The widget's read therefore raced `renderLanding()` — and won.

## Decision

**1. The front door settles which page this is before anything else runs.**
`builders.js` boots through `boot()`: read `/me` (soft), and only then choose.
Signed out → `renderLanding()` and stop; nothing else mounts, nothing else fetches.
Signed in → mount widgets, wire events, render the hall. The resolved `/me` payload
is handed to `loadAll()` rather than re-fetched, so the page still asks once.

Widgets are member surfaces — `renderLanding()` already hid every one of them after
the fact — so not mounting them for a signed-out visitor removes a whole class of
races rather than the one instance of it that was found.

**2. A widget's own boot read may never navigate.** `goals.js`'s mount-time read is
`softAuth`, and answers "no session" by rendering nothing. A 401 during page boot is
not an error and not an instruction to go and sign in; it is the answer *this visitor
has no session*, which the landing already handles. Only a user action may send
someone to the sign-in flow.

## Consequences

- An invite-only instance can admit its first builder: the landing renders, the
  request form is reachable, the queue fills, and the owner has something to approve.
- The "Sign-in failed" page's CTA now lands somewhere useful — the loop is closed at
  both ends.
- `tests/hall_landing_boot.mjs` executes the real `builders.js` in a DOM stub and
  asserts the invariant three ways: a signed-out boot never navigates, renders the
  landing, and mounts no widgets; it asks for `/me` and nothing else; and a signed-in
  boot still mounts the hall on a single `/me`. The guard was confirmed to FAIL
  against the pre-fix file — a regression test that passes both ways guards nothing.
- A widget added later can still reintroduce the class if it hard-redirects at mount
  AND something mounts it while signed out. The boot order is what makes that
  unreachable; the `softAuth` rule is the belt beside it.

## Rejected

- **Patch `goals.js` alone.** It was the widget that happened to fire first. Any
  mount-time authenticated read can steal the page, so the fix belongs at the boot
  order, not at whichever widget was caught doing it.
- **Make the 401 → redirect helper soft everywhere.** A signed-in builder whose
  session expires mid-visit *should* be sent to sign in. The distinction that matters
  is boot versus user action, not the status code.
- **Open enrollment** (`OPEN_XENOS_ENROLLMENT`) as the cure. That removes the gate
  instead of repairing the door, and ADR 0050 chose the gate deliberately.
