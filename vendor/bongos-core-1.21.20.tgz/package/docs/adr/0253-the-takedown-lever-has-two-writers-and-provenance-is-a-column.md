# ADR 0253 — The takedown lever has two writers, and provenance has to be a column

- **Status:** accepted
- **Date:** 2026-09-06
- **Task:** [task 1002327](https://cloudbongos.com/builders#/task/1002327) (BONGOS-V1, goal 1000046 — *Project creation*, criterion `proj-visibility-states` / C1), BV1.R08 — the build
- **Deciders:** Claude, building R08 against ADR 0252's design
- **Amends:** [ADR 0252](0252-the-self-hosted-visibility-report-is-a-pull-and-auto-appear-buys-a-retraction-lever.md) §4 and §5 — three premises that did not survive contact with the tree. The decisions ADR 0252 took are unchanged; what changes is what has to be built to make them true.
- **Related:** [ADR 0246](0246-catalog-membership-is-a-projection-not-a-federation-side-effect.md) (the control-plane projection, and the writer §5 missed) · [ADR 0247](0247-the-join-door-is-one-composed-answer-and-dark-matter-has-no-live-verdict-yet.md) D4 (the fail-closed trap, found live one column over) · [ADR 0182](0182-project-visibility-two-axes.md) D5 (dark matter) · [ADR 0083](0083-modular-architecture-strangler-build-plan.md) (the one-way import rule that forces §2's shape) · [ADR 0209](0209-one-budget-for-the-account-existence-oracle.md) (the limiter precedent) · [ADR 0199](0199-restart-an-unreachable-active-project.md) / [ADR 0226](0226-one-stale-timer-reporting-degrades-enforcement-refuses.md) (reporting degrades; enforcement refuses)

---

## 1. Why this ADR exists

ADR 0252 is a design ADR written from a spike. Building it surfaced three things about the
live tree that the design's own text gets wrong. None of them changes a decision — the pull
is still a pull, auto-appear still ships, `hidden` is still sticky — but each changes what
has to be **built**, and two of them are the difference between a working retraction lever
and a decorative one.

They are recorded here rather than by editing ADR 0252, because ADR 0252 is the record of a
decision that was actually taken on those terms. This is the record of what the terms turned
out to be.

## 2. `hidden` is sticky against TWO writers, and ADR 0252 names the wrong one

**ADR 0252 §5 says:** *"`platform_identity_projects.status` is `('active','hidden')` and the
public feed requires `active`. **No route writes it.** The only `status` write in the module
is on `sso_clients`."* From there it defends the takedown against the visibility pull, and
calls that "the single most important line in this ADR."

**The tree says otherwise.** `project-catalog.js:upsertOwnedProject` writes `status =
EXCLUDED.status` on every conflict, and `retireOwnedProject` writes `status = 'hidden'`
outright. The value comes from `catalog-bridge.js:catalogStatusForInstance`, which returns
`'active'` for any instance that is not `tearing_down`/`torn_down` — and ADR 0246's whole
point is that this projection is **re-taken at every write that can change its inputs**
(create, the detail answers, the settings door, a re-pointed address, plus the backfill
poller).

So the live failure is not the one ADR 0252 guards. It is:

1. A curator hides a project.
2. Its owner saves any setting at all.
3. The bridge re-takes the projection, assigns `status = 'active'`, and the project is back
   on the public map.

**Decision.** The stickiness is a property of the ROW, not of one writer's manners.
`status_pinned` is set by the curated `PATCH /projects/:id/status` and honoured by
`upsertOwnedProject`; the pull, separately, never writes `status` at all (asserted against
the statement text, so a later `status` write in that file reds a test rather than silently
undoing every takedown).

**`retireOwnedProject` deliberately does NOT honour the pin.** It is a safety retraction for
an origin the project no longer answers on — the [ADR 0181](0181-teardown-state-gate-and-address-retention.md)
§2 stale-orb leak — and a curator's `'active'` pin must not be able to keep a dead address
drawing an orb. This is ADR 0252's own principle applied consistently: **narrowing is free;
widening is what costs.** Every guard in R08 refuses in the direction of less exposure.

## 3. Provenance has to be a stored column, because the discriminator does not exist

**ADR 0252 §4 tabulates** control-plane rows against self-hosted ones as though the catalog
knew which was which. It does not. `platform_identity_projects` has no `hosting_shape` and
no other column that distinguishes them; `hosting_shape` lives on `provisioning_instances`,
in a module `platform-identity` may not import (ADR 0083's one-way rule). Nor can it be
inferred: `owner_github_id` is set by the bridge, by `registerClient` **and** left null by
hand-seeded rows, so it separates nothing.

**Decision.** `visibility_source` records which writer owns the row's door
(`'control-plane'` | `'pull'` | NULL for unclaimed), stamped by whichever writer touches it.
The pull's predicate is then a local column read — `visibility_source IS DISTINCT FROM
'control-plane'` — re-asserted in the UPDATE's own `WHERE`, not merely checked before it, so
a bridge projection landing mid-sweep cannot lose the race. "The two never write the same
row" becomes an invariant the SQL enforces instead of a convention someone has to remember,
and no new cross-module seam is opened to ask a question on every sweep.

The rejected alternative — a `provisioning.instanceShape` port — is more general and worse:
it puts a cross-module read in a background loop to answer a question that never changes for
a given row, and it makes the catalog learn another module's vocabulary, which is exactly the
ceiling ADR 0246 set.

## 4. The tri-state cannot live in `visibility`, and the fail-closed default needs a backfill

`visibility` is `NOT NULL DEFAULT 'public'` (migration 011), so it physically cannot express
"never asked". The recency stamp ADR 0252 §4 asks for is therefore also the null-carrier:
`visibility_reported_at IS NULL` **is** the never-read state, and it is the only condition
under which ADR 0182 D5's "unreported ⇒ dark matter" applies. A failed read writes nothing at
all — which is what keeps the stamp meaning *last successful read* and makes "keep the last
known state" fall out rather than being implemented.

**And the fail-closed predicate needed a backfill, for exactly the reason ADR 0247 D4
gives.** Shipping `AND (visibility_source = 'control-plane' OR visibility_reported_at IS NOT
NULL)` without one would have emptied the public map on deploy, because both columns are new
and therefore NULL on every row — the same shape ADR 0247 D4 found live on this very table
(`description: null` on every row, so a fail-closed join gate wired that day would have
refused every join on the platform at once). Migration 020 stamps every pre-existing row
`'control-plane'`, which is safe because it is **true**: every row that exists today got its
door from the bridge or from an Archon, and no instance has ever been asked.

## 5. Two smaller corrections, recorded so they are not rediscovered

- **The manifest key is `brand`, not `branding`.** ADR 0252 §2 and task 1002327's body both
  write `branding.project.visibility`; `buildInstanceManifest` projects the pack under
  `brand`. Reading only the documented spelling would have made every pull a silent
  no-verdict — a failure indistinguishable from "no self-hosted project ever reports". The
  reader accepts both spellings and the test pins both.
- **The pull is a POLLER, not a passenger on the feed's fan-out.** The obvious cheap move —
  add a fifth fetch beside the four `project-stats.js` already makes — cannot work, and the
  reason is invisible until you try it: **the feed excludes exactly the rows that need
  pulling.** A pullable project that has never answered is dark matter, so it is not in
  `listPublicProjects`, so it is never enriched, so it never answers. A read-path pull can
  only refresh projects that are *already visible*, which is backwards; it cannot bootstrap.
  Stealth rows are excluded from enrichment too (deliberately — asking a stealth project's
  API would tell it it was being enumerated), so one could never be seen coming back. And it
  would make a database write a side effect of an anonymous, CORS-open read.

## 6. Consequences

- **The retraction lever actually holds.** Not because the pull is polite, but because the
  row carries a latch every automatic writer honours.
- **`GET /projects/featured` is metered** (limiter #5, 120/min per IP, ADR 0209's shape: one
  exported instance, never a factory). It guards the platform's most expensive anonymous
  read — a cold call fans out to as many as 500 third-party origins — so the ceiling protects
  other people's servers as much as ours.
- **A hand-seeded catalog row created after this lands is dark until it answers.** That is
  ADR 0252 §2's design working as specified, but it is a behaviour change for the Archon
  `POST /projects` path and worth knowing before someone types a row in and wonders where it
  went.
- **ADR 0247 D4's `description: null` problem is NOT fixed here.** ADR 0247 names R08 as the
  report that fills the catalog, but ADR 0252 §7 deliberately refuses to let the pull carry
  name, tagline or description — so every catalog row still has `description: null` and the
  publish gate is still unmet for self-hosted rows. The pull moves the door; it does not
  publish the project. That gap is real and stays open.

## 7. Rejected

- **Editing ADR 0252 instead of amending it.** It records a decision taken on stated terms;
  rewriting the terms afterwards loses what was actually decided and why.
- **Defending `hidden` against the pull only**, as ADR 0252 §5.2 literally specifies. It
  would satisfy the ADR's text and leave the lever decorative against the writer that fires.
- **Inferring self-hosted from `owner_github_id`, or from the absence of a credentialed
  `sso_clients` row.** Both are proxies that are wrong today for real rows.
- **A `provisioning.instanceShape` port.** §3.
- **Backfilling `visibility_reported_at = now()` instead of stamping the source.** It would
  assert a reading that never happened, and it would make every existing row look freshly
  confirmed by an instance that was never contacted.
