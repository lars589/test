# 0273 — The hall nav can gate on a permission, and the Board Room leaves Government

- **Status:** Accepted
- **Date:** 2026-09-09
- **Tasks:** [#1003744](https://cloudbongos.com/builders#/task/1003744) (this record and the work).
- **Goal:** [#1000111](https://cloudbongos.com/builders#/goal/1000111) — Working area 7, Government; criterion `wa7-government`.
- **Decided by:** the owner (Masterqua / `IAMMASTERQUA`, Archon, member of area 7), 2026-09-09 — the placement question in §3.
- **Builds on:** [ADR 0266](0266-the-board-room-is-its-own-surface-reachable-by-whoever-may-vote.md) (the carve that surfaced this gap), [ADR 0175](0175-the-board-room-full-idea-ratification.md) §6 (who governs is configuration), [ADR 0151](0151-governance-permissions-as-atom-ranks-as-roles.md) (permissions as the atom), [ADR 0157](0157-archon-is-rank-and-identity-only.md) (`page.view.government` floors at metic), [ADR 0016](0016-trust-boundary-server-enforced-permissions.md) (the server enforces; the client decorates).

## 1. Context — a sidebar that could only speak rank

`modules/hall-ui/public/shell.js` `gateAllows()` resolved six gate keys, and
every one of them was a **rank**: `always`, `signed`, `member`, `work`,
`government` (a metic-or-archon alias), `archon`. There was no way to ask *does
this viewer hold permission X*.

That was fine while every gated page fronted a rank floor. ADR 0266 ended it.
The Board Room's page gate is the **atom** `board.vote.cast`
(`auth.js requireBoardVotePage`), which floors at **xenos** on purpose —
`modules/government/board.js` records the floor is low *so that widening the
board works*. Its nav item could only borrow the nearest rank the shell could
express, so it carried `gate: 'government'` (metic+), and ADR 0266's own carve
left a comment saying as much and filing the gap rather than guessing at it.

The cost was latent, not theoretical. Today's constitution seats `rank:archon`,
so no sub-Metic member exists. The moment an instance widens membership below
Metic — the exact act ADR 0175 §6 exists to make a configuration change — those
members can reach the room by URL and by the `board_votes` need's deep link, and
have **no sidebar entry at all**.

## 2. Decision — a `perm:<atom>` gate, fed by a server-resolved allowlist

A nav item may now declare `gate: 'perm:<atom>'`. Three pieces:

- **`/me` resolves the answer.** `NAV_PERMISSION_ATOMS` in
  [`src/bongos/routes/me.js`](../../src/bongos/routes/me.js) is a frozen list of
  the atoms a nav item is allowed to gate on; the route resolves each through the
  `government` port's `resolveBuilderPermissions` and returns
  `permissions: { '<atom>': boolean }`.
- **The shell reads it, and never re-derives it.** `applyAccess` stores the map
  on `access`; `gateAllows('perm:X')` answers `permissions[X] === true`.
- **The item quotes its page.** The Board Room item declares
  `perm:board.vote.cast` — the same key `requireBoardVotePage` checks — so the
  nav gate and the page gate cannot drift.

Four rules hold it in place.

- **It stays cosmetic (ADR 0016).** This decides who is *offered* a link. The
  page gate and each data route's `requirePermission` are the wall, and run
  regardless.
- **An allowlist, not the whole set.** The builder's full resolved permission set
  is the shape of the instance's governance, and a cosmetic sidebar has no
  business shipping that on every page load. Adding an atom to
  `NAV_PERMISSION_ATOMS` is the deliberate act that lets a nav item gate on it.
- **Unreadable is not visible.** `permissions` is `null` when authority could not
  be established (government off, port missing, resolver threw). That is *cannot
  say*, not *holds nothing*, and it hides the link — `gateAllows()`'s
  `default: false` and the social mode's OFF-is-the-fallback rule, applied.
- **The client does not re-derive.** The shell reads the resolved boolean, never
  rank plus a guess — the social-mode precedent (task 1003178): a page that
  decided for itself could disagree with the rest of the hall.

## 3. The placement call — the Board Room joins the project group

Gating the item honestly while leaving it in the **Government** group would have
put a wider item under a narrower head: a newcomer board member would see a
sidebar group labelled "Government" holding exactly one link — more authority
than they hold, and an IA claim nobody made. ADR 0266 §Scope reserved that
question, and task 1003744 was written to surface it rather than settle it.

The owner's answer (2026-09-09) was to **move the item**, not widen the group:
the Board Room now sits in the unlabeled project group, after Tasks, beside
Home / Roadmap / Goals. A sitting is work the project does, not a monitoring
surface. The Government group's audience, head and floor are unchanged, and it
is rank surface throughout again.

Two options were declined: widening the Government head so it shows whenever any
item inside is visible (the one-item "Government" group above), and giving the
Board Room its own single-item group.

## 4. Consequences

- The hall's gate vocabulary is no longer rank-only. A page gated on an atom can
  have an honest nav entry; the next such page adds its atom to the allowlist and
  declares it, with no second pattern to invent.
- `tests/hall_nav.mjs` gained the missing half of its group invariant. It checked
  only that a head is never *wider* than its items; an item wider than its own
  **head** — an orphan link under a hidden label, which is precisely the
  arrangement declined in §3 — had no check. It does now, and `GATE_WIDTH` learned
  `government`, which had been `undefined` and made every comparison against that
  group pass vacuously.
- The harness `/me` fixture carries `permissions`. Without it the item would be
  permanently invisible in `scripts/hall-preview`, which is the
  "a page that only ever renders its empty state cannot be redesigned by looking"
  trap `modules/hall-ui/CLAUDE.md` names.
- **Not done here:** no other nav item was re-gated. `people` still reads
  `government` for `project.curate`, and moving it onto its atom is a separate,
  reviewable change.
