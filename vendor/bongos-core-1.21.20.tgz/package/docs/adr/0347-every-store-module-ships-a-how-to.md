# ADR 0347 — Every store module ships a how-to: a file in the module, a publish gate, and a Docs score shown on its own

- **Status:** accepted
- **Date:** 2026-09-29
- **Task:** [task 1004364](https://cloudbongos.com/builders#/task/1004364) (goal 1000091 — working area 5, Module distribution & economy)
- **Deciders:** Will (owner of working area 5) decided the how-to is a file, the "gate plus score" grader, that the Docs score is shown separately rather than averaged in, and the grader's model and cost ceiling; Claude wrote the record.
- **Related:** [ADR 0343](0343-a-module-score-is-a-security-gate-then-an-average-of-visible-parts.md) (the score; D1's parts table is amended here) · [ADR 0338](0338-modules-travel-through-a-bongos-hosted-store.md) (the store, the tarball and its hashes) · [ADR 0098](0098-public-mirror-publish-manifest.md) (`isPublishable()`) · [`docs/modules-contract.md`](../modules-contract.md) §6 (publish) and §7 (install) · follow-on tasks 1004365 (the file and the publish check), 1004366 (the store page and PDF), 1004367 (the AI grader)

## Context

A buyer browsing the store (ADR 0338) sees a module's name, category and score (ADR 0343),
but nothing tells them how to use what they are getting. Today a module carries a
`CLAUDE.md` written for AI sessions working *inside* the module, not for the person who
installs it. There is no rule that an author explains their module at all.

The owner wants every store module to come with a how-to that works for a person or for any
AI, that the buyer can read before acquiring, and that is judged so good explanations are
visible.

## Decision

### D1 — The how-to is a file: `HOWTO.md` at the module root (owner)

The how-to is `modules/<key>/HOWTO.md`, plain Markdown. It is a **file in the module**, not a
hosted page, because:

- it travels inside the tarball, so it is covered by the manifest hashes and **cannot change
  after a version is published** — the how-to a buyer read is the one they get;
- any AI or person can read and write Markdown, so the module does not depend on one vendor;
- it goes wherever the module goes, including instances that are offline.

The packaging allowlist (`isPublishable()`, ADR 0098) must include `HOWTO.md`; task 1004365
checks it is in the tarball.

### D2 — Five required sections, kept short

`HOWTO.md` must contain these five level-2 headings, matched case-insensitively and in any
order, each with some text under it:

| Heading | What goes in it |
|---|---|
| `## What it does` | A few sentences: what the module adds and who it is for. |
| `## Install and enable` | How to get it (`bongos module install <key>`) and switch it on (hall Modules tab). |
| `## How to use it` | Its commands, routes and hall surfaces, with **one worked example**. |
| `## Configuration` | Env vars and settings, with defaults. "None." is a valid answer. |
| `## Limits and known issues` | What it doesn't do, and anything known to go wrong. "None known." is a valid answer. |

Other headings and sections are welcome. The list is short on purpose, so an author can meet
it in minutes; quality above that bar is what the Docs score (D5) rewards.

### D3 — An optional Claude artifact link, shown as an extra and never graded (owner)

An author may set `howto.artifactUrl` in `module.json` to a Claude artifact (an `https://`
link on `claude.ai`). The store page shows it as **"Also available as a Claude page"**, next
to the file, never instead of it.

It is **never graded and never required**, because a hosted page can change after publish;
only the file is frozen with the version. The store validates the field's shape only.

### D4 — The gate: no how-to, no publish

`bongos module publish` **refuses** a version when `HOWTO.md` is missing, or when any required
section (D2) is missing or empty. The refusal names the file or each failing section, e.g.
`HOWTO.md: section "Configuration" is empty`.

- It is a free, deterministic check: it reads headings, it does not judge writing.
- The CLI runs it before uploading, and the store runs it again on upload (as it already
  re-checks hashes and the denylist, `modules-contract.md` §6), so a hand-built upload can't
  skip it.
- It applies **only to store versions**. Core-bundled modules and `bongos module submit`
  (proposing a module into core, ADR 0135) are not gated by it.
- Versions published before the gate existed are not delisted or re-checked; the gate applies
  from the next version.

### D5 — The Docs part: scored, visible, and **not** in the overall score (owner)

This amends ADR 0343 D1's parts table with one row:

| Part | What it measures | Available |
|---|---|---|
| **Docs** | clarity and completeness of the version's `HOWTO.md`, scored by an AI grader (task 1004367) | day one |

- **Scored 0–100 per version**, like every other part, because each version ships its own
  how-to.
- **Shown separately, not averaged in (owner).** Docs is displayed with the other parts
  (ADR 0343 D4), labelled as not counting toward the overall score. It does **not** join the
  plain average in ADR 0343 D3, and so does not move the floor, ranking or cap
  (tasks 1003807–1003809). The overall score stays a measure of how the module *works*; Docs
  tells the buyer how well it is *explained*. A superseding ADR can fold it in later if the
  owner wants.
- **The grader gives a short reason** with the number (a sentence on what is clear and what is
  missing, such as "no worked example"), so an author knows what to fix.
- **"No score yet" is never a zero** (ADR 0343 D5). While grading is under way the part shows
  **"Docs: pending"**; if grading could not run, **"Docs: not scored"**. A version is listed
  as soon as it passes the gate; it never waits for the grader.
- **Price is never an input** (ADR 0343 D6). Free and paid modules are graded by the same
  call, and the Metic+ override applies to Docs like any part, with an audit entry.

### D6 — Cost: one Sonnet 5 call per version, capped at 5¢ (owner)

- **One grader call per published version**, made by the store after the version is accepted.
  A failed call is retried once; if both fail, the part stays "not scored" until Metic+
  re-runs it. Nothing re-grades a version automatically after that.
- **Model: Claude Sonnet 5** (`claude-sonnet-5`), the rung the task grader already uses
  (`modules/grading/grader-rubric.json`). Changing the rung needs the area owner's nod.
- **Ceiling: 5¢ per call** at list price (Sonnet 5 is $2 in / $10 out per million tokens,
  `src/bongos/llm-pricing.js`). The grader caps its output and its input to fit: a how-to too
  long to read in full is cut to fit, and the reason says the score covers only the part read.
  A typical how-to costs about 1–2¢.
- The platform pays, and each call is recorded in the cost log like any other API spend
  (CLAUDE.md §4). At 5¢ a version, a thousand published versions is $50.

## Consequences

- **Task 1004365** adds the scaffolded `HOWTO.md` (with the five headings) to
  `bongos module new`, the section check in `bongos module publish`, the same check on the
  store's upload route, and `HOWTO.md` in the packaging allowlist.
- **Task 1004366** renders the file as the module's store page, with a PDF download of the
  same content, and shows the D3 link when present.
- **Task 1004367** builds the grader to D5 and D6, and stores its score and reason as the
  Docs part.
- **Authors of existing store modules** must add a `HOWTO.md` before their next version.
- **The overall score and ranking are unchanged** by this ADR (D5).

## Rejected

- **A hosted Claude artifact as the how-to.** It can change after publish, isn't covered by
  the hashes, and ties the module to one vendor. Kept only as the optional extra (D3).
- **Gate only, no score.** It proves the sections exist, not that they are any good.
- **AI grader only, no gate.** It costs money for modules with no how-to at all, and an
  outage would leave nothing enforcing the basics.
- **Docs in the plain average.** Considered; the owner chose to keep the overall score about
  how the module works and show Docs beside it.
- **Grading core-bundled modules.** They reach instances through the core, not the store; the
  store page is where the how-to is read.
