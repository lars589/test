# 0167 — The module catalog: `source` (which tree) and `provenance` (who built it) are two axes

- **Status:** Accepted
- **Date:** 2026-08-12
- **Track:** internal
- **Task:** [#1001772](https://cloudbongos.com/builders#/task/1001772) (BONGOS-V1, goal 1000029) — the browsable module catalog with author + origin credit.
- **Builds on:** [ADR 0107](0107-module-upstreaming-contribution-to-core-catalog.md) §2/§3/§6/§9 (upstreaming, attribution-as-portable-record, credit-now-money-later, default-off, the hall Modules tab), [ADR 0108](0108-instance-composition-configurable-root.md) §1 (the loader discovers across BOTH the core package's `modules/` and the instance's own), [ADR 0083](0083-modular-architecture-strangler-build-plan.md) (the manifest + loader), [ADR 0166](0166-module-maintenance-and-deprecation-policy.md) (the `maintenance` block the catalog surfaces).

## Context

ADR 0107 §9 shipped a hall "Modules" tab that split modules into **"built by this project"** vs **"core-loaded from Cloud Bongos"**. That split was derived from one field: the manifest's `origin` string (`src/module-loader/provenance.js` — no origin, or an origin naming this instance, means own-built).

Closing out the goal with the catalog itself (§2/§3 — "a browsable catalog of available core modules, each shown with its author + origin credit") exposed that this single field is being asked two different questions at once:

1. **Can this instance enable it?** — i.e. did the core ship it. This is what makes a catalog a catalog.
2. **Who gets the credit?** — the attribution record ADR 0107 §2 defined.

`origin` only answers the second. Attribution is **optional** in the manifest schema, and core's own modules mostly leave it unset because none of them was upstreamed from anywhere — so on a split instance every core module (`economy`, `governance`, `hall-ui`, …) classified as *built here*, and the catalog of things you could opt into read as empty. The two questions had been collapsed into the one field that cannot answer the first.

A second, smaller problem: a catalog whose author/origin columns are blank for most rows is not a credit surface. But filling them by writing `"author": "Cloud Bongos"` into fifteen core manifests would be a large, self-repeating diff that a sixteenth module would immediately forget.

## Decision

**Split the two questions into two fields on one shared model** — `src/module-loader/catalog.js`, which the hall route (`GET /api/bongos/modules`) and the CLI (`bongos module list --catalog`) both build from, so the two surfaces cannot drift.

- **`source` — which tree the module ships from.** Read *structurally* from the loader's discovery root (ADR 0108 §1): a module found under `resolveCoreRoot()/modules` is `core` (the catalog an instance opts into); one under `resolveInstanceRoot()/modules` is `instance`. This is the catalog axis and it needs no manifest cooperation, so it cannot rot.
  - **When the roots coincide** (a single checkout — the two candidates dedupe to one directory), structure can no longer answer it. There we fall back to what the checkout *says it is*: a `package.json` naming `@bongos/core` / `cloud-bongos` means this is the core repo and its `modules/` **is** the catalog; any other checkout's `modules/` are that instance's own. Fail-soft — an unreadable `package.json` degrades to "instance", which understates the catalog rather than inventing one.
- **`provenance` — who built it.** Unchanged: still `deriveProvenance(manifest.origin, ownProjectName)`, still derived from the **declared** manifest fields, which is why the row keeps `author`/`origin` verbatim (null when the manifest says nothing) beside the display credit below.

**Credit is resolved for display, and an inferred value is marked as inferred.** A `credit: { author, origin, inferred }` field falls back to the platform name for a core-shipped module that declares no attribution — so no catalog row is blank — while `inferred: true` makes both surfaces mark it (`*` in the CLI, a hoverable `<abbr>` in the hall). An instance module that declares nothing stays uncredited rather than borrowing the platform's name.

## Alternatives considered (rejected)

- **Stamp `author`/`origin` into all ~15 core manifests.** Rejected: a repetitive diff that states the same fact fifteen times, and nothing keeps module sixteen from omitting it. The fallback derives it once, for every module, forever. (A module that *wants* a specific credit still declares one and wins — the fallback only fills a hole.)
- **Overload `origin` to also mean "core-shipped".** Rejected — it is the attribution record ADR 0107 §2 deliberately defined as portable metadata, and `tests/modules_route.mjs` correctly pins provenance to the declared value. Writing a derived value into it would silently reclassify every core module as *core-loaded* and destroy the credit axis to fix the catalog one.
- **Decide `source` from `default: true`** (core modules mostly ship default-on). Rejected as a coincidence, not a rule: ADR 0107 §6 requires *accepted* catalog modules to ship `default: false`, so the newest and most interesting catalog entries are exactly the ones this heuristic gets wrong.
- **A `catalog` table in the DB.** Rejected as premature — the on-disk manifests already are the catalog, and a table would need writing at deploy time and could disagree with what actually mounted. Revisit if/when accepted submissions land from a real cross-repo channel ([ADR 0135](0135-module-upstream-submission-interim-queue.md)'s open question).

## Consequences

- **The hall's Modules tab sections by `source`, not `provenance`** — "Module catalog" (what the core ships, opt-in) and "Built by this project". The credit axis moved to the per-card chips where it belongs, and the "Submit for review" list is now drawn from `source: 'instance'`: a module that already ships with the core is by definition already in the catalog and cannot be submitted into it.
- **The catalog is browsable from both surfaces with the same filter rule** — `searchCatalog()` over key/title/description/credit/licence, mirrored in the page's `matchesQuery()`. The hall filters client-side (the whole payload is already there); the CLI takes `--search`.
- **`GET /modules` grew a `catalog` roll-up** and each row grew `source` + `credit`. Every pre-existing field is byte-identical, so an un-redeployed hall keeps working — `modules.js` falls back to the credit axis when `source` is absent.
- **The credit fallback names the platform, not the host instance.** That string is the core's own name (like `CORE_PKG`), not host identity, so it does not cross the [ADR 0062](0062-medusa-instance-model-decoupling.md) §7 core/host line and the BV1.R76 hardcoded-identity fitness check stays green.
