# 0263 — How a version closes: auto, early, roll-forward, and the maintenance exemption

- **Status:** Accepted
- **Date:** 2026-09-07
- **Tasks:** [#1003593](https://cloudbongos.com/builders#/task/1003593) (this design pass, BV1.R06). Implemented by BV1.R12 ([#1003599](https://cloudbongos.com/builders#/task/1003599)), R16 ([#1003603](https://cloudbongos.com/builders#/task/1003603)), R17 ([#1003604](https://cloudbongos.com/builders#/task/1003604)), R18 ([#1003605](https://cloudbongos.com/builders#/task/1003605)), R20 ([#1003607](https://cloudbongos.com/builders#/task/1003607)) and R23 ([#1003610](https://cloudbongos.com/builders#/task/1003610)).
- **Goal:** [#1000086](https://cloudbongos.com/builders#/goal/1000086) — Strict versioning.
- **Implements:** [ADR 0250](0250-strict-versioning-the-version-boundary-is-the-scope-gate.md) D5. That decision says a version *can* close; this one says *how*, so the five build tasks under it are mechanical.

## 1. Why a second ADR

[ADR 0250](0250-strict-versioning-the-version-boundary-is-the-scope-gate.md) is the
decision: the version boundary is the scope gate, and a version must be able to
reach done. It deliberately stops at the rule. Closing a version is the widest
write in the system — it flips a version, dispositions every goal still standing,
promotes the next version into `building`, and carries a bug queue across the
boundary — and *four* separate tasks build pieces of it. Left undesigned, each
would pick its own refusal codes, its own payload shape, and its own answer to
"what happens to the maintenance goal", and the seams would only meet in
production.

So this ADR pins the mechanics. It adds no rule ADR 0250 did not already decide.

## 2. The state machine

`versions.status` has four values (migration 003): `planning`, `building`,
`shipped`, `frozen`. Only two transitions are in scope here:

```
planning ──promote──> building ──close──> shipped
```

`frozen` is archival bookkeeping and no business of this design. Nothing
un-closes a version: reopening is not a move, and a version closed in error is
corrected the way any other bad row is.

**Only a `building` version may close.** Closing a `planning` version is
meaningless (nothing was built), and closing an already-`shipped` one is a
double-close. Both are `version_not_building` (409).

## 3. Two doors, and the asymmetry that makes the design simple

The single most useful thing to notice about D5 is that **auto-close, by
construction, has nothing to disposition.**

Auto-close fires when the last non-maintenance goal achieves. If that goal was
the last one, then every non-maintenance goal on the version is already
`achieved` or `archived` — so the set of open goals needing a decision is *empty
by definition*. The disposition machinery is not merely unnecessary on that path;
it can never have input.

That splits the feature cleanly in two:

| | **Auto-close** (R16) | **Early close** (R12) |
|---|---|---|
| Trigger | the last non-maintenance goal achieves | an Archon calls `POST /versions/:id/close` |
| Open goals at close | zero, by construction | any number |
| Disposition required | none — there is nothing to disposition | one per open non-maintenance goal |
| Actor | the system, on a ship or a satisfy | an Archon, deliberately |
| Roll-forward | the maintenance goal only | the maintenance goal, plus every goal dispositioned `roll_forward` |

Every complication in this feature — the disposition map, the refusal that
returns the open goals, the successor lineage — belongs to **early close only**.
R16 is a much smaller task than the ADR 0250 sentence makes it sound, and R12 is
where the weight is.

## 4. Auto-close: where it fires, and why it cannot fail a ship

Goal achievement has **two writers**, and [ADR 0250](0250-strict-versioning-the-version-boundary-is-the-scope-gate.md) D2 already made them a deliberate,
documented duplicate rather than one helper, because collapsing them creates a
require cycle (`db-goals` → `done-when` → `db-goals`):

- [`db-goals.js` `achieveGoalIfComplete`](../../modules/lifecycle/db-goals.js) — the manual `POST /done-when/:id/satisfy` path.
- [`done-when.js` `autoSatisfyShippedCriteria`](../../modules/lifecycle/done-when.js) — the cascade that fires on **every ship** and every reconciler tick, on the ship transaction's own `exec`.

**Auto-close hangs off both, on the same exec, exactly as R08/R09's closure check
did.** The rule is written twice on purpose, and the two copies move together or
a version closes correctly through one door and wrongly through the other. That
sentence is already load-bearing in both files; this feature adds a second clause
governed by it, so it is repeated here rather than left to be rediscovered.

**Auto-close must never fail a ship.** This is not a preference — it is the
established posture of the surrounding code:
[`closeCompletedWorkForShip`](../../modules/lifecycle/done-when.js) already
swallows its own failure and reports it in a summary line, on the argument that a
criterion close must never fail a ship and the reconciler's unscoped sweep
retries every tick. Version close is a strictly wider write than a criterion
close, so it inherits the posture *a fortiori*:

- it runs inside the ship transaction so it sees the uncommitted `shipped` flip (the same reason R09's clause needs `exec`);
- it is wrapped so a throw is caught, logged, and reported — never propagated into the ship;
- it is **idempotent** (`WHERE status = 'building'` guards the flip), so the reconciler sweep retrying it is a no-op once it has run.

The consequence, stated plainly: **a version can be left un-closed by a failure,
and never half-closed.** Un-closed self-heals on the next sweep. That is the
correct trade — the opposite choice makes a bug in version-close able to block
every builder's ship.

### The archive doc is not part of the transaction

`limitations/<version>-shipped.md` is a **repo file**, and a route cannot write
one. Auto-close therefore flips the database and nothing else; the scope archive
stays a human/agent follow-up driven by
[`scripts/gds/version-close.js`](../../scripts/gds/version-close.js) (R23). This is
worth saying because ADR 0250 §7 speaks of a version "reaching done", and a
reader could reasonably assume the archive rides along. It does not, and pretending
otherwise would put file I/O inside a ship transaction.

## 5. Early close: the two-step, mirroring the archive refusal

`POST /versions/:id/close` is Archon-only, behind the **already-defined**
`version.close` permission ([`government/catalog.js`](../../modules/government/catalog.js)) that nothing has referenced until now.

The shape is **the R10 archive two-step, verbatim in spirit** — that precedent is
shipped, agents already know it, and inventing a second idiom for the same
interaction is how two surfaces drift:

**Step 1 — refuse, and return the work.** Called with open non-maintenance goals
and no disposition, the route refuses with `version_holds_open_goals` (409) and
**returns the goals**, not merely a count. R10's reasoning applies unchanged: the
caller's next move is to decide what happens to each, and an agent that has to go
fetch the list first will guess instead.

```
409 { error: "version_holds_open_goals",
      message: "Version 'BONGOS-V1' still holds 12 open goal(s). …",
      details: { total: 12, shown: 12,
                 goals: [ { id, title, open_tasks } … ] } }
```

**Step 2 — proceed with a disposition map.** One entry per open non-maintenance
goal, keyed by goal id:

```json
{ "reason": "V1 is done; the rest is V2 scope.",
  "dispositions": {
    "1000044": { "verb": "roll_forward" },
    "1000065": { "verb": "abandon" }
  } }
```

Two verbs, and only two:

- **`roll_forward`** — a successor goal is created in the planning version (§6).
- **`abandon`** — the goal is archived, and its open tasks are abandoned with the close's `reason`, through the same path R14 gives the archive flow. It is deliberately **not** possible to abandon a goal without a reason: `reason` is required on the close call, and it is what lands in each abandoned task's record.

**A version holding zero open goals stays a single call**, exactly as a goal
holding zero open tasks does. That is the auto-close path's shape too, so both
doors agree.

### Refusal codes

Every one is **named**, per ADR 0250 §7 — the callers are agents, and an unnamed
409 is an agent stopping to ask a human.

| Code | Status | When |
|---|---|---|
| `version_not_found` | 404 | no such version |
| `version_not_building` | 409 | the version is `planning`, `shipped` or `frozen` |
| `version_holds_open_goals` | 409 | open non-maintenance goals and no/partial disposition map; returns the goals |
| `bad_disposition` | 400 | a disposition names an unknown goal, a goal not on this version, or a verb outside `roll_forward`/`abandon` |
| `no_planning_version` | 409 | a `roll_forward` was asked for and no `planning` version exists to receive it |
| `close_reason_required` | 400 | `reason` missing on a close that dispositions anything |

`no_planning_version` is the one that will actually be hit in practice, and it is
a **refusal rather than an auto-create on purpose**: cutting the successor version
is a scope decision with its own criteria, and doing it implicitly inside a close
is precisely the "fake hotfix version" failure ADR 0250 §3 built the override
counter to prevent.

## 6. Roll-forward: the lineage column already exists, pointing the other way

Migration 160 gave `goals` a **`succeeded_by_goal_id`** column — on the *old*
goal, pointing at the *new* one. Both ADR 0250 and task 1003604's brief say
`succeeds_goal_id`, which does **not** exist. The column that exists wins; there
is no migration here, and R17 must write:

```sql
UPDATE goals SET succeeded_by_goal_id = <new.id> WHERE id = <old.id>
```

Naming this explicitly is the whole reason this section exists — R17's brief would
otherwise send a builder to reserve a migration number for a column that has been
in the schema since the goal tier landed.

A rolled-forward goal is created on the planning version carrying the original's
`title`, `description`, `scope_modules`, `category_id` and **membership**; its
open tasks are re-pointed at it. The predecessor is then `archived` with zero
open tasks — so it passes R10's own check on the way out, rather than being
special-cased around it.

## 7. The maintenance goal: the flag R18 owes, and the exemption

The maintenance goal is currently **matched by title** —
`ensureMaintenanceGoal` (task 1003691) looks up `"<version> — maintenance"`, and
its own comment flags this as R18's debt:

> MATCHED BY TITLE, because there is no column that says "this is the maintenance goal" … task 1003605 (BV1.R18) is where a real flag belongs when the feature gets its own column.

**R18 adds the column**: `goals.is_maintenance boolean NOT NULL DEFAULT false`,
backfilled by title for the rows that already exist, after which the title lookup
becomes a flag read. This is not cosmetic. The close count asks "are there any
open non-maintenance goals?", and answering it with a `title NOT LIKE` would make
a hand-titled goal silently exempt from the gate that decides when a **version**
closes — a much worse blast radius than the provenance wrinkle the title match
carries today.

The exemption is then one predicate, used identically by auto-close and early
close:

```sql
WHERE version_id = $1 AND status = 'open' AND NOT is_maintenance
```

**The maintenance goal always rolls forward, and never needs a disposition.** It
is exempt from the close count, so it cannot hold a version open; and its open
bugs move to the successor version's maintenance goal (`ensureMaintenanceGoal` on
the newly-promoted version — the find-or-create already exists and is
advisory-locked). Bugs arrive on their own schedule and must not need an override
to be filed; that is the pressure valve ADR 0250 §3 describes, and it only works
if the queue survives the boundary.

## 8. Promotion: the close's last act

On a successful close, the single `planning` version is promoted to `building`
(R20), so the project is never without a live train.

- It runs **in the close's transaction** — a project with zero building versions is a broken state, not an intermediate one, and `currentBuildingVersionId` returns `null` there, which fails every routing path closed over it.
- **Zero planning versions is not an error.** The close succeeds and the project sits with no building version until someone cuts one. Refusing the close would trap a finished version open because nobody had scoped the next one yet.
- Exactly one can be promoted, because R04 already refuses a second `planning` version.
- The promoted version gets its maintenance goal via `ensureMaintenanceGoal`, which is what receives the carried-forward bugs in §7.

**Ordering inside the transaction is load-bearing:** promote *before* roll-forward
and before the bug carry-over, because both need a destination version that is
already `building` — `ensureMaintenanceGoal` returns `null` for a version whose
status is not `building`, so a carry-over run before the promotion silently
carries nothing.

## 9. The race, and where the index belongs

[`versions.js`](../../modules/lifecycle/routes/versions.js) already documents R04's
unmitigated check-then-insert race and names R19 as the place to fix both halves
with one partial unique index. That still stands, and this design adds the close
side of the same exposure: two concurrent closes could both promote.

The single migration R19 reserves should therefore carry **both** guards:

```sql
CREATE UNIQUE INDEX ON versions ((status)) WHERE status = 'planning';
CREATE UNIQUE INDEX ON versions ((status)) WHERE status = 'building';
```

With those in place the promotion race resolves the way the version-id collision
already does — the loser gets a `23505` and the route translates it into the same
clean refusal, rather than the check-then-act prayer both rules rely on today.

## 10. What this design does not do

- **It does not gate shipping.** Consistent with ADR 0250 §4. Auto-close rides the ship transaction and is swallowed on failure; nothing here can refuse a ship, a claim, or a grade.
- **It does not write the scope archive.** §4. The route closes the version; the doc is R23's CLI work.
- **It does not auto-create the successor version.** §5. That is a scope decision with criteria, and doing it implicitly is the escape hatch ADR 0250 exists to close.
- **It does not add a reopen.** A version does not un-close.

## 11. The sub-tasks this implies

All five were already filed by the planning session; this ADR is what makes them
mechanical. Two briefs are **corrected** by it:

| Task | What this ADR pins |
|---|---|
| R12 [#1003599](https://cloudbongos.com/builders#/task/1003599) | the route, the six refusal codes, the two-step + disposition payload (§5) |
| R16 [#1003603](https://cloudbongos.com/builders#/task/1003603) | **corrected** — auto-close needs no disposition machinery (§3); it hangs off *both* achievement writers on the caller exec and may never fail a ship (§4) |
| R17 [#1003604](https://cloudbongos.com/builders#/task/1003604) | **corrected** — the column is `succeeded_by_goal_id` and already exists; no migration (§6) |
| R18 [#1003605](https://cloudbongos.com/builders#/task/1003605) | the `is_maintenance` flag, the backfill, the exemption predicate, the bug carry-over (§7) |
| R20 [#1003607](https://cloudbongos.com/builders#/task/1003607) | promotion runs in the close txn, before roll-forward; zero planning versions is not an error (§8) |
| R19 [#1003606](https://cloudbongos.com/builders#/task/1003606) | its migration carries the `building` partial index **and** R04's `planning` one (§9) |
