# 0245 — The way back into an optional step is that step's own answer route

- **Status:** Accepted
- **Date:** 2026-09-04
- **Tasks:** [#1002342](https://cloudbongos.com/builders#/task/1002342) (this decision — BV1.R23)
- **Goal:** [#1000046](https://cloudbongos.com/builders#/goal/1000046) — Project creation, criterion
  `proj-module-select` ("during setup a default set of modules is pre-selected…")
- **Related:** [ADR 0240](0240-a-skipped-module-picker-stores-nothing-and-resolves-the-bundle-on-read.md)
  (R20 — the nullable `modules` column, the three-valued contract, and §6's "R23 … needs to know whether
  an owner has ever been asked"), [ADR 0237](0237-a-starter-bundle-is-a-preset-over-the-always-on-core-keyed-by-declared-type.md)
  (R19 — the bundles and the `OPTIONAL_MODULES` catalog this surface renders),
  [ADR 0243](0243-a-bundle-adjustment-belongs-to-the-bundle-not-the-advice-about-it.md) (R22 — the
  team-shape adjustment inside the fallback, and why `PATCH …/detail` already answered with `modules`),
  [ADR 0238](0238-the-join-door-is-a-provisioning-settings-policy-key.md) (R05 — the manage view, and its
  finding that "the project's own hall settings" is a page that does not exist),
  [ADR 0111](0111-instance-hosting-provisioning-module.md) (the enqueue-only web tier)

## 1. The problem

R20 shipped a module picker as step 4 of the create wizard and made it skippable.
The route file said out loud what that left behind:

> …there is no mutation route yet (R23, task 1002342 is "add modules later"), so
> the receipt says the answer was kept rather than naming a way back that does
> not exist.

So a project's module set was **write-once at creation**. An owner who skipped the
picker, or picked wrong, had no way to change it — which is the same dead end
`PATCH /provisioning/instances/:id/detail` was built to close for the About step
one panel earlier. An optional step is a supported default only while there is a
way back; without one, "optional" quietly means "permanent".

Two questions had to be answered, and the second follows from the first.

## 2. Not a new route — the same route the step beside it uses

The obvious move is a new `PATCH /provisioning/instances/:id/modules`. It is the
wrong one, and the reason is that the wizard's two optional steps are the same
kind of thing:

| | About (step 3) | Modules (step 4) |
|---|---|---|
| asked | optionally, at creation | optionally, at creation |
| stored | `description` + `detail` on the platform row | `modules` on the platform row |
| reaches the running instance | no | no |
| way back | `PATCH …/detail` | **this** |

`PATCH …/detail` is already *"answer (or re-answer) the wizard's optional creation
steps after creation"* — the name is narrower than the job. It already carries the
ownership gate (`instanceAccessDenied`: own-scoped, Archon override, 404 with no
existence leak), already records an event with an `api:self` / `api:archon:<id>`
actor, and — since [ADR 0243](0243-a-bundle-adjustment-belongs-to-the-bundle-not-the-advice-about-it.md)
— **already answers with `effectiveModules(updated)`**, because a `team_shape`
answer moves a bundle-sourced project's modules. The route was already reporting
this value; all that was missing was the ability to set it.

A second route would have duplicated the gate, the actor rule, the 404 shape and
the receipt, for one column on a row the first route already writes. Duplicated
authorization is the kind that drifts.

**Not the settings channel**, for [ADR 0240](0240-a-skipped-module-picker-stores-nothing-and-resolves-the-bundle-on-read.md)
§3's reason, restated: a setting is *a policy the running instance obeys* — it
rides `web.env`, queues a `settings-apply` intent and restarts the service. A
module selection is a declaration held on the platform row until a catalog row
materializes. Nothing is pushed and nothing restarts, and the surface says so
rather than borrowing its neighbours' "your project will restart" receipt.

## 3. The skip state is not writable

`modules` is three-valued (ADR 0240 §2): `NULL` = never asked, `[]` = declined
everything, `[…]` = chosen. A later edit must be able to reach the second and
third, and **must not be able to reach the first**.

So only an **array** is a change. An omitted key, or an explicit `null`, leaves the
column alone; a body carrying nothing but a null `modules` is still the existing
`bad_detail` "nothing to change". That is a deliberate asymmetry rather than an
oversight: `NULL` is a claim about the owner's *history* — that they were never
asked — and a write that could re-assert it would let an answered project become
indistinguishable from an unasked one, permanently, which is the exact collapse
ADR 0240 refused `NOT NULL DEFAULT '[]'` to prevent.

`modules` also **replaces** where `detail` merges. The `detail = detail || $n::jsonb`
precedent exists because a form may send one interview answer without resending
the rest; a module selection has no keys to merge, and a merging write would make
*removal* impossible — the half of "add modules later" an owner needs most.

The always-on core stays unremovable by construction, not by a guard bolted on
here: `badModuleSelection` refuses a core key by name (`"memory" is always on for
every project — it is not one of the modules to choose`), `normalizeModuleSelection`
filters to the opt-in catalog on the way to storage, and `effectiveModules` prepends
the whole core on the way out. Three independent places, none of which this route
had to add.

## 4. The surface is the manage page, because the hall page is still gone

ADR 0182 D5 pointed R05 at "the project's own hall settings"; ADR 0238 found that
page does not exist — `settings.html` is per-*builder*, and the hall's my-projects
page was deleted by task 1003308. Nothing has changed since, so the extras band
lands where its three sibling settings already live: `/projects?view=manage&id=N`.

Two reads, one of them new. The **current set** rides in on the instance itself —
`publicInstance` resolves `effectiveModules(row)`, so a skipped picker reads as its
own starter bundle and this page never re-derives that rule, which is the one way
two surfaces come to name different modules for one project. The **catalog** is the
same public `GET /provisioning/starter-bundles` the wizard's panel reads.

**A toggle is the save.** Every sibling section on that page has a Save button
because each is one choice with one value; the extras band is a list of independent
facts, where a Save button only adds a way to lose one. The write sends the whole
list in catalog order (what the column stores), and the band repaints from the
platform's answer rather than from what was sent — so it can never show a set the
server did not accept, and a refusal puts it back to what the row still holds.

## 5. Consequences

- **`modules_ignored` now names the way back.** A create re-request that carries a
  changed `modules` still refuses to apply it, but its receipt points at this route
  — the `detail_ignored` shape, for the `detail_ignored` reason.
- **The wizard's own `?view=manage` links carry their id now.** The done panel's
  in-page router matched `view=(\w+)` and dropped the query, so every
  `projectPageLink` on that panel landed on a manage page with no project. Fixed in
  passing because criterion B's pointer would have been the fifth link to do it.
- **Still not an input to the runner** (ADR 0240 §6). Changing the set changes a
  declaration on the platform row; turning it into the child instance's own
  `config/modules.json` remains separate work. The surface's copy says so — "nothing
  restarts" is true today and would be a lie the moment that work lands, so it is
  worth re-reading then.
- **A module selection is still not a publish precondition** (ADR 0182 D4).

## 6. Rejected

- **A new `PATCH …/modules` route** — a second copy of one ownership gate, one actor
  rule and one 404 shape, for a column the existing route's own UPDATE already
  reaches.
- **The settings channel** — would queue a `settings-apply` and restart a running
  instance to deliver a value the instance does not read (ADR 0240 §3).
- **Letting `modules: null` clear the column** — reachable, coherent-looking, and it
  destroys the only fact that says whether an owner was ever asked.
- **Merging the list like `detail`** — makes removing a module impossible.
- **A Save button under the band** — one more state to hold, and its failure mode is
  an owner who toggles, leaves, and loses the change.
- **Rendering the always-on core as disabled rows** — ADR 0240's rejection, and it
  holds here for the same reason: a disabled control reads as a choice the owner
  failed to make.
