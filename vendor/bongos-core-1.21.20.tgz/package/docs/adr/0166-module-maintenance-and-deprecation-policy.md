# ADR 0166 — Module maintenance & deprecation policy for accepted modules

- **Status:** Accepted
- **Date:** 2026-08-11
- **Track:** internal
- **Task:** [#1001773](https://cloudbongos.com/builders#/task/1001773) (BONGOS-V1) — "Module upstreaming: maintenance & deprecation policy for accepted modules".
- **Implements:** [ADR 0107](0107-module-upstreaming-contribution-to-core-catalog.md) §7, which named the problem and deferred the mechanics to a follow-up. This is that follow-up.
- **Builds on:** [ADR 0083](0083-modular-architecture-strangler-build-plan.md) (the manifest + loader + `coreVersion` check), [ADR 0107](0107-module-upstreaming-contribution-to-core-catalog.md) §§1/4/6 (submit → review → accept, the AGPL pre-check, default-off acceptance), [ADR 0135](0135-module-upstream-submission-interim-queue.md) (where submissions queue).

## Context

ADR 0107 §7 states the problem in one sentence: *"A module pinned to an old `coreVersion` rots as core advances… The catalog must not fill with silently-broken entries."* It set the direction — on acceptance a module is either **core-maintained** or carries a named **maintainer** and a deprecation path — and left the mechanics open.

Three facts about the system as it stood made the rot silent rather than loud:

1. **Nothing in the manifest said who owns upkeep.** `module.json` carried `maintainer` as free-text attribution (ADR 0107 §2) — a credit line, not a commitment, and never read by any check. A module could be accepted with `maintainer` unset and nothing anywhere would notice.

2. **Accepted modules are default-off, and the disabled path was the silent one.** ADR 0107 §6 makes `default: false` the accept action, so an accepted catalog module is *disabled by construction* in any instance that hasn't opted in. `evaluateUpgrade` correctly classified an incompatible **enabled** module as blocking and an incompatible **disabled** module as a warning — but `preflightModules()` in `scripts/gds/upgrade.js`, the pre-check that runs during a **real** `bongos upgrade --to <version>`, returned only `blocking` and discarded `warnings` entirely. Its headline note read `"all enabled modules satisfy the target"` — true, and profoundly misleading, because every rotted catalog entry was in the bucket it had just thrown away. **The one code path where a module's incompatibility should have surfaced was the one path where it could not.**

3. **A deprecated module had no way to say so.** There was no vocabulary for "on the way out", no successor pointer, and no removal date — so deprecation could only live in prose nobody reads at upgrade time.

## Decision

### 1. Upkeep is a declared, machine-readable property of the module — a `maintenance` block in `module.json`.

```jsonc
"maintenance": {
  "status": "maintained",      // REQUIRED in-block. One of the four below.
  "since":  "1.8.0",           // OPTIONAL. Core version the status took effect.
  "removeAfter": "1.12.0",     // OPTIONAL. Core version after which it may be deleted.
  "successor":   "econ-v2",    // OPTIONAL. Module key that replaces it.
  "note":        "…"           // OPTIONAL. The path out, in one sentence.
}
```

The block is **optional** at the schema level (pre-policy manifests keep validating) but **required to be upstreamed** — see §3. Its key set is closed, so a typo'd `removeafter` fails loud rather than quietly declaring no removal date at all.

### 2. Four statuses, and each one owes something.

| `status` | Means | The obligation the validator enforces |
|---|---|---|
| `core-maintained` | The core team owns it. A core change that breaks it is the core's problem to fix before shipping. | — |
| `maintained` | A named person/handle owns it. | A non-empty top-level `maintainer`. **An unnamed maintainer is the orphaning failure this field exists to prevent**, so it is rejected rather than accepted-and-ignored. Use `orphaned` if that's the truth. |
| `deprecated` | On the way out. | A `successor` and/or a `note` — the *deprecation path* ADR 0107 §7 requires. May carry `removeAfter`. |
| `orphaned` | Nobody owns it. | A `successor` and/or a `note`, so the next reader gets the situation and not just the label. |

`orphaned` is deliberately a **first-class, declarable state**. A policy that only permits happy statuses gets satisfied by lying; the useful system is one where "nobody owns this" is a thing a manifest can honestly say and the tooling can then surface.

`removeAfter` is rejected on a non-sunset status — a removal date on a maintained module is a contradiction, and silently ignoring it would hide the author's actual intent.

### 3. The accept gate: a module must state its upkeep before it may be submitted.

`bongos module check` / `bongos module submit` (and the `POST /modules/:key/submit` route that is the authoritative copy of that check) now refuse a module that:

- declares no `maintenance.status` — *acceptance into the shared catalog is a commitment to keep the module true as the core advances; the module must say who is committing*; or
- declares `deprecated` / `orphaned` — a module already on its way out cannot be submitted *into* the catalog. Upstream a maintained module, or its successor.

This sits alongside the existing §4 AGPL/publish pre-check as a third finding kind (`maintenance`), on the same fail-closed footing.

### 4. `bongos upgrade` surfaces incompatibility for **disabled** modules too — the fix that makes the policy real.

The enabled/disabled asymmetry stays where it belongs: an incompatible **enabled** module still **refuses** the bump (fail-closed, unchanged), and an incompatible **disabled** module still **does not block** — it genuinely breaks nothing at boot. What changes is that the disabled case is now *said out loud, with its owner named*, on both surfaces:

- `preflightModules()` returns `warnings`, `deprecations`, and `expired` alongside `blocking`, and its headline note refuses to claim all-clear when disabled modules have rotted (`"all enabled modules satisfy the target, but 2 disabled module(s) do NOT"`).
- `runUpgrade()` prints them via `reportModulePreflight()`, **before** the blocking check returns — so they appear on a refused bump too, which is exactly when someone is reading the output.
- `bongos upgrade` (the bare pre-check) appends a maintenance hint to every mismatch row and rolls up deprecations, modules past their `removeAfter`, and modules with no declared upkeep at all.

Every one of those lines names an owner, or says plainly that there isn't one. A warning that can't be actioned is noise; the maintainer is what makes it a next step.

### 5. The catalog view shows upkeep.

`GET /modules` returns `maintenance`, and the hall Modules tab renders an `upkeep:` chip — including `upkeep: undeclared` for a module with no block. An unowned catalog entry is precisely what this policy exists to catch, so it must be visible where builders browse modules, not only in a CLI they may never run.

### 6. Every bundled module declares `core-maintained`.

The 17 modules that ship inside `@bongos/core` are core-maintained by definition. Stamping them makes the policy true of the live catalog on day one instead of aspirational, and `tests/module_manifest.mjs` holds the line — a new bundled module with no declared posture fails the unit gate.

## Alternatives considered (rejected)

- **Make an incompatible disabled module BLOCK the upgrade.** Fail-closed everywhere is tempting, but it is wrong here: a disabled module is not running, and blocking an instance's core bump on the rot of a catalog entry it never opted into makes the shared catalog a liability for every consumer. Report, don't block.
- **Make `maintenance` a required manifest field.** Would invalidate every existing manifest at once and break the loader for any instance mid-upgrade. Optional-in-schema + required-at-submit puts the gate at the moment of commitment, where it belongs.
- **Track maintenance in the GDS database instead of the manifest.** Attribution deliberately travels *with* the module as portable metadata rather than as a cross-GDS foreign key (ADR 0107 §2); upkeep has the same property — it must survive the module moving between repos, and it must be readable by `bongos upgrade` on a box with no DB session.
- **Auto-deprecate a module whose `coreVersion` stops matching.** Rejected — incompatibility is a fact, deprecation is a decision. Conflating them would let the tool retire a module its maintainer was about to fix.
- **A separate `MAINTAINERS` file per module.** A second file to drift out of sync with `module.json`, and invisible to the manifest validator. The manifest is already the module's declared contract; upkeep belongs in it.

## Consequences

- **`bongos upgrade` gets noisier, on purpose.** An instance carrying rotted disabled modules now sees a line per module per bump. That is the intended pressure: the cure is to fix, deprecate, or delete the module, and each of those makes the line go away honestly.
- **Submitting a module upstream now requires one more field.** `bongos module new` scaffolds `{"status": "maintained"}` (the author is the maintainer — the honest default), so the friction lands only on modules scaffolded before this ADR.
- **`orphaned` is now sayable, which means it will be said.** Expect the catalog to acquire visibly-unowned entries. That is the policy working: a labelled orphan is a candidate for adoption or deletion, an unlabelled one is a trap.
- **`removeAfter` is declarative, not enforced.** Nothing deletes a module automatically — `expired` only reports that the core has advanced past the declared date. Automatic removal would need the review/accept flow to own module deletion, which is [ADR 0107](0107-module-upstreaming-contribution-to-core-catalog.md) §1 territory and a separate decision.
