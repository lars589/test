# ADR 0364 — Repo access is asked at sign-in on the hub, and held for as long as the builder stays signed in

- **Status:** Accepted.
- **Date:** 2026-10-02
- **Task:** [task 1004549](https://cloudbongos.com/builders#/task/1004549).
- **Amends:** [ADR 0143](0143-onboarding-repo-picker-oauth-scope.md) (the repo token's short hold) and [ADR 0155](0155-adopt-private-repo-widen-oauth-scope.md) (where the `repo` scope is asked).

## Context

The owner reported that "Allow repo access" in the create wizard's review step threw them out of the flow, and never seemed to reach GitHub. Both parts were true:

- GitHub already held the owner's approval of the `repo` scope, so its authorize step answered at once and bounced straight back. The round-trip looked like a reload.
- The platform asked again because it kept its copy of the token for one hour only (`GITHUB_TOKEN_TTL_MS`). An owner who signed in from the front page, or more than an hour earlier, was sent away from the middle of the wizard to fetch a grant GitHub already held.
- The bounce then landed on the wrong screen. With a project created earlier in the same tab, `enter()` passed every arrival to `enterCreated()`, which treats a non-deliberate arrival as "the same visit, show the watched project". So the founder landed on the earlier project's done panel instead of their draft.

## Decision

**D1 — Every sign-in door on the hub's own pages asks for repo access.** These are the front page, the projects hub (bar, Your-projects gate, manage gate, the wizard's own door and its 401 recoveries) and the account page. All of them carry `repos=1`. It is asked once, when the person signs in, because anyone signing in on the hub is there to create or run a project, which needs it. The builders' hall and the CLI sign-ins stay identity-only. That is ADR 0143's least-privilege default, and it is unchanged where the person may only be joining someone else's project.

**D2 — The token lives as long as the session it arrived with.** The callback passes the web session's remaining life (30 days today) to `upsertGithubToken` as its TTL. The one-hour constant remains only as the fallback for when no session expiry is known. A **web** sign-out deletes the token. A CLI logout (bearer header) leaves it alone, because the browser session that granted it is still live. Offboarding and a GitHub-side revocation (401) still delete it, as before.

**D3 — A GitHub round-trip never loses the founder's place.** If a draft sits at a wizard step (1–5) beside a stored create, the draft wins on any non-deliberate arrival: a reload, or a return from GitHub. The earlier project stays one click away on the resume line. A deliberate nav and the resume link still go through `enterCreated()` exactly as task 1003503 built it. The review step's "Allow repo access" offer was kept as a backup at first. The amendment below removes it.

## Consequences

- A first-time visitor signing in on the hub now sees GitHub's repository-access wording at sign-in, rather than at the review step. GitHub words it as full control of all their repositories. The wizard's own explanation still sits beside the review step's backup offer. The front page's sign-in pill carries none, which is the cost of asking at the door.
- The platform holds a powerful credential for up to 30 days instead of one hour. It is still encrypted at rest with secret-box, keyed to one builder and never returned to a client, and it is never stored at all when secret-box is unconfigured. A server compromise during that window exposes more than it did. The owner accepted this explicitly (2026-10-02).
- Tests: `tests/github_token_session_life.mjs` (D2, over the real auth router), `tests/wizard_draft_resume.mjs` slice 4 (D3), and the updated sign-in href pins in `landing_page`, `hub_account_page` and `projects_hub_pre_uat`.

Rejected: keeping the ask inside the wizard and moving it to the first screen. That is still a stop in the middle of a flow, and the owner preferred sign-in. Silently refreshing the token in the background: it needs a GitHub round-trip, which is a navigation, not a background call.

## Amendment — no repo-access button at all ([task 1004555](https://cloudbongos.com/builders#/task/1004555), owner 2026-10-02)

The owner did not want to see the review step's "Allow repo access" box at all. When the repo probe finds no stored token, the wizard now saves the draft and makes **one** automatic repo sign-in round-trip. For anyone who has already approved the scope, GitHub answers at once, and the founder lands back on the same step (D3). The hop is marked once per tab session: a second miss falls back to the manual owner/repo fields with one plain line, rather than looping, and a probe that finds access clears the mark. The `#ghConnect` box, its explanation, the "enter it manually" toggle and its way back are gone. The plain-words explanation of the scope now lives only on GitHub's own screen at sign-in.
