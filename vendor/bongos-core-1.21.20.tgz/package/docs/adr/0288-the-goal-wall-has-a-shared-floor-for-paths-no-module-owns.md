# 0288 — The goal wall has a shared floor for paths no module owns

**Status:** accepted · 2026-09-16 · [task 1003655](https://cloudbongos.com/builders#/task/1003655)

## Context

[ADR 0086](0086-goal-scoped-work-hierarchy.md) §3 gives a goal member bounded authority to author their own tasks: every element of a candidate task's `touches[]` must be *contained within* the union of the goal's modules' globs, resolved through `MODULE_SCOPE_MAP`. The containment is directional (`matchOne`, not the symmetric `touchesOverlap`) precisely so the wall cannot be widened by declaring a broad parent path.

That map answers one question — *who owns this path* — and it answers it for the shipping surfaces. `tests/` has no honest answer. It is 751 flat suites named by feature rather than by module, covering all ~24 keys, and no key claims it. `scopeSubset()` therefore denied every touch under it, under every goal.

Since every real task adds a test, the consequence was structural: `POST /goals/:id/tasks` refused any task that honestly declared its own test file, whatever goal it was filed under. The gate only looked passable because callers under-declared their `touches[]`. This was filed as idea 1000816 while checking coverage for unrelated work; it had not yet surfaced as anyone's confusing 403 because no live caller sent `touches` to the capture-time routing path added in R05 ([task 1003066](https://cloudbongos.com/builders#/task/1003066)).

The same idea named `.claude/skills/` as a second instance. That half resolved itself: [task 1002989](https://cloudbongos.com/builders#/task/1002989) gave the methodology key `.claude/skills/` as the floor under the ~50 skills no module ships. Only `tests/` remained.

## Decision

**`MODULE_SCOPE_MAP` gains `SHARED_GLOBS` — a small set of globs inside every goal's wall and outside every module's territory. Its sole entry is `tests/`.**

The bar for joining it is deliberately narrow, and both halves must hold: **no module can honestly own the path, and every task legitimately writes it.**

`goal-scope-check.scopeSubset()` treats a touch as covered if it is contained in the goal's module globs **or** in the shared floor. The floor is reported as its own `shared_globs` field and is never folded into `goal_globs`, because `check()`'s `unknown_scope` guard tests `goal_globs.length === 0` — mixing an always-present list in would give a goal scoped to nothing but garbage a non-empty territory and slip it past that fail-closed edge.

**The exported floor is derived, not trusted.** On the same contract that makes `protected` a derivation rather than a literal (ADR 0086 §7, the SEC #863 second-list failure mode), a raw entry that overlaps `PROTECTED_GLOBS` is filtered out of the export. A protected path listed here would widen every goal's wall into the trust core in a single line.

## Consequences

- **A task can declare its own test honestly.** The gate stops rewarding under-declaration, which is what made the wall's numbers wrong rather than merely strict.
- **The other two walls are untouched.** Claim collisions are still caught by `touchesOverlap` on `touches[]`, and the protected-path wall runs independently of the subset wall — a sub-Metic author is still blocked from the trust core whether or not a path is shared. `tests/` is not in `PROTECTED_GLOBS`, so the floor opens nothing that was closed.
- **A test file is not a shipping surface.** Nothing imports `tests/*.mjs`, so a member authoring one has zero blast radius on another module's code. That is what makes shared territory sound here and would not make it sound for, say, `src/`.
- **Module-owned suites stay owned.** `modules/<key>/tests/` is already inside its module's glob and is not part of the floor.
- Rejected — **giving `tests/` to a key** (`devsecops` or `methodology`). It is a false ownership claim: an ideas-module test is the ideas module's work. It would also hand one goal's members the entire suite while denying it to everyone else, which is worse than the gap it closes.
- Rejected — **enumerating per-module test paths.** The suites are named by feature, not module, and the glob format has no wildcards to carve with, so the list would rot on the next test file.
- **Adding a second entry is a design decision, not housekeeping.** The floor is the one place where a line of data widens every wall at once, so it carries the derivation guard and a unit test asserting it stays narrow.
