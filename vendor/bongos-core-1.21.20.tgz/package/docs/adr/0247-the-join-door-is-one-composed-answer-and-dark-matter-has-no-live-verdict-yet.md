# ADR 0247 — The join door is ONE composed answer, and dark matter has no live verdict to compose with yet

- **Status:** accepted
- **Date:** 2026-09-04
- **Task:** [task 1002331](https://cloudbongos.com/builders#/task/1002331) (BONGOS-V1, goal 1000046 — *Project creation*, criterion `proj-join-policy`)
- **Deciders:** Claude, under the Archon's standing scope
- **Implements:** [ADR 0182](0182-project-visibility-two-axes.md) D6 (*"visibility sets the ceiling; join policy may only narrow it"*) — which stated the rule and left it unimplemented
- **Related:** [ADR 0194](0194-joinability-one-door-decision.md) (`joinabilityMode`, the one-reader precedent this extends) · [ADR 0238](0238-the-join-door-is-a-provisioning-settings-policy-key.md) (the settings channel the new knob rides) · [ADR 0116](0116-api-error-envelope-and-code-taxonomy.md) (the refusal envelope) · [ADR 0083](0083-modular-architecture-strangler-build-plan.md) (the doorway)

---

## Context

ADR 0182 D6 gave the project plane a table — public self-joins, private queues an
application, stealth refuses at the door, dark matter has no door — and one composition
rule: *the stricter of the two always wins, and neither can widen the other*. R11
(task 1002330) and R13 (task 1002332) then built the queue and its review UI. Neither
built the door: R13's own handoff says it plainly, *"R13 renders and decides, it enforces
nothing."*

So at claim time the public `POST /access-requests` — the one unauthenticated write, the
endpoint the hall's landing form, the `bongos login` CLI **and** the hub's join relay all
funnel into — read exactly one knob:

```js
const refusal = DOOR_REFUSAL[api.joinabilityMode()];
```

An owner could set their project `private` or `stealth` on the platform's map (task
1002324 shipped that control) and the application endpoint would behave exactly as
before. The policy was stored, validated, audited, pushed into the instance's environment
and read back in the manifest — and nothing consulted it.

R12 is that door. It also adds the third knob D6 anticipated: **what a public join
grants** — a look, a request, or membership.

## Decision 1 — The grant is one line of settings vocabulary, not a new route

`join_grant ∈ (view, apply, full)` joins `provisioning.SETTINGS_VOCAB` +
`DEFAULT_SETTINGS`, exactly as `visibility` did in task 1002324. This is not laziness
about the "owner mutation route" the task asked for — in this module the vocabulary **is**
the route. One line buys: the own-scoped `PATCH /provisioning/instances/:id/settings`
with its ownership wall (`instance_not_found` 404, so a wrong owner learns nothing an id
existed), the Archon override with `api:archon:<id>` on the audit row, server-side enum
validation (400 on an off-vocabulary value), the `<PREFIX>_JOIN_GRANT` line the runner
patches into `web.env`, the restart that applies it, and the `GET …/settings` options a
form renders from. A bespoke route would have re-implemented every one of those and could
drift from all of them.

It rides `src/branding.js` onto `project.joinGrant` and into the public manifest, like its
three neighbours — the read-back that lets a client say what a door does before knocking.

**The default is `full`, and that is load-bearing.** `DEFAULT_SETTINGS` must be *today's
behaviour*, and today a public project runs whatever door its `joinability` runs. `full`
is the value that narrows nothing, so **every existing project — all of them `public` —
is byte-identical after this lands**. `apply` as the default would have quietly turned
every open-enrolment project into an application queue.

## Decision 2 — One composed answer, in one pure file

`src/bongos/project-door.js` — `projectJoinDoor({ visibility, joinGrant, joinability,
publishable })` → `'open' | 'apply' | 'invite_only' | 'locked'`.

The door vocabulary is a **list ordered widest → strictest**, and that order *is* D6's
composition rule: the two knobs never negotiate, the higher index simply wins.

| stored state | ceiling | why |
|---|---|---|
| `public` + grant `full` | `open` | the grant narrows nothing |
| `public` + grant `apply` | `apply` | a self-join becomes a request |
| `public` + grant `view` | `invite_only` | on the map to be looked at; joining is by invite |
| `private` | `apply` | visible-but-closed: the application queues for the owner |
| `stealth` | `invite_only` | refused at the door; nothing is stored |
| not publishable | `locked` | dark matter — there is no door to knock on |

then `door = stricter(ceiling, joinability)`. D6's own two examples fall out: a `closed`
public project accepts no self-joins; an `open` stealth project still refuses everything.

**The grant governs `public` alone.** `private` and `stealth` set their own ceilings and
never consult it — "what a **public** join grants" is the question the owner was asked, and
letting a `full` grant reach a private project would be the widening D6 forbids.

It is published through the doorway as `api.projectJoinDoor()`, beside `joinabilityMode`
and for the same SR-19 reason: a module that read one knob would re-open a door the other
two had closed.

## Decision 3 — The refusal never names which knob closed the door

`stealth`, `public`+`view`, and an explicit `invite_only` all answer with the **same**
sentence and the same code. This is the reason the vocabulary has four values and not six.

ADR 0182 D2a makes stealth's anonymity a real privacy primitive — R06 redacts a black
hole's name, tagline, art and origin server-side, and gives it no stable per-project key
precisely so yesterday's feed cannot be diffed against today's to name the project that
went dark. A door that answered *"this project is stealth"* would hand that back for the
price of one POST. So the door's answer is a **behaviour**, never a state read-out, and
`tests/project_join_door_route.mjs` asserts the three refusals are indistinguishable —
byte for byte, including the query count.

The refusal is also answered **before** the body is validated and before any lookup, so it
costs no DB work, reveals nothing about who already exists, and — per D6 — stores nothing:
a closed project accumulates no queue to leak.

**Fail closed, but honestly.** An unreadable pack, a truncated env write, or a fourth enum
value a later release adds resolves to `invite_only` — never a wider door (ADR 0194 D2's
rule, and the direction R06 took for the feed). It does **not** resolve to `locked`:
`locked` is a specific *claim* — "this project is not published" — and an unknown policy
is no evidence for it. Refusing honestly beats refusing hardest.

## Decision 4 — `locked` is specified and tested, and deliberately NOT wired, because neither plane holds a trustworthy publish verdict today

This is the finding of the session, and it is written down rather than papered over.

Dark matter is **derived**, never stored (ADR 0182 D1/D4): a project with no `name` or no
`description` is off the map. To lock the door on it, the door needs that verdict. Both
candidate sources were checked and **both are wrong today**:

1. **The instance cannot derive it.** The publish gate is `name` + `description`; the
   instance's branding pack carries neither. `description` is never pushed — `settingsEnvVars`
   emits `SETTINGS_VOCAB` keys only, and D4 explicitly forbids repurposing `copy.tagline`
   ("editing your card would unpublish your project"). Pushing a *derived* `publishable`
   was rejected on staleness: publishability changes when the owner edits their
   description, which fires no settings push, so a project would sit `locked` after the
   owner had already fixed it — fail-closed in the one direction with no cure.

2. **The hub's copy says every live project is dark matter.** `platform_identity_projects`
   is a **cache** (D5) and the report that fills it is R08 (task 1002327), unshipped. The
   live catalog was read while writing this ADR: **every** row — including the two featured
   ones — has `description: null`, so `publishable: false` on all of them. Enforcing
   `locked` at the hub's join relay off that column would have refused **every join on the
   platform**, immediately.

So `publishable` is a deliberate **tri-state**: `false` locks, `true` opens nothing on its
own, and `null`/undefined means **no verdict** — the same word `provisioning.publishVerdict`
already uses when the `project.publishGate` port is absent. The instance door passes no
verdict and is answered on the three stored knobs alone. The full four-state matrix is
implemented and tested at both the pure and route layers, so wiring the verdict later is
one argument, not a redesign.

What it needs is a verdict that is **live and correct on the plane the door runs on** —
`provisioning_instances.description` is exactly that (the platform holds it, and
`publishVerdict()` already reads it through the kernel port), reachable as a provisioning
seam the way `provisioning.projectPlanets` already is. That is filed, not smuggled in here.

## Decision 5 — The hub relay learns the new code, so it cannot lie about someone else's door

`joinRelayOutcome` maps a project's answer into the hub's own words, and anything it does
not recognise becomes a **502 "the project could not be reached"** — the precise lie ADR
0194 D5 forbids. `not_published` is therefore added to its map and to `RELAY_SENTENCE`
now, with the code, rather than when the verdict is wired.

## What was deliberately not built

- **No manage-page control for the grant.** The setting is API-complete and the vocabulary
  drives `GET …/settings` `options`, so the section is a rendering task; R14 (task
  1002333) proves the behaviour through the API. Adding a fourth fold to a page whose
  three existing ones already answer three confusable questions is a design decision, not
  a side effect of this one.
- **No change to the sign-in gate.** See Consequences — this is the known limit, not an
  oversight.
- **No new column, no migration.** The jsonb settings store is a dumb store with room, and
  D1's whole point is that a derived state must never be stored.

## Consequences

- The join/apply door is enforced, from one function, on every surface that funnels into
  the public `POST /access-requests` — the hall's landing form, the CLI, and the hub's
  join relay all inherit it without changing.
- **Nothing changes for any existing project.** Every live project is `visibility=public`,
  and the new knob defaults to the value that narrows nothing.
- **KNOWN LIMIT — the door narrows, the sign-in gate does not.** `openEnrollmentEnabled()`
  is still `joinabilityMode() === 'open'`, so an owner who sets `private` *and* leaves
  `joinability: open` gets a door that queues applications while a first-time sign-in
  still self-enrols. D6's *self-join* column therefore holds only where the owner has not
  explicitly opened enrolment. Closing it means composing the ceiling into
  `src/bongos/auth-admission.js`, a kernel admission surface this task was scoped out of
  touching; it is filed with the dark-matter verdict above. The direction of the gap is
  worth naming: the door is **stricter** than the gate, never looser, so nothing is
  admitted that the owner's own `joinability` did not already admit.
- `src/bongos/project-door.js` joins `KERNEL_FILES` — the doorway re-exports it, so
  leaving it off would read as a kernel→non-kernel leak, and being on the roster holds it
  to the kernel import rule, which is the point for a file that decides who may knock.
- The doorway gains one additive export. Per ADR 0194 D7 it rides the next CI patch rather
  than a hand-bumped MINOR (the publish lane's LIVE test refuses a version its own carrier
  commits never announced); `modules/onboarding/module.json` floors at the newest announced
  version, which is the closest honest floor that prohibition allows.

## Alternatives rejected

- **A fifth door value for stealth, with its own copy.** Rejected: two doors that behave
  identically and *say* different things are a state read-out, and stealth's is the one
  state that may not be read out (D2a).
- **Composing the ceiling into the pushed `joinability` at the platform, so the instance
  needs no new reader.** Tempting — every surface would follow for free — but it makes the
  stored setting and the pushed value disagree, breaks the manage page's "did my save take
  effect?" read-back (ADR 0194 D1), cannot express `locked`, and would have to compute a
  publish verdict at push time, which is Decision 4's staleness trap.
- **Enforcing dark matter at the hub relay off `platform_identity_projects`.** Rejected on
  the live data: it refuses every join on the platform today (Decision 4).
- **Making the composed door fail to `locked` when the pack is unreadable.** Rejected: it
  contradicts ADR 0194 D2 for no safety gain, and it tells an applicant a specific untruth
  about the project's publication state.

## Amendment — 2026-09-17 (task 1003578): the verdict is wired at the hub relay, from the provisioning row

Decision 4's filed follow-up, built the way it named. `modules/provisioning/seams.js` provides
`provisioning.<redacted>` (`{ slug, host }` → `{ name, description }` or `null`),
keyed on both halves of the ADR 0246 projection like `provisioning.projectOwnedBy`. The hub's
`POST /my-projects/join` asks it before relaying and judges the answer with its own
`projectPublishability`, so the mapping stays in provisioning and the rule stays in the hub.
A positive `publishable: false` answers `not_published` with no relay and no echo.

Everything else is still **no verdict**, per Decision 4's tri-state: no port, no provisioning
row (a self-hosted or hand-seeded project, whose hub copy remains a cache) or a failed read.
The request is relayed as before, because relaying grants nothing and a refusal on a guess
would be an untruth about someone else's project. The instance's own door is unchanged: it
still passes no verdict, so an applicant arriving at the project directly is answered on the
stored knobs alone. The rejected alternative above still stands. This reads the provisioning
row, not `platform_identity_projects`.
