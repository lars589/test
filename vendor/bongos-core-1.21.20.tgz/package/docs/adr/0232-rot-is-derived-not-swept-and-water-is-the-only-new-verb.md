# 0232 — Rot is derived, not swept; and `water` is the only new verb

- **Status:** Accepted
- **Date:** 2026-09-02
- **Tasks:** [#1003279](https://cloudbongos.com/builders#/task/1003279)
- **Goal:** [#1000072](https://cloudbongos.com/builders#/goal/1000072) — Human legibility, criterion `legibility-sort-and-staleness`.
- **Completes:** [ADR 0226](0226-one-stale-timer-reporting-degrades-enforcement-refuses.md), which split the *claim* timer out of this task and recorded that "1003279 stays open for its inbox half". This is that half.
- **Builds on:** [#1003278](https://cloudbongos.com/builders#/task/1003278) (the shared *task* staleness vocabulary the boards use — §3 below is why this reuses its definition rather than writing a second one).
- **Unblocks:** [#1003280](https://cloudbongos.com/builders#/task/1003280), whose settings page needs the timer to be "live, DB-backed" and warns "do not fork a second store". §4 is that store.

## 1. What the owner decided, and what was rejected

Goal 1000072's rotting half asks that "untouched-for-X triggers a configured action
rather than a silent decay". The owner's decision (2026-08-25) fixed *what the action
is*: a **needs-attention item** — one line in the hall's existing inbox, addressed to
whoever created the thing and to the owner, offering four human verbs: **prune, kill,
prioritise, water** (water = leave it, and reset the clock). Nothing changes status on
its own; a human decides.

Two alternatives were rejected, and the reasons matter because both are the obvious
implementation:

| Rejected | Why |
|---|---|
| Auto-demote a stale thing to a review queue | It mutates real work with no human in the loop, and a wrong timer then silently freezes it. The failure is invisible: nobody notices work that stopped being offered. |
| A nightly digest | A notification is not an action. It gets scrolled past, and a digest you scroll past is indistinguishable from the silent decay it was meant to fix. |

## 2. The decision that shaped everything else: **rot is derived, not swept**

The task's own build note asked for "a poller/routine that is idempotent (one open item
per stale thing, not one per sweep)". That requirement is real — an inbox that accretes
a duplicate line per sweep is unusable within a week — but the sweep is not what
delivers it, and building one would have made the requirement *harder* to satisfy.

**There is no `attention_items` table and no poller.** A line is a `SELECT`: the thing's
rot clock compared against the timer, evaluated at read time. Everything the owner's
note asks for then falls out of arithmetic rather than out of code that must be written
correctly and then stay correct:

- *exactly one item per stale thing* — a row either satisfies the predicate or it does
  not; there is nothing to duplicate.
- *the item clears when the thing is touched* — a real edit moves `updated_at`.
- *the item clears when it is decided* — prune/kill/prioritise change `status`, and the
  status filter stops matching.
- *water resets the clock* — the water mark is a term in the clock.

There is also no window in which the inbox and the database disagree, no reconciliation,
and nothing to garbage-collect. **A stored item would have been a cache of a query whose
inputs it could not observe** — and keeping that cache honest is precisely the class of
bug the sweep was being asked to avoid.

The cost, stated plainly: the rot list is computed per request rather than materialised.
That is affordable here because the predicate is indexed (`idx_tasks_attention_rot`,
`idx_goals_attention_rot` in migration `core_231`) and the read is capped. If the corpus
ever outgrows it, the fix is a materialised view over the same predicate — still not an
items table, because the derivation is the part worth keeping.

## 3. What can rot — and the exclusions, which are the load-bearing part

Rot is **work nobody has picked up**, not work in flight. Tasks at `backlog` or `ready`;
goals at `open`. Every exclusion is excluded because *another surface already owns that
question*, and two surfaces asking one question with two different timers is exactly the
failure [ADR 0226](0226-one-stale-timer-reporting-degrades-enforcement-refuses.md) was
written to end:

| Excluded | Who owns it instead |
|---|---|
| `active` | the **claim-silence timer** (`src/stale-timer.js`) — the sweeper releases it, the Archon roster reports it |
| `blocked` | the blocker, and `/blocker-review` as its cadence |
| `completed`, `confirmed` | the ship pipeline — the publish reconciler and the "Stranded ships" line |
| `shipped`, `abandoned` | terminal; nothing rots after it is done |

`active` is the one that would have been easy to get wrong, and the one that matters
most: a claimed-but-quiet task is *already* reported, in hours, by a surface that acts
on it. Reporting it again here, in days, would have put the same rot in two inboxes
under two numbers — re-creating the 6h-vs-24h split one tier up. `tests/rot_inbox.mjs`
asserts the exclusion directly, so a later "why isn't my active task listed?" cannot be
fixed by deleting the reason.

**The clock is not a new definition of "touched".** `modules/hall-ui/public/task-lib.js`
already publishes one for the boards (task 1003278): `max(updated_at, shipped_at)`,
folding in `shipped_at` because a ship path can stamp it without touching `updated_at`.
This adds a third term and nothing else:

```
tasks:  GREATEST(updated_at, COALESCE(shipped_at, updated_at), COALESCE(attention_watered_at, updated_at))
goals:  GREATEST(updated_at, COALESCE(attention_watered_at, updated_at))
```

Had the server invented its own two-term clock, the board and the inbox would disagree
about which rows are stale. Two tests pin this: one asserts the domain's expression
appears **verbatim** in the migration's index expressions (drift there is silent — the
query simply stops using the index), and one asserts `task-lib.js` still defines
"touched" the way the server assumes.

## 4. The timer is DB-backed, and it is a *second* timer on purpose

ADR 0226's whole subject is that one question must have one answer. So adding a second
timer needs a defence, and it is that these are **two questions**:

| | claim-silence (`src/stale-timer.js`) | rot (this ADR) |
|---|---|---|
| measures | a builder who went quiet | work nobody picked up |
| unit | hours | days |
| configured in | env (a redeploy) | `project_settings` (a live knob) |
| consequence | the machine **releases** the claim, alone | the machine **asks** a human |

The store is a generic key/value table rather than a column per knob, because task
1003280 puts five fundamentals on one page and a knob-per-migration would make that page
a schema change every time. `project_settings` is created here, unseeded: **no row means
"never configured, use the code default"**, which is what lets a fresh instance boot on
an empty table and what lets the settings page tell "never touched" apart from
"deliberately set to the default value".

Precedence mirrors ADR 0226 exactly — `override` (a per-request lens, never written
back) > the DB row > the code default — and so does the **fail posture**, on the
reporting side of that ADR's asymmetry: a value that fails its range check degrades to
the default **with a receipt**, which the inbox renders in its own heading. A typo shows
up on the screen of the person who can fix it instead of 500-ing the inbox they were
using to find the problem. One case is deliberately *not* treated as a bad value: an
unreachable database is a failure to read, not a misconfiguration, and it must not blame
the operator for something they did not type.

## 5. Three of the four verbs add no authority to the system

Only `water` is a new route. `prioritise`, `prune` and `kill` reuse `POST
/tasks/:id/promote`, `/demote` and `/abandon` (and `/goals/:id/archive`) — the precedent
the nod slice set in this same card (task 1003066), and the reason three quarters of
this feature introduces no new permission at all.

The verbs are **served with each row** rather than hardcoded in the client. That is not
decoration: the tier→verb mapping already differs (a goal gets two verbs, because
promote/demote are task-lifecycle transitions a goal has no equivalent of), and a
hardcoded list in the hall would be a second copy of that mapping, free to drift into
rendering a button the server refuses. A test asserts every advertised verb names a
route that actually exists.

`water` itself is gated on **ownership OR the atom**: the creator may always water their
own line, and `builder.roster.read` — "may read another builder's record off the roster",
the atom `/builders/:id/active-claims` already carries — covers the owner. That check
runs *inside* the handler rather than as middleware, because a creator holding no atom
must still get through, and a gate mounted in front would refuse them before ownership
is known. It fails closed: no governance port means no permission (ADR 0016).

## 6. Consequences

- The hall's needs-attention card gains one slice, `#attention-rot`, placed last: every
  slice above it is somebody waiting on you *now*, while rot has already waited weeks.
- `project_settings` exists and has exactly one key. Task 1003280 adds rows, not tables.
- `tasks` and `goals` each gain two nullable columns. No backfill: never-watered is the
  honest state for every existing row.
- The rot list is per-request. §2 names the escape hatch if that ever stops being cheap.
- **A future third timer needs its own ADR.** §4 is the template for defending one: name
  the question, the unit, the store and the consequence, and show they differ from both
  of the existing two. If they do not, it is not a new timer — it is a second answer.
