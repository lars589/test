# ADR 0356 — A recruit invite expires 30 days after it is sent, decided at read time

- **Status:** accepted
- **Date:** 2026-09-30
- **Task:** [task 1002969](https://cloudbongos.com/builders#/task/1002969) (goal 1000110)
- **Builds on:** privacy spec D4 (`docs/specs/<redacted>.md`; the owner signed the 30 days), [ADR 0335](0335-an-invite-is-a-pre-approved-row-on-the-projects-own-instance.md) D2 (an invite is a `kind='invite'` row on the project's own instance), [ADR 0353](0353-a-hub-invite-is-a-notice-of-the-projects-own-invite.md) (the hub's `pending` row is a notice of that invite)
- **Amends:** ADR 0335 D2.5 ("no admission path reads `kind`")
- **Decided with:** the owner split the original task on 2026-09-30. `seen_at` is [task 1004443](https://cloudbongos.com/builders#/task/1004443); the decline relay is [task 1004444](https://cloudbongos.com/builders#/task/1004444).

## Context

An invite writes an `invited` row, and the sign-in gate admits any login holding one. Nothing ever closed it, so an invite sent months ago still let its login walk in. Spec D4 says a recruit invite's door closes after 30 days, enforced when it is read: no sweeper and no cron. ADR 0353 left the hub side of the same question to this task, because an expired invite's hub notice still said "Open project →".

## Decision

**D1 — One definition, computed at read time.** `src/bongos/invite-expiry.js` holds `INVITE_EXPIRY_DAYS` (30) and the SQL for "this row is an invite past its window", `kind = 'invite' AND created_at <= now() - interval '30 days'`. The sign-in gate (`hasInvitedAccessRequest`), the waiting-page probe (`accessStateByLogin`), the onboarding routes and the hub all read it: core directly, and modules through the doorway's `inviteExpiry`. Nothing is stored, so the day a door closes cannot drift between readers, and nothing has to run for it to close.

**D2 — Only invites expire.** An approved application (`kind = 'application'`) stays open: its applicant asked, and D4 is about invites. Goal invites get no expiry either.

**D3 — The gate now reads `kind`, and only to be stricter (amends ADR 0335 D2.5).** D2.5 kept `kind` out of admission because it was descriptive. It is now read in one place, inside the expiry unit, and that unit can only close a door. A row that is anything but an invite behaves exactly as before, so a mis-kinded row fails toward the old gate and never past it. Only server code writes `kind`: the public POST cannot set it. `created_by` is still never read. `tests/application_lifecycle.mjs` enforces both: its admission statements may mention `kind` only inside the expiry unit.

**D4 — What an expired invite looks like.**
- The gate refuses it. The public "already approved?" check and the standing-invite probe no longer count it, so the invitee may apply and the recruiter can re-invite.
- A re-invite writes a fresh row, which opens a fresh door. The expired row stays as history.
- The queue marks it `expired` with `expires_at`. The outstanding-invite list keeps it so the sender knows to invite again, and drops it once a newer invite for that login is live. The hall's queue shows "Invite expired" and offers no rescind.
- The public status probe answers `expired` (`admitted: false`), and `bongos login` stops waiting on it. An older CLI treats an unknown status as "wait" and times out, which is no worse than before.
- A rescind that leaves only expired rows clears the hub notice.

**D5 — The hub's notice follows the door.** `listPendingInvitesForAccount` hides a `pending` notice older than the same 30 days (its `joined_at` is when the project sent the notice). `inviteToProject` restamps `joined_at` only on a `pending` row that is already past the window, so a re-invite shows again. A re-send while the invite is live changes nothing, and a real membership is never touched.

## Consequences

- **Invites already older than 30 days close at deploy.** That is the spec's rule applied to existing rows. Their senders re-invite.
- **Wire skew (ADR 0352).** A newer hub with an older instance hides a notice after 30 days while that instance's door stays open. Only the nudge is lost. An older hub with a newer instance keeps showing an expired notice, which is today's behaviour.
- **The hub's clock is the notice's, not the invite's.** A notice healed by a late re-send (the hub missed the first) can outlive its invite by up to the gap between them. A lost clear can hide a live notice early. In both cases the next re-invite fixes it.
- **The outstanding list's cost stays that of its own scan.** "Does this login have a live invite" is a window (`bool_or … OVER (PARTITION BY lower(github_login))`) over the rows the list already reads, not a correlated lookup per row: `access_requests` has no index on `lower(github_login)` outside pending rows, and invite rows are kept as history. The sender filter (`?mine=1`) sits outside the window. Migration `core_266` adds the index those reads lacked, partial on `status = 'invited'` over `lower(github_login)`, which serves the sign-in gate, the standing-invite probe and this list. The owner approved it on 2026-09-30 after a grader finding.
- **Declining still closes only the hub's notice.** The project's row stays open until it expires. Task 1004444 owns the relay.

## Alternatives considered

- **A sweeper that flips expired rows to `dismissed`.** Spec D4 rules it out. It would also mislabel an expiry as a decline in the history.
- **Expire every `invited` row, applications included.** That is wider than D4, and at deploy it would lock out every applicant approved more than 30 days ago.
- **Dismiss the expired row when re-inviting.** That keeps the list tidy, but the hall renders `dismissed` as "Declined", which would be false.
- **Carry the invite's `created_at` to the hub in a header, making its clock exact.** That is a new wire field on the notify route for an edge case a re-invite already heals.

Proof: `tests/invite_expiry.mjs` (the definition), `tests/application_lifecycle.mjs` (the gate, queues, probe, re-invite and notice clear, interpreted), `tests/invite_expiry_db.mjs` (the same statements on real Postgres, plus the hub's notice), `tests/hub_invite_notices.mjs` and `modules/platform-identity/tests/platform-identity.mjs` (the notice statement's shape), `tests/bongos_login.mjs` (the CLI stops on `expired`).
