# ADR 0308 — An eleventh working area: Autobongos

**Status:** accepted · **Date:** 2026-09-17 · **Task:** [task 1003900](https://cloudbongos.com/builders#/task/1003900) (goal 1000119 — BONGOS-V2)

**Amends:** [ADR 0264](0264-the-ten-working-areas.md) (the ten working areas, held until 5,000 builders)

**Related:** [ADR 0307](0307-autobongos-a-deterministic-supervisor-and-agentic-workers.md) (what the area actually builds) · [ADR 0250](0250-strict-versioning-the-version-boundary-is-the-scope-gate.md) (the version boundary that had to be reopened to admit it) · [ADR 0086](0086-goal-scoped-work-hierarchy.md) (the goal tier)

## Context

[ADR 0264](0264-the-ten-working-areas.md) collapsed thirty-eight open goals into
**ten working areas, one goal each, held until the platform has 5,000 builders**.
Ten was chosen so that every area has a single owner who can hold its whole shape
in their head, and the horizon is a scale question rather than a calendar one.

That ADR is nine days old. Adding to it needs a better argument than "here is
something else we want to build", because a scope that grows by exception is the
failure ADR 0264 exists to stop.

## The decision

**Autobongos becomes working area 11** — [goal 1000119](https://cloudbongos.com/builders#/goal/1000119) on BONGOS-V2.

> **11 · Autobongos** — *owner: Lars.* At 5,000 builders: a project owner points
> idle compute at goals they have allowlisted, and it builds unattended inside
> their subscription limits — stopping rather than guessing whenever a human is
> needed, and reporting what it did without being asked.

## Why this is an axis and not a feature of an existing area

The obvious home was **area 6** (Governor / Builder / Artist / Ideator
experience), whose 5,000-builder state already says *"Agents are designed to aid
all these roles."* It was considered and rejected, for one reason:

**Area 6 is about a human's experience of the platform. This area has no human in
it.** Its whole subject is what the system does across the hours when nobody is
watching — which limits it may spend, which fences hold without supervision, how
it recovers from failure with nobody at the keyboard, and what it owes the owner
the next morning. Those questions do not get better answers by being asked
alongside "how do we keep the Artist's surface from breaking into the Ideator's".
They get less attention, because they compete with work that has a user in front
of it.

Area 4 (core distribution) was the other candidate and is a worse fit still — it
would file autonomous building as a shipping-cadence tool, under a goal about how
core updates reach instances.

## It reopens a closed goal rather than inventing a new one

[Goal 1000028 — *Autonomy groundwork*](https://cloudbongos.com/builders#/goal/1000028)
(*"safe unattended routines — guardrails first, then arm the safe set"*, criteria
`gcarry-auto-guardrails` and `gcarry-auto-armed`) was archived in the 38→10 cut
**with no successor**. Goal 1000119 carries `succeeds_goal_id: 1000028`, so the
lineage is in the ledger rather than in this prose: the eleventh area is a
reopening, not a new axis nobody had thought of.

That is also the honest reading of what happened. ADR 0264 §3 left three goals
*"not covered by the review"*, one of them explicitly marked **"needs an owner
decision: fold, keep as an eleventh, or close."** The eleventh slot was a live
question in the ADR itself, not a door this one forces.

## What it cost to admit, and why that is recorded

BONGOS-V2 is `building`, so its goal set is **closed** ([ADR 0250](0250-strict-versioning-the-version-boundary-is-the-scope-gate.md)):
`POST /goals` refuses with `version_not_planning`. An Archon may reopen it, but
only by writing an `admit_reason`, which is stored against the goal with who
admitted it and when.

Goal 1000119 therefore carries a permanent admission record. This is the gate
working, and it is the answer to "does an eleventh area mean the cut did not
hold": the cut held well enough that adding to it left evidence.

## What this does not decide

- **The ten-area discipline stands.** This is one exception with a written
  reason, not a return to a board that grows on request. The 5,000-builder
  horizon is unchanged, and areas 1–10 are untouched.
- **It does not settle ADR 0264 §3's other two open rows** — goal 1000065
  (community surface) and goal 1000088 (repo cleanup) are still open questions.
- **It does not give the area a second goal.** One goal per area is the rule that
  makes ten legible, and eleven is only legible under the same rule.

## Consequences

- The board is twelve rows: eleven areas plus maintenance.
- ADR 0264's §1 table is now incomplete on its own, so it links forward to this
  record. A reader who finds 0264 first is not left with a stale ten.
- The next area proposed has a precedent to argue against, which is the point of
  writing the reasoning down rather than just the outcome.
