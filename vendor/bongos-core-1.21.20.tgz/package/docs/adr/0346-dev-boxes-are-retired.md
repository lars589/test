# ADR 0346 — Dev boxes are retired; a builder builds from their own checkout

- **Status:** accepted
- **Date:** 2026-09-28
- **Task:** [task 1003898](https://cloudbongos.com/builders#/task/1003898) (goal 1000120 — Dev-box removal)
- **Deciders:** Lars (Archon) decided the removal and its three rulings on 2026-09-13. Claude carried out the removal and wrote the record.
- **Supersedes:** [0031](0031-cloud-dev-environments-for-builders.md) · [0044](0044-per-box-live-game-preview.md) · [0045](0045-devbox-desktop-app.md) · [0053](0053-scoped-dev-box-session.md) · [0057](0057-container-cost-ledger.md) · [0059](0059-single-approval-remove-devbox-approval-gate.md) · [0071](0071-box-confirm-before-destroyed-and-drift-reconcile.md) · [0072 (code staleness)](0072-dev-box-code-staleness-visibility.md) · [0123](0123-box-idle-sweep-autosave-before-destroy.md) · [0144](0144-devbox-rehome-onto-cloudbongos-plane.md) · [0145 (desktop-app branding)](0145-devbox-app-branding-driven-module.md) · [0148](0148-task-scoped-box-source-access.md) · [0193](0193-pause-task-scoped-box-slices.md) · [0277](0277-a-box-is-in-use-only-while-a-human-is-attached.md)
- **Supersedes in part:** [0035](0035-builder-onboarding-three-paths.md) (the DO-box path) · [0046](0046-sandbox-first-review-gate.md) (the box half) · [0052](0052-sandbox-for-everyone-game-only-preview.md) (the box half) · [0055](0055-server-mediated-branch-publish.md) (the box as its reason; the mechanism survives) · [0072 (Bongos app)](0072-bongos-app-mac-signed-first-windows-deferred.md) (absorbing the Dev Box app) · [0151](0151-governance-permissions-as-atom-ranks-as-roles.md) §3 (the narrowing session scope)

## Context

ADR 0031 gave every builder a hosted cloud machine, the **dev box**: a DigitalOcean droplet built from `.devcontainer/`, switched on and off by a desktop app (0045), reached over SSH or a browser terminal, holding a box-scoped session (0053) and a task-scoped sparse checkout (0148), swept when idle (0123), and landing its work through the server because it held no push credential (0055). It grew to roughly 22,000 lines, and about a third of it lived in the core rather than in `modules/dev-box/`.

By 2026-09-13 it had no users. The fleet was cold: 0 live droplets, 4 destroyed, 1 parked. `/downloads/devbox/*` already answered 404, because cloudbongos.com had no `config/devbox-app.json`. Every live builder builds from a checkout of the project repo on their own machine. The owner decided to remove it outright rather than keep maintaining it.

## Decision

We removed the dev box and everything that existed only for it. What a builder does instead is the path that already worked for everyone: **clone the project repo, sign the CLI in with `/builder-setup`, and build locally** (`/builder-stage` for a local preview). A cloud replacement, such as Claude's own cloud sessions working from a clone, is separate later work and is deliberately not designed here.

**The owner's three rulings (2026-09-13):**

1. **Drop the box's stored data now.** The historic box compute spend is not worth preserving as box state.
2. **Delete `.devcontainer/`** with the rest. It was the box as code; a later cloud plan defines its own environment.
3. **Remove `bongos box`, `bongos shell` and `bongos code` entirely**, including their Metic-only `--local` modes.

**What was removed** (goal 1000120, one linear chain, each link leaving `main` green):

| Task | Removed |
|---|---|
| [1003889](https://cloudbongos.com/builders#/task/1003889) | the three CLI verbs |
| [1003890](https://cloudbongos.com/builders#/task/1003890) | the Harbor page, the box panel and the pair page |
| [1003891](https://cloudbongos.com/builders#/task/1003891) | the Electron desktop app, its CI workflow and download route |
| [1003896](https://cloudbongos.com/builders#/task/1003896) | `.devcontainer/` |
| [1003893](https://cloudbongos.com/builders#/task/1003893) | the box control-plane and bring-up scripts (`scripts/gds/box*`, `infra/box-*`), with the last box recipe |
| [1003892](https://cloudbongos.com/builders#/task/1003892) | `modules/dev-box/` and its registrations |
| [1004310](https://cloudbongos.com/builders#/task/1004310) | desktop-app pairing, the onboarding box step, and box fields in the core API |
| [1004311](https://cloudbongos.com/builders#/task/1004311) | the hall's box surfaces, preview fixtures, and the DEV BOX subgraph of the architecture diagram |
| [1003894](https://cloudbongos.com/builders#/task/1003894) | the box session scope and `box.source.full` / `box.fleet.manage` / `box.manage.own` (migration `government_019`) |
| [1003895](https://cloudbongos.com/builders#/task/1003895) | `builder_boxes`, `box_events`, `box_intents`, `builder_ssh_keys` and the `'box'` session source (migration `core_258`) |
| [1003897](https://cloudbongos.com/builders#/task/1003897) | the residual mentions in code, tests and fixtures |
| [1003899](https://cloudbongos.com/builders#/task/1003899) | (the fitness check that keeps it out) |

**Kept on purpose.** These were born for the box and are now load-bearing for everyone:

- **Server-mediated publish** (0055: `modules/lifecycle/github-push.js`, `publish-reconciler.js`, `POST /tasks/:id/publish-branch`, `ship-land.js`'s `ciLandServer`). It serves any checkout with no GitHub push credential. Only its reason changed.
- **`src/bongos-downloads.js`**, the `bongos` CLI binary downloads (the Dev Box app's own downloads were removed).
- **`src/bongos/secret-box.js`**, the AES secret store. It is unrelated to dev boxes despite the name.
- **`scripts/gds/do-api.js`**, which instance provisioning still uses.
- **The session-source registry** (`modules/government/session-scopes.json`). Its narrowing form had no user left and was removed (task 1003894). Its fail-closed rule, that a session whose source the registry does not declare is refused on every route and page, is what kept the leftover box tokens out until `core_258` deleted them.

**Deliberate retirement guards.** These still name the box, and that is correct:

- `RETIRED_MODULE_KEYS` in `src/modules.js`: an instance whose config still says `"dev-box": true` boots with a one-line warning instead of failing.
- `allowBoxScope` stays on the module doorway as a no-op until the next MAJOR. Removing an export is a MAJOR, and modules declare `^1`.
- `config/devbox-app.json` stays in the publish manifest's instance-exclude list, because instance repos still carry the file.

## Alternatives considered

- **Keep the module, switched off.** Rejected: a third of it lived in the core (auth, migrations, the ship path, the hall), so "off" still cost maintenance and review attention on every change near it, for zero users.
- **Replace it with a cloud-session product in the same goal.** Rejected by the owner: the replacement is its own design question, and coupling it would have held the removal hostage to it.
- **One big deletion.** Rejected in the 2026-09-27 re-scope: each link deletes its own tests and regenerates its own artifacts, so `main` stays green at every step and any one link can be reverted alone.
- **Drop the four `builders.box_blocked*` columns with the tables.** Deferred to [task 1004360](https://cloudbongos.com/builders#/task/1004360). A deploy migrates while the previous server is still up, and a failed upgrade rolls back code but never schema. Every previous core reads those columns in `getBuilderById`.

## Consequences

- A builder's only setup is a local checkout. The hall's welcome panel, the primer and the architecture diagram now describe that path. The welcome panel's own-machine steps had been hidden by a stylesheet rule written for the box's Desktop/Online toggle; they now show.
- Nothing user-facing regressed: the fleet was cold and the downloads already 404'd.
- Owner follow-ups outside the code: reclaim or verify absent the DigitalOcean and Cloudflare resources (task [1003887](https://cloudbongos.com/builders#/task/1003887), blocker 1000159, including the one parked droplet snapshot). Remove `"dev-box"` from each instance repo's `config/modules.json` and `config/devbox-app.json` when convenient; the retirement guard makes both harmless meanwhile.
- The historical ADRs above keep their bodies; each carries a status line pointing here.
