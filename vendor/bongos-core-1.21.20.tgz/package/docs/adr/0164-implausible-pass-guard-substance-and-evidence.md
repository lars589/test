# ADR 0164 — The implausible-pass guard reads substance + evidence, and the honor-system residual is explicit

- **Status:** accepted
- **Date:** 2026-08-11
- **Task:** task 1002658 (grader hardening, goal 1000056; evidence from the 14-agent grader evaluation)
- **Related:** ADR 0024 (the adversarial panel), ADR 0041 (Archon bypass floor), ADR 0042 (CI grade gate — deferred), ADR 0162 (no new human gates on the ship path)

## Context

`serverSideGuards` (modules/grading/grader.js) carries one plausibility check on the client-asserted grade: the `implausible_pass` guard. Its original form fired when a client PASS arrived with `issues.length === 0` on a non-trivial diff. The evaluation confirmed two structural defects:

1. **One fabricated `{}` defeated it.** The guard counted raw array length; a single junk element made a forged clean pass invisible. Worse, the magnitude inputs it reads (`diff_stats`, `committed_files`) are themselves client-supplied — the same forger authors them.
2. **Every real firing was a false positive.** Its in-sample firings (the eval's 2, task 1002643 twice, task 1002663 once) were all honest, unanimous, zero-issue panel passes on clean diffs — exactly the verdict a working panel produces on good small-to-medium work. The guard imposed its full manual-confirm cost on honest ships while offering ~zero adversarial value.

The structural constraint underneath both: **at grade time the server cannot re-derive the feature branch's diff** (the published tip is recorded at ci-land, after the grade). No client-arithmetic plausibility check can be made adversarially sound against a forger who authors every input.

## Decision

**1. Count substance, not entries.** An issue counts only when it has a known severity (`blocker|major|minor|nit`) and a non-empty summary (`isSubstantiveIssue`). An `issues[]` with entries but no substance is the *padded-issues forgery signature* and trips the guard regardless of anything else. This closes the `{}` bypass using only the submitted body — genuinely server-checkable.

**2. Waive the honest unanimous pass on panel evidence.** A zero-issue PASS on a non-trivial diff no longer downgrades when the submitted `signals.workers` carries the full per-worker panel shape (≥3 workers, each with a kind and a legal verdict or error tag — `hasPanelEvidence`). It stands, with an audit marker (`server_guard.implausible_pass_waived: 'panel_evidence'`) so /grade-audit can distinguish *waived* from *never evaluated*. A zero-issue pass with **no** evidence still downgrades to manual-confirm, as before.

**3. Name the residual instead of pretending to close it.** `signals.workers` is client-supplied; a determined Metic+ forger can fabricate the full panel shape. We accept this **explicitly as honor-system at grade time** for Metic+ builders, because the binding authorities on the *real* diff are land-time: the branch's CI `unit` run, the gate-review classification, and the post-push main audit — all of which read committed history the client cannot re-author. The grade-time guard's job is honest-mistake hygiene (a truncated body, a panel that silently didn't run, lazy padding), not adversarial defense. Sub-Metic builders remain covered by the hard guards (permission-path with its unprovable-input fail-closed branch, route-rank) which key on the server-known live rank.

**4. The CI grade-gate question goes to the owner.** ADR 0042's deferred CI-side grade gate (`grade-gate.yml` absent, `ci-grade.js` with zero callers) is the one mechanism that could move grade verification out of the client's hands entirely. Whether to land it or to correct ADR 0042 to record permanent deferral is an owner decision — filed as a GDS blocker from task 1002658, not decided here.

## Consequences

- The three confirmed false-positive shapes (unanimous zero-issue passes) now land without an Archon manual-confirm — removing the exact churn class that consumed panel rounds and human attention on tasks 1002643/1002663, and removing pressure to reach for the raw confirm.
- The lazy forgery class (`issues:[{}]` padding) is now caught; the sophisticated forgery class (full fabricated panel shape) is documented as accepted honor-system residual for Metic+, bounded by land-time authorities.
- No approval step was added or removed (ADR 0162): the change only re-aims an existing automatic downgrade.
- `server_guard.implausible_pass_waived` gives /grade-audit and /grader-health a queryable marker for zero-issue passes that stood on evidence.

## Alternatives considered

- **Gate on more client arithmetic** (worker cost/timing consistency, score-distribution checks): same trust hole — the forger authors the inputs; adds false-positive surface for no adversarial gain.
- **Drop the guard entirely:** loses the honest-mistake net (truncated bodies, silently-skipped panels) that costs nothing when the waiver works.
- **Block until a server-side diff exists at grade time:** requires restructuring ship so the server holds the branch before grading (the ADR 0055 server-mediated path does this for boxes) — the right long-term direction, but it is the CI grade-gate decision (owner blocker), not a guard tweak.
