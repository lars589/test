# 0195 — ADR numbers are checked like migration numbers, and the twenty existing collisions are grandfathered by name

- **Status:** Accepted
- **Date:** 2026-08-27
- **Deciders:** the builder on [task 1003164](https://cloudbongos.com/builders#/task/1003164)

## Context

Two ADRs could carry the same number and nothing flagged it. It happened for real on 2026-08-22: [task 1002483](https://cloudbongos.com/builders#/task/1002483)'s branch authored `<redacted>.md` while, three days into that branch sitting stranded at `completed`, [task 1003042](https://cloudbongos.com/builders#/task/1003042) landed `0181-teardown-state-gate-and-address-retention.md` on `main`. Merging `main` into the branch produced both files side by side.

**Git cannot see this.** The filenames differ, so there is no path collision and no merge conflict — git adds both cleanly. `docs/adr/README.md` auto-merges too, ending up with two `| 0181 |` rows, the incoming one placed out of the ascending order the index reads in. The `unit` gate, fitness, docs-entropy and the grader all passed. A human reading `ls docs/adr/` found it.

**The asymmetry that made this a bug rather than a gap.** Migrations already have exactly this protection. `migration-namespace.js` exports `stemCollisions()`, and `fitness.js` runs `checkMigrationNamespacing` as a hard failure — because a re-used migration number silently *skips* a migration, which the team correctly treated as unacceptable. ADRs got `next-number.js`, which computes the next free number for a claim card from a possibly-stale tree, best-effort, at claim time — and then nothing enforced it afterwards. Same shared, monotonic, human-allocated number line; one guarded, one not.

**Why it matters past tidiness.** An ADR number is a *citation target*. [Task 1000900](https://cloudbongos.com/builders#/task/1000900)'s close-rationale cited "ADR 0180" and, because of this collision, `0180` on `main` is *Dependency intake & drift policy* — an unrelated document. A reader following that citation lands nowhere near the ship gate it meant. ADRs cite each other by number throughout, and `docs/adr/README.md` is the index every agent is told to consult, so a duplicated number makes a citation ambiguous **forever**.

**What building the check revealed.** The bug report described one collision. The live tree held **twenty**, plus fourteen index defects the same merge class had produced: two ADRs listed twice (`0116`, `0117` — a merge duplicated the rows verbatim) and twelve ADRs with no index row at all. Ten of those twelve were the *second file of a colliding pair* — which is the mechanism by which a collision hides, since the file that never gets indexed is the one nobody sees. The hand-written "known collision" paragraph under the index narrated eight collisions and had fallen twelve behind reality: a record nobody checked, the shape [ADR 0184](0184-ship-requires-an-assurance.md) was written about.

## Decision

**We will check ADR numbers the way we check migration numbers — a hard CI failure — and grandfather the twenty existing collisions by exact filename rather than renumbering them.**

1. **`scripts/gds/adr-namespace.js`** is the ADR sibling of `migration-namespace.js`: pure functions over a file list and the index text, no disk, unit-testable. It exports `checkAdrNumbering()`, registered in `fitness.js` (Check 31) and therefore inside the required `unit` CI check — no new workflow.

2. **A number claimed by two files is a hard failure naming both paths**, unless that number's file set is *exactly* the frozen pair in `LEGACY_DUPLICATE_ADRS`.

3. **The index is checked by link target, not by number**: every ADR file has exactly one row, and every row points at a file that exists. This is one invariant covering all three real defects — the dangling row, the duplicated row, and the unindexed file.

4. **Row ordering warns, never blocks.** Ten legacy rows sit out of ascending order. Blocking would fail every PR for a mess nobody's diff created — the split [ADR 0189](0189-baseline-floors-and-the-freeze-detector.md) draws between declaration rot (hard) and inherited drift (warn).

## Alternatives considered

- **Renumber the nineteen newer halves so the tree is genuinely unique.** Rejected: renumbering breaks every existing citation to those numbers, which is precisely the harm this check exists to prevent, and `README.md` states the rule outright — a number, once assigned, is never reused. It would also rewrite nineteen files' git history for a cosmetic property no reader depends on, since each pair's two files are unambiguous by *name*.
- **Grandfather by number instead of by exact filename** (`0181` is simply exempt). Rejected: that permanently un-guards twenty numbers. A third ADR joining `0181`, or a rename of either half, would pass silently. Set-equality on filenames keeps the exemption exactly as wide as the history that earned it, and the list can only shrink.
- **A numeric cutoff, mirroring `LEGACY_BARE_CORE_MAX`.** Rejected: migrations could use a cutoff because the new namespace makes collision *structurally* impossible above it. Here a new ADR takes a number above the current max, so a cutoff would exempt every historical number while catching nothing that hasn't already happened — and a new file deliberately numbered `0050` would sail through.
- **Enforce "exactly one index row per ADR *number*"**, as the bug report proposed. Rejected: it cannot express a grandfathered pair, which legitimately has two rows. Keying on the link target says what we actually mean and catches strictly more.
- **Fix it in `next-number.js` instead** — make the allocator authoritative. Rejected: the allocator already exists and already tries. It runs at *claim* time against a tree that may be days stale, which is exactly how the `0181` pair happened; only a check at merge time sees both files.
- **Leave the check advisory** (warn, like the doc-comment gate). Rejected: this is the failure the migration check treats as unacceptable, one layer up, and a warning is what the situation already effectively had.

## Consequences

- A new ADR number collision now fails the `unit` gate, naming both paths and the remedy. The failure arrives on the PR that creates it rather than months later via a wrong citation.
- The index and the tree can no longer drift apart unnoticed: 214 files, 214 rows, checked on every PR. Adding an ADR without indexing it is now a build failure — a small new obligation on every ADR author, and the point.
- The twenty legacy pairs keep their filenames and their citations. They are listed once, in code, in a list that may only shrink; the prose paragraph that used to narrate them (and lagged twelve behind) now points at that list instead of restating it.
- Ten index rows sit out of order and stay that way, as warnings. Anyone reordering them is welcome to; nothing forces it.
- `docs/adr/README.md`'s `#` column now uses `NNNN-a` / `NNNN-b` for all twenty pairs, extending a convention that previously covered five of them.
