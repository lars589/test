# 0176. Private-repo standup: a per-repo read-only deploy key, minted with the owner's token

Date: 2026-08-17 · Status: accepted · Task: 1002735 (walk finding N4, idea 1000708)

> **Amended by [ADR 0350](0350-the-hub-holds-a-per-project-write-deploy-key-so-a-hosted-upgrade-reaches-github.md):** the hub now also holds a second, WRITABLE per-project key (`cloudbongos-pin-<slug>`), kept outside the checkout, so an upgraded pin reaches the repo without the owner's one-hour token. The pull key described here is unchanged.

## Context

A standalone instance's repo is cloned/pushed **once** with the owner's `repo`-scoped OAuth
token (ADR 0155), but its durable `origin` is the shared SSH deploy alias
(`instanceRepoRemote`, ADR 0125) because the recurring deploy — `git pull --ff-only origin
main` at every provision, and the pull-deploy reset between them — needs auth that never
expires. The shared key is not registered on repos the platform didn't create, so a PRIVATE
repo fails every recurring pull with GitHub's no-leak `Repository not found` (reproduced 3×
in the goal-1000032 walk, **including with a valid token stored** — finding N4). The create
wizard nevertheless advertised "create the repo yourself and adopt it" as the private-code
path: a promise the runner could not keep. Seen live on prod (`mercury`, 2026-08-17).

## Decision

When a standalone instance's `target_ref` repo answers **private** to the owner's stored
token, provisioning mints the instance its own GitHub **deploy key** and wires the repo
checkout to use it:

- an ed25519 keypair generated beside the checkout (`<root>/.git/cloudbongos-deploy-key` —
  untracked by definition, survives `git reset --hard`, dies with the checkout);
- registered on the repo via the owner's token as **`read_only: true`**, titled
  `cloudbongos-deploy-<slug>` (idempotent: a stale same-title key is replaced);
- `origin` re-pointed at plain `git@github.com:<owner>/<repo>.git` and
  `core.sshCommand` set to `ssh -F /dev/null -i <key> -o IdentitiesOnly=yes` **in the repo's
  own config**, so every future git op in that checkout authenticates with this key no matter
  which script runs it, and the shared alias's `~/.ssh/config` identity can never leak in.

Public repos take the unchanged shared-alias path — zero behavior change. Teardown
best-effort revokes the key by title. Pushes keep preferring the owner-token HTTPS URL
(task 1002317), which is why read-only suffices.

## Alternatives rejected

- **GitHub App installation token** (ADR 0133 gives instances an App): tokens expire hourly,
  so every unattended pull would need a minting sidecar or a platform round-trip — the wrong
  amount of machinery for a cron `git pull`, and self-host venues would depend on the hub.
- **Registering the shared platform key on the repo**: grants the whole platform durable
  access to the owner's private code with one shared secret; per-repo keys keep the blast
  radius to one repo, are revocable one at a time, and are visible to the owner in their own
  repo settings.

## Consequences

- Private repos work end-to-end for adopt, manual, and fresh standups whenever the owner's
  `repo`-scoped token is stored; without one, private standups still fail at git (the
  request-time refusal is task 1002909's preflight).
- The flip-to-private refusal on the manage page (task 1003045) stays until existing
  already-provisioned instances get the same wiring on flip — a follow-up task, since their
  origin still rides the shared alias.
  **Progress (2026-09-23):** the runner half has landed — task 1004167 let the wiring run
  before a flip (`intendedPrivate`), and task 1004193 added the `repo-private` intent whose
  runner leg wires the key and only then flips. Task 1003078 then added the route
  (`POST /provisioning/instances/:id/repo-private`) and the manage-page control that enqueue it,
  and the refusal is gone. **That route is owner-only** (owner decision, task 1004194): the
  runner acts with the owner's stored GitHub token whoever queued the intent, so an archon
  override would act on another person's GitHub account.
- Builder **dev boxes** of a private-repo project were parked here as out of scope.
  **Answered on hardware 2026-08-25 (task 1003247): a box CAN read the private repo, and the
  auth design needed no change.** The GDS-backed credential helper (`otb-git-credential`,
  task 1002907) fetches a per-request, per-LIVE-rank credential from `/box/source-access`, so
  `git ls-remote origin` succeeds against the private repo. ADR 0055's posture holds
  underneath it: that same credential is read-only, so `git push` still returns 403 `Write
  access to repository not granted`. The real gap was not box-side auth at all but a
  config-dir mismatch -- `box-source-fetch.sh` and the helper read the legacy
  `~/.config/otb/` while `/builder-reauth` writes to the branding `configDir`, so after a
  re-auth both presented a dead token and every git op died with the opaque "could not read
  Username". Task 1003252 fixed the four tracked `infra/box-*.sh` scripts; the two
  instance-owned consumers are task 1003253.
- `bongos upgrade --commit-pin` on a private instance pushes its pin via `origin` — now the
  read-only key, so GitHub refuses it and the pull-deploy reset can revert the bump.
  `upgrade.js` needs the owner-token push path (follow-up).
