# ADR 0097 — One active claim per session + a claim binds to a dedicated worktree

**Date:** 2026-06-29
**Status:** Accepted
**Track:** `internal` (development system / lifecycle)
**Task:** [#1642](https://example.com/builders#/task/1642) (GDS-V4)
**Amends:** [ADR 0049](0049-split-parallel-safety-contract.md) (the parallel-safety contract). 0049 fixed *cross-claim* parallel safety (two claims colliding); this adds the missing *within-session* invariant.

## Context — the commingled-ship hole

ADR 0049 made cross-claim safety honest: `git merge` is the authoritative collision detector for interactive builders, and `uniq_active_claim_per_task` guarantees two sessions can't both claim the same task. But it left one invariant unstated, and a real failure mode followed from it.

A single Claude Code session works inside **one git worktree**, and that worktree owns **one branch**. If a builder claims a second task from the *same* worktree, both tasks' commits land on that one branch. `/builder-ship` publishes the whole branch — so shipping the first task drags the second task's (unfinished, ungraded) commits along with it. The ship is *commingled*: two tasks' work ride out under one task's ship, the grader reads a diff that mixes scopes, and the second task's ledger is now a lie.

The only pre-existing "one claim" guard was `gateNewcomerClaim`: **Xenos-only**, **builder-scoped**, and **fail-open**. It kept a brand-new builder focused, but did nothing for a Metic/Archon (or even a graduated Thetes) running two claims from one worktree, and it keyed on the builder, not the worktree — so it couldn't express "one claim *per worktree*" at all.

## Decision

Two new rules, both at the lifecycle layer:

### 1. One active claim per session

`POST /api/gds/claims` refuses a new claim when the **same `creator_session_id`** already holds an active claim, returning `409 session_already_has_active_claim` whose body names the in-flight task (`active_task_id` + `active_task_title`) and the remedy. This generalizes `gateNewcomerClaim` from Xenos-only to **all ranks** and from builder-scoped to **session-scoped**.

- **Session-scoped, NOT builder-scoped — the load-bearing choice.** A builder legitimately runs many sessions in parallel, each in its own worktree with its own single claim (the `feedback_parallel_sessions_not_anomaly` memory; one human builder, many sessions, is the *norm* at current scale). Keying on the builder would break that norm — it would cap a builder at one claim across all their worktrees. Keying on `creator_session_id` (already on the claim row, set per-CLI-session) caps each *worktree* at one claim, which is exactly the branch-isolation invariant we need and nothing more.
- **Fail-CLOSED.** Unlike `gateNewcomerClaim` (fail-open — onboarding plumbing must never brick a claim), this is a *correctness* guard against commingled ships. If the session-active-claim lookup throws, the route REFUSES (`409 session_claim_check_failed`) rather than silently allowing a second claim through. The deliberate asymmetry: a flaky onboarding read should not block work, but a flaky concurrency read must not let a commingling claim slip past.
- **NULL-session handling.** A web claim (`bind_session=false`, [#616](https://example.com/builders#/task/616)) stores `creator_session_id = NULL` and is adoptable by any of the builder's CLI sessions. The guard **skips NULL sessions**: an incoming NULL-session claim is allowed (there is nothing to scope to), and a pile of existing NULL-session web claims never counts against any CLI session (the DB lookup filters to the same non-null session, and the pure decision double-checks `creator_session_id != null`). So web-claim-then-ship-from-any-terminal keeps working untouched.
- **The decision is a pure, exported function.** `shouldRefuseSessionClaim({ activeClaimsForSession, creatorSessionId })` lives in `modules/lifecycle/routes/claims.js` and is unit-tested DB-free (`tests/one_active_claim_per_session.mjs`). The route middleware (`gateOneActiveClaimPerSession`) is thin: resolve the session, look up its active claims, call the pure fn, translate refuse→409.

### 2. A claim binds to a dedicated worktree

The default claim flow (`.claude/skills/builder-claim/SKILL.md`) ensures the task runs in its **own** worktree (e.g. `EnterWorktree task-N`) so a builder never reuses a worktree that already owns a claim. This is the harness's job — the GDS cannot create worktrees — so it is enforced as skill guidance plus the server guard above: if the harness reuses a busy worktree, the server refusal is the backstop, and the documented remedy is a fresh worktree/session.

### DB defence-in-depth

`migrations/<redacted>.sql` adds a **partial unique index** `uniq_active_claim_per_session ON claims (creator_session_id) WHERE released_at IS NULL AND creator_session_id IS NOT NULL`.

- **Predicate divergence from the task spec, on purpose.** The spec cited `WHERE status='active'`, but `claims` has **no `status` column** — "active" is the table's `released_at IS NULL` convention (the row's lifecycle status lives on `tasks`). The index uses the real column.
- **Migration safety.** A unique index *fails to create* if existing rows already violate it, which would block deploy. The migration first heals any current violation (keep the earliest active bound claim per session, close the rest — the same shape as migration 174), so the `CREATE` always succeeds; it is idempotent. The **app-layer guard is authoritative**; the index is belt-and-braces and must not break deploy.

> **Amended 2026-08-06 (task 1002570 / `core_204`).** The index as shipped was *stricter* than the worktree-scoped guard above: keyed on `creator_session_id` alone, it refused at the DB layer the second-worktree parallel claim the guard deliberately allows — breaking the many-sessions-per-builder norm this ADR set out to preserve. `migrations/core_204_rekey_active_claim_per_session_worktree.sql` re-keys it to `(creator_session_id, COALESCE(worktree_name, ''))` under the name `uniq_active_claim_per_session_worktree`, same partial predicate, so the backstop now enforces exactly the guard's boundary. The `COALESCE` fold (rather than PG15's `NULLS NOT DISTINCT`) is load-bearing: a plain composite index treats NULLs as distinct, so two worktree-less claims off one shared clone would both insert and re-open the commingling hole. A `23505` from either index generation surfaces as `session_already_has_bound_claim` (task 1002589), never the false `ALREADY_CLAIMED`.

> **Amended 2026-08-11 (task 1002522) — the guard and the index now fold tree identity identically.** `core_204`'s key folds `NULL` and `''` together (`COALESCE(worktree_name, '')`); the guard compared raw values, where `'' !== null`. So a claim sent with `worktree_name: ""` (the route caps the length but never required non-empty) was waved through beside a worktree-less claim and *then* refused by the index — a `23505` on a task nobody had taken. `db.foldWorktreeName` is now the single normalization: it folds empty/whitespace-only to `NULL` and trims, and it is applied at **every ingest point** (`claimTask`, `claimTasksBatch`'s prefix, and `shouldRefuseSessionClaim`), so stored names are always trimmed-or-`NULL` and the guard's comparison of stored rows is exact by construction. Pinned DB-free in `tests/one_active_claim_per_session.mjs`.
>
> Two things were checked and deliberately left alone. **The stale-claim sweep needs no re-tuning** now that one session may hold N claims: both the heartbeat (`session_pulses`, PK `claim_id`) and the sweep (`modules/sessions/pulse.js sweepStaleClaims`) are keyed per *claim*, never per session, so each parallel worktree's claim ages out on its own clock. **One residual divergence remains**, tracked as [#1002709](https://example.com/builders#/task/1002709): V3.R51 disambiguation renames a colliding `worktree_name` (`"wt-a"` → `"wt-a-2"`) while the CLI keeps sending the original, so guard and index both key on a name the caller never used — a second claim in the *same* real tree can slip past both. Closing it needs the requested name persisted (a schema decision), which is why it is a follow-up rather than part of this amendment. **That follow-up landed — see the next amendment.**

## Consequences

- A session can hold at most one active claim — commingled ships are structurally prevented, not just discouraged.
> **Amended 2026-08-19 (task 1002709 / `core_221`) — the residual divergence above is closed: the guard keys on the REQUESTED worktree name.** V3.R51 disambiguation silently renames a colliding `worktree_name` (`"overnight"` → `"overnight-2"`), which is correct and load-bearing — `.claude/worktrees/<name>` is a filesystem path and two live builders pointing at one would stomp each other. But both halves of the rule then keyed on the **stored** name while `scripts/gds/claim.js` keeps sending the **real directory** name, which is never renamed. So a second claim from the same session in the same tree compared `"overnight"` against the stored `"overnight-2"`, read them as two trees, and was allowed by the guard *and* the index: one working tree, one branch, two active claims — precisely the commingled ship this ADR exists to prevent. Reachable for any fixed reusable name (the overnight builder, box workflows, a hand-passed `--worktree`).
>
> `claims.requested_worktree_name` now stores what the caller asked for, and the guard (`shouldRefuseSessionClaim`) plus the re-keyed index `uniq_active_claim_per_session_requested_worktree` both key on it. **Two names, two jobs, and keeping them apart is the point:** `worktree_name` is the disambiguated name on disk and stays globally unique across active claims (branch naming and the operator surfaces read it); `requested_worktree_name` is the identity of the working *tree*, which is what "do these two claims share a tree" actually asks.
>
> **Why a stored column and not a cleverer guard.** Matching `^<requested>-\d+$` would refuse a builder genuinely running worktrees `foo` and `foo-2` side by side — reintroducing exactly the false refusal this family of amendments (1002570, 1002589, 1002522) keeps having to undo. The guard needs the name the claim was *filed* under, and that was simply never recorded.
>
> **The migration deliberately UNDER-heals, and that is a decision rather than an oversight.** After the backfill copies `worktree_name` across, a pre-existing commingled pair (stored `overnight` + `overnight-2`, one real tree) and a legitimate pair (stored `foo` + `foo-2`, two real trees) are **indistinguishable** — the requested name was never recorded, which is the whole bug. Any heuristic able to close the first would also silently close the second, killing an active claim of a builder who did nothing wrong, and a migration acts without asking. So pairs already in flight stay in flight (the pre-existing hazard, unchanged: the first to ship takes the branch), and no *new* pair can be created from the moment the guard lands. The heal still earns its place for rows the new code writes, where a genuine collision on the requested name is possible and would otherwise block `CREATE UNIQUE INDEX` on deploy.
>
> All three index generations stay in `claimUniqueViolationError`'s `SESSION_CLAIM_INDEXES`, because a deploy applies code and migration at different instants and an unrecognised constraint falls closed onto the generic `ALREADY_CLAIMED` — the phantom-rival answer task 1002589 removed. The guard falls back to `worktree_name` when `requested_worktree_name` is NULL, which keeps it correct in that same window. Pinned DB-free in `tests/one_active_claim_per_session.mjs` (including the three-step repro, which fails against the old code) and against a real Postgres in `tests/claims_requested_worktree_db.mjs`.

- The many-sessions-per-builder norm (ADR 0049's `feedback_parallel_sessions_not_anomaly`) is preserved exactly: each worktree/session still gets its own claim.
- Web claims (NULL session) are unaffected — claim-in-browser, ship-from-any-terminal still works.
- This composes with, and does not alter, ADR 0049's split cross-claim contract: the per-task index, the advisory `touches[]` warning, and the autonomous-runner footprint gate are all untouched. This ADR only adds the within-session invariant 0049 left implicit.
