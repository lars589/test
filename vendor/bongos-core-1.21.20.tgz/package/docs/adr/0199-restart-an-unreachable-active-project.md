# ADR 0199 — An unreachable ACTIVE project gets a restart of its own, not a re-provision, and the restart never claims the verdict its probe cannot reach

- **Status:** accepted
- **Date:** 2026-08-28
- **Task:** [task 1003238](https://cloudbongos.com/builders#/task/1003238) (goal 1000058 — the non-cloudbongos project lifecycle)
- **Relates to:** ADR 0111 (provisioning trust boundary), ADR 0190 (settings-apply in-place env patch — the leg this one is carved from), ADR 0181 (teardown state gate + address retention), task 1002696 (the liveness overlay), task 1002691 (the open-intent slot), task 1002720 (F16/F19/F23 truthfulness)

> ADR **0198** is reserved by task 1003321, in flight in another session at the time of writing; this ADR takes 0199 rather than race it. The gap is deliberate.

## Context

The liveness overlay (task 1002696) is an *overlay*, never a seventh state: a project whose heartbeat cannot reach it is still `status='active'`, and the hub renders that reading four ways — an `unreachable` chip, an ashen orb, a "Not answering at …" address row, and a "Needs you" filter bucket.

None of them came with an action. The pre-UAT hub review (2026-08-24) recorded why: `PROVISION_ENQUEUE_FROM` is `{requested, provisioning, error, torn_down}` and **deliberately excludes `active`** (task 1002691 — a blind re-enqueue on a slug re-request left a stale open provision intent that then blocked the owner's own teardown). So the two re-enqueue doors the card already has, *Try again* and *Bring it back*, both refuse on an active project by construction. A Restart wired to that POST would have 409'd on every press, which is why the finding was filed as a task rather than fixed as a UI tweak.

`settings-apply` (ADR 0190) is the only existing action that runs *from* `active`, and it does restart the service — but only as the tail of a change whose value differs from the stored row (ADR 0190 §6: a save that changes nothing neither writes nor restarts). The one case where restarting is the whole point is exactly the case that leg refuses.

## Decision

1. **A `restart` intent** (migration `provisioning_011`, `INTENT_ACTIONS` in lockstep). `POST /provisioning/instances/:id/restart` gates on `RESTART_FROM = {active}` and `RESTART_SHAPES = {co-tenant, standalone}`, then enqueues; the control-plane runner performs it. The web tier still only enqueues — the trust boundary is unchanged (ADR 0111 §2).

2. **The runner leg is `settingsApplyInstance` minus the env patch.** `restartInstance` does one `systemctl restart <slug>` and then the same **patient** healthz verify (`MANIFEST_VERIFY_TRIES × MANIFEST_VERIFY_INTERVAL_MS`, the F23 lesson). It reads and writes **no file at all** — nothing about the instance's configuration is changing, so the in-place-patch hazard ADR 0190 exists to avoid does not arise here.

3. **The probe result is recorded with the same narrowness, and the event says which probe answered.** `probeIsVerdict = healthy === false || (healthy === true && !inst.domain)` — carried over verbatim, and it is load-bearing in a way worth naming: **the liveness sweep probes the public `https://<domain>/healthz` while the runner's verify probes loopback.** So a project can answer here while DNS, Caddy or TLS is the thing actually broken. The leg therefore never writes an up-verdict for a domained instance, and its event says *"restarted and answering on the box; whether its public address answers is for the next liveness sweep to say"* rather than "answering again" — a sentence the card, still reading `unreachable`, would contradict.

4. **A project that stays down is `ok:true`.** The restart *ran*; the instance not coming back is a truthful observation for the card, not a failed intent. Returning `ok:false` would re-pend it to `MAX_INTENT_ATTEMPTS`, restart a broken project four more times, and end by stamping an `error_note` over the owner's own deliberate action. Only a restart that **throws** returns `ok:false` — and it returns rather than throws, because the drain loop's `catch` flips the instance to `error`, and an instance that is merely unreachable must never be relabelled broken by the action meant to recover it (ADR 0190 §2).

5. **`enqueueRestart` is idempotent against its own kind in EITHER open state** — where it deliberately differs from `enqueueSettingsApply`. That one must refuse to ride a *running* sibling, because the runner may have read the settings row before this write, so the in-flight run would not carry the change. A restart carries no payload: one already running **is** the thing the owner asked for, so "already under way" is the truth, not a swallowed request. Any other action holding the single open slot is `409 intent_conflict`, naming it.

6. **A pending restart yields to a teardown.** It joins `provision` and `settings-apply` in `enqueueTeardown`'s supersede list — and more sharply than either, since the owner reaches for Restart precisely when a project looks broken, which is also when they give up and delete it. A running intent is still never yanked.

7. **The door appears only where it has a reason to exist:** `status === 'active' && last_verified_up === false && hosting_shape !== 'dedicated' && !open_intent`, mirrored on the list card and the manage page so the two can never disagree. `last_verified_up === null` (never probed) is **not** the same claim as `false` and does not raise the door — the distinction `publicInstance` maintains on purpose. A Restart button on every healthy card would only invite needless downtime.

8. **Every refusal names the action that IS available in that state**, and no branch promises a duration (the F16 rule): an offline or snagged project is told to stand it up again; a pre-active one that it hasn't finished standing up; a dedicated droplet is refused honestly and given the exact `systemctl restart <slug>` for whoever runs that machine. The state gate is checked before the shape gate, so a torn-down droplet hears the more useful of the two refusals.

## Consequences

- The "Needs you" bucket finally has a door: an owner whose project stopped answering can act on it themselves instead of only being told the platform keeps checking. The address row's sentence now names that action.
- A restart is visible while it runs — its own `FLOWS.restart` strip (`Restart queued → Restarting → Answering again`), whose final stage the queue never lights; only a probe earns that.
- An archon may restart any project; the override is stamped `api:archon:<id>` on both the intent and the audit event (the force-teardown convention).
- The lockstep assertion between `INTENT_ACTIONS` and the migration CHECK moved to the **newest** migration's test. Pinning strict set-equality to `provisioning_010` made every future action fail that test; 010 now asserts only that every value it admits is still a live action, which is the drift it can actually speak to.

## Rejected

- **Widening `PROVISION_ENQUEUE_FROM` to include `active`** — precisely the change task 1002691 reverted; a stale open provision intent blocks the owner's teardown, and `provisionInstance` is a no-op on an active instance anyway.
- **Reusing `settings-apply` by re-sending unchanged settings** — its no-change branch exists to stop a whole-form save bouncing a live project (ADR 0190 §6). Punching through it to get a restart would delete that protection for everyone.
- **Reporting `healthy:true` as "answering again" on a domained instance** — the loopback probe cannot see what the sweep sees; the card would still say unreachable and the event would read as a lie.
- **Retrying a restart that left the project down** — restarting a broken instance four more times fixes nothing and ends by overwriting the owner's action with an `error_note`.
- **Showing the door on every active card** — an always-available Restart invites downtime on projects that are fine, and there is no reading behind it to act on.
