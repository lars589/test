# ADR 0359 — Nobody sets a module's score by hand; a Metic+ person can ask for a re-check

- **Status:** accepted
- **Date:** 2026-10-01
- **Task:** [task 1003796](https://cloudbongos.com/builders#/task/1003796) (goal 1000091 — working area 5, Module distribution & economy; criterion `wa5-quality-assessed`)
- **Amends:** [ADR 0343](0343-a-module-score-is-a-security-gate-then-an-average-of-visible-parts.md) D6 (the Metic+ score override) and [ADR 0347](0347-every-store-module-ships-a-how-to.md) D5 ("the Metic+ override applies to Docs like any part").
- **Keeps:** ADR 0343 D6's delist (task 1003797) and "every action is recorded"; ADR 0347 D6's "Metic+ re-runs it" for a Docs grade that could not run.
- **Decided with:** the owner (Will, Archon), 2026-10-01: "I don't think someone should be able to override a module's score. Maybe trigger a regrade but not change it." Metic and Archon may trigger it; the permission grant migration was approved the same day.

## Context

ADR 0343 D6 put a Metic+ override on top of the computed score, because an automated score will sometimes be wrong and a human-review-only panel does not scale. Task 1003796 was to build it. Before any code was written the owner ruled the other way: a score a person can type in is a score a person can sell, and the reason field does not change that.

## Decision

### D1 — No route sets, raises or lowers a score

A module version's score only ever comes from its signals, composed by `scripts/gds/module-assess-score.js`. There is no override route, and the `kind = 'override'` rows `core_265` allows for are never written. The column and its CHECKs stay (removing them is a migration with nothing to gain); a test asserts no store route writes `module_assessment_scores`.

### D2 — A Metic+ person can ask for a re-check, with a reason

`POST /api/bongos/store/modules/:key/versions/:version/reassess { reason }` queues the same assessment a publish runs (`assessVersion`): Tests `pending` if there is no Tests result yet, the Security gate, the Docs grader, then the score. It answers 202, or 503 when the assessment queue is full. A reason is required and nothing else is accepted in the body, so a score cannot ride along. The audit middleware records who asked and why.

This is how a wrong score gets corrected: if a signal was wrong because a check failed to run (the grader was down, npm could not be reached), the re-check runs it again. If a check itself is wrong, that is a bug in the check, fixed in code for every module.

### D3 — Metic and Archon, through one new atom

The route is gated by `module.assessment.rerun` (floor `metic`, not a system key) in `modules/government/catalog.js`, granted to `metic` and `archon` by `government_021_module_assessment_rerun.sql`. It is Metic+ and not open to every builder because each re-check spends a Docs grader call (up to 5¢, ADR 0347 D6) and re-runs the npm audit.

## Consequences

- An author who thinks their score is wrong asks a Metic+ person to re-check it, or reports a bug in the check. Neither path lets anyone pick the number.
- A re-check can lower a score as well as raise it: it is whatever the checks say now.
- The delist (task 1003797) is unchanged: it hides a module from the store, it does not change a score.

## Rejected

- **The override as ADR 0343 D6 planned it.** The owner's call (above).
- **An override that only lowers a score.** It is still a person choosing the number.
- **Re-checks for every builder.** Each one costs money; Metic+ keeps that spend with trusted people.
