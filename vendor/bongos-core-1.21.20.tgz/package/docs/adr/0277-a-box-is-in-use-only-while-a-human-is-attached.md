# ADR 0277 — A box is "in use" only while a human is attached, and the claim expires

- **Status:** Superseded by [ADR 0346](0346-dev-boxes-are-retired.md) — the dev box was removed (goal 1000120). Was: accepted
- **Date:** 2026-09-10
- **Task:** [1003507](https://cloudbongos.com/builders#/task/1003507) (goal 1000095 — *Working area 6*, criterion `wa6-role-experience`)
- **Supersedes the "never touch a box with a claude process" rule** in [ADR 0031](0031-cloud-dev-environments-for-builders.md) §5(a); the park/preserve guarantee of tasks 1002726/1002727 is unchanged and is what makes this safe.

## Context

`sweep-idle` parks an `active` box whose heartbeat has gone quiet. Which boxes it may touch was decided by `selectIdleBoxes()`, and the rule was: skip any box with `claude_active = true`, at any age, plus skip anything whose `last_activity_at` is recent.

Both halves were satisfiable without a human being anywhere near the box.

1. **`claude_active` is a latch, not a level.** Only a heartbeat ping writes it, and `infra/box-heartbeat.sh` **exits without pinging** when it sees no activity. So silence — the very signal the sweep exists to act on — could never clear the flag. Reproduced against the shipped selector: a row with `claude_active = true` was skipped at `idleMinutes` of 10, 120, 1440 and **5,256,000** (ten years). Not "reaped late": never.
2. **`load > 0.2` kept the activity clock fresh.** A running devcontainer plus an idle `claude` clears that floor on its own, so `last_activity_at` was bumped every 5 minutes indefinitely.

Either leg alone kept a box alive, which is why the incident looked inexplicable: `example-owner`'s box had been up since 2026-08-12 with a heartbeat every 5 minutes, while tmux session `otb` had been **unattached since 2026-08-15 18:01 UTC** and the `claude` inside it had burned 16 minutes of CPU across 25 hours of wall clock. An abandoned interactive `claude` sitting at its prompt is byte-for-byte indistinguishable from a working one. Cost: **$20.21** on one box, almost all of it unattended.

**A third defect made the whole sweep inert**, found while testing this fix and confirmed on clean `origin/main`: `loadDeps()` in `scripts/gds/box.js` opened with `if (_deps) return _deps;` and **`_deps` was never declared**. The assignment further down would have created a global in sloppy mode, but the read comes first, and reading an undeclared identifier is a `ReferenceError`. So `loadDeps()` threw on its first call, every time, and every command that resolves a DigitalOcean client died with it — including `sweep-idle --apply`, which builds that client *before* the park loop. **The idle sweep could not park any box at all.** No test caught it because the only `apply: true` test in the suite relied on the `claude_active` veto emptying the idle set before `makeDo()` was reached: the bug was hidden behind the other bug.

## Decision

**A box may not stay active longer than `BOX_UNATTENDED_MAX_HOURS` (default 12) without evidence that a human was actually attached to it.** One number bounds both proxies.

The heartbeat already computed the human signal and threw it away by folding it into one boolean. It now reports **`attached`** separately — a login session (`who`), an established inbound SSH connection, an open browser terminal (ttyd), or an **attached tmux client** (`#{session_attached}`, the signal that distinguishes this incident's box from a working one). The server stamps `last_attached_at` from it. `claude_active` keeps its meaning and its veto, but the veto now expires: `claude_active_since` records the `false→true` edge (`COALESCE`d across a run of true beats, so it measures the session and not the last 5 minutes), and past the cap the flag stops counting.

`pgrep -x claude` and the load floor stay as reasons the box **pings**; they are no longer accepted as evidence anyone is **there**. That distinction is the whole decision — a running process is not a person.

Both new clocks are cleared with `claude_active` at park, wake and deprovision, or a woken box would inherit an expired latch and be parked instantly — the fix reintroducing the bug from the far side.

### `NULL` means "no data", never "unattended"

A box still running the pre-1003507 heartbeat never sends `attached`, so its `last_attached_at` stays `NULL` forever. Treating that as unattended would park **every un-upgraded box mid-work**, and box source sync is not reliably prompt (idea 1000745 records a spell where a box sat 257 commits behind for three days). So `NULL` is read as unknown and the box keeps the old behaviour, and migration `core_238` deliberately **does not backfill** the column — a backfilled `now()` would start a clock nothing could ever advance and park the box one cap later.

`claude_active_since` takes the opposite default and **is** backfilled, because an unknown latch age *is* the forever-latch being fixed; after the migration a `true` flag with no stamp is unreachable, so refusing it costs nothing and closes the hole.

### Why 12 hours

Longer than any interactive session and long enough for a real overnight autonomous run. The asymmetry justifies the generosity: since task 1002726 the idle sweep **parks** — snapshot kept, filesystem preserved — so a false positive costs one wake, while no cap at all cost $20.21 on a single box. Tunable per instance via the env var.

## Consequences

- `sweep-idle` can park a box that claims `claude_active`. Its log names the clock that selected it (`unattended 21h (cap 12h) — abandoned session`) through a shared `idleReason()`, so the log cannot drift from the selection.
- **`sweep-idle --apply` works for the first time.** Fixing `_deps` was not optional scope: the selection fix is inert without it, since the sweep crashes before parking anything. A regression test now reaches dep resolution through the same `apply: true` path that hid it.
- A box nobody ever attaches to (a pure autonomous run on an upgraded heartbeat, `last_attached_at` still `NULL`) is bounded by the `claude_active_since` cap rather than by attachment. That is the intended fallback and the reason the claude clock kept its own bound rather than deferring entirely to attachment.

## Rejected

- **Tracking attachment *instead of* bounding `claude_active`** (the task's option (b), and the more honest-looking fix): it does not close the reported hole. A box that stops pinging keeps its last `claude_active = true` forever, because only a ping can clear it — so the forever-latch survives untouched, and the fix would have shipped against a stale-heartbeat fixture looking green.
- **Bounding `claude_active` alone** (options (a)/(c)): this is what was built first, and the verification probe caught it — the incident's heartbeat was *fresh*, so lifting the veto changed nothing and the box was still never idle. Recorded because it is the plausible-looking half-fix, and the task's own framing offered the three options as alternatives when the reported cost needs two of them.
- **Deleting the `load > 0.2` floor** so an abandoned box simply stops pinging: it is what makes an autonomous run count as use, and removing it would park legitimate unattended runs after `idleMinutes`.
- **Measuring the cap from `active_since`**: that is uptime. A box worked on continuously for days has an old `active_since` and would be parked mid-work.
- **Raising `BOX_IDLE_MINUTES`**: the reproduction shows no threshold reaches these boxes. The veto was unbounded, so the threshold was never the variable.
