# 0227 — A task network map is refused; the goal graph is the map, and search answers findability

- **Status:** Accepted
- **Date:** 2026-09-02
- **Tasks:** [#1003282](https://cloudbongos.com/builders#/task/1003282)
- **Goal:** [#1000072](https://cloudbongos.com/builders#/goal/1000072) — Human legibility, criterion `legibility-project-map`, which gates itself on this spike.
- **Evidence:** [`docs/research/task-network-map-readability.md`](../research/task-network-map-readability.md) and the figures in [`docs/research/task-network-map/`](../research/task-network-map/), rendered by [`scripts/gds/spike-task-map.js`](../../scripts/gds/spike-task-map.js).
- **Sibling goal:** [#1000027](https://cloudbongos.com/builders#/goal/1000027) — Findability, "the grep path" (ADR 0095, ADR 0060).

## 1. The decision

**No whole-corpus task map, at any dependency density.** The measured verdict holds
across a swept range (p=2% to p=40% of tasks carrying a dependency): a node-link view of
~1,357 tasks is confetti, not structure, and the obvious fix — drawing it denser — draws
forty goals badly while claiming to show a thousand tasks. A confident picture of nothing
is the opposite of legibility, which is the goal this criterion serves.

What is readable is **the ~40-node goal graph as the entry point**, with a **per-goal
dependency forest as the drill-down**, queried when a goal is opened rather than zoomed
out of a global map.

**This is a negative result, and it is the deliverable.** The criterion said so in
advance: a network view that becomes unreadable at 1,300 tasks is not a solution, and the
spike's output is an ADR plus a task list, not a prototype.

## 2. What the edges are, and which already exist in the DB

Every edge a map could draw is already stored. None needs a new table.

| Edge | Storage | Notes |
|---|---|---|
| task → task dependency | `task_dependencies` (migration 020) | The load-bearing one; gates claims (`409 DEPS_NOT_SHIPPED`, ADR 0015). This is view B. |
| task → subtask | `tasks.parent_task_id` | Tree, not graph. Cheap. |
| task → goal | `tasks.goal_id` → `goals` | The aggregation key for view C's node weights. |
| task → criterion → goal | `task_criteria` → `done_when_criteria` | The done-when rollup `/status` already walks (ADR 0025). |
| idea → task (promotion) | `idea_inbox.promoted_to_task_id` → `tasks` | Triage lineage, forward direction. |
| idea → idea (merge) | `idea_inbox.merged_into_idea_id` (`migrations/core_195_idea_triage_provenance.sql`) | The merge target; chain-free by CHECK constraint. |
| task → version | `tasks.version_id` → `versions` | Membership, not connection — a filter, never an edge to draw. |

The triage-lineage edges (the last three) are the ones the owner's question actually
reaches for — what became of the thing I was brainstorming — and they form **short
chains, not a network**. That distinction drives §4.

## 3. How it survives the number

- **View C is aggregated at the query.** One `goalRollups` query plus a cross-goal
  dependency count. ~40 nodes; the payload is bytes.
- **View B is lazy and scoped.** A separate small query per opened goal. It covers 3–40%
  of the corpus and never 100% — and the tasks it omits are precisely those with nothing
  to connect them to, so the omission is the finding rather than a gap.
- **Views A (every task) and D (densified) are never drawn** — not as a default, not
  behind an "advanced" toggle.
- **Density is measured before anything is built.** Two numbers decide the shape: the
  share of tasks carrying a dependency, and the share of dependencies crossing a goal
  boundary. If cross-goal dependencies are near zero, view C is forty disconnected dots
  and the honest deliverable is a grid of goal cards — which the hall's Goals page
  already is. **That outcome would mean the right amount of new map is none**, and it is
  why the first task in §6 is a measurement, not a build.

## 4. Findability (goal 1000027) answers the owner's question more cheaply than a map

Read first, as the criterion required. Goal 1000027 is the grep path: a repo navigated by
literal search, with meaning written into the source (ADR 0095), plus the rank-scoped
lexical search over repo docs and indexed DB prose that `/recall` serves (ADR 0060).

The owner's question splits in two, and only one half is a map:

- **Find what I was brainstorming.** This is search, and it already exists. `/recall`
  plus the lineage columns in §2 answers it end to end: find the idea, follow
  `promoted_to_task_id` / `merged_into_idea_id` to what became of it. What is missing is
  not a picture but a **lineage trail** — one thing and its ancestry, rendered as an
  ordered list. That is a text surface, cheap, accessible for free, and it does not
  degrade at 1,357 rows because it never shows more than one chain.
- **See the shape of the portfolio.** Search cannot answer this, and this is the only
  half a graph earns. It is view C, and it is about ~40 goals — not about tasks.

**Therefore the lineage trail outranks the map.** It is the cheaper answer to the question
actually asked, and it is sequenced first in §6. A whole-corpus picture was never the
cheap way to find a thing.

## 5. Accessibility and the no-sideways-scroll rule

Whatever ships lands in the hall, so it inherits the hall's rules, and a node-link graph
is the hardest surface to make accessible.

1. **The table is the primary surface; the graph is the enhancement.** Every graph view
   ships with a semantic equivalent (goal name, task count, category, dependency count) —
   not an `aria-label` bolted onto an SVG blob, and not a "view as table" toggle that
   hides the accessible path behind a click. A keyboard-only or screen-reader user gets
   the same facts by default.
2. **No sideways scroll on the page.** A graph that cannot fit the width scrolls inside
   its own `overflow-x: auto` container; the page body never scrolls horizontally.
3. **Colour is never the only channel.** View C encodes category as colour; category must
   also be text on the node or in the row, since the ADR 0192 category set is not
   colour-distinguishable at forty nodes.
4. **The lineage trail has none of these problems**, which is a further reason it is
   sequenced first.

## 6. The ranked task list

Ranked, and deliberately front-loaded with the cheap text surfaces so the graph is built
only if the measurement says it would carry anything.

1. **Measure the real density** — [#1003477](https://cloudbongos.com/builders#/task/1003477) — against the live DB (`--from`), recording the two
   numbers from §3. Gates items 3 and 4; may cancel them outright.
2. **The lineage trail** — [#1003478](https://cloudbongos.com/builders#/task/1003478) — an idea's ancestry and what became of it, as an ordered text
   surface on the existing search path (§4). Independent of the graph, and the answer to
   the owner's actual question.
3. **The goal graph (view C)** — [#1003479](https://cloudbongos.com/builders#/task/1003479) — ~40 nodes, cross-goal dependency edges, task-count
   weight, category as colour *and* text, table equivalent shipped with it. Only if
   item 1 finds cross-goal edges.
4. **The per-goal dependency forest (view B)** — [#1003480](https://cloudbongos.com/builders#/task/1003480) — the drill-down, queried per goal. Only
   if item 1 finds a meaningful share of tasks carrying dependencies.

## 7. What was rejected

- **The task graph, zoomed out (view A).** A thousand dots whose positions are noise.
- **Densifying to make it look structured (view D).** Forty dots presented as a thousand;
  it invites belief in structure that is not there.
- **A prototype as this spike's output.** The criterion forbade it. `spike-task-map.js` is
  a measuring instrument that renders figures from a synthetic sweep — it ships as
  evidence under `docs/research/`, is wired to no route and no page, and nothing in the
  hall imports it.
- **Building the map before measuring.** The two numbers in §3 can cancel items 3 and 4,
  and discovering that after building would be the expensive order.

## 8. The honest limit

**The measured corpus is synthetic.** The live DB was unreachable from the environment the
harness ran in, so it sweeps a plausible range instead of observing one truth. The sweep
is what makes the *verdict* robust — every conclusion above holds from p=2% to p=40% —
but the specific numbers are model output, not observation, and the ~40 goal count and the
85% within-goal edge preference are modelled from the repo's own record. This is exactly
why item 1 of §6 is a measurement against the real DB and why it gates the rest. A
negative result that saves building an unreadable graph is a successful spike; a negative
result that also names the one query that could overturn it is a finished one.

## 9. Conceded: the harness over-built for the question

The adversarial review of this work made a point worth keeping rather than arguing with,
so it is recorded here instead of in a session log that nobody re-reads.

**The verdict above rests on arithmetic, not on the renderer.** The two load-bearing
findings — the share of nodes with degree 0, and the ink budget (screen area ÷ nodes
against a minimum dot pitch and label width) — are division. They need no force
simulation and no PNG. Yet `spike-task-map.js` carries a Barnes-Hut layout and a
hand-rolled PNG encoder (CRC32, zlib framing, canvas primitives), and the write-up itself
concedes that in view A "every dot's location is an accident of the seed". Building an
accurate physics simulation to place points whose positions are then declared
meaningless is disproportionate to a decision document.

**What the renderer does still earn:** the figures are what make overplotting legible to
a human reader, which a table of `marks` counts genuinely does not do — and item 1 of §6
re-runs this same harness against the live DB, so it is the instrument that closes the
spike, not dead weight. That is why it is kept rather than deleted.

**What was fixed rather than argued:** the encoder had no test coverage at all, which is
the sharper version of the same criticism — the figures are cited as evidence, so a
stride, CRC or alpha-blend bug would have corrupted the evidence *silently*. `crc32`,
`chunk`, `writePng`, `canvas`, `goalColor` and `render` are now exported and pinned by
`tests/spike_task_map.mjs` (canonical CRC-32 vectors plus a cross-check against
`zlib.crc32`, chunk framing, stride correctness, out-of-bounds clipping, alpha blending,
disc radius, line endpoints, and a full inflate-and-locate round trip). The stride
assertion was mutation-tested: changing `y * w` to `y * h` fails two tests.

**The transferable rule:** *a spike may build only what its verdict actually rests on;
anything further is a prototype wearing a harness's name.* Had the arithmetic been run
first, the figures would have been a nice-to-have and the physics would never have been
written.

---

## 10. Amendment (2026-09-04) — the density measured against the live DB

*Task [#1003477](https://cloudbongos.com/builders#/task/1003477), §6 item 1. §3 said two numbers would decide items 3 and 4, and
the original spike could only model them: the live DB was unreachable from where that
harness ran. They are now measured. This section is appended, not edited in — §§1–9 stand
as written, and the one number in them that the corpus contradicts is called out below.*

### 10.1 What was run

`GET /api/gds/tasks?include=deps` paged at `limit=1000` over the whole `tasks` table
(3,253 rows, all versions — BONGOS-V1 alone is 1,894), reduced to `{id, goal_id,
version_id, status, blocked_by[]}` and fed to the same harness through `--from`:

```
node scripts/gds/spike-task-map.js --from <dump>.json
```

**The loader was broken, and would have answered confidently.** `loadReal` read
`dependencies`/`deps`; `GET /tasks?include=deps` answers with **`blocked_by`**
(`db.attachTaskDepSummaries`). A real dump therefore parsed as a corpus with **zero
edges**, and every `--from` number would have described an empty graph while looking
entirely plausible — nothing in the output says *"no edges here because the field was
misnamed."* This is the failure mode a spike must not have, so `depIdsOf` now accepts all
three spellings and `tests/spike_task_map.mjs` pins it. Two tasks with **no** goal also no
longer share a goal bucket: pooling them turned every dependency between two ungoaled
tasks into a within-goal edge, understating the very number §3 asked for.

### 10.2 The two numbers

| §3's question | Measured | Modelled range |
|---|---|---|
| Share of tasks carrying ≥1 dependency row | **23.61%** (768 of 3,253) | swept 2–40% |
| Share of dependency edges crossing a goal boundary | **5.60%** (66 of 1,178) | assumed 15% |

Supporting shape, all exact:

- **70 goals** carry tasks (not ~40 — §§1–3 say "~40 nodes" throughout; the real graph is
  **76 nodes**: 70 goals plus 6 ungoaled tasks, which are each their own bucket). No
  dependency edge touches an ungoaled task, so that distinction changes no number here —
  but it is now measured rather than assumed away.
- **33** distinct directed goal pairs. **36** goals carry a cross-goal edge; **34 are
  isolated dots (48.57%)**. The goal graph breaks into **48 components, the largest 17**.
- The dependency forest: **1,012 tasks have an edge in either direction (31.11%)**, in
  **128 components**, largest 102, **median 4**.
- Per-goal drill-down: **56 goals have one**, largest **127** tasks, median **9**.

Figures rendered from the live corpus, beside the synthetic ones:
[`real-a-every-task.png`](../research/task-network-map/real-a-every-task.png),
[`real-b-dependency-forest.png`](../research/task-network-map/real-b-dependency-forest.png),
[`real-c-goals.png`](../research/task-network-map/real-c-goals.png),
[`real-d-joined-by-goal.png`](../research/task-network-map/real-d-joined-by-goal.png).

### 10.3 §1 survives, and the real corpus is worse than the model

View A on real data: 3,253 nodes, **68.9% isolated**, 2,369 components, 16.8px pitch —
below the 48px a label needs. View D: **94.7% of nodes overplot**. The refusal in §1 was
argued from a sweep; the live corpus lands inside that sweep and fails it harder than the
midpoint did. **Nothing in §1 is reopened.**

### 10.4 Item 3 — the goal graph: **PROCEED**, with the shape changed

Cross-goal dependencies are **not** near zero. §3's cancel condition ("forty disconnected
dots") does not fire: there are 33 goal pairs and 66 edges, and at 76 nodes the view is
comfortably readable — 110.1px of pitch, labels fit, 14 crossings, 69ms, **under 1KB of
graph payload**. Item 3 is worth building.

But the evidence changes what to build, and [#1003479](https://cloudbongos.com/builders#/task/1003479) must be built to this rather
than to §6's wording:

1. **Half the goals have no edge at all.** 34 of 70 are isolated. A pure node-link layout
   spends half its canvas on dots a force layout has nothing to say about — §3's own
   objection to view A, one order of magnitude down. The honest shape is a **graph of the
   36 connected goals plus a list (or the existing card grid) for the 34 isolated ones**,
   with the split stated on the page. §3 was right that "a grid of goal cards" is the
   answer for edgeless goals; it is right for *half* of them, not none.
2. **Even the connected half is not one graph** — 42 components among real goals, the
   largest 17. The view must read as "one cluster and a scatter of pairs", not as a
   network.
3. **The table equivalent §6 already requires is not optional here.** With 48 components,
   the table carries more of the structure than the picture does.

### 10.5 Item 4 — the per-goal dependency forest: **PROCEED**, as scoped and not wider

23.61% of tasks carry a dependency — inside §3's stated 3–40% band, so the forest has real
content. The scoping in §3 ("lazy and scoped", per opened goal) is now *load-bearing
rather than merely prudent*, and the measurement says so both ways:

- **Whole-corpus forest: refused.** 1,012 nodes at 30.2px pitch — above the 7px dot floor
  but **below the 48px label floor**. It would draw 1,012 discs nobody can name, in 128
  pieces. This is the same failure as view A, and it must not be offered as a "show all"
  toggle.
- **Per-goal drill-down: clears the bar, worst case included.** The biggest single goal's
  forest is **127 tasks → 85.2px pitch, labels fit**; the median is 9. **No goal's forest
  exceeds the label floor** (that would take >400). The drill-down is readable for every
  goal that has one, which is exactly the claim item 4 needed and could not previously
  make.

[#1003480](https://cloudbongos.com/builders#/task/1003480) proceeds unchanged in scope. The one thing it must add: 14 goals have **no**
intra-goal forest, so the drill-down needs a real empty state rather than a blank panel.

### 10.6 What this cost, and the transferable rule

The measurement took one session and cancelled nothing — but it changed item 3's design
before it was built (half the nodes belong in a list, not a graph) and it turned item 4's
"lazy and scoped" from a preference into a constraint with a number behind it. It also
caught a loader bug that would have made every future `--from` run answer "no edges" with
a straight face.

**The transferable rule:** *a spike that reads a real API must be run against the real API
before its numbers are quoted — a field-name mismatch does not fail, it answers zero.* §9
already conceded this harness over-built for its question; the other half of that lesson is
that the part it under-built was the twenty lines that touch reality.

## 11. Amendment (2026-09-24) — the project sky takes the goal map's page

Recorded by [ADR 0331](0331-the-sky-is-the-ideators-home.md); tasks
[#1004229](https://cloudbongos.com/builders#/task/1004229)–[#1004233](https://cloudbongos.com/builders#/task/1004233).
The owner adopted an interactive prototype of the **project sky** as is, and it replaces the goal
map page. This section says what that changes here, and what it does not.

**§1's refusal stands.** There is still no whole-corpus task map, at any density. The project sky
is §1's own shape — the goal graph as the entry point, the per-goal drill-down as the detail —
drawn as one page instead of two:

- **Tasks are drawn only inside one goal, past a zoom threshold.** That is the per-goal forest
  §10.5 measured as readable (worst case 127 tasks at 85.2px pitch, median 9), not the refused
  1,012-node view. Below the threshold, tasks are **dust density on the rings of the goals beneath
  it, with no identities** — a texture that says how full a goal is, never a disc anybody is asked
  to name. A "show all tasks" toggle remains refused.
- **The goal map's table survives as the sky's ledger drawer.** §6's table equivalent is kept,
  not dropped; every drawn thing is a row in it, one key away.
- **The nav slot the goal map was denied is granted to the sky**, under Goals (owner,
  2026-09-24). The goal map page (task 1004105) took no slot on purpose, and a test asserts the
  same; part 4 ([#1004232](https://cloudbongos.com/builders#/task/1004232)) changes the page and
  that test together, with this section as the licence. **Landed 2026-09-24:** `/goal-map` serves
  the sky in its whole-project lens, the goal map's files and the test that pinned its missing
  slot are gone, and "Sky" sits under Goals in the nav (`tests/goal_map_page.mjs` now pins the
  slot, the ledger drawer and this section's task rule).

**Design of record:** [`docs/design/mocks/sky/`](../design/mocks/sky/) — the pixel contract for
the build. [ADR 0264](0264-the-ten-working-areas.md)'s deletion of the goal *Living project sky*
([#1000044](https://cloudbongos.com/builders#/goal/1000044)) is superseded by this work, under
Working area 3.
