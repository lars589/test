# `CORE_VERSION` changelog — the `@bongos/core` doorway

The release ledger for `CORE_VERSION`, the semver of the published module doorway
[`src/module-api.js`](../src/module-api.js) (ADR 0083). Oldest entry first, newest last.

**The number itself has not moved.** `const CORE_VERSION` is still declared in
`src/module-api.js` and is still the single literal every release reads. Only the
history lives here.

**Why the history moved** ([ADR 0203](adr/0203-doorway-changelog-out-of-module-api.md)):
the CI auto-patch carrier (ADR 0161) appends a two-line entry on *every* release and
pushes straight to `main`, bypassing the `unit` gate. As a comment block inside
`src/module-api.js` that growth pushed the file past the 1500-line
`oversized_file_count` fitness ratchet — a red `unit` on `main` that every open PR
inherited and that each further release made worse. The ratchet counts `git ls-files
'*.js'`, so a markdown ledger is exempt and the history can grow forever without
gating the repo again.

**Semver rule.** Bump MINOR when adding an export to the doorway; MAJOR when changing
or removing one. A MINOR or MAJOR is a deliberate human in-task edit — CI only ever
bumps PATCH (ADR 0161 §2).

**How the carrier writes here.** `scripts/gds/bump-version.js` inserts each new entry
immediately **above the divider that closes the ledger** below — the same insertion
contract the comment block used, so the ordering convention is unchanged. That divider
is load-bearing: the script throws rather than guess if it is missing, and
`tests/bump_version.mjs` pins both halves.

## The ledger

```text
1.0.0 — initial doorway: auth gates, pool accessor, config/branding, seams.
1.1.0 — contribution seam: contribute/contributions/collectContributions/
        listContributionPoints (BV1.R42 / task 1411) — additive, so MINOR.
1.2.0 — capabilities the first extracted module (dev-box, BV1.R43 / task 1412)
        needs from the kernel: auth.allowBoxScope, db.getBuilderById /
        setBuilderBoxBlocked, buildInfo, route _helpers (validateOrRespond /
        LIMITS) — all additive, so MINOR.
1.3.0 — capabilities the art-pipeline module (BV1.R48 / task 1417) needs:
        db.getBuilderGeminiKeyRow / setBuilderGeminiKey / clearBuilderGeminiKey
        — all additive, so MINOR.
1.4.0 — generic kernel capabilities the discord module (BV1.R47 / task 1416)
        needs: db.insertAuditLog / createTask, inbox.captureIdea, the
        LIVE_RANK_LADDER rank ladder, and task-classifier VOTABLE_TASK_STATUSES.
        All generic (no module is named) + additive, so MINOR. The discord-
        SPECIFIC helpers (bot-token loader, snowflake validator, webhook poster)
        are deliberately NOT here — a module vendors its own domain code; the
        kernel doorway stays module-agnostic (the "core carries no module code"
        fitness check forbids naming a module key in this file).
1.5.0 — BV1.R68 / ADR 0091 (kernel-bounding): adds `withTx` — the BEGIN/COMMIT
        transaction primitive a carved CORE domain needs for a multi-statement
        write (memory, R72, runs transactional stores). Additive → MINOR. The
        same change RELOCATES the dev-box domain query `setBuilderBoxBlocked`
        out to modules/dev-box/db.js and drops its doorway re-export. A strict
        reading calls removing an export MAJOR, but the sole consumer (the
        dev-box module) moves in lockstep and no enabled module at its pinned
        coreVersion loses a capability it uses — so the strangler treats an
        in-repo lockstep relocation as MINOR (a real MAJOR bump would
        gratuitously break every `^1.x` module at the loader's coreVersion gate).
        ADR 0091 §3 classifies the rest of this surface (kernel vs leak) below.
1.6.0 — BV1.R73 / ADR 0091 §1+§4 (grading carve): adds the two KERNEL trust
        classifiers `routeRankCheck` + `permissionPathCheck` (the deterministic
        route→rank + protected-path matchers — KERNEL_FILES per R70) so the
        grading module's deterministic pre-passes reach them through the doorway
        instead of a deep core require; and `llmCache` (the shared LLM-cost
        cache — a DOMAIN leak, not kernel; see the leak bucket below). All
        additive → MINOR. The grade capability itself is NOT a doorway export —
        it is a kernel PORT the grading module registers (`grade`) and the
        lifecycle resolves (ADR 0091 §4).
1.7.0 — BV1.R77 / ADR 0093 (economy carve): adds `llmPricing` (the shared
        token->USD pricing lib — a DOMAIN leak like `llmCache`, consumed by BOTH
        the carved economy module's reward/cost paths AND core cost scripts
        ship.js/session-cost.js, so it can't be economy-owned). Additive ->
        MINOR. The reward capability is a kernel PORT the economy module
        registers (`reward`), not a doorway export.
1.8.0 — BV1.R78 / ADR 0093 §5 (ideas carve): adds `parseId` — the route-param
        validator from routes/_helpers.js, alongside `validateOrRespond`/`LIMITS`
        (KERNEL shared route helpers, ADR 0091 §1) so the carved ideas module's
        routes don't vendor their own. Additive. The same change RETIRES the
        `captureIdea` doorway leak: it relocates to the ideas module behind the
        `ideas.capture` kernel PORT (the home ADR 0091 §3 promised), with the
        sole consumer (discord #ideas inbound) moving to resolve the port in
        lockstep — so, like `setBuilderBoxBlocked` at 1.5.0, the export removal
        is treated as MINOR (no enabled module at its pinned coreVersion loses a
        capability it uses; a real MAJOR bump would gratuitously break every
        `^1.x` module at the loader's coreVersion gate).
1.9.0 — BV1.R81 / ADR 0093 §1 (onboarding carve): adds `enabledDisciplines` —
        the instance's offered-disciplines resolver (src/modules.js: core
        engineer/ideator + each enabled module's disciplines). The carved
        onboarding module's newcomer-restock backstop intersects the chore
        disciplines with what THIS instance offers, so it needs the registry's
        answer without reaching into src/modules.js directly. Generic (names no
        module) + additive, so MINOR. The onboarding capability itself is NOT a
        doorway export — it is a kernel PORT the onboarding module registers
        (`onboarding`) and the lifecycle/profile readers resolve (ADR 0093 §1).
1.10.0 — BV1.R82 / ADR 0093 §1 (sessions/BFG carve): adds `builderRollingAvgGrade`
        — the per-builder rolling grade-pass read the BFG's cross-builder
        `gatherInteractionSignals` needs to score interaction quality. It is a
        grade-TREND read (not kernel; consumed by the carved sessions module's
        BFG AND still by core routes/me.js's profile reader — the discord-twin
        pattern), so it sits in the DOMAIN-leak bucket like `llmPricing`/
        `getBuilderGeminiKeyRow`, relocating behind a port if/when the grade-
        trend reads are carved. Generic (names no module) + additive, so MINOR.
        The sessions capability itself is NOT a doorway export and NOT a port —
        sessions registers no provider (like memory); core never calls back in.
1.11.0 — BV1.R83 / ADR 0093 §1 (autonomy/MAS carve): adds `tallyPeerVotes` —
        the peer-vote→karma weekly fold-in transaction the carved autonomy
        module's in-process routine timer (modules/autonomy/pollers/routine-
        timers.js) fires. It's the SAME transaction the lifecycle route
        POST /tasks/peer-votes/tally runs (the route + timer must share ONE
        path, never diverge), so it can't be autonomy-owned — it writes
        karma_log/peer_votes/tasks, all lifecycle/core-owned. A LIFECYCLE leak
        like `createTask`/`VOTABLE_TASK_STATUSES`: no clean home until the
        lifecycle domain is carved (R86), when it resolves behind a `lifecycle.*`
        kernel port. Until then the doorway re-export IS the (explicit, marked)
        seam. Generic (names no module) + additive, so MINOR. The autonomy
        capability itself is NOT a doorway export — the timer is a poller the
        loader starts, the precheck a module route, and the gate a CLI.
1.12.0 — BV1.R86 / ADR 0093 §1,§3 (lifecycle carve — the LAST core-domain
        carve): the build state machine (tasks·claims·versions·done-when·ship
        orchestration) became modules/lifecycle/, so two net changes to this
        surface:
        (a) ADDS the KERNEL helpers the moved lifecycle libs need through the
            doorway instead of a deep core require: `repoInfo` (src/bongos/repo-
            info.js — the git-remote/slug resolver github-push.js + conflict-
            resolve.js read), `moduleScopeMap` (src/bongos/module-scope-map.js —
            the goal scope-wall roster routes/tasks.js + routes/goals.js read for
            module-key validation), `userAgent` (src/branding.js — the
            branding-derived HTTP UA github-push.js stamps GitHub requests with),
            `pathMatch` (src/bongos/path-match.js — the pure touches[]-overlap
            matcher claim/optimizer use; already grandfathered kernel-adjacent
            infra), and two more shared route helpers off _helpers.js
            (`asyncHandler` + `corsPublicGet`, alongside the existing
            validateOrRespond/LIMITS/parseId) the carved lifecycle routes
            (versions/done-when/analytics) reuse. All KERNEL config/identity/
            infra/route-helpers (ADR 0091 §1); additive → MINOR.
        (b) RETIRES the three LIFECYCLE doorway leaks `createTask`,
            `VOTABLE_TASK_STATUSES`, and `tallyPeerVotes` — they now resolve
            behind the `lifecycle` kernel PORT the module registers (ADR 0093 §3,
            "each carve deletes its leak"). The sole consumers (modules/ideas →
            via onboarding/discord, modules/discord, modules/autonomy, and core
            cascade-dispatch.js) resolve that port in lockstep, so — like
            `setBuilderBoxBlocked` at 1.5.0 / `captureIdea` at 1.8.0 — the export
            removal is treated as MINOR (no enabled module at its pinned
            coreVersion loses a capability it uses; a real MAJOR bump would
            gratuitously break every `^1.x` module at the loader's coreVersion
            gate). The lifecycle capability itself is NOT a doorway export — it is
            a kernel PORT (`lifecycle`) the module registers and core + the other
            modules resolve.
1.13.0 — BV1.R60 / ADR 0086 §3 (goal-scoped bounded task authoring): adds
        `goalScopeCheck` (src/bongos/goal-scope-check.js) — the PURE scope wall the
        carved lifecycle module's POST /goals/:id/tasks create gate calls to
        decide "may this member author this task here?". It is KERNEL (the trust
        boundary for the create-time gate; it only COMPOSES the existing kernel
        matchers moduleScopeMap + pathMatch + permissionPathCheck, holding no
        domain logic), exposed so the module reaches it through the doorway
        instead of a deep core require. Generic (names no module) + additive, so
        MINOR. PERMANENT — same family as routeRankCheck/permissionPathCheck.
1.15.0 — task 1971 (single-host hall): the published ./serve-internal surface's
        host router (isBuildersHost) now also treats the configured
        branding().domains.buildersOrigin host as the hall host, so an instance with
        no dedicated builders.<apex> subdomain serves its hall on its own host.
        Backward-compatible new capability of an exported surface → MINOR. Also
        carries task 1970 (the firstAdmin web-flow admission fix, src/bongos/auth.js).
        First stock version to supersede the emersonian-circles 1.14.1 fork (the
        task 1973 de-fork).
1.16.0 — task 1690 / ADR 0100 §2 + ADR 0103 §4: the first core release consumed via the REAL
        `bongos upgrade` channel (previously the module-compat pre-check stub). Turns it into a
        real bump-pin → npm install → migrate → materialize .claude → restart → verify path, plus
        the per-instance core_upgrades ledger (core_189). Builds on the 1.15.0 line above; no
        doorway export removed or changed → MINOR.
1.17.0 — R14 (#2001 / ADR 0119, criterion api-pagination): adds the shared
        pagination helpers `parsePagination` / `pageMeta` / `PAGINATION` off
        _helpers.js so a MODULE list route adopts the one paging contract
        (limit/offset clamp + the page-meta block) instead of hand-rolling it —
        the same reason validateOrRespond/LIMITS are on the doorway. Additive
        (new exports, no export removed or changed) → MINOR; every `^1.x`
        module keeps working, and a module using them is satisfied by 1.17.0.
1.17.1 — task 2124 (republish after task 2121): the FIRST PATCH bump on this
        surface. No doorway export is added, changed, or removed — the exported
        surface is byte-identical to 1.17.0. What changed is the PUBLISHED ARTIFACT's
        content: (a) task 2121 taught package-core to replace every CLAUDE.md/AGENTS.md
        in the @bongos/core tarball with a tiny brand-free stub, so a consumer instance's
        agent no longer auto-loads the platform's own project memory from
        node_modules/@bongos/core/ (the 2026-07-08 demo audit leak); (b) the bundled code
        carries the task-2126 clearer device_flow_disabled error surfacing. A backwards-
        compatible artifact fix with no API change is exactly semver PATCH. The bump is
        REQUIRED because 1.17.0 was already published to npm and task 2121 shipped
        without one, so `bongos package-core --publish` on 1.17.0 would be rejected as a
        re-publish. Every `^1.x` / `^1.17` module pin is satisfied by 1.17.1.
1.17.2 — task 2148 (canary upgrade-proof on demo.cloudbongos.com): a controlled
        PATCH bump used to round-trip the real `bongos upgrade` channel on the live
        demo instance with an OBSERVABLE code marker (the channel shipped in 1.16.0
        and was proven on emersonian-circles by task 1976, but never on demo with a
        served marker). No doorway export is added, changed, or removed — the exported
        surface is byte-identical to 1.17.1. What changed: the served /version payload
        now carries `coreVersion` (the running doorway version — a PERMANENT additive
        read so upgrade/fleet tooling can confirm which core an instance materialized),
        plus a THROWAWAY `updateCanary` marker removed in the phase-E follow-up. A
        backwards-compatible additive change with no API removal is exactly semver
        PATCH. Every `^1.x` / `^1.17` module pin is satisfied by 1.17.2.
1.17.3 — task 2183 (R89 cutover prereq): republish so the packaged core carries the
        F6 migrate.sh fix (task 2180). Post-split, `scripts/migrate.sh` cd'd into the
        installed @bongos/core package before resolving the instance root, so a literal
        `npm run migrate` read the core's VANILLA module config and SILENTLY skipped
        every host + flag-gated module migration (rehearsal: 115 rows, no game schema;
        from the instance cwd, 121). 2180 fixed the script to resolve INSTANCE_ROOT from
        the invocation cwd (INIT_CWD/$PWD → the instance's bongos.config.json) and added
        a DB-free `--print-roots` regression guard. Published 1.17.2 PREDATES 2180, so a
        consumer pinning 1.17.2 would still skip host migrations — hence a PATCH republish
        at the F6-inclusive main. A functional-file bug fix with no doorway export change
        is exactly semver PATCH. Every `^1.x` / `^1.17` module pin is satisfied by 1.17.3.
1.18.0 — task 2190 (R89 follow-up): first version cut from the cloud-bongos AUTHORITATIVE
        source repo. Re-seeds the standalone core (which had frozen at the 2026-07-03
        v1.14.0 extraction while core dev continued inside example through 1.17.3)
        from example's last-with-core commit 345494f2. Content is 1.17.3 PLUS the
        builders'-hall UI redesign (developed in example as tasks 2171/2172/2173/2184) that
        post-dates the published 1.17.3 tarball — a new user-facing feature set with no
        doorway export removal, so semver MINOR. NOT yet published to npm (that is the
        follow-on release task); example still runs the vendored 1.17.3.
1.18.1 — go-live cut deployed to cloudbongos.com (owner-directed, 2026-07-14). Rolling
        1.18.0 content PLUS the onboarding GitHub repo picker + auto-create (task 1002099,
        ADR 0143 — core auth: opt-in public_repo scope, encrypted short-TTL token store,
        GET/POST /github/repos) and the goal 1000041 cross-project hub features
        (platform-identity module, ADR 0141). Adds no doorway export → semver PATCH.
1.18.2 — go-live cut for cloudbongos.com (owner-directed, 2026-07-14). Rolling 1.18.1
        content PLUS the /create onboarding repo-picker rendering fix (task 1002228):
        the Home step's `hidden` attribute was defeated by author display rules
        (.field/.row2), so the adopt-picker / fresh-name / manual sub-panels all showed
        at once, and #ghConnect never appeared (toggled via `hidden` instead of its .on
        class). A CSS/markup-only fix in public-landing/create.html. No doorway export
        change → semver PATCH.
1.18.3 — package-core .gitignore pin fix (task 1002229, idea 1000543). `npm install` never
        materializes .gitignore/.npmignore/.npmrc into an installed package, but package-core
        pinned a tracked .gitignore in tree_sha256 → every vendored `bongos upgrade` pin-verify
        failed with `missing installed file: .gitignore` and auto-rolled-back (the workaround
        was --skip-pin-verify, which the unattended auto-upgrade subscription cannot pass).
        package-core now drops npm-stripped files from the manifest + pin so it describes exactly
        what npm installs. Build-tool fix, no doorway export change → semver PATCH.
1.18.4 — ship the platform-identity hub module in the core package (task 1002235, goal 1000041).
        The module (ADR 0141: /sso/*, projects catalog, my-projects, scouting + its migrations) was
        built but never added to publish-manifest PUBLISH_ALLOWLIST, so it did not ship in
        @bongos/core — the hub's enabledModules() threw "unknown module platform-identity" and
        provision.js's federation load MODULE_NOT_FOUNDed. Reclassified IN (sibling of provisioning);
        default:false → shipped ≠ enabled, dormant on every instance until the hub turns it on. PATCH.
1.18.5 — configurable post-login landing (task 1002240, goal 1000041). A successful web sign-in
        that carried no explicit ?return= / same-apex Referer now lands on branding.landing.postLogin
        (auth.js postLoginLanding) instead of a hardcoded /builders. Portable default stays
        '/builders' (the hall always exists); env-overridable per instance via
        <PREFIX>_POST_LOGIN_LANDING. cloudbongos.com sets it to /gate/ so a visitor who signs in
        from the orbs returns to the orbs, never auto-redirected into the builders' hall. The value
        is validated through the open-redirect allowlist. Additive config read, no doorway change → PATCH.
1.18.6 — post-login ?return= fix (task 1002241). parseCookie() now URL-DECODES the cookie
        value, symmetric with Express res.cookie's percent-ENCODING. Before this, a return
        target like "/create" was stored as "%2Fcreate"; safeReturnTo() rejected the encoded
        form and every explicit ?return= fell through to the post-login landing (on
        cloudbongos.com, /gate/) — most visibly the onboarding "Connect GitHub" button, which
        bounced to the orbs instead of back to the wizard. Also un-breaks the #726 subdomain
        return. A bug fix in a shared route helper, no doorway change → PATCH.
1.18.7 — federated single-logout (task 1002238, goal 1000041, ADR 0144). Signing out of the hub now
        signs you out of every federated project too. Core gains: a `builder.logout` seam event
        (emitted by POST /auth/logout), a POST /auth/backchannel-logout endpoint (dormant unless the
        instance federates — idp set), and auth.js verifyHubLogoutToken. The hub (platform-identity)
        listens for builder.logout and fans a hub-signed EdDSA logout token out to each federated
        instance the builder entered, which verifies it (aud-scoped, purpose-tagged, ~120s TTL) and
        revokes that builder's local sessions. Identity/trust boundary intact (the token carries only
        a subject + purpose, never a rank). Additive event + route, no doorway change → PATCH.
1.18.8 — hall sign-out works on every page (task 1002245). The real sign-out (POST /auth/logout:
        revoke session + clear cookies + emit the `builder.logout` federated single-logout) was wired
        ONLY in the index script (builders.js); shell.js draws the sign-out control on EVERY hall page
        as a bare GET anchor to the POST-only endpoint, so on non-index pages the click 404'd — the
        session was never revoked and the hub never notified (the 1.18.7 SLO was bypassed). Centralized
        in shell.js (doLogout + a delegated click listener), with tests/hall_signout.mjs proving it.
        Also carries minor /create wizard polish (tasks 1002246/1002247). Client + shared-surface fix,
        no doorway change → PATCH.
1.18.9 — /create onboarding: the wizard's own "Sign in with GitHub" now requests repo scope up front
        (read:user + public_repo via &repos=1), so a visitor who signs in THROUGH the create flow grants
        everything in one GitHub screen and never hits the separate "Connect GitHub" step at Home —
        ensureRepoAccess()'s probe finds the stored token and shows the picker/creator directly. Also
        reworks the residual need-connect copy + button ("Allow repo access") so a user already signed
        in with identity-only scope isn't asked to "connect" as if signing in twice. Hall + CLI sign-in
        stay identity-only (ADR 0143 least-privilege default). Client-only (public-landing/create.html),
        no doorway change → PATCH. (task 1002259)
1.18.10 — reward-mode go-live: the configurable per-instance branding.reward.mode knob (economy;
        ADR 0146) lands together with the goal-1000037 pay-on-land migrations. Cloud Bongos selects
        "cost-plus-only" (instance config), so a shipped task pays only the cost-plus session reward,
        not the per-task author estimate; the estimate still rides the row for display + the no-zero
        claim gate. This deploy applies core_193 (tasks.needs_rebase columns) + core_194 (the one-time
        confirmed-backlog clawback). Default stays "cost-plus-and-estimate" → every other instance is
        unchanged; economy-only, no doorway change → PATCH. (task 1002270 + goal 1000037 go-live 1002273)
  1.18.12 — Docs-surface correctness (task 1002374). User-facing "GDS"/"Game Development System" →
        "Bongos" (primer, OpenAPI spec title/description + reference header, the two CLI session
        messages the primer quotes). 04-architecture diagram REDRAWN for the standalone model —
        own repo + auto-pull deploy (ADR 0129) + vendored @bongos/core (ADR 0108), product-neutral;
        it had hardcoded the reference game monorepo (example.com / GitHub-Actions deploy-prod.yml
        / "the live game"). Docs/prose + diagram generator only, no schema/doorway change → PATCH.
  1.18.11 — Standalone instances get live-updating docs (ADR 0147, task 1002314). gen-session-index.js
        now resolves the INSTANCE root (was hardcoded to the core, so a standalone box indexed
        node_modules/@bongos/core instead of its own sessions); adds upgrade.regenerateNavDocs() +
        a regen-instance-docs.js CLI wired into init/upgrade/provision-deploy; INSTANCE_GITIGNORE
        ignores the whole-file nav docs. Docs-pipeline only, no schema/doorway change → PATCH.
        (go-live 1002318)
  1.18.12 — docs-surface correctness: GDS→Bongos rename + standalone architecture redraw
        (task 1002374). Docs/prose + diagram generator only, no schema/doorway change → PATCH.
  1.18.13 — `bongos dev`: one-command LOCAL launcher for a standalone instance (task 1002397,
        ADR 0149). New CLI verb + scripts/gds/dev.js + dev-lib.js so a freshly-created,
        localhost-configured project stands up locally in one step. No schema/doorway change → PATCH.
  1.18.14 — module pollers actually start on a standalone instance (task 1002419). The loader's
        startModulePollers had ZERO callers once the game entrypoint server.js was retired, so
        EVERY module poller was dead — most visibly lifecycle/publish-reconciler, which is what
        drives confirmed→shipped, leaving merged tasks stranded at 'confirmed' indefinitely
        (12 rows, oldest 6.2 days). src/platform-server.js now starts them at boot behind the
        same isEnabled gate mountModuleRoutes uses, and stops them on SIGTERM/SIGINT. Wiring
        only — no schema/doorway change → PATCH. Any instance on ≤1.18.13 lands nothing until
        it takes this bump.
  1.18.15 — re-release of the 1.18.14 module-poller fix (task 1002419) under a fresh number.
        A SEPARATE release had already published 1.18.14 for the task-scoped dev-box go-live
        (goal 1000051), so the poller-fix 1.18.14 could never reach an instance already pinned to
        the dev-box 1.18.14 (same version = npm no-op; the pull-deploy loop skips npm ci when the
        lockfile is unchanged). This bump carries the identical src/platform-server.js poller
        wiring forward on a number no instance has taken yet, so the pin can actually move. No
        code delta vs the 1.18.14 already on main — version constant only → PATCH. (task 1002421)
  1.18.16 — go-live carrier for the hall version-UI work already merged to main since 1.18.15:
        the Roadmap "Command deck" redesign (task 1002426) and the sidebar reorg — nav order
        Roadmap→Goals→Tasks, the "Work" board relabelled "Tasks", goal-detail task parity
        (task 1002425, PR #17). Both landed on main with NO version bump, so no vendored-tarball
        instance could take them (the pull-deploy pin only moves on a fresh number). No new code
        delta beyond this constant → PATCH. (go-live task 1002431)
  1.18.17 — Goals page reorganised into a task-readiness rollup (grouped
        Active/Blocked/Achieved; each goal rolls its tasks into ready/in-progress/
        blocked + a next claimable task) and the task-list API gained an opt-in
        `?include=deps` that enriches each task with blocked_by[]/blocks so the
        hall can paint readiness without an N+1 (db.attachTaskDepSummaries). New
        export is additive; the enrichment is opt-in → PATCH. (task 1002439)
  1.18.18 — go-live carrier for 171 commits that landed on main between 2026-07-24
        and 2026-08-03 with no bump behind them, so no vendored-tarball instance
        could take any of them. Headline: the governance permission system
        (BV1.R95–R109 — resolver + kernel port, first-class principals, session
        scopes, requirePermission(), ownership-scoped grants, config/government.json)
        and the route-rank/validation hardening that followed it; the ship.js
        Windows project-path fix so Windows sessions actually get paid (89f291c);
        the sequential chain runner (task 1002484); Metic task abandon/un-abandon
        (ADR 0152); goal-authored criteria + the orphan-task goal_advisory (ADR
        0154); the nightly-backup 203/EXEC fix (task 1002479); and a broad hall
        pass (jump palette, sidebar regroup, browser-side idea triage, mobile
        overflow). This bump also carries the /<redacted> divergence
        check added under task 1002521 — the gap above went unnoticed for ten days
        precisely because nothing compared live against main. The doorway surface
        is byte-identical to 1.18.17 (governance is reached through the kernel
        port, not a new export), so despite the size this is → PATCH. (task 1002521)
  1.18.19 — NEVER PUBLISHED UNDER THIS NUMBER. This entry described a carrier bump
        that was never cut; the version 1.18.19 on the registry is something else
        entirely — a SINGLE-FIX patch published out-of-band on 2026-08-08 from a
        branch off the core-v1.18.18 tag (release/core-1.18.19), carrying only the
        space-in-path migration fix (`for f in $MIGRATIONS` word-split
        the migration list on IFS, so any checkout whose path contains a space
        applied ZERO core migrations, silently). It was cut off the TAG rather than
        off main precisely so a blocked instance could take that one fix without
        also taking the unreleased 1.19 tree. Everything the original note below
        describes is still unreleased and ships with 1.19.x — as does the migration
        fix itself, which is also on main. Original notes kept for the record:
        carrier bump for the 32 commits that landed on main between the
        1.18.18 bump (e25c7da, 2026-08-03) and 2026-08-04. Headline: the
        security-tooling line — the reading-room mirror with on-disk scrub +
        fence and realpath confinement, a hardened fetch with quarantine and a
        deterministic manifest, the SSRF hole closed, and the durable
        `security_tool_scans` record + its Metic+-write/all-ranks-read route
        (tasks 1002542/1002543/1002546/1002547, heavily grader-iterated). Also:
        the core unit suite went green (task 1002470 — 57 failing files down to
        3, and those 3 now sit behind an explicit ratchet that requires a
        justification and a named owner per entry, so a mute is no longer
        indistinguishable from a fix); the ship card can no longer report a
        bailed merge as landing (task 1002541); a user-set display name now
        survives sign-in (task 1002568) and the onboarding OAuth scope widened
        to `repo` so a private repo can be adopted; the hall profile shows the
        real reward instead of 0 (task 1002569); linking a blocker actually
        blocks the task (task 1002559); and the CLI box_scope detector was
        revived against the ADR 0116 envelope, which had silently dead-ended
        three call sites (task 1002162). The doorway surface is byte-identical
        to 1.18.18 — verified by diffing src/module-api.js across the range —
        so despite the volume this is → PATCH. (task 1002581)
  1.19.0 — requirePermission re-exported (BV1.R105, ADR 0151). A module route
        gated on an authority ATOM needs the same doorway access to the gate
        that requireRank has had since 1.0.0; without it the R104-R107
        migration could reach core routes only. Additive → MINOR. (task 1001847)
        Landed after 1.18.19, so this bump carries that carrier's contents too;
        the MINOR is owed solely to the added export. Instances pinned to a
        patch-only update channel will not take this automatically.
  1.19.1 — the release that actually carries 1.19.0. 1.19.0 was bumped by
        ad7a262 and never packaged, so ~104 non-merge commits sat on main
        reachable by no pin; this is the artifact that ships them. Headline:
        the governance permission system's second half (R110 roles/perms/
        assignments CRUD behind government.manage, R113 the Roles nav +
        page gate, R114 the C6 live proof, ADR 0157 delegating the
        operational block from Archon to Metic, and the permission resolve
        folded into the session load); the scan-before-install security
        line (deterministic zero-LLM floor, verdict reducer, reading-room
        mirror with on-disk scrub + realpath confinement, the scan-record
        route, and the SSRF fix — tasks 1002544-1002548); core_204
        re-keying the one-active-claim index per (session, worktree) so
        parallel worktrees can hold bound claims; the hall People tab and
        governance page; and the goal-board CLI. The doorway surface is
        byte-identical to 1.19.0 — verified by diffing src/module-api.js
        across ad7a262..HEAD — so despite the volume this is → PATCH.
        Cut as a fresh number rather than releasing HEAD as 1.19.0 so the
        changelog cannot claim 1.19.0's one-line entry describes 104
        commits. Note 1.18.x → 1.19.1 crosses a minor: a patch-only
        channel will not take it unattended. (task 1002602)
  1.19.2 — the init-blocker fixes: db.createVersion now sends the NOT NULL
        versions.track column (every POST /versions 500ed on a fresh DB,
        blocking bongos init outright — greenfield AND adopt), the route
        accepts + validates an optional `track`, init.js sends it explicitly,
        the 'instance look' kickoff task is kind:'decision' +
        discipline:'ideator' (kind:'ideator' violated tasks_kind_check and
        was silently dropped), and seed failures now report loudly with
        actual-vs-expected counts (task 1002623). Also carries the other
        unreleased commits since the 1.19.1 bump: the CI `unit` check +
        real CODEOWNERS/required-checks gating (tasks 1002610/1002611/
        1002619, ADR 0159), the repo-verifiable main-audit caller (1002612/
        1002618, ADR 0160), migrate.sh space-in-path fix, ship smoke-fail
        abort (1002605) + sandbox review-gate fix (1002607), strand
        notify-on-detect (1002606), reconciler out-of-band land (1002615),
        and the Metic-floor string sweep (1002604). The doorway surface is
        unchanged (an optional request field, no export change) → PATCH.
        (task 1002624)
  1.19.3 — CLI/init ergonomics carrier: `bongos <verb> --help` is answered by
        the dispatcher instead of blocking on init's interview (1002625),
        `bongos init` defaults branding configDir from the product slug so
        instances stop sharing ~/.config/cloudbongos and evicting each
        other's CLI sessions (1002626), versions.track gains DB DEFAULT
        'product' via core_205 so no insert path can reproduce the
        fresh-instance standup blocker (1002627). Also sweeps PATCH
        /tasks/:id gate atomicity (1002609) and the publish-on-merge lane
        (1002620, ADR 0161). git diff 1.19.2..main on this file was empty —
        the doorway surface is byte-identical → PATCH. (task 1002631)
  1.19.4 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.3 with no explicit bump. run 31275959473. (task 1002620)
  1.19.5 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.4 with no explicit bump. run 31276103393. (task 1002620)
  1.19.6 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.5 with no explicit bump. run 31277243929. (task 1002620)
  1.19.7 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.6 with no explicit bump. run 31277387539. (task 1002620)
  1.19.8 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.7 with no explicit bump. run 31277471863. (task 1002620)
  1.19.9 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.8 with no explicit bump. run 31277560455. (task 1002620)
  1.19.10 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.9 with no explicit bump. run 31277644352. (task 1002620)
  1.19.11 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.10 with no explicit bump. run 31277735279. (task 1002620)
  1.19.12 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.11 with no explicit bump. run 31277905072. (task 1002620)
  1.19.13 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.12 with no explicit bump. run 31277989346. (task 1002620)
  1.19.14 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.13 with no explicit bump. run 31332130808. (task 1002620)
  1.19.15 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.14 with no explicit bump. run 31332226243. (task 1002620)
  1.19.16 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.15 with no explicit bump. run 31332334081. (task 1002620)
  1.19.17 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.16 with no explicit bump. run 31332429037. (task 1002620)
  1.19.18 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.17 with no explicit bump. run 31346900677. (task 1002620)
  1.19.19 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.18 with no explicit bump. run 31346996715. (task 1002620)
  1.19.20 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.19 with no explicit bump. run 31347092915. (task 1002620)
  1.19.21 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.20 with no explicit bump. run 31446766597. (task 1002620)
  1.19.22 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.21 with no explicit bump. run 31449168428. (task 1002620)
  1.19.23 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.22 with no explicit bump. run 31450197816. (task 1002620)
  1.19.24 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.23 with no explicit bump. run 31450459825. (task 1002620)
  1.19.25 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.24 with no explicit bump. run 31495418623. (task 1002620)
  1.19.26 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.25 with no explicit bump. run 31495996665. (task 1002620)
  1.19.27 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.26 with no explicit bump. run 31497212656. (task 1002620)
  1.19.28 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.27 with no explicit bump. run 31499228797. (task 1002620)
  1.19.29 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.28 with no explicit bump. run 31500810303. (task 1002620)
  1.19.30 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.29 with no explicit bump. run 31502880105. (task 1002620)
  1.19.31 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.30 with no explicit bump. run 31503461332. (task 1002620)
  1.19.32 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.31 with no explicit bump. run 31504858325. (task 1002620)
  1.19.33 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.32 with no explicit bump. run 31505528205. (task 1002620)
  1.19.34 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.33 with no explicit bump. run 31505952506. (task 1002620)
  1.19.35 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.34 with no explicit bump. run 31507293725. (task 1002620)
  1.19.36 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.35 with no explicit bump. run 31509715311. (task 1002620)
  1.19.37 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.36 with no explicit bump. run 31510590459. (task 1002620)
  1.19.38 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.37 with no explicit bump. run 31511537558. (task 1002620)
  1.19.39 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.38 with no explicit bump. run 31512284325. (task 1002620)
  1.19.40 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.39 with no explicit bump. run 31513136724. (task 1002620)
  1.19.41 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.40 with no explicit bump. run 31513793491. (task 1002620)
  1.19.42 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.41 with no explicit bump. run 31515200576. (task 1002620)
  1.19.43 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.42 with no explicit bump. run 31517196176. (task 1002620)
  1.19.44 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.43 with no explicit bump. run 31518312009. (task 1002620)
  1.19.45 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.44 with no explicit bump. run 31519500533. (task 1002620)
  1.19.46 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.45 with no explicit bump. run 31520432748. (task 1002620)
  1.19.47 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.46 with no explicit bump. run 31521404176. (task 1002620)
  1.19.48 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.47 with no explicit bump. run 31522865111. (task 1002620)
  1.19.49 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.48 with no explicit bump. run 31523559509. (task 1002620)
  1.19.50 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.49 with no explicit bump. run 31524280584. (task 1002620)
  1.19.51 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.50 with no explicit bump. run 31525032273. (task 1002620)
  1.19.52 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.51 with no explicit bump. run 31526131183. (task 1002620)
  1.19.53 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.52 with no explicit bump. run 31527057565. (task 1002620)
  1.19.54 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.53 with no explicit bump. run 31531157867. (task 1002620)
  1.19.55 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.54 with no explicit bump. run 31534150701. (task 1002620)
  1.19.56 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.55 with no explicit bump. run 31535063954. (task 1002620)
  1.19.57 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.56 with no explicit bump. run 31542659439. (task 1002620)
  1.19.58 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.57 with no explicit bump. run 31546064883. (task 1002620)
  1.19.59 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.58 with no explicit bump. run 31547103265. (task 1002620)
  1.19.60 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.59 with no explicit bump. run 31548021746. (task 1002620)
  1.19.61 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.60 with no explicit bump. run 31550061440. (task 1002620)
  1.19.62 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.61 with no explicit bump. run 31552833331. (task 1002620)
  1.19.63 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.62 with no explicit bump. run 31553743979. (task 1002620)
  1.19.64 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.63 with no explicit bump. run 31560059785. (task 1002620)
  1.19.65 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.64 with no explicit bump. run 31562193292. (task 1002620)
  1.19.66 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.65 with no explicit bump. run 31599966075. (task 1002620)
  1.19.67 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.66 with no explicit bump. run 31605591253. (task 1002620)
  1.19.68 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.67 with no explicit bump. run 31608183268. (task 1002620)
  1.19.69 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.68 with no explicit bump. run 31608503813. (task 1002620)
  1.19.70 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.69 with no explicit bump. run 31612248859. (task 1002620)
  1.19.71 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.70 with no explicit bump. run 31613220077. (task 1002620)
  1.19.72 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.71 with no explicit bump. run 31617976225. (task 1002620)
  1.19.73 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.72 with no explicit bump. run 31619275904. (task 1002620)
  1.19.74 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.73 with no explicit bump. run 31628379432. (task 1002620)
  1.19.75 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.74 with no explicit bump. run 31632769733. (task 1002620)
  1.19.76 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.75 with no explicit bump. run 31637719876. (task 1002620)
  1.19.77 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.76 with no explicit bump. run 31647860631. (task 1002620)
  1.19.78 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.77 with no explicit bump. run 31648127800. (task 1002620)
  1.19.79 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.78 with no explicit bump. run 31648954641. (task 1002620)
  1.19.80 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.79 with no explicit bump. run 31649366675. (task 1002620)
  1.19.81 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.80 with no explicit bump. run 31649705242. (task 1002620)
  1.19.82 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.81 with no explicit bump. run 31650108283. (task 1002620)
  1.19.83 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.82 with no explicit bump. run 31651046759. (task 1002620)
  1.19.84 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.83 with no explicit bump. run 31651217970. (task 1002620)
  1.19.85 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.84 with no explicit bump. run 31651469729. (task 1002620)
  1.19.86 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.85 with no explicit bump. run 31655210981. (task 1002620)
  1.19.87 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.86 with no explicit bump. run 31656188572. (task 1002620)
  1.19.88 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.87 with no explicit bump. run 31656577595. (task 1002620)
  1.19.89 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.88 with no explicit bump. run 31657467485. (task 1002620)
  1.19.90 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.89 with no explicit bump. run 31717551308. (task 1002620)
  1.19.91 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.90 with no explicit bump. run 31722841411. (task 1002620)
  1.19.92 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.91 with no explicit bump. run 31727411036. (task 1002620)
  1.19.93 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.92 with no explicit bump. run 31735192921. (task 1002620)
  1.19.94 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.93 with no explicit bump. run 31742308532. (task 1002620)
  1.19.95 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.94 with no explicit bump. run 31746921919. (task 1002620)
  1.19.96 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.95 with no explicit bump. run 31748829423. (task 1002620)
  1.19.97 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.96 with no explicit bump. run 31749223878. (task 1002620)
  1.19.98 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.97 with no explicit bump. run 31749841394. (task 1002620)
  1.19.99 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.98 with no explicit bump. run 31750941866. (task 1002620)
  1.19.100 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.99 with no explicit bump. run 31751275973. (task 1002620)
  1.19.101 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.100 with no explicit bump. run 31752022322. (task 1002620)
  1.19.102 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.101 with no explicit bump. run 31753496152. (task 1002620)
  1.19.103 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.102 with no explicit bump. run 31754659965. (task 1002620)
  1.19.104 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.103 with no explicit bump. run 31756625919. (task 1002620)
  1.19.105 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.104 with no explicit bump. run 31758526405. (task 1002620)
  1.19.106 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.105 with no explicit bump. run 31759315328. (task 1002620)
  1.19.107 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.106 with no explicit bump. run 31762781737. (task 1002620)
  1.19.108 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.107 with no explicit bump. run 31803763842. (task 1002620)
  1.19.109 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.108 with no explicit bump. run 31809188532. (task 1002620)
  1.19.110 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.109 with no explicit bump. run 31810003558. (task 1002620)
  1.19.111 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.110 with no explicit bump. run 31810638191. (task 1002620)
  1.19.112 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.111 with no explicit bump. run 31814245230. (task 1002620)
  1.19.113 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.112 with no explicit bump. run 31816239246. (task 1002620)
  1.19.114 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.113 with no explicit bump. run 31816599678. (task 1002620)
  1.19.115 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.114 with no explicit bump. run 31825824596. (task 1002620)
  1.19.116 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.115 with no explicit bump. run 31827642395. (task 1002620)
  1.19.117 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.116 with no explicit bump. run 31830559253. (task 1002620)
  1.19.118 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.117 with no explicit bump. run 31833658900. (task 1002620)
  1.19.119 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.118 with no explicit bump. run 31835957309. (task 1002620)
  1.19.120 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.119 with no explicit bump. run 31836959112. (task 1002620)
  1.19.121 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.120 with no explicit bump. run 31838955115. (task 1002620)
  1.19.122 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.121 with no explicit bump. run 31840810826. (task 1002620)
  1.19.123 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.122 with no explicit bump. run 31842559470. (task 1002620)
  1.19.124 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.123 with no explicit bump. run 31844281033. (task 1002620)
  1.19.125 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.124 with no explicit bump. run 31849445746. (task 1002620)
  1.19.126 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.125 with no explicit bump. run 31853055269. (task 1002620)
  1.19.127 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.126 with no explicit bump. run 31854730552. (task 1002620)
  1.19.128 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.127 with no explicit bump. run 31857842473. (task 1002620)
  1.19.129 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.128 with no explicit bump. run 31858158416. (task 1002620)
  1.19.130 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.129 with no explicit bump. run 31861289412. (task 1002620)
  1.19.131 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.130 with no explicit bump. run 31861682626. (task 1002620)
  1.19.132 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.131 with no explicit bump. run 31862317758. (task 1002620)
  1.19.133 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.132 with no explicit bump. run 31862484011. (task 1002620)
  1.19.134 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.133 with no explicit bump. run 31862749526. (task 1002620)
  1.19.135 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.134 with no explicit bump. run 31863235867. (task 1002620)
  1.19.136 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.135 with no explicit bump. run 31889474899. (task 1002620)
  1.19.137 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.136 with no explicit bump. run 31890033301. (task 1002620)
  1.19.138 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.137 with no explicit bump. run 31891128524. (task 1002620)
  1.19.139 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.138 with no explicit bump. run 31891461224. (task 1002620)
  1.19.140 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.139 with no explicit bump. run 31891805999. (task 1002620)
  1.19.141 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.140 with no explicit bump. run 31892484952. (task 1002620)
  1.19.142 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.141 with no explicit bump. run 31893298770. (task 1002620)
  1.19.143 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.142 with no explicit bump. run 31893905320. (task 1002620)
  1.19.144 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.143 with no explicit bump. run 31894547582. (task 1002620)
  1.19.145 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.144 with no explicit bump. run 31895007353. (task 1002620)
  1.19.146 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.145 with no explicit bump. run 31904091158. (task 1002620)
  1.19.147 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.146 with no explicit bump. run 31950807165. (task 1002620)
  1.19.148 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.147 with no explicit bump. run 31952592623. (task 1002620)
  1.19.149 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.148 with no explicit bump. run 31953207683. (task 1002620)
  1.19.150 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.149 with no explicit bump. run 31953504697. (task 1002620)
  1.19.151 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.150 with no explicit bump. run 31953827282. (task 1002620)
  1.19.152 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.151 with no explicit bump. run 31955923444. (task 1002620)
  1.19.153 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.152 with no explicit bump. run 31956560292. (task 1002620)
  1.19.154 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.153 with no explicit bump. run 31957052737. (task 1002620)
  1.19.155 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.154 with no explicit bump. run 31957556550. (task 1002620)
  1.19.156 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.155 with no explicit bump. run 31957976979. (task 1002620)
  1.19.157 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.156 with no explicit bump. run 31958139486. (task 1002620)
  1.19.158 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.157 with no explicit bump. run 31958753412. (task 1002620)
  1.19.159 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.158 with no explicit bump. run 31958999646. (task 1002620)
  1.19.160 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.159 with no explicit bump. run 31959145128. (task 1002620)
  1.19.161 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.160 with no explicit bump. run 31959299652. (task 1002620)
  1.19.162 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.161 with no explicit bump. run 31959496815. (task 1002620)
  1.19.163 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.162 with no explicit bump. run 31959864781. (task 1002620)
  1.19.164 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.163 with no explicit bump. run 31960518012. (task 1002620)
  1.19.165 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.164 with no explicit bump. run 31960929146. (task 1002620)
  1.19.166 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.165 with no explicit bump. run 31961272140. (task 1002620)
  1.19.167 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.166 with no explicit bump. run 31961815831. (task 1002620)
  1.19.168 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.167 with no explicit bump. run 31962256201. (task 1002620)
  1.19.169 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.168 with no explicit bump. run 31964702865. (task 1002620)
  1.19.170 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.169 with no explicit bump. run 31965483417. (task 1002620)
  1.19.171 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.170 with no explicit bump. run 31967255167. (task 1002620)
  1.19.172 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.171 with no explicit bump. run 31968188738. (task 1002620)
  1.19.173 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.172 with no explicit bump. run 31968656001. (task 1002620)
  1.19.174 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.173 with no explicit bump. run 31969032984. (task 1002620)
  1.19.175 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.174 with no explicit bump. run 31970199477. (task 1002620)
  1.19.176 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.175 with no explicit bump. run 31971125373. (task 1002620)
  1.19.177 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.176 with no explicit bump. run 31971532260. (task 1002620)
  1.19.178 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.177 with no explicit bump. run 31971769062. (task 1002620)
  1.19.179 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.178 with no explicit bump. run 31972209764. (task 1002620)
  1.19.180 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.179 with no explicit bump. run 31972568511. (task 1002620)
  1.19.181 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.180 with no explicit bump. run 31972686846. (task 1002620)
  1.19.182 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.181 with no explicit bump. run 31972846686. (task 1002620)
  1.19.183 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.182 with no explicit bump. run 31973728179. (task 1002620)
  1.19.184 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.183 with no explicit bump. run 31974847472. (task 1002620)
  1.19.185 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.184 with no explicit bump. run 31976564067. (task 1002620)
  1.19.186 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.185 with no explicit bump. run 31977207459. (task 1002620)
  1.19.187 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.186 with no explicit bump. run 31978548058. (task 1002620)
  1.19.188 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.187 with no explicit bump. run 31978931152. (task 1002620)
  1.19.189 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.188 with no explicit bump. run 31983108640. (task 1002620)
  1.19.190 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.189 with no explicit bump. run 31983360426. (task 1002620)
  1.19.191 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.190 with no explicit bump. run 31983663234. (task 1002620)
  1.19.192 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.191 with no explicit bump. run 31984583069. (task 1002620)
  1.19.193 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.192 with no explicit bump. run 31985689267. (task 1002620)
  1.19.194 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.193 with no explicit bump. run 31987857242. (task 1002620)
  1.19.195 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.194 with no explicit bump. run 31988381869. (task 1002620)
  1.19.196 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.195 with no explicit bump. run 31988890305. (task 1002620)
  1.19.197 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.196 with no explicit bump. run 32039532169. (task 1002620)
  1.19.198 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.197 with no explicit bump. run 32045034525. (task 1002620)
  1.19.199 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.198 with no explicit bump. run 32045249602. (task 1002620)
  1.19.200 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.199 with no explicit bump. run 32058296632. (task 1002620)
  1.19.201 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.200 with no explicit bump. run 32058666256. (task 1002620)
  1.19.202 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.201 with no explicit bump. run 32059276345. (task 1002620)
  1.19.203 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.202 with no explicit bump. run 32059705946. (task 1002620)
  1.19.204 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.203 with no explicit bump. run 32060607072. (task 1002620)
  1.19.205 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.204 with no explicit bump. run 32061149280. (task 1002620)
  1.19.206 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.205 with no explicit bump. run 32064728346. (task 1002620)
  1.19.207 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.206 with no explicit bump. run 32065995444. (task 1002620)
  1.19.208 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.207 with no explicit bump. run 32068332007. (task 1002620)
  1.19.209 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.208 with no explicit bump. run 32072227661. (task 1002620)
  1.19.210 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.209 with no explicit bump. run 32078135414. (task 1002620)
  1.19.211 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.210 with no explicit bump. run 32079512489. (task 1002620)
  1.19.212 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.211 with no explicit bump. run 32080157462. (task 1002620)
  1.19.213 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.212 with no explicit bump. run 32081051255. (task 1002620)
  1.19.214 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.213 with no explicit bump. run 32081917908. (task 1002620)
  1.19.215 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.214 with no explicit bump. run 32084187695. (task 1002620)
  1.19.216 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.215 with no explicit bump. run 32084584347. (task 1002620)
  1.19.217 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.216 with no explicit bump. run 32084927511. (task 1002620)
  1.19.218 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.217 with no explicit bump. run 32086598601. (task 1002620)
  1.19.219 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.218 with no explicit bump. run 32094215476. (task 1002620)
  1.19.220 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.219 with no explicit bump. run 32094701831. (task 1002620)
  1.19.221 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.220 with no explicit bump. run 32095276039. (task 1002620)
  1.19.222 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.221 with no explicit bump. run 32096034408. (task 1002620)
  1.19.223 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.222 with no explicit bump. run 32097491676. (task 1002620)
  1.19.224 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.223 with no explicit bump. run 32098083321. (task 1002620)
  1.19.225 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.224 with no explicit bump. run 32099793591. (task 1002620)
  1.19.226 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.225 with no explicit bump. run 32100543772. (task 1002620)
  1.19.227 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.226 with no explicit bump. run 32101041951. (task 1002620)
  1.19.228 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.227 with no explicit bump. run 32101659669. (task 1002620)
  1.19.229 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.228 with no explicit bump. run 32130159805. (task 1002620)
  1.19.230 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.229 with no explicit bump. run 32131450528. (task 1002620)
  1.19.231 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.230 with no explicit bump. run 32133132988. (task 1002620)
  1.19.232 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.231 with no explicit bump. run 32133691409. (task 1002620)
  1.19.233 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.232 with no explicit bump. run 32160823445. (task 1002620)
  1.19.234 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.233 with no explicit bump. run 32161368847. (task 1002620)
  1.19.235 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.234 with no explicit bump. run 32161981393. (task 1002620)
  1.19.236 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.235 with no explicit bump. run 32162811851. (task 1002620)
  1.19.237 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.236 with no explicit bump. run 32164526454. (task 1002620)
  1.19.238 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.237 with no explicit bump. run 32172843539. (task 1002620)
  1.19.239 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.238 with no explicit bump. run 32174983930. (task 1002620)
  1.19.240 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.239 with no explicit bump. run 32182178305. (task 1002620)
  1.19.241 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.240 with no explicit bump. run 32184475745. (task 1002620)
  1.19.242 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.241 with no explicit bump. run 32185198139. (task 1002620)
  1.19.243 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.242 with no explicit bump. run 32193666731. (task 1002620)
  1.19.244 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.243 with no explicit bump. run 32196511343. (task 1002620)
  1.19.245 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.244 with no explicit bump. run 32196805853. (task 1002620)
  1.19.246 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.245 with no explicit bump. run 32197129803. (task 1002620)
  1.19.247 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.246 with no explicit bump. run 32197488065. (task 1002620)
  1.19.248 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.247 with no explicit bump. run 32198208766. (task 1002620)
  1.19.249 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.248 with no explicit bump. run 32199293372. (task 1002620)
  1.19.250 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.249 with no explicit bump. run 32203357427. (task 1002620)
  1.19.251 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.250 with no explicit bump. run 32204008770. (task 1002620)
  1.19.252 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.251 with no explicit bump. run 32205191350. (task 1002620)
  1.19.253 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.252 with no explicit bump. run 32205833181. (task 1002620)
  1.19.254 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.253 with no explicit bump. run 32207504942. (task 1002620)
  1.19.255 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.254 with no explicit bump. run 32207967928. (task 1002620)
  1.19.256 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.255 with no explicit bump. run 32208475455. (task 1002620)
  1.19.257 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.256 with no explicit bump. run 32209295358. (task 1002620)
  1.19.258 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.257 with no explicit bump. run 32284962866. (task 1002620)
  1.19.259 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.258 with no explicit bump. run 32286866098. (task 1002620)
  1.19.260 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.259 with no explicit bump. run 32289043893. (task 1002620)
  1.19.261 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.260 with no explicit bump. run 32295699354. (task 1002620)
  1.19.262 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.261 with no explicit bump. run 32298063660. (task 1002620)
  1.19.263 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.262 with no explicit bump. run 32305228786. (task 1002620)
  1.19.264 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.263 with no explicit bump. run 32396082154. (task 1002620)
  1.19.265 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.264 with no explicit bump. run 32396925426. (task 1002620)
  1.19.266 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.265 with no explicit bump. run 32400609982. (task 1002620)
  1.19.267 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.266 with no explicit bump. run 32404853216. (task 1002620)
  1.19.268 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.267 with no explicit bump. run 32407127474. (task 1002620)
  1.19.269 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.268 with no explicit bump. run 32427178123. (task 1002620)
  1.19.270 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.269 with no explicit bump. run 32428659648. (task 1002620)
  1.19.271 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.270 with no explicit bump. run 32437463473. (task 1002620)
  1.19.272 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.271 with no explicit bump. run 32438140524. (task 1002620)
  1.19.273 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.272 with no explicit bump. run 32441024959. (task 1002620)
  1.19.274 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.273 with no explicit bump. run 32490024209. (task 1002620)
  1.19.275 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.274 with no explicit bump. run 32492414871. (task 1002620)
  1.19.276 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.275 with no explicit bump. run 32499257959. (task 1002620)
  1.19.277 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.276 with no explicit bump. run 32503053532. (task 1002620)
  1.19.278 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.277 with no explicit bump. run 32508270995. (task 1002620)
  1.19.279 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.278 with no explicit bump. run 32521664476. (task 1002620)
  1.19.280 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.279 with no explicit bump. run 32523185119. (task 1002620)
  1.19.281 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.280 with no explicit bump. run 32525071763. (task 1002620)
  1.19.282 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.281 with no explicit bump. run 32526392955. (task 1002620)
  1.19.283 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.282 with no explicit bump. run 32527313879. (task 1002620)
  1.19.284 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.283 with no explicit bump. run 32531111199. (task 1002620)
  1.19.285 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.284 with no explicit bump. run 32531963073. (task 1002620)
  1.19.286 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.285 with no explicit bump. run 32533647172. (task 1002620)
  1.19.287 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.286 with no explicit bump. run 32539649191. (task 1002620)
  1.19.288 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.287 with no explicit bump. run 32546561232. (task 1002620)
  1.19.289 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.288 with no explicit bump. run 32549912116. (task 1002620)
  1.19.290 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.289 with no explicit bump. run 32552538814. (task 1002620)
  1.19.291 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.290 with no explicit bump. run 32580353000. (task 1002620)
  1.19.292 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.291 with no explicit bump. run 32582800234. (task 1002620)
  1.19.293 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.292 with no explicit bump. run 32586174253. (task 1002620)
  1.19.294 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.293 with no explicit bump. run 32588977219. (task 1002620)
  1.19.295 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.294 with no explicit bump. run 32590508145. (task 1002620)
  1.19.296 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.295 with no explicit bump. run 32591155887. (task 1002620)
  1.19.297 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.296 with no explicit bump. run 32592502621. (task 1002620)
  1.19.298 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.297 with no explicit bump. run 32597859474. (task 1002620)
  1.19.299 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.298 with no explicit bump. run 32600322268. (task 1002620)
  1.19.300 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.299 with no explicit bump. run 32601521458. (task 1002620)
  1.19.301 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.300 with no explicit bump. run 32602146266. (task 1002620)
  1.19.302 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.301 with no explicit bump. run 32604538465. (task 1002620)
  1.19.303 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.302 with no explicit bump. run 32605477232. (task 1002620)
  1.19.304 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.303 with no explicit bump. run 32660527575. (task 1002620)
  1.19.305 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.304 with no explicit bump. run 32660902666. (task 1002620)
  1.19.306 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.305 with no explicit bump. run 32662000590. (task 1002620)
  1.19.307 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.306 with no explicit bump. run 32663876767. (task 1002620)
  1.19.308 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.307 with no explicit bump. run 32664559221. (task 1002620)
  1.19.309 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.308 with no explicit bump. run 32664868080. (task 1002620)
  1.19.310 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.309 with no explicit bump. run 32665109518. (task 1002620)
  1.19.311 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.310 with no explicit bump. run 32665535518. (task 1002620)
  1.19.312 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.311 with no explicit bump. run 32665664699. (task 1002620)
  1.19.313 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.312 with no explicit bump. run 32668457836. (task 1002620)
  1.19.314 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.313 with no explicit bump. run 32668599111. (task 1002620)
  1.19.315 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.314 with no explicit bump. run 32668969037. (task 1002620)
  1.19.316 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.315 with no explicit bump. run 32669347711. (task 1002620)
  1.19.317 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.316 with no explicit bump. run 32669571610. (task 1002620)
  1.19.318 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.317 with no explicit bump. run 32669798745. (task 1002620)
  1.19.319 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.318 with no explicit bump. run 32670195088. (task 1002620)
  1.19.320 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.319 with no explicit bump. run 32678147546. (task 1002620)
  1.19.321 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.320 with no explicit bump. run 32679324013. (task 1002620)
  1.19.322 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.321 with no explicit bump. run 32679604360. (task 1002620)
  1.19.323 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.322 with no explicit bump. run 32680138776. (task 1002620)
  1.19.324 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.323 with no explicit bump. run 32737868129. (task 1002620)
  1.19.325 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.324 with no explicit bump. run 32738897943. (task 1002620)
  1.19.326 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.325 with no explicit bump. run 32777788032. (task 1002620)
  1.19.327 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.326 with no explicit bump. run 32782353048. (task 1002620)
  1.19.328 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.327 with no explicit bump. run 32786284063. (task 1002620)
  1.19.329 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.328 with no explicit bump. run 32788827293. (task 1002620)
  1.19.330 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.329 with no explicit bump. run 32789596635. (task 1002620)
  1.19.331 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.330 with no explicit bump. run 32791877167. (task 1002620)
  1.19.332 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.331 with no explicit bump. run 32793033453. (task 1002620)
  1.19.333 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.332 with no explicit bump. run 32793666555. (task 1002620)
  1.19.334 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.333 with no explicit bump. run 32794305277. (task 1002620)
  1.19.335 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.334 with no explicit bump. run 32795232997. (task 1002620)
  1.19.336 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.335 with no explicit bump. run 32795564021. (task 1002620)
  1.19.337 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.336 with no explicit bump. run 32795896926. (task 1002620)
  1.19.338 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.337 with no explicit bump. run 32796733697. (task 1002620)
  1.19.339 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.338 with no explicit bump. run 32797325535. (task 1002620)
  1.19.340 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.339 with no explicit bump. run 32798342738. (task 1002620)
  1.19.341 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.340 with no explicit bump. run 32798507686. (task 1002620)
  1.19.342 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.341 with no explicit bump. run 32799103427. (task 1002620)
  1.19.343 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.342 with no explicit bump. run 32799245758. (task 1002620)
  1.19.344 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.343 with no explicit bump. run 32799492873. (task 1002620)
  1.19.345 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.344 with no explicit bump. run 32800819617. (task 1002620)
  1.19.346 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.345 with no explicit bump. run 32801147433. (task 1002620)
  1.19.347 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.346 with no explicit bump. run 32802265337. (task 1002620)
  1.19.348 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.347 with no explicit bump. run 32802746363. (task 1002620)
  1.19.349 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.348 with no explicit bump. run 32803276871. (task 1002620)
  1.19.350 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.349 with no explicit bump. run 32810944115. (task 1002620)
  1.19.351 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.350 with no explicit bump. run 32850120472. (task 1002620)
  1.19.352 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.351 with no explicit bump. run 32850767673. (task 1002620)
  1.19.353 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.352 with no explicit bump. run 32851392269. (task 1002620)
  1.19.354 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.353 with no explicit bump. run 32852045058. (task 1002620)
  1.19.355 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.354 with no explicit bump. run 32853063015. (task 1002620)
  1.19.356 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.355 with no explicit bump. run 32861072779. (task 1002620)
  1.19.357 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.356 with no explicit bump. run 32871335939. (task 1002620)
  1.19.358 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.357 with no explicit bump. run 32872551850. (task 1002620)
  1.19.359 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.358 with no explicit bump. run 32877754251. (task 1002620)
  1.19.360 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.359 with no explicit bump. run 32881040669. (task 1002620)
  1.19.361 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.360 with no explicit bump. run 32883230235. (task 1002620)
  1.19.362 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.361 with no explicit bump. run 32886106098. (task 1002620)
  1.19.363 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.362 with no explicit bump. run 32889324497. (task 1002620)
  1.19.364 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.363 with no explicit bump. run 32890225073. (task 1002620)
  1.19.365 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.364 with no explicit bump. run 32893443215. (task 1002620)
  1.19.366 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.365 with no explicit bump. run 32895705036. (task 1002620)
  1.19.367 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.366 with no explicit bump. run 32902059088. (task 1002620)
  1.19.368 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.367 with no explicit bump. run 32902864988. (task 1002620)
  1.19.369 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.368 with no explicit bump. run 32903289072. (task 1002620)
  1.19.370 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.369 with no explicit bump. run 32904231221. (task 1002620)
  1.19.371 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.370 with no explicit bump. run 32904582252. (task 1002620)
  1.19.372 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.371 with no explicit bump. run 32905166786. (task 1002620)
  1.19.373 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.372 with no explicit bump. run 32906118616. (task 1002620)
  1.19.374 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.373 with no explicit bump. run 32906477349. (task 1002620)
  (next carrier) — joinabilityMode re-exported (task 1003044, goal 1000058; ADR 0194).
        The project's membership door — open / apply / invite_only — is enforced by
        the admission machinery: the two sign-in flows self-enrol only on 'open', and
        the onboarding module's public POST /access-requests must refuse an invite-only
        project with the SAME decision (SR-19: one gate, no drift), so the reader moves
        onto the doorway beside branding. Additive — a MINOR by the 1.19.0 precedent,
        but a hand-bumped version cannot pass the publish lane's LIVE test
        (tests/bump_version.mjs: HEAD's version must be one the lane's own carrier
        commits announced), so it rides the next CI patch; the contradiction with
        ADR 0161 §2 is filed as an idea from task 1003044.
  1.19.375 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.374 with no explicit bump. run 32909701598. (task 1002620)
  1.19.376 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.375 with no explicit bump. run 32910331206. (task 1002620)
  1.19.377 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.376 with no explicit bump. run 33025011131. (task 1002620)
  1.19.378 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.377 with no explicit bump. run 33025512093. (task 1002620)
  1.19.379 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.378 with no explicit bump. run 33026467245. (task 1002620)
  1.19.380 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.379 with no explicit bump. run 33085516721. (task 1002620)
  1.19.381 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.380 with no explicit bump. run 33088290961. (task 1002620)
  1.19.382 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.381 with no explicit bump. run 33094545251. (task 1002620)
  1.19.383 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.382 with no explicit bump. run 33101389971. (task 1002620)
  1.19.384 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.383 with no explicit bump. run 33116184189. (task 1002620)
  1.19.385 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.384 with no explicit bump. run 33118682829. (task 1002620)
  1.19.386 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.385 with no explicit bump. run 33120468176. (task 1002620)
  1.19.387 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.386 with no explicit bump. run 33121066592. (task 1002620)
  1.19.388 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.387 with no explicit bump. run 33125589814. (task 1002620)
  1.19.389 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.388 with no explicit bump. run 33126279278. (task 1002620)
  1.19.390 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.389 with no explicit bump. run 33133575931. (task 1002620)
  1.19.391 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.390 with no explicit bump. run 33134514193. (task 1002620)
  1.19.392 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.391 with no explicit bump. run 33176032603. (task 1002620)
  1.19.393 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.392 with no explicit bump. run 33177136260. (task 1002620)
  1.19.394 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.393 with no explicit bump. run 33182535783. (task 1002620)
  1.19.395 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.394 with no explicit bump. run 33188021384. (task 1002620)
  1.19.396 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.395 with no explicit bump. run 33188525568. (task 1002620)
  1.19.397 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.396 with no explicit bump. run 33193365480. (task 1002620)
  1.19.398 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.397 with no explicit bump. run 33199474439. (task 1002620)
  1.19.399 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.398 with no explicit bump. run 33201243958. (task 1002620)
  1.19.400 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.399 with no explicit bump. run 33201979306. (task 1002620)
  1.19.401 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.400 with no explicit bump. run 33205015717. (task 1002620)
  1.19.402 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.401 with no explicit bump. run 33206226800. (task 1002620)
  1.19.403 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.402 with no explicit bump. run 33208825538. (task 1002620)
  1.19.404 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.403 with no explicit bump. run 33211074633. (task 1002620)
  1.19.405 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.404 with no explicit bump. run 33212035244. (task 1002620)
  1.19.406 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.405 with no explicit bump. run 33213981964. (task 1002620)
  1.19.407 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.406 with no explicit bump. run 33214451873. (task 1002620)
  1.19.408 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.407 with no explicit bump. run 33216756796. (task 1002620)
  1.19.409 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.408 with no explicit bump. run 33217065997. (task 1002620)
  1.19.410 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.409 with no explicit bump. run 33217599338. (task 1002620)
  1.19.411 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.410 with no explicit bump. run 33218290583. (task 1002620)
  1.19.412 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.411 with no explicit bump. run 33259357678. (task 1002620)
  1.19.413 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.412 with no explicit bump. run 33259477562. (task 1002620)
  1.19.414 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.413 with no explicit bump. run 33260596712. (task 1002620)
  1.19.415 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.414 with no explicit bump. run 33262322596. (task 1002620)
  1.19.416 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.415 with no explicit bump. run 33262582879. (task 1002620)
  1.19.417 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.416 with no explicit bump. run 33263505319. (task 1002620)
  1.19.418 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.417 with no explicit bump. run 33264139544. (task 1002620)
  1.19.419 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.418 with no explicit bump. run 33265382684. (task 1002620)
  1.19.420 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.419 with no explicit bump. run 33266034679. (task 1002620)
  1.19.421 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.420 with no explicit bump. run 33266605270. (task 1002620)
  1.19.422 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.421 with no explicit bump. run 33267393283. (task 1002620)
  1.19.423 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.422 with no explicit bump. run 33269205170. (task 1002620)
  1.19.424 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.423 with no explicit bump. run 33270353952. (task 1002620)
  1.19.425 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.424 with no explicit bump. run 33270559541. (task 1002620)
  1.19.426 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.425 with no explicit bump. run 33270772607. (task 1002620)
  1.19.427 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.426 with no explicit bump. run 33271340372. (task 1002620)
  1.19.428 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.427 with no explicit bump. run 33274315388. (task 1002620)
  1.19.429 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.428 with no explicit bump. run 33274860035. (task 1002620)
  1.19.430 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.429 with no explicit bump. run 33275468532. (task 1002620)
  1.19.431 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.430 with no explicit bump. run 33277001235. (task 1002620)
  1.19.432 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.431 with no explicit bump. run 33279328366. (task 1002620)
  1.19.433 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.432 with no explicit bump. run 33279772171. (task 1002620)
  1.19.434 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.433 with no explicit bump. run 33281881764. (task 1002620)
  1.19.435 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.434 with no explicit bump. run 33286790214. (task 1002620)
  1.19.436 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.435 with no explicit bump. run 33288364716. (task 1002620)
  1.19.437 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.436 with no explicit bump. run 33289560561. (task 1002620)
  1.19.438 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.437 with no explicit bump. run 33290212472. (task 1002620)
  1.19.439 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.438 with no explicit bump. run 33290633434. (task 1002620)
  1.19.440 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.439 with no explicit bump. run 33321131006. (task 1002620)
  1.19.441 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.440 with no explicit bump. run 33323478836. (task 1002620)
  1.19.442 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.441 with no explicit bump. run 33326781131. (task 1002620)
  1.19.443 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.442 with no explicit bump. run 33330337830. (task 1002620)
  1.19.444 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.443 with no explicit bump. run 33334908383. (task 1002620)
  1.19.445 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.444 with no explicit bump. run 33337122866. (task 1002620)
  1.19.446 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.445 with no explicit bump. run 33341626697. (task 1002620)
  1.19.447 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.446 with no explicit bump. run 33345047021. (task 1002620)
  1.19.448 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.447 with no explicit bump. run 33348050270. (task 1002620)
  1.19.449 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.448 with no explicit bump. run 33406714743. (task 1002620)
  1.19.450 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.449 with no explicit bump. run 33414986466. (task 1002620)
  1.19.451 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.450 with no explicit bump. run 33549781105. (task 1002620)
  1.19.452 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.451 with no explicit bump. run 33552353620. (task 1002620)
  1.19.453 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.452 with no explicit bump. run 33553290345. (task 1002620)
  1.19.454 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.453 with no explicit bump. run 33554965618. (task 1002620)
  1.19.455 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.454 with no explicit bump. run 33558738299. (task 1002620)
  1.19.456 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.455 with no explicit bump. run 33560584235. (task 1002620)
  1.19.457 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.456 with no explicit bump. run 33561330390. (task 1002620)
  1.19.458 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.457 with no explicit bump. run 33566876510. (task 1002620)
  1.19.459 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.458 with no explicit bump. run 33568609735. (task 1002620)
  1.19.460 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.459 with no explicit bump. run 33571137958. (task 1002620)
  1.19.461 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.460 with no explicit bump. run 33571982271. (task 1002620)
  1.19.462 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.461 with no explicit bump. run 33576366095. (task 1002620)
  1.19.463 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.462 with no explicit bump. run 33577660347. (task 1002620)
  1.19.464 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.463 with no explicit bump. run 33578746178. (task 1002620)
  1.19.465 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.464 with no explicit bump. run 33581328823. (task 1002620)
  1.19.466 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.465 with no explicit bump. run 33583122775. (task 1002620)
  1.19.467 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.466 with no explicit bump. run 33638703282. (task 1002620)
  1.19.468 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.467 with no explicit bump. run 33640370009. (task 1002620)
  1.19.469 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.468 with no explicit bump. run 33643388774. (task 1002620)
  1.19.470 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.469 with no explicit bump. run 33644371734. (task 1002620)
  1.19.471 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.470 with no explicit bump. run 33645344292. (task 1002620)
  1.19.472 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.471 with no explicit bump. run 33646171957. (task 1002620)
  1.19.473 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.472 with no explicit bump. run 33646919877. (task 1002620)
  1.19.474 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.473 with no explicit bump. run 33650008858. (task 1002620)
  1.19.475 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.474 with no explicit bump. run 33653632532. (task 1002620)
  1.19.476 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.475 with no explicit bump. run 33655706909. (task 1002620)
  1.19.477 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.476 with no explicit bump. run 33662059275. (task 1002620)
  1.19.478 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.477 with no explicit bump. run 33664027105. (task 1002620)
  1.19.479 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.478 with no explicit bump. run 33665076054. (task 1002620)
  1.19.480 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.479 with no explicit bump. run 33668172411. (task 1002620)
  1.19.481 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.480 with no explicit bump. run 33670051626. (task 1002620)
  1.19.482 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.481 with no explicit bump. run 33670786915. (task 1002620)
  1.19.483 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.482 with no explicit bump. run 33674657478. (task 1002620)
  1.19.484 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.483 with no explicit bump. run 33675143968. (task 1002620)
  1.19.485 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.484 with no explicit bump. run 33681828446. (task 1002620)
  1.19.486 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.485 with no explicit bump. run 33682949187. (task 1002620)
  1.19.487 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.486 with no explicit bump. run 33684267982. (task 1002620)
  1.19.488 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.487 with no explicit bump. run 33686951657. (task 1002620)
  1.19.489 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.488 with no explicit bump. run 33687461982. (task 1002620)
  1.19.490 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.489 with no explicit bump. run 33691767867. (task 1002620)
  1.19.491 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.490 with no explicit bump. run 33692191645. (task 1002620)
  1.19.492 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.491 with no explicit bump. run 33693742388. (task 1002620)
  1.19.493 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.492 with no explicit bump. run 33694576680. (task 1002620)
  1.19.494 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.493 with no explicit bump. run 33697218855. (task 1002620)
  1.19.495 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.494 with no explicit bump. run 33766103175. (task 1002620)
  1.19.496 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.495 with no explicit bump. run 33766363834. (task 1002620)
  1.19.497 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.496 with no explicit bump. run 33767382661. (task 1002620)
  1.19.498 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.497 with no explicit bump. run 33768753719. (task 1002620)
  1.19.499 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.498 with no explicit bump. run 33769500709. (task 1002620)
  1.19.500 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.499 with no explicit bump. run 33772499045. (task 1002620)
  1.19.501 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.500 with no explicit bump. run 33774087943. (task 1002620)
  1.19.502 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.501 with no explicit bump. run 33777587058. (task 1002620)
  1.19.503 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.502 with no explicit bump. run 33783963947. (task 1002620)
  1.19.504 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.503 with no explicit bump. run 33784387586. (task 1002620)
  1.19.505 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.504 with no explicit bump. run 33785121177. (task 1002620)
  1.19.506 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.505 with no explicit bump. run 33787453336. (task 1002620)
  1.19.507 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.506 with no explicit bump. run 33788726591. (task 1002620)
  1.19.508 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.507 with no explicit bump. run 33790206682. (task 1002620)
  1.19.509 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.508 with no explicit bump. run 33790542026. (task 1002620)
  1.19.510 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.509 with no explicit bump. run 33791237400. (task 1002620)
  1.19.511 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.510 with no explicit bump. run 33792868990. (task 1002620)
  1.19.512 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.511 with no explicit bump. run 33793208383. (task 1002620)
  1.19.513 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.512 with no explicit bump. run 33795977371. (task 1002620)
  1.19.514 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.513 with no explicit bump. run 33796959752. (task 1002620)
  1.19.515 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.514 with no explicit bump. run 33797825811. (task 1002620)
  1.19.516 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.515 with no explicit bump. run 33798954769. (task 1002620)
  1.19.517 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.516 with no explicit bump. run 33799755382. (task 1002620)
  1.19.518 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.517 with no explicit bump. run 33801792364. (task 1002620)
  1.19.519 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.518 with no explicit bump. run 33802471495. (task 1002620)
  1.19.520 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.519 with no explicit bump. run 33810716476. (task 1002620)
  1.19.521 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.520 with no explicit bump. run 33813285951. (task 1002620)
  1.19.522 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.521 with no explicit bump. run 33815020928. (task 1002620)
  1.19.523 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.522 with no explicit bump. run 33816191865. (task 1002620)
  1.19.524 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.523 with no explicit bump. run 33818285201. (task 1002620)
  1.19.525 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.524 with no explicit bump. run 33823218193. (task 1002620)
  1.19.526 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.525 with no explicit bump. run 33824700579. (task 1002620)
  1.19.527 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.526 with no explicit bump. run 33827382028. (task 1002620)
  1.19.528 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.527 with no explicit bump. run 33829339717. (task 1002620)
  1.19.529 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.528 with no explicit bump. run 33877197857. (task 1002620)
  1.19.530 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.529 with no explicit bump. run 33878817005. (task 1002620)
  1.19.531 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.530 with no explicit bump. run 33879403011. (task 1002620)
  1.19.532 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.531 with no explicit bump. run 33880032943. (task 1002620)
  1.19.533 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.532 with no explicit bump. run 33881330388. (task 1002620)
  (next carrier) — projectJoinDoor re-exported (task 1002331, goal 1000046; ADR
        0182 D6, ADR 0247). joinabilityMode above answers ONE knob; a project's
        join/apply door is the composition of three — where it stands on the
        platform's map (visibility), what a public join grants (joinGrant), and how
        someone becomes a member (joinability) — and ADR 0182 D6's rule is that the
        stricter always wins and none may widen another. That is only true if ONE
        function says so, so the composed answer moves onto the doorway beside
        joinabilityMode, and the onboarding module's public POST /access-requests
        calls it instead of reading a single knob. Additive — a MINOR by the 1.19.0
        precedent, but a hand-bumped version cannot pass the publish lane's LIVE
        test (tests/bump_version.mjs), so it rides the next CI patch, exactly as
        joinabilityMode did at 1.19.374.
  1.19.534 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.533 with no explicit bump. run 33885355024. (task 1002620)
  1.19.535 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.534 with no explicit bump. run 33886686350. (task 1002620)
  1.19.536 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.535 with no explicit bump. run 33888048777. (task 1002620)
  1.19.537 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.536 with no explicit bump. run 33888812605. (task 1002620)
  1.19.538 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.537 with no explicit bump. run 33890191596. (task 1002620)
  1.19.539 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.538 with no explicit bump. run 33892948885. (task 1002620)
  1.19.540 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.539 with no explicit bump. run 33895602533. (task 1002620)
  1.19.541 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.540 with no explicit bump. run 33897974683. (task 1002620)
  1.19.542 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.541 with no explicit bump. run 33898437821. (task 1002620)
  1.19.543 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.542 with no explicit bump. run 33898997776. (task 1002620)
  1.19.544 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.543 with no explicit bump. run 33899781074. (task 1002620)
  1.19.545 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.544 with no explicit bump. run 33902527608. (task 1002620)
  1.19.546 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.545 with no explicit bump. run 33904396127. (task 1002620)
  1.19.547 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.546 with no explicit bump. run 33904937499. (task 1002620)
  1.19.548 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.547 with no explicit bump. run 33905411089. (task 1002620)
  1.19.549 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.548 with no explicit bump. run 33906859934. (task 1002620)
  1.19.550 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.549 with no explicit bump. run 33907331050. (task 1002620)
  1.19.551 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.550 with no explicit bump. run 33917261720. (task 1002620)
  1.19.552 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.551 with no explicit bump. run 34043771286. (task 1002620)
  1.19.553 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.552 with no explicit bump. run 34044208907. (task 1002620)
  1.19.554 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.553 with no explicit bump. run 34044540046. (task 1002620)
  1.19.555 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.554 with no explicit bump. run 34045075186. (task 1002620)
  1.19.556 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.555 with no explicit bump. run 34045323629. (task 1002620)
  1.19.557 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.556 with no explicit bump. run 34045753301. (task 1002620)
  1.19.558 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.557 with no explicit bump. run 34046699120. (task 1002620)
  1.19.559 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.558 with no explicit bump. run 34047187381. (task 1002620)
  1.19.560 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.559 with no explicit bump. run 34047736326. (task 1002620)
  1.19.561 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.560 with no explicit bump. run 34048169727. (task 1002620)
  1.19.562 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.561 with no explicit bump. run 34048961786. (task 1002620)
  1.19.563 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.562 with no explicit bump. run 34049959536. (task 1002620)
  1.19.564 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.563 with no explicit bump. run 34052578659. (task 1002620)
  1.19.565 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.564 with no explicit bump. run 34055981223. (task 1002620)
  1.19.566 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.565 with no explicit bump. run 34056809932. (task 1002620)
  1.19.567 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.566 with no explicit bump. run 34057551680. (task 1002620)
  1.19.568 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.567 with no explicit bump. run 34058174866. (task 1002620)
  1.19.569 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.568 with no explicit bump. run 34058387853. (task 1002620)
  1.19.570 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.569 with no explicit bump. run 34060442118. (task 1002620)
  1.19.571 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.570 with no explicit bump. run 34065943703. (task 1002620)
  1.19.572 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.571 with no explicit bump. run 34071078624. (task 1002620)
  1.19.573 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.572 with no explicit bump. run 34072921884. (task 1002620)
  1.19.574 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.573 with no explicit bump. run 34075598213. (task 1002620)
  1.19.575 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.574 with no explicit bump. run 34076465465. (task 1002620)
  1.19.576 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.575 with no explicit bump. run 34132732488. (task 1002620)
  1.19.577 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.576 with no explicit bump. run 34142767912. (task 1002620)
  1.19.578 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.577 with no explicit bump. run 34146835487. (task 1002620)
  1.19.579 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.578 with no explicit bump. run 34149317186. (task 1002620)
  1.19.580 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.579 with no explicit bump. run 34153217035. (task 1002620)
  1.19.581 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.580 with no explicit bump. run 34158683008. (task 1002620)
  1.19.582 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.581 with no explicit bump. run 34160253741. (task 1002620)
  1.19.583 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.582 with no explicit bump. run 34162998083. (task 1002620)
  1.19.584 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.583 with no explicit bump. run 34164936809. (task 1002620)
  1.19.585 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.584 with no explicit bump. run 34165392436. (task 1002620)
  1.19.586 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.585 with no explicit bump. run 34167072966. (task 1002620)
  1.19.587 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.586 with no explicit bump. run 34172785860. (task 1002620)
  1.19.588 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.587 with no explicit bump. run 34178696372. (task 1002620)
  1.19.589 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.588 with no explicit bump. run 34179479729. (task 1002620)
  1.19.590 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.589 with no explicit bump. run 34180363432. (task 1002620)
  1.19.591 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.590 with no explicit bump. run 34181177013. (task 1002620)
  1.19.592 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.591 with no explicit bump. run 34181434332. (task 1002620)
  1.19.593 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.592 with no explicit bump. run 34184095455. (task 1002620)
  1.19.594 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.593 with no explicit bump. run 34184562228. (task 1002620)
  1.19.595 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.594 with no explicit bump. run 34185042811. (task 1002620)
  1.19.596 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.595 with no explicit bump. run 34185477798. (task 1002620)
  1.19.597 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.596 with no explicit bump. run 34186368179. (task 1002620)
  1.19.598 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.597 with no explicit bump. run 34186758247. (task 1002620)
  1.19.599 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.598 with no explicit bump. run 34187136306. (task 1002620)
  1.19.600 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.599 with no explicit bump. run 34187881031. (task 1002620)
  1.19.601 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.600 with no explicit bump. run 34188958832. (task 1002620)
  1.19.602 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.601 with no explicit bump. run 34189930315. (task 1002620)
  1.19.603 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.602 with no explicit bump. run 34191126290. (task 1002620)
  1.19.604 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.603 with no explicit bump. run 34288910914. (task 1002620)
  1.19.605 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.604 with no explicit bump. run 34290892691. (task 1002620)
  1.19.606 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.605 with no explicit bump. run 34291868670. (task 1002620)
  1.19.607 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.606 with no explicit bump. run 34292436274. (task 1002620)
  1.19.608 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.607 with no explicit bump. run 34293848928. (task 1002620)
  1.19.609 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.608 with no explicit bump. run 34297289824. (task 1002620)
  1.19.610 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.609 with no explicit bump. run 34305007041. (task 1002620)
  1.19.611 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.610 with no explicit bump. run 34305857169. (task 1002620)
  1.19.612 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.611 with no explicit bump. run 34310708322. (task 1002620)
  1.19.613 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.612 with no explicit bump. run 34311691842. (task 1002620)
  1.19.614 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.613 with no explicit bump. run 34314327601. (task 1002620)
  1.19.615 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.614 with no explicit bump. run 34314595235. (task 1002620)
  1.19.616 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.615 with no explicit bump. run 34315726534. (task 1002620)
  1.19.617 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.616 with no explicit bump. run 34317034024. (task 1002620)
  1.19.618 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.617 with no explicit bump. run 34318552090. (task 1002620)
  1.19.619 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.618 with no explicit bump. run 34320024204. (task 1002620)
  1.19.620 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.619 with no explicit bump. run 34321089991. (task 1002620)
  1.19.621 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.620 with no explicit bump. run 34321546662. (task 1002620)
  1.19.622 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.621 with no explicit bump. run 34322091367. (task 1002620)
  1.19.623 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.622 with no explicit bump. run 34323141703. (task 1002620)
  1.19.624 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.623 with no explicit bump. run 34326009063. (task 1002620)
  1.19.625 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.624 with no explicit bump. run 34328603214. (task 1002620)
  1.19.626 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.625 with no explicit bump. run 34363350286. (task 1002620)
  1.19.627 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.626 with no explicit bump. run 34390069410. (task 1002620)
  1.19.628 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.627 with no explicit bump. run 34397967061. (task 1002620)
  1.19.629 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.628 with no explicit bump. run 34412159317. (task 1002620)
  1.19.630 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.629 with no explicit bump. run 34415169250. (task 1002620)
  1.19.631 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.630 with no explicit bump. run 34415537907. (task 1002620)
  1.19.632 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.631 with no explicit bump. run 34417373737. (task 1002620)
  1.19.633 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.632 with no explicit bump. run 34417769106. (task 1002620)
  1.19.634 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.633 with no explicit bump. run 34429621784. (task 1002620)
  1.19.635 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.634 with no explicit bump. run 34429906252. (task 1002620)
  1.19.636 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.635 with no explicit bump. run 34434517065. (task 1002620)
  1.19.637 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.636 with no explicit bump. run 34436870653. (task 1002620)
  1.19.638 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.637 with no explicit bump. run 34438897721. (task 1002620)
  1.19.639 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.638 with no explicit bump. run 34502609272. (task 1002620)
  1.19.640 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.639 with no explicit bump. run 34506041899. (task 1002620)
  1.19.641 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.640 with no explicit bump. run 34506718627. (task 1002620)
  1.19.642 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.641 with no explicit bump. run 34507442448. (task 1002620)
  1.19.643 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.642 with no explicit bump. run 34509123612. (task 1002620)
  1.19.644 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.643 with no explicit bump. run 34509682128. (task 1002620)
  1.19.645 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.644 with no explicit bump. run 34511775606. (task 1002620)
  1.19.646 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.645 with no explicit bump. run 34512629504. (task 1002620)
  1.19.647 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.646 with no explicit bump. run 34515733973. (task 1002620)
  1.19.648 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.647 with no explicit bump. run 34518387614. (task 1002620)
  1.19.649 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.648 with no explicit bump. run 34523111338. (task 1002620)
  1.19.650 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.649 with no explicit bump. run 34523753119. (task 1002620)
  1.19.651 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.650 with no explicit bump. run 34526936330. (task 1002620)
  1.19.652 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.651 with no explicit bump. run 34529655648. (task 1002620)
  1.19.653 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.652 with no explicit bump. run 34543713846. (task 1002620)
  1.19.654 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.653 with no explicit bump. run 34544345437. (task 1002620)
  1.19.655 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.654 with no explicit bump. run 34545744588. (task 1002620)
  1.19.656 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.655 with no explicit bump. run 34546461767. (task 1002620)
  1.19.657 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.656 with no explicit bump. run 34546894776. (task 1002620)
  1.19.658 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.657 with no explicit bump. run 34547406494. (task 1002620)
  1.19.659 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.658 with no explicit bump. run 34550130772. (task 1002620)
  1.19.660 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.659 with no explicit bump. run 34551485764. (task 1002620)
  1.19.661 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.660 with no explicit bump. run 34552525938. (task 1002620)
  1.19.662 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.661 with no explicit bump. run 34553965204. (task 1002620)
  1.19.663 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.662 with no explicit bump. run 34557840364. (task 1002620)
  (next carrier) — grantedScopeCoversRepos re-exported (task 1002909, goal 1000106).
        The provisioning module's create-route credential preflight must tell "that
        repo does not exist" apart from "it is private and your pre-ADR-0155 token
        cannot see it" — GitHub answers 404 to both — so it needs the canonical scope
        read. Shared rather than re-implemented because `public_repo` CONTAINS the
        substring "repo", so a naive match accepts exactly the stale token it guards
        against. auth-config.js is KERNEL (ADR 0091 §1), so this stays inside the
        kernel-imports-only rule; db.getGithubToken and github-repos are DOMAIN and
        deliberately did NOT come through the doorway — the module reaches those via
        the already-exposed `pool` + `secretBox` and its own one-field repo client.
  1.19.664 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.663 with no explicit bump. run 34558906002. (task 1002620)
  1.19.665 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.664 with no explicit bump. run 34560552542. (task 1002620)
  1.19.666 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.665 with no explicit bump. run 34567142386. (task 1002620)
  1.19.667 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.666 with no explicit bump. run 34576878372. (task 1002620)
  1.19.668 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.667 with no explicit bump. run 34618700494. (task 1002620)
  1.19.669 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.668 with no explicit bump. run 34619821252. (task 1002620)
  1.19.670 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.669 with no explicit bump. run 34622305231. (task 1002620)
  1.19.671 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.670 with no explicit bump. run 34627255469. (task 1002620)
  1.19.672 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.671 with no explicit bump. run 34629971417. (task 1002620)
  1.19.673 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.672 with no explicit bump. run 34632328471. (task 1002620)
  1.19.674 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.673 with no explicit bump. run 34634515595. (task 1002620)
  1.19.675 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.674 with no explicit bump. run 34639371461. (task 1002620)
  1.19.676 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.675 with no explicit bump. run 34645751352. (task 1002620)
  1.19.677 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.676 with no explicit bump. run 34650610723. (task 1002620)
  1.19.678 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.677 with no explicit bump. run 34653458123. (task 1002620)
  1.19.679 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.678 with no explicit bump. run 34657605820. (task 1002620)
  1.19.680 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.679 with no explicit bump. run 34665216511. (task 1002620)
  1.19.681 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.680 with no explicit bump. run 34666648354. (task 1002620)
  1.19.682 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.681 with no explicit bump. run 34704993368. (task 1002620)
  1.19.683 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.682 with no explicit bump. run 34706984747. (task 1002620)
  1.19.684 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.683 with no explicit bump. run 34718471740. (task 1002620)
  1.19.685 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.684 with no explicit bump. run 34719298791. (task 1002620)
  1.19.686 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.685 with no explicit bump. run 34721104118. (task 1002620)
  1.19.687 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.686 with no explicit bump. run 34724811506. (task 1002620)
  1.19.688 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.687 with no explicit bump. run 34725902871. (task 1002620)
  1.19.689 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.688 with no explicit bump. run 34726470555. (task 1002620)
  1.19.690 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.689 with no explicit bump. run 34727464797. (task 1002620)
  1.19.691 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.690 with no explicit bump. run 34729018766. (task 1002620)
  1.19.692 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.691 with no explicit bump. run 34730821372. (task 1002620)
  1.19.693 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.692 with no explicit bump. run 34731402927. (task 1002620)
  1.19.694 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.693 with no explicit bump. run 34731674808. (task 1002620)
  1.19.695 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.694 with no explicit bump. run 34732266878. (task 1002620)
  1.19.696 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.695 with no explicit bump. run 34733145358. (task 1002620)
  1.19.697 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.696 with no explicit bump. run 34733301156. (task 1002620)
  1.19.698 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.697 with no explicit bump. run 34733917938. (task 1002620)
  1.19.699 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.698 with no explicit bump. run 34734848584. (task 1002620)
  1.19.700 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.699 with no explicit bump. run 34735048203. (task 1002620)
  1.19.701 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.700 with no explicit bump. run 34735311256. (task 1002620)
  1.19.702 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.701 with no explicit bump. run 34735775228. (task 1002620)
  1.19.703 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.702 with no explicit bump. run 34736566183. (task 1002620)
  1.19.704 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.703 with no explicit bump. run 34738864605. (task 1002620)
  1.19.705 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.704 with no explicit bump. run 34739785273. (task 1002620)
  1.19.706 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.705 with no explicit bump. run 34740247460. (task 1002620)
  1.19.707 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.706 with no explicit bump. run 34741980536. (task 1002620)
  1.19.708 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.707 with no explicit bump. run 34742245823. (task 1002620)
  1.19.709 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.708 with no explicit bump. run 34743928060. (task 1002620)
  1.19.710 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.709 with no explicit bump. run 34744369035. (task 1002620)
  1.19.711 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.710 with no explicit bump. run 34744940181. (task 1002620)
  1.19.712 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.711 with no explicit bump. run 34745412403. (task 1002620)
  1.19.713 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.712 with no explicit bump. run 34745667268. (task 1002620)
  1.19.714 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.713 with no explicit bump. run 34746102135. (task 1002620)
  1.19.715 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.714 with no explicit bump. run 34747181910. (task 1002620)
  1.19.716 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.715 with no explicit bump. run 34750496516. (task 1002620)
  (next carrier) — artistGate + getFoundingBuilder re-exported (task 1003575,
        goal 1000074; ADR 0241). The project ARTIST GATE — off | advisory | strict —
        and the pure verdict helpers over it. Two modules ask it two different
        questions: the lifecycle cascade asks "should this artist review be filed at
        all?" (off files none), and the deploy asks "does an open one hold the pin?"
        (strict holds it). Both must resolve the knob through THIS one reader rather
        than branding().project, because the fail-closed default and ADR 0241
        section 5 non-retroactivity cutoff live in it, and a second reader is how the
        level that FILES and the level that HOLDS start disagreeing.
        getFoundingBuilder rides with it as kernel identity beside getBuilderById:
        ADR 0241 section 3 gives the gate's one escape hatch to the PROJECT OWNER
        alone, and a module cannot enforce that without being able to ask who that
        is. Additive — a MINOR by the 1.19.0 precedent, but a hand-bumped version
        cannot pass the publish lane LIVE test (tests/bump_version.mjs), so it rides
        the next CI patch, exactly as projectJoinDoor did.
  1.19.717 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.716 with no explicit bump. run 34751690435. (task 1002620)
  1.19.718 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.717 with no explicit bump. run 34753530801. (task 1002620)
  1.19.719 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.718 with no explicit bump. run 34754578762. (task 1002620)
  1.19.720 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.719 with no explicit bump. run 34755367817. (task 1002620)
  1.19.721 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.720 with no explicit bump. run 34756186426. (task 1002620)
  1.19.722 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.721 with no explicit bump. run 34757838186. (task 1002620)
  1.19.723 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.722 with no explicit bump. run 34758720786. (task 1002620)
  1.19.724 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.723 with no explicit bump. run 34759302425. (task 1002620)
  1.19.725 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.724 with no explicit bump. run 34760272743. (task 1002620)
  1.19.726 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.725 with no explicit bump. run 34763380132. (task 1002620)
  1.19.727 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.726 with no explicit bump. run 34763937238. (task 1002620)
  1.19.728 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.727 with no explicit bump. run 34764630913. (task 1002620)
  1.19.729 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.728 with no explicit bump. run 34765179905. (task 1002620)
  1.19.730 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.729 with no explicit bump. run 34765502139. (task 1002620)
  1.19.731 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.730 with no explicit bump. run 34766029928. (task 1002620)
  1.19.732 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.731 with no explicit bump. run 34766314699. (task 1002620)
  1.19.733 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.732 with no explicit bump. run 34766569496. (task 1002620)
  1.19.734 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.733 with no explicit bump. run 34767120578. (task 1002620)
  1.19.735 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.734 with no explicit bump. run 34768136326. (task 1002620)
  1.19.736 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.735 with no explicit bump. run 34771773838. (task 1002620)
  1.19.737 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.736 with no explicit bump. run 34795026282. (task 1002620)
  1.19.738 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.737 with no explicit bump. run 34797297122. (task 1002620)
  1.19.739 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.738 with no explicit bump. run 34838475604. (task 1002620)
  1.19.740 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.739 with no explicit bump. run 34839732962. (task 1002620)
  1.19.741 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.740 with no explicit bump. run 34977074381. (task 1002620)
  1.19.742 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.741 with no explicit bump. run 34983109625. (task 1002620)
  1.19.743 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.742 with no explicit bump. run 34984876076. (task 1002620)
  1.19.744 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.743 with no explicit bump. run 34985887902. (task 1002620)
  1.19.745 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.744 with no explicit bump. run 34990123950. (task 1002620)
  1.19.746 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.745 with no explicit bump. run 35021312150. (task 1002620)
  1.19.747 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.746 with no explicit bump. run 35025151628. (task 1002620)
  1.19.748 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.747 with no explicit bump. run 35026862340. (task 1002620)
  1.19.749 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.748 with no explicit bump. run 35028684745. (task 1002620)
  1.19.750 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.749 with no explicit bump. run 35030717430. (task 1002620)
  1.19.751 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.750 with no explicit bump. run 35033016299. (task 1002620)
  1.19.752 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.751 with no explicit bump. run 35034524356. (task 1002620)
  1.19.753 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.752 with no explicit bump. run 35036151976. (task 1002620)
  1.19.754 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.753 with no explicit bump. run 35039836268. (task 1002620)
  1.19.755 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.754 with no explicit bump. run 35047010813. (task 1002620)
  1.19.756 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.755 with no explicit bump. run 35047623582. (task 1002620)
  1.19.757 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.756 with no explicit bump. run 35048307666. (task 1002620)
  1.19.758 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.757 with no explicit bump. run 35049006030. (task 1002620)
  1.19.759 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.758 with no explicit bump. run 35050268139. (task 1002620)
  1.19.760 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.759 with no explicit bump. run 35052040282. (task 1002620)
  1.19.761 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.760 with no explicit bump. run 35052410219. (task 1002620)
  1.19.762 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.761 with no explicit bump. run 35053643269. (task 1002620)
  1.19.763 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.762 with no explicit bump. run 35056690992. (task 1002620)
  1.19.764 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.763 with no explicit bump. run 35059447999. (task 1002620)
  1.19.765 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.764 with no explicit bump. run 35102327521. (task 1002620)
  1.19.766 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.765 with no explicit bump. run 35104246900. (task 1002620)
  1.19.767 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.766 with no explicit bump. run 35109111074. (task 1002620)
  1.19.768 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.767 with no explicit bump. run 35110800163. (task 1002620)
  1.19.769 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.768 with no explicit bump. run 35111616379. (task 1002620)
  1.19.770 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.769 with no explicit bump. run 35113578542. (task 1002620)
  1.19.771 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.770 with no explicit bump. run 35116254725. (task 1002620)
  1.19.772 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.771 with no explicit bump. run 35117652607. (task 1002620)
  1.19.773 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.772 with no explicit bump. run 35118731311. (task 1002620)
  1.19.774 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.773 with no explicit bump. run 35132992149. (task 1002620)
  1.19.775 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.774 with no explicit bump. run 35133750943. (task 1002620)
  1.19.776 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.775 with no explicit bump. run 35135604764. (task 1002620)
  1.19.777 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.776 with no explicit bump. run 35137334438. (task 1002620)
  1.19.778 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.777 with no explicit bump. run 35139523999. (task 1002620)
  1.19.779 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.778 with no explicit bump. run 35144678111. (task 1002620)
  1.19.780 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.779 with no explicit bump. run 35147229585. (task 1002620)
  1.19.781 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.780 with no explicit bump. run 35150109281. (task 1002620)
  1.19.782 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.781 with no explicit bump. run 35150844959. (task 1002620)
  1.19.783 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.782 with no explicit bump. run 35152631705. (task 1002620)
  1.19.784 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.783 with no explicit bump. run 35155326585. (task 1002620)
  1.19.785 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.784 with no explicit bump. run 35156349018. (task 1002620)
  1.19.786 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.785 with no explicit bump. run 35157132070. (task 1002620)
  1.19.787 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.786 with no explicit bump. run 35158163962. (task 1002620)
  1.19.788 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.787 with no explicit bump. run 35159266737. (task 1002620)
  1.19.789 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.788 with no explicit bump. run 35159544354. (task 1002620)
  1.19.790 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.789 with no explicit bump. run 35163350575. (task 1002620)
  1.19.791 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.790 with no explicit bump. run 35165066743. (task 1002620)
  1.19.792 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.791 with no explicit bump. run 35166486577. (task 1002620)
  1.19.793 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.792 with no explicit bump. run 35167484049. (task 1002620)
  1.19.794 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.793 with no explicit bump. run 35167814500. (task 1002620)
  1.19.795 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.794 with no explicit bump. run 35168408728. (task 1002620)
  1.19.796 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.795 with no explicit bump. run 35169093667. (task 1002620)
  1.19.797 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.796 with no explicit bump. run 35169694391. (task 1002620)
  1.19.798 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.797 with no explicit bump. run 35170229509. (task 1002620)
  1.19.799 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.798 with no explicit bump. run 35170980369. (task 1002620)
  1.19.800 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.799 with no explicit bump. run 35172784518. (task 1002620)
  1.19.801 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.800 with no explicit bump. run 35173442594. (task 1002620)
  1.19.802 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.801 with no explicit bump. run 35174865190. (task 1002620)
  1.19.803 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.802 with no explicit bump. run 35175617185. (task 1002620)
  1.19.804 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.803 with no explicit bump. run 35178689663. (task 1002620)
  1.19.805 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.804 with no explicit bump. run 35180781365. (task 1002620)
  1.19.806 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.805 with no explicit bump. run 35182765995. (task 1002620)
  1.19.807 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.806 with no explicit bump. run 35183654397. (task 1002620)
  1.19.808 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.807 with no explicit bump. run 35185130913. (task 1002620)
  1.19.809 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.808 with no explicit bump. run 35187322516. (task 1002620)
  1.19.810 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.809 with no explicit bump. run 35188253911. (task 1002620)
  1.19.811 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.810 with no explicit bump. run 35189324772. (task 1002620)
  1.19.812 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.811 with no explicit bump. run 35191850392. (task 1002620)
  1.19.813 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.812 with no explicit bump. run 35193306517. (task 1002620)
  1.19.814 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.813 with no explicit bump. run 35194334679. (task 1002620)
  1.19.815 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.814 with no explicit bump. run 35197139985. (task 1002620)
  1.19.816 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.815 with no explicit bump. run 35198566737. (task 1002620)
  1.19.817 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.816 with no explicit bump. run 35200401779. (task 1002620)
  1.19.818 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.817 with no explicit bump. run 35201213516. (task 1002620)
  1.19.819 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.818 with no explicit bump. run 35206448426. (task 1002620)
  1.19.820 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.819 with no explicit bump. run 35209838815. (task 1002620)
  1.19.821 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.820 with no explicit bump. run 35212866365. (task 1002620)
  1.19.822 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.821 with no explicit bump. run 35213847140. (task 1002620)
  1.19.823 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.822 with no explicit bump. run 35218585239. (task 1002620)
  1.19.824 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.823 with no explicit bump. run 35220051893. (task 1002620)
  1.19.825 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.824 with no explicit bump. run 35227529838. (task 1002620)
  1.19.826 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.825 with no explicit bump. run 35228618989. (task 1002620)
  1.19.827 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.826 with no explicit bump. run 35230339528. (task 1002620)
  1.19.828 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.827 with no explicit bump. run 35231300810. (task 1002620)
  1.19.829 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.828 with no explicit bump. run 35234300466. (task 1002620)
  1.19.830 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.829 with no explicit bump. run 35235005422. (task 1002620)
  1.19.831 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.830 with no explicit bump. run 35238952391. (task 1002620)
  1.19.832 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.831 with no explicit bump. run 35240512571. (task 1002620)
  1.19.833 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.832 with no explicit bump. run 35243115057. (task 1002620)
  1.19.834 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.833 with no explicit bump. run 35244719662. (task 1002620)
  1.19.835 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.834 with no explicit bump. run 35245617627. (task 1002620)
  1.19.836 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.835 with no explicit bump. run 35247495964. (task 1002620)
  1.19.837 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.836 with no explicit bump. run 35248928789. (task 1002620)
  1.19.838 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.837 with no explicit bump. run 35250225228. (task 1002620)
  1.19.839 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.838 with no explicit bump. run 35252591179. (task 1002620)
  1.19.840 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.839 with no explicit bump. run 35254616836. (task 1002620)
  1.19.841 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.840 with no explicit bump. run 35257419225. (task 1002620)
  1.19.842 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.841 with no explicit bump. run 35258288930. (task 1002620)
  1.19.843 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.842 with no explicit bump. run 35259608793. (task 1002620)
  1.19.844 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.843 with no explicit bump. run 35262101669. (task 1002620)
  1.19.845 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.844 with no explicit bump. run 35263096514. (task 1002620)
  1.19.846 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.845 with no explicit bump. run 35264882014. (task 1002620)
  1.19.847 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.846 with no explicit bump. run 35266409194. (task 1002620)
  1.19.848 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.847 with no explicit bump. run 35267380720. (task 1002620)
  1.19.849 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.848 with no explicit bump. run 35269098215. (task 1002620)
  1.19.850 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.849 with no explicit bump. run 35271402682. (task 1002620)
  1.19.851 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.850 with no explicit bump. run 35274042996. (task 1002620)
  1.19.852 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.851 with no explicit bump. run 35274827497. (task 1002620)
  1.19.853 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.852 with no explicit bump. run 35275456041. (task 1002620)
  1.19.854 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.853 with no explicit bump. run 35276402271. (task 1002620)
  1.19.855 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.854 with no explicit bump. run 35277047800. (task 1002620)
  1.19.856 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.855 with no explicit bump. run 35277927951. (task 1002620)
  1.19.857 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.856 with no explicit bump. run 35278916322. (task 1002620)
  1.19.858 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.857 with no explicit bump. run 35279781206. (task 1002620)
  1.19.859 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.858 with no explicit bump. run 35280770718. (task 1002620)
  1.19.860 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.859 with no explicit bump. run 35281454119. (task 1002620)
  1.19.861 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.860 with no explicit bump. run 35290990147. (task 1002620)
  1.19.862 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.861 with no explicit bump. run 35292190396. (task 1002620)
  1.19.863 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.862 with no explicit bump. run 35292877780. (task 1002620)
  1.19.864 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.863 with no explicit bump. run 35294233113. (task 1002620)
  1.19.865 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.864 with no explicit bump. run 35295856053. (task 1002620)
  1.19.866 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.865 with no explicit bump. run 35355019469. (task 1002620)
  1.19.867 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.866 with no explicit bump. run 35380895321. (task 1002620)
  1.19.868 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.867 with no explicit bump. run 35381947323. (task 1002620)
  1.19.869 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.868 with no explicit bump. run 35382740500. (task 1002620)
  1.19.870 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.869 with no explicit bump. run 35388809554. (task 1002620)
  1.19.871 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.870 with no explicit bump. run 35393164740. (task 1002620)
  1.19.872 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.871 with no explicit bump. run 35419318693. (task 1002620)
  1.19.873 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.872 with no explicit bump. run 35419621747. (task 1002620)
  1.19.874 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.873 with no explicit bump. run 35419921833. (task 1002620)
  1.19.875 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.874 with no explicit bump. run 35420682750. (task 1002620)
  1.19.876 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.875 with no explicit bump. run 35420916304. (task 1002620)
  1.19.877 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.876 with no explicit bump. run 35438492966. (task 1002620)
  1.19.878 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.877 with no explicit bump. run 35439004814. (task 1002620)
  1.19.879 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.878 with no explicit bump. run 35439529685. (task 1002620)
  1.19.880 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.879 with no explicit bump. run 35453118533. (task 1002620)
  1.19.881 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.880 with no explicit bump. run 35455207976. (task 1002620)
  1.19.882 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.881 with no explicit bump. run 35463113839. (task 1002620)
  1.19.883 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.882 with no explicit bump. run 35463573638. (task 1002620)
  1.19.884 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.883 with no explicit bump. run 35464075741. (task 1002620)
  1.19.885 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.884 with no explicit bump. run 35464802278. (task 1002620)
  1.19.886 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.885 with no explicit bump. run 35467975408. (task 1002620)
  1.19.887 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.886 with no explicit bump. run 35468511941. (task 1002620)
  1.19.888 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.887 with no explicit bump. run 35468948342. (task 1002620)
  1.19.889 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.888 with no explicit bump. run 35470239834. (task 1002620)
  1.19.890 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.889 with no explicit bump. run 35470624284. (task 1002620)
  1.19.891 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.890 with no explicit bump. run 35471575521. (task 1002620)
  1.19.892 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.891 with no explicit bump. run 35471773244. (task 1002620)
  1.19.893 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.892 with no explicit bump. run 35473299957. (task 1002620)
  1.19.894 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.893 with no explicit bump. run 35473999345. (task 1002620)
  1.19.895 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.894 with no explicit bump. run 35475074265. (task 1002620)
  1.19.896 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.895 with no explicit bump. run 35478072367. (task 1002620)
  1.19.897 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.896 with no explicit bump. run 35485346707. (task 1002620)
  1.19.898 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.897 with no explicit bump. run 35487863230. (task 1002620)
  1.19.899 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.898 with no explicit bump. run 35488237998. (task 1002620)
  1.19.900 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.899 with no explicit bump. run 35492534307. (task 1002620)
  1.19.901 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.900 with no explicit bump. run 35494090938. (task 1002620)
  1.19.902 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.901 with no explicit bump. run 35497860558. (task 1002620)
  1.19.903 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.902 with no explicit bump. run 35510679104. (task 1002620)
  1.19.904 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.903 with no explicit bump. run 35511494246. (task 1002620)
  1.19.905 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.904 with no explicit bump. run 35513060618. (task 1002620)
  1.19.906 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.905 with no explicit bump. run 35514202453. (task 1002620)
  1.19.907 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.906 with no explicit bump. run 35514739370. (task 1002620)
  1.19.908 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.907 with no explicit bump. run 35516559010. (task 1002620)
  1.19.909 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.908 with no explicit bump. run 35517426559. (task 1002620)
  1.19.910 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.909 with no explicit bump. run 35519966415. (task 1002620)
  1.19.911 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.910 with no explicit bump. run 35520751450. (task 1002620)
  1.19.912 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.911 with no explicit bump. run 35522352719. (task 1002620)
  1.19.913 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.912 with no explicit bump. run 35523207325. (task 1002620)
  1.19.914 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.913 with no explicit bump. run 35523700531. (task 1002620)
  1.19.915 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.914 with no explicit bump. run 35524223153. (task 1002620)
  1.19.916 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.915 with no explicit bump. run 35525694524. (task 1002620)
  1.19.917 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.916 with no explicit bump. run 35526196428. (task 1002620)
  1.19.918 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.917 with no explicit bump. run 35529342372. (task 1002620)
  1.19.919 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.918 with no explicit bump. run 35531198454. (task 1002620)
  1.19.920 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.919 with no explicit bump. run 35531720944. (task 1002620)
  1.19.921 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.920 with no explicit bump. run 35534076467. (task 1002620)
  1.19.922 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.921 with no explicit bump. run 35536293721. (task 1002620)
  1.19.923 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.922 with no explicit bump. run 35541278656. (task 1002620)
  1.19.924 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.923 with no explicit bump. run 35541674047. (task 1002620)
  1.19.925 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.924 with no explicit bump. run 35542154729. (task 1002620)
  1.19.926 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.925 with no explicit bump. run 35543911646. (task 1002620)
  1.19.927 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.926 with no explicit bump. run 35545006099. (task 1002620)
  1.19.928 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.927 with no explicit bump. run 35547446984. (task 1002620)
  1.19.929 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.928 with no explicit bump. run 35548065983. (task 1002620)
  1.19.930 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.929 with no explicit bump. run 35549362371. (task 1002620)
  1.19.931 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.930 with no explicit bump. run 35551146764. (task 1002620)
  1.19.932 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.931 with no explicit bump. run 35555080510. (task 1002620)
  1.19.933 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.932 with no explicit bump. run 35555853466. (task 1002620)
  1.19.934 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.933 with no explicit bump. run 35556739619. (task 1002620)
  1.19.935 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.934 with no explicit bump. run 35558269194. (task 1002620)
  1.19.936 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.935 with no explicit bump. run 35561285958. (task 1002620)
  1.19.937 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.936 with no explicit bump. run 35566446478. (task 1002620)
  1.19.938 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.937 with no explicit bump. run 35638291152. (task 1002620)
  1.19.939 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.938 with no explicit bump. run 35641614084. (task 1002620)
  1.19.940 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.939 with no explicit bump. run 35647628385. (task 1002620)
  1.19.941 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.940 with no explicit bump. run 35652433730. (task 1002620)
  1.19.942 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.941 with no explicit bump. run 35659043986. (task 1002620)
  1.19.943 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.942 with no explicit bump. run 35661533404. (task 1002620)
  1.19.944 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.943 with no explicit bump. run 35665131778. (task 1002620)
  1.19.945 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.944 with no explicit bump. run 35668642462. (task 1002620)
  1.19.946 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.945 with no explicit bump. run 35669244197. (task 1002620)
  1.19.947 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.946 with no explicit bump. run 35671409094. (task 1002620)
  1.19.948 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.947 with no explicit bump. run 35671807404. (task 1002620)
  1.19.949 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.948 with no explicit bump. run 35675336642. (task 1002620)
  1.19.950 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.949 with no explicit bump. run 35683452297. (task 1002620)
  1.19.951 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.950 with no explicit bump. run 35685346231. (task 1002620)
  1.19.952 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.951 with no explicit bump. run 35686469735. (task 1002620)
  1.19.953 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.952 with no explicit bump. run 35687192774. (task 1002620)
  1.19.954 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.953 with no explicit bump. run 35687914716. (task 1002620)
  1.19.955 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.954 with no explicit bump. run 35690089430. (task 1002620)
  1.19.956 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.955 with no explicit bump. run 35691908420. (task 1002620)
  1.19.957 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.956 with no explicit bump. run 35692861666. (task 1002620)
  1.19.958 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.957 with no explicit bump. run 35735231183. (task 1002620)
  1.19.959 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.958 with no explicit bump. run 35740227000. (task 1002620)
  1.19.960 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.959 with no explicit bump. run 35755397900. (task 1002620)
  1.19.961 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.960 with no explicit bump. run 35757951835. (task 1002620)
  1.19.962 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.961 with no explicit bump. run 35761137402. (task 1002620)
  1.19.963 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.962 with no explicit bump. run 35770645163. (task 1002620)
  1.19.964 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.963 with no explicit bump. run 35787848112. (task 1002620)
  1.19.965 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.964 with no explicit bump. run 35790478196. (task 1002620)
  1.19.966 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.965 with no explicit bump. run 35793400408. (task 1002620)
  1.19.967 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.966 with no explicit bump. run 35795807836. (task 1002620)
  1.19.968 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.967 with no explicit bump. run 35797263467. (task 1002620)
  1.19.969 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.968 with no explicit bump. run 35798488315. (task 1002620)
  1.19.970 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.969 with no explicit bump. run 35804568036. (task 1002620)
  1.19.971 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.970 with no explicit bump. run 35805746484. (task 1002620)
  1.19.972 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.971 with no explicit bump. run 35806478158. (task 1002620)
  1.19.973 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.972 with no explicit bump. run 35813381436. (task 1002620)
  1.19.974 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.973 with no explicit bump. run 35816317024. (task 1002620)
  1.19.975 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.974 with no explicit bump. run 35871083707. (task 1002620)
  1.19.976 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.975 with no explicit bump. run 35878415178. (task 1002620)
  1.19.977 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.976 with no explicit bump. run 35880930697. (task 1002620)
  1.19.978 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.977 with no explicit bump. run 35882259144. (task 1002620)
  1.19.979 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.978 with no explicit bump. run 35887876013. (task 1002620)
  1.19.980 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.979 with no explicit bump. run 35889261972. (task 1002620)
  1.19.981 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.980 with no explicit bump. run 35891635199. (task 1002620)
  1.19.982 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.981 with no explicit bump. run 35894422097. (task 1002620)
  1.19.983 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.982 with no explicit bump. run 35896466235. (task 1002620)
  1.19.984 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.983 with no explicit bump. run 35900593334. (task 1002620)
  1.19.985 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.984 with no explicit bump. run 35902000024. (task 1002620)
  1.19.986 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.985 with no explicit bump. run 35903379073. (task 1002620)
  1.19.987 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.986 with no explicit bump. run 35906802480. (task 1002620)
  1.19.988 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.987 with no explicit bump. run 35909292753. (task 1002620)
  1.19.989 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.988 with no explicit bump. run 35911817390. (task 1002620)
  1.19.990 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.989 with no explicit bump. run 35912578496. (task 1002620)
  1.19.991 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.990 with no explicit bump. run 35916061384. (task 1002620)
  1.19.992 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.991 with no explicit bump. run 35918717050. (task 1002620)
  1.19.993 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.992 with no explicit bump. run 35920872835. (task 1002620)
  1.19.994 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.993 with no explicit bump. run 35929622479. (task 1002620)
  1.19.995 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.994 with no explicit bump. run 35933457545. (task 1002620)
  1.19.996 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.995 with no explicit bump. run 35934673169. (task 1002620)
  1.19.997 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.996 with no explicit bump. run 35937246865. (task 1002620)
  1.19.998 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.997 with no explicit bump. run 35940192900. (task 1002620)
  1.19.999 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.998 with no explicit bump. run 35942048393. (task 1002620)
  1.19.1000 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.999 with no explicit bump. run 35943151697. (task 1002620)
  1.19.1001 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1000 with no explicit bump. run 36016738965. (task 1002620)
  1.19.1002 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1001 with no explicit bump. run 36019839845. (task 1002620)
  1.19.1003 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1002 with no explicit bump. run 36028273772. (task 1002620)
  1.19.1004 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1003 with no explicit bump. run 36030644887. (task 1002620)
  1.19.1005 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1004 with no explicit bump. run 36032559593. (task 1002620)
  1.19.1006 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1005 with no explicit bump. run 36036374443. (task 1002620)
  1.19.1007 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1006 with no explicit bump. run 36043267244. (task 1002620)
  1.19.1008 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1007 with no explicit bump. run 36052924171. (task 1002620)
  1.19.1009 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1008 with no explicit bump. run 36056558236. (task 1002620)
  1.19.1010 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1009 with no explicit bump. run 36064558803. (task 1002620)
  1.19.1011 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1010 with no explicit bump. run 36066617514. (task 1002620)
  1.19.1012 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1011 with no explicit bump. run 36067980398. (task 1002620)
  1.19.1013 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1012 with no explicit bump. run 36072935774. (task 1002620)
  1.19.1014 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1013 with no explicit bump. run 36076310606. (task 1002620)
  1.19.1015 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1014 with no explicit bump. run 36078624472. (task 1002620)
  1.19.1016 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1015 with no explicit bump. run 36080388706. (task 1002620)
  1.19.1017 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1016 with no explicit bump. run 36081753087. (task 1002620)
  (next carrier) — readApplicationVouch re-exported (task 1002285, goal 1000110;
        ADR 0201 D2). The public POST /access-requests' check of the hub's signed
        application vouch → { githubId, handle } or null. Core supplies the hub
        public key and this instance's client_id, so the onboarding module passes
        only a token and a login — the <redacted> precedent.
  1.19.1018 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1017 with no explicit bump. run 36083406390. (task 1002620)
  1.19.1019 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1018 with no explicit bump. run 36084684814. (task 1002620)
  1.19.1020 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1019 with no explicit bump. run 36085437258. (task 1002620)
  1.19.1021 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1020 with no explicit bump. run 36086047874. (task 1002620)
  1.19.1022 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1021 with no explicit bump. run 36176262855. (task 1002620)
  1.19.1023 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1022 with no explicit bump. run 36178875275. (task 1002620)
  1.19.1024 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1023 with no explicit bump. run 36183325302. (task 1002620)
  1.19.1025 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1024 with no explicit bump. run 36185386905. (task 1002620)
  1.19.1026 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1025 with no explicit bump. run 36186644421. (task 1002620)
  1.19.1027 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1026 with no explicit bump. run 36187742785. (task 1002620)
  1.19.1028 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1027 with no explicit bump. run 36188894725. (task 1002620)
  1.19.1029 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1028 with no explicit bump. run 36189693139. (task 1002620)
  1.19.1030 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1029 with no explicit bump. run 36190779629. (task 1002620)
  1.19.1031 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1030 with no explicit bump. run 36192093201. (task 1002620)
  1.19.1032 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1031 with no explicit bump. run 36192968150. (task 1002620)
  1.19.1033 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1032 with no explicit bump. run 36214617025. (task 1002620)
  1.19.1034 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1033 with no explicit bump. run 36215757254. (task 1002620)
  1.19.1035 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1034 with no explicit bump. run 36226356336. (task 1002620)
  1.19.1036 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1035 with no explicit bump. run 36226955285. (task 1002620)
  1.19.1037 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1036 with no explicit bump. run 36227523642. (task 1002620)
  1.19.1038 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1037 with no explicit bump. run 36228854271. (task 1002620)
  1.19.1039 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1038 with no explicit bump. run 36229255566. (task 1002620)
  1.19.1040 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1039 with no explicit bump. run 36251192410. (task 1002620)
  1.19.1041 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1040 with no explicit bump. run 36253865251. (task 1002620)
  (next carrier) — readPackageRegistry re-exported (task 1004296, goal 1000090).
        What the npm registry says about a package — its versions, their publish
        dates, the `latest` label, and the release notes the newest version was
        packed with — moved from a module into the core (src/bongos/
        package-registry.js), because Settings → Software update needs it in
        every hall. A module that publishes a package reads the same answer and
        the same process-local cache through here. Additive — a MINOR by the
        1.19.0 precedent, riding the next CI patch as joinabilityMode did.
  1.19.1042 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1041 with no explicit bump. run 36254852933. (task 1002620)
  1.19.1043 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1042 with no explicit bump. run 36258640780. (task 1002620)
  1.19.1044 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1043 with no explicit bump. run 36260641494. (task 1002620)
  1.19.1045 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1044 with no explicit bump. run 36263855490. (task 1002620)
  1.19.1046 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1045 with no explicit bump. run 36265788618. (task 1002620)
  1.19.1047 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1046 with no explicit bump. run 36280220559. (task 1002620)
  1.19.1048 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1047 with no explicit bump. run 36285856717. (task 1002620)
  1.19.1049 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1048 with no explicit bump. run 36323359891. (task 1002620)
  1.19.1050 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1049 with no explicit bump. run 36324195800. (task 1002620)
  1.19.1051 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1050 with no explicit bump. run 36369343116. (task 1002620)
  1.19.1052 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1051 with no explicit bump. run 36372902384. (task 1002620)
  1.19.1053 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1052 with no explicit bump. run 36375859084. (task 1002620)
  1.19.1054 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1053 with no explicit bump. run 36378326588. (task 1002620)
  1.19.1055 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1054 with no explicit bump. run 36380323033. (task 1002620)
  1.19.1056 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1055 with no explicit bump. run 36382270561. (task 1002620)
  1.19.1057 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1056 with no explicit bump. run 36387147130. (task 1002620)
  1.19.1058 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1057 with no explicit bump. run 36390971623. (task 1002620)
  1.19.1059 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1058 with no explicit bump. run 36415558760. (task 1002620)
  1.19.1060 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1059 with no explicit bump. run 36418832327. (task 1002620)
  1.19.1061 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1060 with no explicit bump. run 36423029975. (task 1002620)
  1.19.1062 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1061 with no explicit bump. run 36428277106. (task 1002620)
  1.19.1063 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1062 with no explicit bump. run 36435823058. (task 1002620)
  1.19.1064 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1063 with no explicit bump. run 36441707814. (task 1002620)
  1.19.1065 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1064 with no explicit bump. run 36451089716. (task 1002620)
  1.19.1066 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1065 with no explicit bump. run 36454504693. (task 1002620)
  1.19.1067 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1066 with no explicit bump. run 36458843914. (task 1002620)
  1.19.1068 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1067 with no explicit bump. run 36467481353. (task 1002620)
  1.19.1069 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1068 with no explicit bump. run 36470192310. (task 1002620)
  1.19.1070 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1069 with no explicit bump. run 36472133987. (task 1002620)
  1.19.1071 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1070 with no explicit bump. run 36473239367. (task 1002620)
  1.19.1072 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1071 with no explicit bump. run 36474285523. (task 1002620)
  1.19.1073 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1072 with no explicit bump. run 36485068639. (task 1002620)
  1.19.1074 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1073 with no explicit bump. run 36510198162. (task 1002620)
  1.19.1075 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1074 with no explicit bump. run 36512197709. (task 1002620)
  (note, no bump) — auth.allowBoxScope is now a deprecated no-op (task 1003894).
        The narrowing session scope it opted a route into, and the three box.*
        permissions, were removed with the dev box (ADR 0346). The export is kept so
        the doorway loses nothing inside 1.x; it goes at the next MAJOR.
  1.19.1076 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1075 with no explicit bump. run 36523068301. (task 1002620)
  1.19.1077 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1076 with no explicit bump. run 36558431394. (task 1002620)
  1.19.1078 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1077 with no explicit bump. run 36600137276. (task 1002620)
  1.19.1079 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1078 with no explicit bump. run 36602720244. (task 1002620)
  1.19.1080 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1079 with no explicit bump. run 36638268217. (task 1002620)
  1.19.1081 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.19.1080 with no explicit bump. run 36639564721. (task 1002620)
  1.20.0 — cascadeDispatch: the cheapest-model-first cascade router
        (src/bongos/cascade-dispatch.js), for the lifecycle module's ADR 0101
        Part 1 relevance/anti-hack judge — its first real caller (task 1001691).
        Additive, so MINOR.
  1.20.1 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.0 with no explicit bump. run 36658043092. (task 1002620)
  1.20.2 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.1 with no explicit bump. run 36660725673. (task 1002620)
  1.20.3 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.2 with no explicit bump. run 36662547009. (task 1002620)
  1.20.4 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.3 with no explicit bump. run 36664167210. (task 1002620)
  1.20.5 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.4 with no explicit bump. run 36666171516. (task 1002620)
  1.20.6 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.5 with no explicit bump. run 36667238912. (task 1002620)
  1.20.7 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.6 with no explicit bump. run 36668328505. (task 1002620)
  1.20.8 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.7 with no explicit bump. run 36669272909. (task 1002620)
  1.20.9 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.8 with no explicit bump. run 36669791458. (task 1002620)
  1.20.10 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.9 with no explicit bump. run 36670625760. (task 1002620)
  1.20.11 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.10 with no explicit bump. run 36672606449. (task 1002620)
  1.20.12 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.11 with no explicit bump. run 36709211337. (task 1002620)
  1.20.13 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.12 with no explicit bump. run 36710762884. (task 1002620)
  1.20.14 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.13 with no explicit bump. run 36712510525. (task 1002620)
  1.20.15 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.14 with no explicit bump. run 36713710510. (task 1002620)
  1.20.16 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.15 with no explicit bump. run 36717488992. (task 1002620)
  1.20.17 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.16 with no explicit bump. run 36722139698. (task 1002620)
  1.20.18 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.17 with no explicit bump. run 36724081934. (task 1002620)
  1.20.19 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.18 with no explicit bump. run 36727774141. (task 1002620)
  1.20.20 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.19 with no explicit bump. run 36732445320. (task 1002620)
  1.20.21 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.20 with no explicit bump. run 36735857856. (task 1002620)
  1.20.22 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.21 with no explicit bump. run 36743446010. (task 1002620)
  1.20.23 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.22 with no explicit bump. run 36747567551. (task 1002620)
  1.20.24 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.23 with no explicit bump. run 36759918201. (task 1002620)
  1.20.25 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.24 with no explicit bump. run 36762454104. (task 1002620)
  1.20.26 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.25 with no explicit bump. run 36764011836. (task 1002620)
  1.20.27 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.26 with no explicit bump. run 36768642814. (task 1002620)
  1.20.28 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.27 with no explicit bump. run 36772266063. (task 1002620)
  1.20.29 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.28 with no explicit bump. run 36775277990. (task 1002620)
  1.20.30 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.29 with no explicit bump. run 36777226204. (task 1002620)
  1.20.31 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.30 with no explicit bump. run 36779142919. (task 1002620)
  1.20.32 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.31 with no explicit bump. run 36781343271. (task 1002620)
  1.20.33 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.32 with no explicit bump. run 36783765458. (task 1002620)
  1.20.34 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.33 with no explicit bump. run 36784565937. (task 1002620)
  1.20.35 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.34 with no explicit bump. run 36787635391. (task 1002620)
  1.20.36 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.35 with no explicit bump. run 36788696388. (task 1002620)
  1.20.37 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.36 with no explicit bump. run 36790298715. (task 1002620)
  1.20.38 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.37 with no explicit bump. run 36794921587. (task 1002620)
  1.20.39 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.38 with no explicit bump. run 36796243918. (task 1002620)
  1.20.40 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.39 with no explicit bump. run 36797045221. (task 1002620)
  1.20.41 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.40 with no explicit bump. run 36798842066. (task 1002620)
  1.20.42 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.41 with no explicit bump. run 36801585300. (task 1002620)
  1.20.43 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.42 with no explicit bump. run 36802367948. (task 1002620)
  1.20.44 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.43 with no explicit bump. run 36804013644. (task 1002620)
  1.20.45 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.44 with no explicit bump. run 36806095325. (task 1002620)
  1.20.46 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.45 with no explicit bump. run 36807065875. (task 1002620)
  1.20.47 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.46 with no explicit bump. run 36809534394. (task 1002620)
  1.20.48 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.47 with no explicit bump. run 36813335220. (task 1002620)
  1.20.49 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.48 with no explicit bump. run 36814272594. (task 1002620)
  1.20.50 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.49 with no explicit bump. run 36815399738. (task 1002620)
  1.20.51 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.50 with no explicit bump. run 36816320939. (task 1002620)
  1.20.52 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.51 with no explicit bump. run 36817286385. (task 1002620)
  1.20.53 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.52 with no explicit bump. run 36818406554. (task 1002620)
  1.20.54 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.53 with no explicit bump. run 36819731905. (task 1002620)
  1.20.55 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.54 with no explicit bump. run 36820911043. (task 1002620)
  1.20.56 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.55 with no explicit bump. run 36822184597. (task 1002620)
  1.20.57 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.56 with no explicit bump. run 36823118111. (task 1002620)
  1.20.58 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.57 with no explicit bump. run 36825877084. (task 1002620)
  1.20.59 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.58 with no explicit bump. run 36828212808. (task 1002620)
  1.20.60 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.59 with no explicit bump. run 36830884810. (task 1002620)
  1.20.61 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.60 with no explicit bump. run 36846600005. (task 1002620)
  1.20.62 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.61 with no explicit bump. run 36849277076. (task 1002620)
  1.20.63 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.62 with no explicit bump. run 36850426143. (task 1002620)
  1.20.64 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.63 with no explicit bump. run 36851876428. (task 1002620)
  1.20.65 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.64 with no explicit bump. run 36852902728. (task 1002620)
  1.20.66 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.65 with no explicit bump. run 36854308972. (task 1002620)
  1.20.67 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.66 with no explicit bump. run 36860726629. (task 1002620)
  1.20.68 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.67 with no explicit bump. run 36871565601. (task 1002620)
  1.20.69 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.68 with no explicit bump. run 36873353617. (task 1002620)
  1.20.70 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.69 with no explicit bump. run 36877499272. (task 1002620)
  1.20.71 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.70 with no explicit bump. run 36881290177. (task 1002620)
  1.20.72 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.71 with no explicit bump. run 36884685441. (task 1002620)
  1.20.73 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.72 with no explicit bump. run 36886320087. (task 1002620)
  1.20.74 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.73 with no explicit bump. run 36891334916. (task 1002620)
  1.20.75 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.74 with no explicit bump. run 36894812535. (task 1002620)
  1.20.76 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.75 with no explicit bump. run 36898800355. (task 1002620)
  1.20.77 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.76 with no explicit bump. run 36909904812. (task 1002620)
  1.20.78 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.77 with no explicit bump. run 36923602676. (task 1002620)
  1.20.79 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.78 with no explicit bump. run 36924822923. (task 1002620)
  1.20.80 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.79 with no explicit bump. run 36927627121. (task 1002620)
  1.20.81 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.80 with no explicit bump. run 36928688478. (task 1002620)
  1.20.82 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.81 with no explicit bump. run 36932856805. (task 1002620)
  1.20.83 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.20.82 with no explicit bump. run 36935503851. (task 1002620)
  1.21.0 — no new doorway export. A deliberate MINOR, owner-requested
        2026-10-01, to prove a step-up release lands unattended on a project
        whose /deploy update rule is `minor` (task 1004521, for the proof task
        1004451; ADR 0357). Patch-channel projects stay on 1.20.x.
  1.21.1 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.21.0 with no explicit bump. run 36940540656. (task 1002620)
  1.21.2 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.21.1 with no explicit bump. run 36943290103. (task 1002620)
  1.21.3 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.21.2 with no explicit bump. run 36944637655. (task 1002620)
  1.21.4 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.21.3 with no explicit bump. run 36954271746. (task 1002620)
  1.21.5 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.21.4 with no explicit bump. run 36985819041. (task 1002620)
  1.21.6 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.21.5 with no explicit bump. run 37035421571. (task 1002620)
  1.21.7 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.21.6 with no explicit bump. run 37038340446. (task 1002620)
  1.21.8 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.21.7 with no explicit bump. run 37041143274. (task 1002620)
  1.21.9 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.21.8 with no explicit bump. run 37042188671. (task 1002620)
  1.21.10 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.21.9 with no explicit bump. run 37048132870. (task 1002620)
  1.21.11 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.21.10 with no explicit bump. run 37049412231. (task 1002620)
  1.21.12 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.21.11 with no explicit bump. run 37051031732. (task 1002620)
  1.21.13 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.21.12 with no explicit bump. run 37053665960. (task 1002620)
  1.21.14 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.21.13 with no explicit bump. run 37055782677. (task 1002620)
  1.21.15 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.21.14 with no explicit bump. run 37057118119. (task 1002620)
  1.21.16 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.21.15 with no explicit bump. run 37058696837. (task 1002620)
  1.21.17 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.21.16 with no explicit bump. run 37060414658. (task 1002620)
  1.21.18 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.21.17 with no explicit bump. run 37061507293. (task 1002620)
  1.21.19 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.21.18 with no explicit bump. run 37065102803. (task 1002620)
  1.21.20 — CI auto-patch (publish-on-merge, ADR 0161): carrier for merges
        landed since 1.21.19 with no explicit bump. run 37066131214. (task 1002620)
---------------------------------------------------------------------------
```
