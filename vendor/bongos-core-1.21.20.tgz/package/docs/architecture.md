# Architecture — current state

> Split out of `CLAUDE.md` §10 in V3.R86 ([#305](https://example.com/builders#/task/305)) to keep the agent index lean. `CLAUDE.md` §10 now
> carries a one-paragraph orientation and points here. This file is **descriptive** — for live Bongos
> state (tasks, versions, claims, ranks) the source of truth is the database via `/api/bongos/*`, and
> for permissions specifically see [`docs/canonical-permissions.md`](canonical-permissions.md).

> **For decision rationale (why we chose what), read [`docs/adr/`](adr/). The most relevant: 0001 (stack), 0002 (DigitalOcean), 0003 (Cloudflare cert), 0006 (singleton WorldRoom + queue), 0007 (persistent identity), 0008 (Google Chat OAuth), 0010 (Bongos architecture), 0016 (trust boundary).**

**Live & running:**

- **Domain:** `example.com` — registered at Cloudflare Registrar. DNS A records (apex + `www`) point to the droplet at `REDACTED_IP`. Cloudflare proxy is **ON (orange cloud)**. CF terminates TLS at the edge; the **Cloudflare Origin Certificate** handles the CF↔origin leg (valid through 2041-05-04). A `status` subdomain is added at PMS-V1 deploy time (see `docs/pms-v1-deploy.md` (instance-side)) with the same proxy/cert posture; Origin Cert needs `*.example.com` SAN. Real client IPs come in via `CF-Connecting-IP` / `X-Forwarded-For`, wired into Caddy's `trusted_proxies static` (the Cloudflare IP ranges) in the `infra/Caddyfile` global options block.
- **Production droplet (co-hosting box):** DigitalOcean, hostname `example`, IPv4 `REDACTED_IP`, IPv6 `REDACTED_IP`. NYC3, Premium Intel 2 GB / 1 vCPU / 60 GB NVMe. Ubuntu 24.04 LTS. ~$14/mo. Hosts the OTB game + co-hosted project instances (`emersonian-circles.`, `staging.`).
- **Cloud Bongos control-plane droplet (NEW 2026-07-05, [ADR 0126](adr/0126-dedicated-cloudbongos-control-plane-droplet.md), task [#2063](https://example.com/builders#/task/2063)):** DigitalOcean, hostname `cloudbongos`, IPv4 `REDACTED_IP`, NYC3, `s-1vcpu-2gb` (2 GB / 1 vCPU), Ubuntu 24.04, ~$12/mo, tag `cloudbongos-control`. Runs **cloudbongos.com + `builders.` + `status.`** (`src/platform-server.js`, Cloud Bongos brand, port 3002, own `cloudbongos` DB, checkout `/home/lars/cloudbongos-instance`, the root subscribed to the nightly core-patch sweep) and is the **sole token-holding control plane** — a SECOND root, `/home/lars/cloudbongos`, is left over from the retired dev-box bring-up, which vendored `infra/` from it ([ADR 0346](adr/0346-dev-boxes-are-retired.md)); it is not subscribed, so nothing may resolve core code from it (task 1002738) — `/etc/cloudbongos/box.env` holds the account-wide Cloudflare token (IP-locked to this box) + the DigitalOcean token; this is where `provision.js` provisions instance subdomains. **Structurally separate SSH** (own `cloudbongos_ed25519` key). IPv6 egress disabled so the IPv4-locked CF token can't be spuriously rejected. cloudbongos.com was previously a co-tenant on the co-hosting box; that unit was decommissioned at cutover. **Follow-ups:** deploy automation (task [#2064](https://example.com/builders#/task/2064)) + fully stripping cloud tokens off the co-hosting box (task [#2065](https://example.com/builders#/task/2065)).
- **Where projects run ([ADR 0345](adr/0345-we-host-every-projects-hall-and-its-app-deploys-where-the-owner-chooses.md), 2026-09-28):** every project's **Builders Hall** is hosted by us on the shared control-plane box (`hosting_shape='cloud-host'`, labelled "hosted by us"), at one of our addresses or the owner's own domain. The project's **app** deploys wherever its owner chooses; the setup wizard offers Render first, creating the app on the owner's own Render account with a borrowed, never-stored key (ADR 0327 §2). ADR 0323's plan to move the halls to Render is reversed. Halls at our addresses receive the hub cookie until task 1004357 ships.
- **Server stack:** Node.js 22 LTS · PostgreSQL 16 · Caddy 2.11.2. `example.service` (systemd) runs `node server.js` as user `lars` on `127.0.0.1:3000`; restart-on-failure.
- **Hardening:** `lars` user with passwordless sudo; SSH key-only (root login disabled, password auth disabled); ufw allows 22/80/443; fail2ban active; unattended-upgrades enabled; timezone `America/New_York`.
- **Credentials:** every credential the instance needs — what it is for, which env file holds it (`web.env` · `box.env` · `spaces.env`), GitHub Actions secrets and builder-machine logins — is listed in [`docs/credentials.md`](credentials.md), names only. Whether each is SET on a host is one command run there: `node scripts/gds/credential-presence.js` (task 1002880). Check both before asking the owner for a credential.
- **TLS:** Origin cert at `/etc/caddy/origin.crt` + `/etc/caddy/origin.key` for the example apexes on the co-hosting box. **cloudbongos.com's apexes moved to the dedicated control-plane droplet** ([ADR 0126](adr/0126-dedicated-cloudbongos-control-plane-droplet.md)) with their own copy of the Cloudflare Origin Cert (SAN `*.cloudbongos.com, cloudbongos.com`) at `/etc/caddy/cloudbongos-origin.{crt,key}` on `REDACTED_IP`. Cloudflare SSL/TLS mode = Full (strict). Renewal is a non-issue for ~15 years. **Provisioned instance hosts use a different, coexisting posture** ([ADR 0111](adr/0111-instance-hosting-provisioning-module.md) §4 / task P4): Caddy **on-demand ACME** (Let's Encrypt) via the global `on_demand_tls { ask … }` block, gated to hostnames the `provisioning` module actually stood up (`/api/bongos/provisioning/tls-check`). Their DNS records are **proxied=false (grey cloud)** so the ACME challenge reaches Caddy — the opposite of the origin-cert apexes; do not enable the proxy on them or renewal breaks silently ([ADR 0003](adr/0003-cloudflare-origin-cert-over-letsencrypt.md)). Per-instance site snippets live in `/etc/caddy/sites/*.caddy` (`import`ed by `infra/Caddyfile`); the provisioning runner verifies the box's resolved Caddy config carries that import and the `on_demand_tls` ask before it reports a domain wired, and refuses with the line to add rather than editing the base file ([ADR 0303](adr/0303-provisioning-verifies-the-base-caddyfile-and-never-edits-it.md)). **Tradeoff (accepted, SEC review of task 1945):** `proxied=false` publishes the box's real origin IP in public DNS for every co-tenant provisioned hostname — defeating, for those names, the Cloudflare-proxy IP-hiding the apexes enjoy (a co-tenant host resolves to the same `REDACTED_IP` that serves the main game). This is inherent to on-demand ACME (the challenge must hit the origin) and acceptable under the budget/trust model; prefer a **dedicated droplet** (its own IP) for any instance expected to draw hostile attention.
- **Platform observability — REMOVED 2026-09-15 ([ADR 0284](adr/0284-the-control-plane-carries-no-metrics-stack.md), task 1003876):** the control plane runs **no Grafana and no Prometheus**, and `metrics.cloudbongos.com` has no Caddy site. They cost ~300 MB RSS + 2.5 GB of data on the box every provisioned project shares, and scraped none of those projects. Every instance still exports `/metrics` ([`src/bongos/metrics.js`](../src/bongos/metrics.js), loopback or `METRICS_TOKEN`), so a scraper can return from a box that is *not* the control plane. The rest of this bullet is the **historical** ADR 0127 layout, kept so its leftovers (co-hosting-box forwarders, instance `infra/` copies) can be found: this watched the **Bongos API** (`gds_http`/`tasks`/`claims`/`builders`/`auth`), not any one game, so it lived **on the control-plane box** (REDACTED_IP) at **`https://metrics.cloudbongos.com`** and observed the **whole fleet**. **Prometheus** (`127.0.0.1:9090`, loopback-only) scrapes every instance's `/metrics` ([`src/bongos/metrics.js`](../src/bongos/metrics.js)), each tagged with a `project` label (`infra/prometheus/prometheus.yml` (instance-side)): **cloudbongos** locally (`:3002`); **example + emersonian-circles** on the co-hosting box, reached over the **private VPC** via `socat` forwarders on `10.108.0.2:9101/9102` (→ their loopback `:3000`/`:3004`), ufw-locked to the control-plane box's private IP — raw TCP relays, so the exporter still sees a loopback request and needs no token; nothing is public. **Grafana** (`127.0.0.1:3003`, loopback-only) renders the 4 provisioned-as-code dashboards (folder **Cloud Bongos**: system-overview, error-watch, builder-activity, auth-security), each with a **`project`** template variable for per-instance / fleet views. Reverse-proxied on the `*.cloudbongos.com` origin cert — Archon-only, gated by Caddy `basic_auth` (user `archon`) **and** Grafana's own admin login (both secrets owner-held, never in the repo). Grafana config is a systemd `GF_*` env drop-in (`grafana-server.service.d/override.conf`, `chmod 600`). ~256 MB RAM. A future dedicated-droplet instance is added as a `METRICS_TOKEN` Bearer target instead of a VPC forwarder.

**Application stack:**

- **Phaser 3** (browser game engine) — UMD via `/vendor/phaser.min.js`. Game code lives as plain ES modules in `public/`.
- **Colyseus 0.16** (server-authoritative WS rooms + state). Server pinned `^0.16` to match `colyseus.js` 0.16. UMD client bundle at `/vendor/colyseus.js`.
- **Express 4** — static file serving + a `/healthz` route. Same Node process as Colyseus.
- **`pg`** Postgres client over Unix socket (`host: '/var/run/postgresql'`).
- **Auth (planned, not yet wired):** Email + magic link, tied to a Stripe customer record on first purchase.

**Module system (core + modules, [ADR 0083](adr/0083-modular-architecture-strangler-build-plan.md)):**

The product is organized as a small kernel (`src/`) + **19 modules** under `modules/<key>/` — the four optional *feature* modules **plus** the carved *core-domain* modules. The four-feature carve (Config A) was only the least-coupled ~26% of the tree; the **core decomposition (Config B = BONGOS-V1 C7 `gds-core-modularized`)** is now done too ([ADR 0091](adr/0091-bounding-the-kernel-and-db-carve.md), [ADR 0093](adr/0093-tranche-2-core-carve-sequence.md)). The full, live roster + contract is at [docs/modules-contract.md](modules-contract.md).

- **The one-way rule** — a module reaches core only through `src/module-api.js` (the published, semver'd doorway). Core never imports a module. Modules never import each other — they cooperate through `src/module-seams.js` (ports + events). Two CI fitness checks enforce this; a violation is a red build.
- **The loader** (`src/module-loader/loader.js`) — discovers `modules/*/module.json` at boot, validates manifests, checks `coreVersion` compatibility, and mounts each enabled module's routes behind kernel-composed auth. No core file changes to add or remove a module.
- **Enablement** — `config/modules.json` (instance config) or `<PREFIX>_MODULE_<KEY>=1` (env override). Vanilla = all off.
- **Feature modules** (optional — off on a vanilla instance, enabled per-instance via `config/modules.json`):
  - `game` — Phaser client + Colyseus rooms + world/terrain; ports: `game.staticRoot`, `game.registerRooms`, `game.precreateWorldRoom`
  - `discord` — ship broadcast + inbound bot + role-sync; port: `discord.isLinked`
  - `art-pipeline` — pixel-art generation + artist discipline; port: `art.sharedKeyConfigured`
  - (+ `character-anim`, declaration-only — ADR 0088)
- **Core-domain modules** (`default: true` — always on unless disabled): `memory`, `grading`, `economy`, `ideas`, `security`, `builder-settings`, `onboarding`, `sessions`, plus `lifecycle` (the task/claim/version state machine), `autonomy` (the MAS), the `hall-ui` + `status-ui` internal surfaces, `public-landing` (the apex front door — [ADR 0218](adr/0218-the-apex-root-web-surface.md)), `ui-design` (the design contract, its adapters and the `/design` playbook as a platform capability — [ADR 0197](adr/0197-the-ui-design-module.md)), and the `demo` acceptance-proof module. See [docs/modules-contract.md](modules-contract.md) for the live roster and which default on.
- **Module-owned migrations** — `modules/<key>/migrations/*.sql` applied only when the module is enabled. Stem-keyed so moving a migration never re-runs it.
- **`bongos module new <key>`** — scaffolds a new module directory in one command.
- **`bongos upgrade`** — the update-consumption channel a two-repo consumer uses to pull the core from version N→N+1 (task 1690, ADR 0100 §2 / ADR 0103 §4): pre-flight (module-compat + clean tree) → bump the vendored-tarball pin → `npm install` → `npm run migrate` (additive `core_*` migrations; the core's own `migrate.sh` when an adopted instance declares no such script — task 1004274) → re-materialize `.claude/` → restart → verify. Run bare (no `--to`) it is still just the module-compat pre-check that exits 1 on mismatch; `--to <version>` runs the real bump. (`scripts/gds/upgrade.js`.)

**V1 networking design:**

- **Singleton `WorldRoom`** (Colyseus, `autoDispose=false`, `maxClients=100`). Pre-created via `matchMaker.createRoom`. Spawn at tile (10,10).
- **Sibling `QueueRoom`** — unbounded, FIFO, admits via shared in-process seat bus (`src/seats.js`). Browser-close releases seat automatically (Colyseus `onLeave`).
- **Move protocol:** client sends `{ dir }` per step. Server validates direction, applies position unless target tile is blocked or out of bounds, always commits facing.
- **Movement is client-predicted, server-authoritative.** Both sides run identical walkability rules. Walkability lives in `BLOCKING_TERRAINS` (ground impassable — sea) and `BLOCKING_OBJECTS` (object impassable — rocks, container panels) in the shared `terrain.js` module (CJS twin at `src/world/terrain.js`, ESM twin at `public/game/world/terrain.js`); the hardcoded V1 map lives in `src/world/map.js` (server) and `public/game/world/map.js` (client) — **the two map.js + the two terrain.js files must stay in sync** until the world becomes data-driven.
- **Cell data model ([ADR 0012](adr/0012-ground-object-cell-split.md), extends [ADR 0011](adr/0011-terrain-id-rendering-model.md)):** each cell carries TWO independent pieces:
  - **Ground terrain** (always defined) — `GRASS`, `SAND`, `SEA`, `MARBLE_PATH`. Drives the autotile renderer. `INITIAL_MAP.ground[y][x]`.
  - **Object** (optional, sparse) — `ROCK` or one of the 8 `CONTAINER_PANEL_*` (V1). Painted in a second draw pass at depth 1. `INITIAL_MAP.objects[y][x]` (null in most cells).
  The autotile picker sees the ground grid only; objects never affect tile selection. That is the invariant that lets rocks scatter through a meadow without polluting boundary tiles, and lets the container sit cleanly on sand.
- **Render dispatch ([ADR 0011](adr/0011-terrain-id-rendering-model.md)):** ground terrains pick a render strategy declared in `TERRAIN_RENDER`:
  - `single` — paint one PNG (sea).
  - `blob47` — query 8 neighbors on the GROUND grid, call `selectBlob47` from `autotile.js`, paint `tex_at_<family>_<idx>` (PNG at `/assets/tiles/autotile/<family>/<NN>.png`).
  - `path16` — same shape with 4-cardinal-only and 16 tiles.
  Each autotile-strategy terrain declares a `fallbackTile` so the world keeps rendering before the autotile family has been generated. Objects render via single-tile dispatch only. Python (`art/pipeline/autotile_mapping.py`) and JS (`public/game/world/autotile.js`) lookup tables are cross-verified at smoke-test time via `tests/autotile_xverify.mjs`. Picker invariants + walkability are guarded by `tests/terrain_picker.mjs` and `tests/walkability.mjs`.
- **Player positions are not broadcast** — other players are invisible in V1.
- **Identity:** localStorage UUID sent as join option. Server keys position by UUID and rehydrates from `players` table on join.
- **Persistence:** append-only `world_events` table is source of truth. Logged event types: `room.created · player.joined · player.left · player.moved · player.bumped · player.interacted · queue.joined · queue.left · queue.admitted`.

**Code & deploy:**

- **Code repo:** [github.com/example-owner/example](https://github.com/example-owner/example) — **private**. Clone URL: `git@github.com:example-owner/example.git`. Default branch: `main`. GitHub user: `example-owner`.
- **Deploy:** two modes, selected by `config/deploy.json` `mode` (env `<PREFIX>_DEPLOY_MODE` overrides — `BONGOS_DEPLOY_MODE` on a vanilla instance; the legacy `OTB_DEPLOY_MODE` is still read), currently **`ci`** (flipped from `laptop` 2026-06-13, [#859](https://example.com/builders#/task/859)) — see [ADR 0042](adr/0042-builder-self-deploy-ci-auto-merge.md). **`laptop`** (legacy): `git push origin main` from the Mac → `ssh lars@REDACTED_IP ~/deploy.sh`. The droplet has a read-only deploy key at `~/.ssh/github_deploy` registered on the repo. `~/deploy.sh` does: `git fetch + reset --hard origin/main` → `npm ci --omit=dev` if `package-lock.json` changed → `./scripts/migrate.sh` → `sudo systemctl restart example` → `curl /healthz` smoke (**retried up to 15× @ 1s** — `systemctl` reports "active" before the Node process binds the port, so a single curl raced the bind and false-failed healthy deploys: [ADR 0056](adr/0056-prod-deploy-script-mirror-and-healthcheck-retry.md) / [#1026](https://example.com/builders#/task/1026)). Droplet checkout: `/home/lars/example/`. `~/deploy.sh` is hand-maintained on the droplet but now has a byte-faithful, reviewable repo mirror at `scripts/deploy/deploy-prod.sh` (instance-side) — **not** auto-installed (the ci deploy key is forced-command-locked, ADR 0042/0043; reinstall by hand on change: `scp scripts/deploy/deploy-prod.sh lars@…:deploy.sh`). **`ci`** (current, armed via [#679](https://example.com/builders#/task/679)): no builder machine holds the droplet key — `ship.js` opens a PR + enables GitHub auto-merge, and `.github/workflows/deploy-prod.yml` (instance-side) runs the same `~/deploy.sh` from Actions on merge to `main`. Cutover preconditions (incl. a server-recorded **CI grade-gate**) are in ADR 0042.
- **Post-merge branch cleanup (standard practice):** Every feature branch that lands on main via `--no-ff` merge gets deleted on origin once the deploy succeeds. The merge commit itself preserves the branch's history in main, so the named ref isn't carrying any signal — keeping it just clutters GitHub's branch list and tricks the UI into offering empty PRs against zero-diff branches. The auto-merge in [`scripts/gds/ship.js`](../scripts/gds/ship.js) does this automatically after `~/deploy.sh` returns 0; the manual [`/merge-mode`](../.claude/skills/merge-mode/SKILL.md) flow follows the same step 5b. Local refs and worktree directories stay — only the origin branch and the local tracking ref (cleaned on next `git fetch --prune`) go.
- **Local dev machine:** Lars's MacBook Air (Apple Silicon, macOS Sequoia). Tooling installed via Homebrew at `/opt/homebrew/`. Node v26.0.0 locally; `package.json` declares `"engines": { "node": ">=22" }`. Single ed25519 SSH key (`~/.ssh/id_ed25519`) authenticates to GitHub and droplet.
- **Smoke tests:** lightweight scripts in `/tmp/colyseus-*-smoketest.js` verify joinOrCreate, move protocol, interact, identity, queue. Run any after deploy with `node /tmp/colyseus-<name>-smoketest.js`.
- **Repo topology today vs. the configurable-root future ([ADR 0108](adr/0108-instance-composition-configurable-root.md)):** everything above describes the current **single checkout** — `git reset --hard` deploy, `resolveCoreRoot()`/`resolveInstanceRoot()` ([`src/instance-config.js`](../src/instance-config.js)) both resolving to this same repo root. ADR 0108 lands (Mercury-first, then Example last) a model where Example instead installs a versioned `@bongos/core` npm package and deploy becomes `git pull` (the instance repo) → `npm ci` (the pinned core) → migrate → restart — no more `git reset --hard` on a shared checkout. This section gets rewritten for the new topology once Example actually splits (ADR 0108 §6, task 1884/W4); until then it is unchanged and accurate.

**Database (`example` on Postgres 16, peer auth as `lars`):**

Game tables:

```
schema_migrations(version PK, applied_at)
world_events(id bigserial PK, type text, actor_session_id text, payload jsonb, created_at)
  indexes: (created_at), (type)
players(id text PK, current_grid_x int, current_grid_y int, current_facing text,
        first_seen_at timestamptz, last_seen_at timestamptz)
  indexes: (last_seen_at)
```

Bongos tables (migration `003_pms.sql`, see [ADR 0010](adr/0010-pms-architecture.md)):

```
builders(id, github_id UNIQUE, github_login, display_name, avatar_url, total_credits, karma,
         created_at, rank, status, system_role, timezone, preferred_disciplines,
         skill_model_prefs, behavior_prefs, deactivated_at, reactivated_at, deactivated_reason,
         gemini_key_enc, gemini_key_last4, gemini_key_set_at)  -- mig 122: per-builder Gemini key, AES-256-GCM at rest (ADR 0073); master key BUILDER_SECRET_KEY in server env only
  rank text NOT NULL DEFAULT 'xenos' (mig 023; default flipped to xenos in mig 029)
       CHECK IN 16-value ladder; LIVE: archon|metic|xenos (three-rank model, #360/ADR 0018)
  karma integer NOT NULL DEFAULT 0 (mig 040) -- good-citizenship track alongside example
       (=total_credits); append-only karma_log + AFTER INSERT trigger keep it in sync
  status text DEFAULT 'active' (mig 025) -- 'active'|'inactive'; a deactivated builder can't claim (#307)
  system_role text NULL (mig 065) -- NULL for every human; 'bfg' = the BFG service principal
       (system: can't claim/earn/log-in). The cross-builder memory WRITE gate keys on this
       EXACT value, not on rank (ADR 0026 §6C) — an Archon token is rejected.
  + skill_model_prefs jsonb (mig 037), preferred_disciplines text[] (mig 027), timezone (PMS-V2),
    main_discipline text NULL (core_268 — the builder chosen MAIN role; NULL = not chosen, inferred from credits),
    deactivated_at/reactivated_at/deactivated_reason (mig 025 — the /builder-exit flow; #307 guard)
tasks ... + xenos_claimable boolean NOT NULL DEFAULT false (mig 029) -- Xenos may claim only these
versions(id PK 'V1'|'PMS-V1'..., name, track, status, scope_doc_path, ...)  -- track is free text (the product|internal CHECK was dropped in mig 112, task 1191); the valid set is instance config (config/branding.json "tracks"), not a DB constraint
tasks(id, version_id, title, description, status, touches text[], est_minutes, est_cost_usd,
      manual_degree, priority, automation_tag, credits_reward, source, source_ref,
      promoted_at, shipped_at, shipped_by, value_summary, created_at, updated_at)
  + visual_url, visual_alt (mig core_223, task 1003109) -- the OPTIONAL ship-time VISUAL: a
    screenshot / before-after / diagram, stored on disk under <INSTANCE ROOT>/var/task-visuals/
    (never inside the installed core package, which every upgrade replaces; task 1004381) and served by
    GET /api/bongos/task-visuals/:name. It is value_summary's claim in another medium, so it
    inherits that summary's audience (public only for shipped|confirmed, and never for a
    security_sensitive task); never required, and nothing on the ship path blocks on it.
  status ∈ {backlog, ready, active, blocked, completed, confirmed, shipped, abandoned}
    completed = builder declared done (Phase 5 / 2026-05-10)
    confirmed = scanner+smoke passed AND quality grader >= threshold; verified, NOT yet paid
                (task 197 / 2026-05-12 — grader is a hard gate; on grader fail the task
                 stays at completed, no credits, builder can manual-confirm via POST
                 /tasks/:id/confirm if they think the grade is wrong)
    shipped   = merged to main + deployed; credits awarded here (credit_log.reason =
                'task.shipped' — ADR 0120 pays on land, not on confirm; which streams
                actually pay depends on the instance reward mode, ADR 0146)
  indexes: (version_id, status), (priority), GIN(touches), (goal_id), (parent_task_id),
           (created_by), (shipped_by) WHERE needs_rebase,
           (source, source_ref) WHERE source IS NOT NULL (idx_tasks_source_ref, core_240)
task_blockers(task_id, blocker_ref)            -- markdown anchors are canonical
claims(id, task_id, builder_id, worktree_name, claimed_at, released_at, outcome)
  UNIQUE INDEX uniq_active_claim_per_task ON (task_id) WHERE released_at IS NULL
cost_log(id, task_id?, amount_usd, category, description, source, source_ref, recorded_at)
credit_log(id, builder_id, task_id, delta, reason, recorded_at)
  trigger: bumps builders.total_credits
builder_sessions(id, builder_id, token UNIQUE, source 'cli'|'web', user_agent,
                 created_at, last_used_at, expires_at, revoked_at)
session_logs(id, builder_id, task_id?, claim_id?, started_at, ended_at, outcome,
             notes_md, confidence)
```

PMS-V2 additions (migration `006_pms_v2.sql`, see `limitations/pms-v2-shipped.md` (instance-side)):

```
-- new columns
tasks  + kind text NOT NULL DEFAULT 'unclassified'  CHECK IN (feature|bug|infra|refactor|spike|
                                                              learning-capture|cleanup|decision|
                                                              blocker-resolution|unclassified)
       + parent_task_id bigint REFERENCES tasks(id)
       + actual_minutes integer                     -- SUM of session_logs for the task, so
                                              -- CLAIMED-session time only; a --regrade has no
                                              -- claim and is deliberately not counted (task 1003964)
       + scoping_confidence integer  CHECK (1..5)
       + discipline text NOT NULL DEFAULT 'unclassified' (mig 014; renamed mig 086)
                                              CHECK IN (engineer|artist|ideator|unclassified)
                                              -- orthogonal to kind; classifies builder
                                              -- interest area (engineer = code/infra/mechanics/bugs,
                                              -- artist = pixel art/sprites/pipeline,
                                              -- ideator = scoping/research/docs/narrative/lore)
claims + head_sha text                              -- captured at claim time for incidental-work scanner
builders + timezone text NOT NULL DEFAULT 'America/New_York'

-- new tables
achievements(id text PK, name, description, icon, credit_bonus, sort_order)  -- 8 seeded
builder_achievements(builder_id, achievement_id, unlocked_at, unlocked_by_task_id, PK on both)
learnings(id, title, body_md, tags text[], related_files text[], captured_by, source,
          source_ref, task_id?, created_at)
  indexes: GIN(tags), GIN(related_files), UNIQUE(source, source_ref) WHERE non-null
idea_inbox(id, title, body_md, kind, suggested_version, suggested_priority, captured_at,
           captured_by, status 'open'|'promoted'|'discarded'|'merged', promoted_to_task_id, reviewed_at,
           merged_into_idea_id? FK idea_inbox, triage_note?,   -- mig core_195 (task 1002447): what a
           -- triage VERDICT decided -- which idea a merge folded into, and why a discard happened.
           -- CHECK (merged_into_idea_id IS NULL OR status = 'merged') -- no merge chains.
           suggested_goal_id? FK goals ON DELETE SET NULL,  -- mig core_222 (task 1003060, goal 1000071):
           -- an ADVISORY routing hint for rows that did NOT convert (homeless/soft-landed/Discord).
           -- The binding home for routed work is tasks.goal_id; nothing may gate on this column.
           filed_via? text CHECK IN ('hall'|'cli'|'discord'|'planning'|'api'))  -- mig core_253_idea_filed_via (task 1004233, sky part 5):
           -- WHICH DOOR filed it, read off the SESSION (web=hall, cli=cli, else api; 'planning' by capture.js
           -- --via planning; the Discord bot names 'discord'). NULL = older than the column; never backfilled.
done_when_criteria(id, version_id, criterion_id, criterion_md, satisfied bool, satisfied_by_task_id,
                   checked_at, sort_order, UNIQUE(version_id, criterion_id))  -- 13 seeded (V1 + PMS-V2)
task_criteria(task_id FK tasks, criterion_id FK done_when_criteria, source 'backfill'|'manual'|'planning',
              created_at, PK(task_id, criterion_id))  -- mig 055 (#435, ADR 0025): the forward MANY link
              -- (the many tasks that GATE a criterion), vs done_when_criteria.satisfied_by_task_id (the one
              -- ship that CLOSED it). Backed GET /versions/:id/progress + /status. Populated on task-create
              -- via POST /tasks { criterion_ids } + the /tasks/:id/criteria manage endpoints (#438); "Cn" is
              -- the 1-based position by (sort_order, criterion_id). idx on (criterion_id) + (task_id).
lifecycle_criterion_uats(id, criterion_id FK done_when_criteria, kind 'uat'|'backend_signoff'|'override',
              signed_off_by FK builders, recording_file, live_basis 'deploy_reading'|'attested'|'not_checked',
              note, created_at)  -- lifecycle_015 (task 1004392, ADR 0351): APPEND-ONLY sign-offs. A criterion
              -- closes only with a uat/backend_signoff row no older than its newest linked ship; until then
              -- it reads "Awaiting UAT". An `override` row is what POST /done-when/:id/satisfy writes now.
lifecycle_criterion_backend_only(criterion_id PK FK done_when_criteria, marked_by, marked_at)
              -- presence = backend-only (no screen to record); settable only while the criterion is open.
session_pulses(claim_id PK, builder_id, last_pulse_at)  -- heartbeat for stale-claim detection
task_grades(id, task_id UNIQUE, score NUMERIC(3,1), passed bool, threshold NUMERIC(3,1),
            grader_kind 'auto'|'subagent'|'lars', grader_version, rubric_scores jsonb,
            signals jsonb, notes_md, graded_at)  -- mig 016, one row per task
grade_attempts(id, task_id, builder_id?, passed bool, score NUMERIC(3,1), attempted_at,
            worker_verdicts jsonb?)  -- worker_verdicts: core_261 (task 1004292), nullable: each round's
            -- per-worker [{kind, verdict, error, severities[]}], NO prose; written best-effort by applyGrade,
            -- read by the correlation audit (served as grade.attempts on GET /tasks/:id?include=grade)
            -- mig 064 (6D.6, ADR 0027): APPEND-ONLY, one row per grade run, so
            -- re-grade thrash is countable (task_grades keeps only the latest)
session_transcripts(session_id PK, builder_id, turn_count, byte_size, truncated,
            turns jsonb, uploaded_at)  -- core_269 (ADR 0051): the FULL secret-scrubbed transcript,
            -- one row per session_records row, in its own table so the BFG's searched rows stay KB
session_records(id, session_id UNIQUE, builder_id, task_ids bigint[], example_earned,
            total_tokens, duration_seconds, started_at, ended_at, uploaded_at,
            detail jsonb, metrics jsonb)  -- mig 062 (6D.1, ADR 0027): per-shipped-session
            -- secret-scrubbed digest (per-turn metadata + short snippets); idx on
            -- ((metrics->>'tool_error_count')::int) in mig 063 (6D.2). The BFG
            -- session-inefficiency evaluator searches + deep-dives this corpus.
```

Memory, audit, and reputation tables (later migrations — the substrate the
`/memory/*` API + the BFG cross-builder write path operate on):

```
builder_memory(builder_id, path, content, mtime, sha256, byte_len, created_at, updated_at,
               PK(builder_id, path))  -- mig 054 (ADR 0024): server-canonical, per-builder-
               -- ISOLATED Claude Code memory. Quotas: 1 MB/file, 50 MB + 2000 files/builder.
               -- The `bfg/` path prefix is RESERVED for BFG-authored notes (sync rejects it);
               -- the self DELETE /memory/file is the builder's affordance to remove them (6C).
karma_log(id, builder_id, delta, reason, recorded_at, granted_by)  -- mig 040: APPEND-ONLY
               -- karma ledger; AFTER INSERT trigger gds_apply_karma bumps builders.karma.
               -- reason e.g. peer_upvote|proposal_ratified|archon_grant|bfg_correction (6C.2,
               -- granted_by = the BFG principal; a correction's negative delta lands here in
               -- the SAME tx as its visible note + audit row).
audit_log(id, builder_id, route, method CHECK IN (POST|PATCH|PUT|DELETE),
          request_body_redacted jsonb, response_status, ip, user_agent, recorded_at)  -- mig 033
               -- APPEND-ONLY authenticated-write log (middleware/audit.js, post-response,
               -- fire-and-forget). GET reads bypass it, so the cross-builder memory reads +
               -- writes log EXPLICITLY + fail-closed; the true verb/action lives in
               -- request_body_redacted.action: archon_forensic_memory_read | bfg_memory_read |
               -- bfg_dream_write | bfg_correction_write.
```

Module store registry (migration `core_257`, [ADR 0338](adr/0338-modules-travel-through-a-bongos-hosted-store.md) — the store surface only; payment, balances and payout are area 8's):

```
store_modules(module_key PK, title, description, author_id, status CHECK IN (listed|delisted),
              delisted_at, created_at)  -- delisting stops what comes NEXT only (ADR 0338 D2)
store_module_versions(id, module_key, version exact X.Y.Z, core_version, manifest jsonb,
              tree_sha256, tarball_sha256, tarball_bytes, artifact_path, published_by,
              published_at, UNIQUE(module_key, version))  -- immutable; a fix is a new version
store_module_prices(id, module_key, price_cents, price_credits, set_by, set_at)
              -- history; newest row per module is current. 0 = free, NULL = not offered
              -- in that currency, at least one must be set.
```

Module entitlements (migration `core_259`, task 1003813 — who holds which module, at which version; the record install, update and the telemetry signals consult; it records ownership, never payment — area 8 owns money):

```
module_entitlements(id, module_key, holder_kind IN (builder|instance), holder_ref,
              source IN (free|core|grant|purchase), payment_ref (opaque, area 8's),
              version exact X.Y.Z | NULL, acquired_at, granted_by, granted_at,
              revoked_at, revoked_reason, UNIQUE(module_key, holder_kind, holder_ref))
              -- module_key is NOT an FK: a core-bundled module has no store row and
              -- holds an entitlement like any other. Ownership is per module; an update
              -- moves `version` forward, never asks for a second purchase. A delist never
              -- touches it (ADR 0338 D2); only revoke (refund, task 1003789) ends a hold,
              -- keeping the row.
```

Module assessments (migration `core_265`, task 1003814 — [ADR 0343](adr/0343-a-module-score-is-a-security-gate-then-an-average-of-visible-parts.md) + [ADR 0347](adr/0347-every-store-module-ships-a-how-to.md) D5; per module VERSION, append-only history, the current row is the newest; never reads price):

```
module_assessment_signals(id, version_id → store_module_versions, part IN (security|tests|
              install|reliability|tester_feedback|docs), outcome IN (scored|passed|failed|
              no_data|pending|not_scored), score 0-100 iff scored, sample_size, reason,
              detail jsonb, measured_at)  -- security is pass/fail only (the D2 gate);
              -- "no data yet" is an outcome, never a zero (D3/D5)
module_assessment_scores(id, version_id, kind IN (computed|override), overall 0-100 | NULL,
              security_passed, is_new (D5 "New" label), formula, signal_ids bigint[],
              override_by, override_reason, computed_at)  -- an override names who + why
              -- and is a new row on the computed history, never an edit (D6)
```

Signals that fill it: **Tests** — `scripts/gds/module-assess-tests.js <version id>` (task 1003791) unpacks the published tarball to `<core root>/.module-assess-<run>/<key>/` (gitignored, removed after), runs each `tests/*.mjs` in its own node process with a timeout and a credential-free environment — regardless of `isModuleEnabled`, which skips every default-off catalog module in the unit gate — and appends one `tests` row: `scored` = % of test files passing (sample_size = files), `no_data` = declares no tests, `not_scored` = tarball unreadable. The store path **refuses unless `MODULE_TEST_SANDBOX=1`** — a published module's tests run only in a separate testing environment with no secrets on disk, never on the control plane (owner, 2026-09-30). `--dir modules/<key>` is a DB-free dry run on your own checkout. On publish the version's Tests part is recorded `pending` until that environment runs it. **Security** — `scripts/gds/module-assess-security.js <version id>` (task 1003792, ADR 0343 D2 gate) appends one `security` row, `passed`/`failed` only: fails on a publish-denylist file, a `module.json` dependency fetched outside the registry (an allowlist: a plain npm name with a plain semver range or dist-tag, anything else fails and is never handed to npm), or a high/critical `npm audit` advisory (resolved metadata-only with `--ignore-scripts`; nothing of the module runs, so it is control-plane safe). An audit that cannot run is `not_scored` — the gate stays shut. Floating ranges and the `maintenance` posture (ADR 0166) are noted in `detail`, never failed on. **Docs** — `scripts/gds/module-assess-docs.js <version id>` (task 1004367, ADR 0347 D5/D6) grades the version's `HOWTO.md`, read from its verified tarball (never the optional `howto.artifactUrl`), with one Claude Sonnet 5 call through the `grade` port's cached `runSubagent` (no tools, the file fenced as untrusted, cut to 40,000 characters to stay under 5¢), retried once. It appends a `pending` row, then `scored` (the average of four 0–100 criteria — purpose, newcomer could use it, runnable example, limits stated — each with a reason, kept in `detail`) or `not_scored` (outage, malformed reply twice, no `HOWTO.md`, bad tarball). Each call's spend goes to `cost_log` via the `reward` port (source `module-docs-grader`). Price is never in the prompt. `--file <HOWTO.md>` is a DB-free dry run. **Score** — `scripts/gds/module-assess-score.js` (task 1003794) composes a version's newest signal per part into a `module_assessment_scores` row: `security_passed` from the gate (NULL = not run), `overall` = the plain average of the SCORED parts among Tests, Install, Reliability and Tester feedback (a part with no data is left out, never zero; none → NULL), Docs shown but never averaged, `is_new` until Install or Reliability is scored, plus the signal ids and a readable `formula`. A recompose that would repeat the current score writes nothing. All three signal CLIs recompose after recording, and the store's publish route queues `assessVersion` after answering the author (one at a time per process, at most 20 waiting; past that it is logged as not assessed): Tests `pending` (only if no Tests result exists), the Security gate, Docs, then the score. `node scripts/gds/module-assess-version.js <id>` re-runs it by hand (`scripts/gds/module-assess-version.js` holds the publish-time half, apart from the composer so the signal CLIs recompose without a require cycle). **No score is ever set by hand** (owner, ADR 0359): a Metic+ person can only ask for a re-check, `POST /store/modules/:key/versions/:version/reassess { reason }` (atom `module.assessment.rerun`, metic + archon via `government_021`), which queues the same `assessVersion` a publish runs and answers 202.

Code: `src/bongos/module-entitlements.js` (`grantEntitlement`, `recordAcquired`, `revokeEntitlement`, `checkEntitlement`, `listEntitlements`). Read routes (own-scoped, `requireBuilder`): `GET /store/entitlements`, `GET /store/modules/:key/entitlement`. Install (task 1003785) grants a free module through `POST /store/modules/:key/acquire`; the buy action (area 8) will grant a paid one.

Bongos views: `claimable_tasks` (rebuilt in 006 to use SELECT t.*; rebuilt again in 014 so the new `discipline` column flows through), `version_progress` (rebuilt in 006 to count only leaf tasks for forward-compat with task hierarchy), `tasks_session_fit` (new in 006: derives `fits_session_modes[]` and `credits_per_minute`; rebuilt in 014 for the same SELECT t.* refresh), `task_grades_with_context` (new in 016: joins task_grades × tasks × builders × cost_log so the V4 optimizer has quality-per-dollar in one read).

**Bongos API (`/api/bongos/*`, mounted in the same Node process):**

- **Canonical path is `/api/bongos` (task 1919); `/api/gds` is a PERMANENT alias.** The router + the discovery index are dual-mounted at both by `serve-internal.js`, driven by the single `src/bongos/api-prefix.js` constant (`API_PREFIX` + `LEGACY_API_PREFIXES`). The legacy `/api/gds` alias never goes away — shipped older CLI binaries, the cached status mirror, and older instances call it. **Exception:** the GitHub OAuth callback stays pinned to `/api/gds/auth/web/callback` (registered on the OAuth app; `src/bongos/routes/auth.js`). Not yet flipped (still ride the permanent alias): `src/**` internal callers + the deeper internal names (folders, `GDS_*` env, `gds_session` cookie) — the deferred internal-rename pass.
- **Self-describing (task 1918, [ADR 0109](adr/0109-self-describing-openapi-and-hosted-docs.md)).** The whole surface is documented in the standard **OpenAPI 3.1** format at [`docs/api/openapi.json`](api/openapi.json), **generated from the live route files** by `scripts/gds/gen-api-docs.js` (reusing the same `route-rank-check.js` introspection the ship-time rank gate uses — so it can't drift; a fitness `--check` + ship-time regen enforce freshness). A rendered docs site (vendored Redoc) is served at **`/docs`** on the apex of every instance (`cloudbongos.com/docs` canonical); `GET /api/bongos` returns a machine-discovery index pointing at it. The generated [`docs/api-reference.md`](api-reference.md) supersedes the old hand-maintained `routes-permissions.md`. The mount prefix is the single `src/bongos/api-prefix.js` constant.

- Auth: `POST /auth/device/start`, `/poll` (CLI Device Flow); `GET /auth/web/start`, `/web/callback` (browser); `POST /auth/logout`.
- Own-scoped session self-service ([ADR 0206](adr/0206-own-scoped-session-revocation-no-absolute-ceiling.md), task 1003341), in [`src/bongos/routes/my-sessions.js`](../src/bongos/routes/my-sessions.js): `GET /me/sessions` (every live session on the caller's own account — source, user agent, created/last-used/expires, a `current` flag; the token value is never selected), `POST /me/sessions/revoke` (`{session_id}` — one of your own; a miss answers `revoked: 0` so a stranger's id cannot be probed) and `POST /me/sessions/revoke-all` (sign out everywhere, the requesting session included). All three gate on `requireBuilder` alone and key every statement on `req.builder.id` — an account is never named in the query, body or path. They exist because a bearer refreshes to `now()+24h` on every call, so a leaked one never expires, and the cross-builder pair (`POST /auth/revoke`, `/auth/revoke-all`, both still gated on the admin `auth.session.revoke` atom) needed an Archon the victim might not have. Surfaced in the hall at Settings → Active sessions.
- Authenticated CLI/web: `GET /me` (returns `rank`), `GET /versions[/progress]`, `GET /tasks[?version=&status=&kind=&discipline=]`, `GET /tasks/claimable[?version=&discipline=]`, `GET /tasks/:id`, `POST /tasks` (accepts `discipline` + `criterion_ids`; **metic+** — [ADR 0090](adr/0090-metic-task-authoring.md)), `PATCH /tasks/:id` (supports `parent_task_id`, `kind`, `discipline`, `goal_id` — (re)assign the task's goal; must be a goal in the task's own version, task 1763; **metic+**), `POST /tasks/:id/promote` (**metic+**), `POST /claims`, `POST /claims/:id/resolve`, `POST /cost`.
- Criterion rollup + task↔criterion links ([ADR 0025](adr/0025-structured-criterion-task-link.md), [#435](https://example.com/builders#/task/435)/[#438](https://example.com/builders#/task/438)): `GET /versions/:id/progress` rolls up each done-when criterion → its gating tasks (via `task_criteria`) → live status counts + the not-yet-shipped `remaining[]` + `unattributed_tasks` (the read behind the `/status` skill, in `src/bongos/done-when.js criterionProgress`). The link CRUD mirrors the dependency endpoints: `GET /tasks/:id/criteria`, `POST /tasks/:id/criteria` (**metic+** — [ADR 0090](adr/0090-metic-task-authoring.md)) and `DELETE /tasks/:id/criteria/:criterionId` (**metic+**). A criterion ref is a numeric `done_when_criteria.id`, a positional `"Cn"` token, or a `criterion_id` slug, resolved against the task's version (`POST /tasks` links at create time so `/status` counts the task with no backfill).
- Module store publish (ADR 0338 D1, task 1004271): `POST /store/modules/:key/versions` (`requireBuilder` + `requirePermission('module.submit')`, Metic floor). The body is the raw gzip tarball `bongos module publish` builds (own `express.raw` parser, 5 MB cap; 16 MB / 2000 files unpacked). `scripts/gds/module-artifact.js` re-verifies every hash and the publish gate, then `src/bongos/module-store.js` keeps the file under `var/module-store/` and inserts the `store_module_versions` row in one transaction. The first publish makes the caller the author; later versions are author-only, newer than the last and never overwritten; a delisted key takes none.
- Module store install (ADR 0338 D1, task 1003785), all `requireBuilder` and own-scoped (the holder is the caller): `POST /store/modules/:key/acquire` (`{version?}`; grants a free entitlement — no price row, or a zero price, is free — or `402 payment_required` for a priced module; refuses a delisted one), `GET /store/modules/:key/versions/:version/tarball` (served only to a live entitlement holder; `X-Tarball-Sha256`), `POST /store/modules/:key/acquired` (`{version}` → `recordAcquired`). Read side in `src/bongos/module-store.js` (`resolveAcquirable`, `isFreePrice`, `versionArtifactFile`). No channel check yet (tasks 1003815, 1003805). `bongos module update` (task 1003786) reuses the same three calls; the acquire route reads price only for a caller with no entitlement, so a holder is never charged again.
- Server-mediated branch publish (ADR 0055 / [#1025](https://example.com/builders#/task/1025) — lets a checkout with no GitHub push credential ship). Owner-gated like ship: `POST /tasks/:id/publish-branch` (`requireBuilder` + `gateTaskOwnership`; own 32 MB json parser for the base64 thin-bundle body, 20 MB decoded cap; the server pushes the branch + opens the PR + auto-merges with a server-side push credential — a **GitHub App** installation token (short-lived, repo-scoped; preferred, [ADR 0055](adr/0055-server-mediated-branch-publish.md) update / task 1028) or the `GITHUB_PUSH_TOKEN` PAT fallback; `503 push_unconfigured` when neither is set; `400 tip_mismatch` if the bundle tip ≠ the claimed `head_sha`) and `GET /tasks/:id/publish-status?branch=…` (polls PR + deploy-prod state derived live from GitHub). `branch` is optional: without it the server finds the task's own PR by its `task <id>: …` title, and the answer names the `branch` it used and its `branch_source` (`query` / `task_pr`, or `null` with a `branch_hint` when there is no such PR) — never a `400` (task 1003764). When the PR is still open it also carries `merge_driver`, whose `reason` says why it has not merged; on a red PR `failing_tests` names the failing unit tests (read from the `unit-report` commit status the `unit` workflow posts) and `checks_unreadable: true` says the check list is blind because the App lacks `Checks: read` — so an empty `checks[]` is never read as "nothing failed" (task 1003988, ADR 0301). Because the server's credential is the PR's AUTHOR, publish also **assigns the PR to the task's claim holder** and names them in the body (`modules/lifecycle/pr-assign.js`, task 1003991) — best-effort: the 201 carries `pr_assignee` (the login, or `null` when GitHub would not assign it) and a failed assignment never fails the publish. `ship.js` uses these in `ci` mode only when `pushVia()` resolves to server (no authenticated `gh` on the machine, or `<PREFIX>_PUSH_VIA_SERVER=1`); a machine with `gh` keeps the local push path unchanged. Implementation in `src/bongos/github-push.js`.
- Archon monitoring reads backing the `/watch` page (ADR 0036): `GET /builders/roster`, `GET /grades/by-builder[?days=N]` (**archon-only**, [#726](https://example.com/builders#/task/726) — per-builder grade breakdown for the MARKS section; the project-wide aggregate stays public at `/public/grades`), `GET /audit-log`, `GET /override-requests`, `GET /access-requests`, `GET /security/reports`. Personal-prefs writes backing `/settings`: `GET/PATCH /me/skill-prefs`, `PATCH /me/disciplines`.
- Per-builder "needs" + own Gemini key ([ADR 0073](adr/0073-builder-needs-signal-and-byok-gemini-key.md), [#1013](https://example.com/builders#/task/1013)): `GET /me` now also carries `needs` ({items, action_needed_count} — the consistent "the system needs an input from you" signal; `modules/builder-settings/builder-needs.js` is the SSOT — carved out in BV1.R80, resolved by `GET /me` via the `builder-settings` kernel port — rendered by the hall Standing card + the CLI `printNeedsNudge`). The own-key (pragmatic BYOK) endpoints, all own-scoped: `GET /me/art-key/own` (masked meta — last4 only), `PUT /me/art-key/own` (validate-on-save via a Google list-models call → encrypt with `src/bongos/secret-box.js` → store; `503 storage_not_configured` until `BUILDER_SECRET_KEY` is set, `422 invalid_key` on a bad key), `DELETE /me/art-key/own`. The existing `GET /me/art-key` (shared-key delivery) is extended to also deliver the decrypted own key, which `scripts/gds/fetch-art-key.js` syncs into the local `gemini_api_key` slot (own key wins in the `gen_api.py` cascade).
- Builder memory (ADR 0024 cloneable memory + ADR 0026 BFG). Self-scoped (owner is always `req.builder.id`, never input): `POST /memory/sync` (push own memory; own 64 MB parser, vs the global 64 KB), `GET /memory/files`, `GET /memory/file`, `DELETE /memory/file` (the BFG delete affordance, 6C.2). Cross-builder (input-owner) endpoints — all privileged + audit-logged fail-closed: `GET /memory/builders/:id/files`+`/file` (**archon forensic** read), `GET /memory/bfg/builders/:id/files`+`/file` (**BFG-principal only**, 6B.1 read), and the one cross-builder WRITE `POST /memory/builders/:id/bfg-write` (**BFG-principal only**, kill-switched `BFG_WRITE_ENABLED` default-OFF, namespaced `bfg/`, attributed `author: BFG`, write+audit in one tx — dreams + transparent corrections, 6C.1/6C.2).
- Session corpus (BFG evaluator — 6D, ADR 0027): `POST /sessions` (upload own session digest; own **4 MB** json parser — capped, vs the global 64 KB — and the digest is per-turn metadata + short scrubbed snippets, never raw transcript content), `GET /sessions/mine` (self-serve), `GET /sessions/search` (cross-builder, **archon-gated** — the BFG-principal stand-in; the principal now exists (6C.1) and the *memory* cross-reads moved to it (6B.1), but these *session* reads still use the archon stand-in pending a retrofit, + audit_log row per read), `GET /sessions/:id` (own self-serve; cross-builder needs archon + audit; non-owner → 404).
- Public (no auth, `Cache-Control: max-age=60`): `/public/versions`, `/public/progress`, `/public/cost-summary`, `/public/recent-shipped`, `/public/leaderboard`, `/public/grades[?days=N]`, `/public/tasks/:id` ([#604](https://example.com/builders#/task/604) — single-task resolver for `#NNN` doc deep-links; `title`/`value_summary`/`visual_url` returned **only** for `shipped`|`confirmed` work and withheld for in-flight tasks so unshipped/security task names can't leak; the status dashboard renders it at `#/task/:id`), `/public/ref-ids` ([#653](https://example.com/builders#/task/653) — `{tasks:[ids]}`, ids only, token-free; the doc-ref linkifier + its CI gate consult it to decide which bare `#NNN` are real task refs). These power `status.example.com`.
- Live updates (Server-Sent Events — [#569](https://example.com/builders#/task/569), [ADR 0030](adr/0030-builders-hall-live-updates.md) signal layer, [ADR 0069](adr/0069-hall-live-channel-sse-decouple.md) transport): an SSE stream at `GET /api/bongos/live` ([`src/bongos/routes/live.js`](../src/bongos/routes/live.js)), mounted in both entrypoints (`server.js` + `src/platform-server.js`) so the hall stays live on a game-less boot. This **superseded** the original broadcast-only Colyseus `builders_hall` room (R55 / task 1194 — the room and `src/rooms/BuildersHallRoom.js` were deleted because a Bongos-only instance has no Colyseus in the process). The change-signal layer is **unchanged**: a statement-level Postgres `NOTIFY` trigger (migration 066) on `tasks`/`claims`/`builders`/`builder_onboarding_state`/`credit_log`/`karma_log` fires a `gds_live` notification on every write (incl. direct `psql`); one persistent `LISTEN` connection ([`src/bongos/live-channel.js`](../src/bongos/live-channel.js)) relays each notification, and the SSE endpoint emits an **opaque empty nudge** to open hall tabs (the `{table, op}` is kept server-side so internal table names can't leak); the hall re-runs its `loadAll()` (debounced) on any nudge. No row data crosses the channel — access control stays on the per-panel re-fetches.

**Builder ranks & the trust boundary:** moved to its own canonical reference —
[`docs/canonical-permissions.md`](canonical-permissions.md) (rank ladder, live ranks, what's gated,
failure modes) and [ADR 0016](adr/0016-trust-boundary-server-enforced-permissions.md) (the decision).
**Authority lives in `builders.rank` on the prod DB, checked server-side per request with no caching;
markdown describes, the DB enforces.**

> **Two entrypoints, one serving path (ADR 0062 R51, task 1190).** The host-routing + hall/status serving below is factored into `mountInternalSurfaces(app)` in [`src/bongos/serve-internal.js`](../src/bongos/serve-internal.js), called by **both** the game boot (`server.js` (instance-side)) and the new **Bongos-only boot** ([`src/platform-server.js`](../src/platform-server.js)). The platform boot constructs **no Colyseus, no game rooms, no `/vendor/*`, no `/assets/tiles`, no `public/`** — a game-less Cloud Bongos instance runs it unchanged, and "no game route is reachable" holds by absence (the inverse of `preview-server.js`, which serves only the game). Prod still runs `node server.js`; Bongos-only entrypoint is the seam the instance model (R54/R67) boots on.

**Multi-host setup (same Node process), routed by `Host` header in [`src/bongos/serve-internal.js`](../src/bongos/serve-internal.js), shared by both entrypoints:**

- **the apex root itself** — the public front door (`/`, `/projects`, `/create`, `/privacy`, `/terms`, `/contact`). **Carved to the `public-landing` module in task 1003322** ([ADR 0218](adr/0218-the-apex-root-web-surface.md)): the surface moved from repo-root `public-landing/` to `modules/public-landing/public/` and is a loader-discovered web-surface module — the THIRD, and the first that is not a subdomain. Where `hall-ui`/`status-ui` declare a Host PREFIX, this one declares `{ apexRoot: true, dir }`, because the apex is whatever host is left once the subdomains are taken (`isApexHost` = `!isStatusHost && !isBuildersHost`); `host: ""` is rejected, since `host.startsWith("")` is true for every host and would swallow the other two surfaces. Like the hall it keeps its **dedicated** serving block — in `src/platform-server.js`, now resolving its root through `moduleWebSurfaces()` by the `apexRoot` predicate rather than a hardcoded path — so the apex-only sentinel strip, the brand-token stamp and the `?v=` content stamp are unchanged. Disable the module and the front door vanishes: every route falls through to the game-less 404 tail. Served bytes are identical across the carve apart from the module's own `window.__MODULES__` entry.
- **`example.com`** — game (Phaser + Colyseus). Static files from `public/`. `/builders` + `/builders/*` now **301-redirect to `builders.example.com/<rest>`** ([#739](https://example.com/builders#/task/739) then promoted to permanent 301 in [#741](https://example.com/builders#/task/741), ADR 0036 cutover); the apex no longer serves the builder surface directly.
- **`status.example.com`** — public build dashboard. **Carved to the `status-ui` module in BV1.R84** ([ADR 0093](adr/0093-tranche-2-core-carve-sequence.md) §1): the surface moved from `public-status/` to `modules/status-ui/public/`, now served by the loader's web-surface seam (`moduleWebSurfaces` → `serve-internal.js`, routed on the `status.` Host prefix the manifest declares) instead of a hardcoded block — no behavior change. Layout reorganized in [#726](https://example.com/builders#/task/726) (ADR 0036): Pulse / Watch(uptime) / Architects / Works / Treasury / Lately Inscribed / The World — the grade-aggregate, estimation-drift, and repo-health tablets moved to the Archon `/watch` page. **⚠ Served OFF the droplet** (ADR 0029, outage resilience): the live page is **GitHub Pages from the separate repo `example-owner/example-status`** (CNAME → Fastly), reading data cross-origin from the droplet's `/api/bongos/public/*` (CORS open) and an availability banner from the prober's `status-data` branch. The droplet still serves `modules/status-ui/public/` (on the `status.` host) as a same-origin fallback, but **DNS points at Pages, not the droplet** — so a droplet deploy does NOT update the live page. Changes to the surface publish to the mirror via `scripts/status-mirror-sync.js` (re-pointed at `modules/status-ui/public/`; status.js/style.css/cursors are byte-identical copies; index.html gets the off-box bits injected), run automatically by `.github/workflows/sync-status-mirror.yml` (needs the `STATUS_MIRROR_TOKEN` secret) ([#737](https://example.com/builders#/task/737)). **⚠ FOLLOW-UP (R84):** that workflow's path trigger still watches `public-status/**` and must be re-pointed at `modules/status-ui/public/**` by an owner/Archon — the GitHub App can't push `.github/workflows/*` (learning 107), so until then the mirror sync won't auto-fire on future status edits.
- **`builders.example.com`** — dedicated builder surface (`isBuildersHost`, ADR 0036). **Carved to the `hall-ui` module in BV1.R85** ([ADR 0093](adr/0093-tranche-2-core-carve-sequence.md) §1): the surface moved from `public-builders/` to `modules/hall-ui/public/` (~13k LOC, the largest module) and is a loader-discovered web-surface module (`contributes.webSurfaces` host `builders.`). UNLIKE the generic status surface it keeps its **dedicated** serving block in `serve-internal.js` (`BUILDERS_DIR = modules/hall-ui/public/`), partitioned out of the generic web-surface loop on the `isBuildersHost` predicate. A thin rewrite shim maps every non-API path onto the existing `/builders/*` tree (so all serving + gating + asset-stamping is reused), serving the hall (`/`), the Metic+ **`/watch`** monitoring page (gated by `requireGovernmentPage`), **`/settings`** (Voices + Craft prefs), plus ranks/sessions/primer/diagrams. No behavior change — byte-identical (only `window.__MODULES__.enabled` gains `hall-ui:true`). **Additive** — until its DNS A record + cert are live, the whole surface stays reachable at `example.com/builders/*`. No `.github/workflows/*` follow-up: unlike R84, no workflow path-trigger watches `public-builders/**`.
- The `/api/bongos/*` surface is reachable from every host. **Cross-subdomain sign-in:** the `gds_session` cookie is scoped to `.example.com` on the production hosts (apex/www/builders/status) and host-only on localhost/staging (no cross-env token bleed); the OAuth handshake runs on the canonical origin with a validated `?return=` (open-redirect-guarded) so the subdomain can land a builder back on itself.
- Caddy gets a site block per host (`infra/Caddyfile` (instance-side)), all reverse-proxying to `127.0.0.1:3000`.

**Asset cache-busting (content-hash `?v=`, task [#521](https://example.com/builders#/task/521)).** The hall + status HTML pages (`modules/hall-ui/public/*.html`, `modules/status-ui/public/index.html`) are served from an **in-memory stamped copy**, not straight off disk: at boot [`src/asset-version.js`](../src/asset-version.js) rewrites each local css/js ref's `?v=` query to a 12-hex hash of the referenced file's content (`buildStampedHtml`). The on-disk HTML keeps a hand-typed `?v=` only as a fallback. This is the durable fix for stale-asset serving — Cloudflare overrides the origin's `max-age=60` with a **4h browser TTL** for js/css, so before this, editing `builders.js` without manually bumping its `?v=` left every returning browser (and CF's edge) serving pre-deploy bytes for hours. Now any content change → new hash → new URL → fetched fresh automatically. HTML pages stay short-cached (CF serves them DYNAMIC), so the new `?v=` reaches clients within ~60s. Assets and non-HTML paths still fall through to `express.static`; the sign-in gate on primer/diagrams runs before the stamped serving.

**External:**

- GitHub repo (private): [github.com/example-owner/example](https://github.com/example-owner/example)
- Live site: [https://example.com](https://example.com)
- DNS + domain registrar: Cloudflare
- Hosting: DigitalOcean (droplet `example`, NYC3, IPv4 `REDACTED_IP`)
