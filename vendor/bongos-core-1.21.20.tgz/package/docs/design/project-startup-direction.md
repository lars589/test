# Project startup — design direction (the design of record)

> Goal 1000121 · task BV2.PS01 (1004415) · spec [`docs/specs/<redacted>.md`](../specs/<redacted>.md) (final) · idea 1001172.
> Live prototype: the Claude Design canvas "Project Startup Onboarding" (https://claude.ai/artifact/<redacted>). It is private to the owner. Its sources are committed in [`mocks/project-startup/`](mocks/project-startup/README.md).

This document is what every build task in goal 1000121 cites. Name a screen by its canvas file (for example "`Charter.dc.html`") and look it up here. It records:

- **what each screen is**;
- **what the live product KEEPS**;
- **what the new design ADDS**;
- the decisions that govern both.

## The blended flow — supersedes the hub-side screens (owner, 2026-10-01)

> *Go for this as the design of record.* — the owner, approving the blended mockup (task 1004515).

The first build put the new startup screens and the old create wizard back to back: fourteen panels, a ten-step progress rail, a planet that changed material at every answer. The owner asked for one flow, less text, no progress bar, and subtle lofi art. The mockup in [`mocks/combined-onboarding/`](mocks/combined-onboarding/README.md) is now the design of record for **every hub-side screen**. Where it disagrees with the front door, route 1, route 2 part 1 and the coordinates/look/birth tables below, the mockup wins. Genesis (part 2) and the blend rule are unchanged.

### The six screens

| # | Screen | What it folds together |
|---|---|---|
| 1 | Sign in | Today's gate, unchanged. |
| 2 | Demo or real project | The fork, with the terms as one required checkbox on it. The terms version stamp still records the acceptance. |
| 3 | What are you making? | Name, kind, and an optional one-sentence description. |
| 4 | A few quick checks | Country and state or province, where builders will be, anyone under 18, who is behind it. |
| 5 | Check what we set up | Every prefilled answer as a row: code home, address, app hosting, extras, rewards, how much we run, team size. |
| 6 | Give it a look → Create | The look picker, with logo and night tint, and a one-line recap. |
| — | Alive | The done panel, leading into genesis. |

**No progress rail.** The ten-step rail and the seven-question inner rail go. Back stays, and a small eyebrow names where you are.

**The review must not be skippable.** On screen 5 each row has **Looks right** and **Change**. Change opens the real control in place, and choosing in it confirms the row. Continue reads "Confirm N more" and stays locked until every row is confirmed.

**Voice (changes D5).** Plain project words for everyone. Planet words survive only as a light touch: the fork ("You're about to start a digital planet") and the alive moment.

**Art (replaces "The planet as a system" for the hub).** The studio's lofi night room in its own palette: a window with moon, stars and city lights, the floor, lamp glow, mug and plant, and a soft grain. The chrome seed hangs in the window sky and grows a little on each screen, so the alive screen is the next frame of the same picture. Motion is a slow twinkle, a lamp-glow breathe and a seed float, all off under reduced motion and the kill switch. The nebula field plate, the changing planet materials, rings, moons, ghost beads, sun tether and guard ring leave the wizard.

### Nothing the live wizard does is lost

The mockup draws the simple path. Every live capability stays, as a reveal (shown only when an answer calls for it) or behind a row's Change:

| Today | In the blended flow |
|---|---|
| Q1 new or existing, and what already exists | Screen 5's code row: "A repo I already have" reveals what already exists and the adopt path. |
| Adopt: GitHub repo picker, manual fallback, conflict pre-flight, backlog import | Behind the code row's Change, unchanged. |
| Q2 geography | Screen 4, with state or province beside country. |
| Q3 under-18s and the age tiers | Screen 4; "Yes" reveals the tiers and the guardian rules. |
| Q4 entity, new intent or existing legal type | Screen 4's "who is behind it"; a company or nonprofit reveals the full entity list. |
| The screening stop | Unchanged: an answer the platform cannot serve still stops the flow before anything is created. |
| Q5 one or many, count, growth guess | Screen 5's team size row. The About step's "who's building it" merges into it. |
| Q6 rewards | Screen 5's rewards row (pick several). |
| Q7 framing A–D and the hybrid suite | Screen 5's "we run" row; "Some of it" reveals the service checklist. |
| Auto-fill from my account | Kept, as an offer at the top of screen 3 when the account has a last project. |
| Resume a saved draft | Kept, on the fork. |
| Type and About | Screen 3. |
| Modules picker and search | Screen 5's extras row; Change opens the searchable picker. |
| Address: handle, own domain, no address | Screen 5's address row (PS19: shown and confirmed on every path, the demo included). |
| App: Render key check, workspace, runtime, commands, plan, database | Screen 5's app hosting row; Render opens today's settings. |
| Look, logo, night tint | Screen 6. |
| Review | Folded into screen 5 and screen 6's recap. |
| Done: standup strip, the owner-only steps, invite | The alive screen. The owner-only steps stay ahead of the genesis door; the invite box appears only once the hall is live (PS15). |
| Demo: fit check, settings, teammates, 30-day notice | One demo screen, then screens 3–6 marked "demo". The settings appear as screen 5's rows. |

### Who builds it

| Task | Builds |
|---|---|
| PS16 (1004504) | Plain wording everywhere and no progress rail. |
| PS21 (1004516) | The fold into six screens, the locked review, every reveal above. |
| PS22 (1004517) | The lofi night room art. |
| PS19 (1004507) | The address is chosen on every path before Create. |
| PS15 (1004503) | The invite box only once the hall is live. |
| PS18 (1004506) | Birth into genesis; the alive screen's door. |

## The blend rule — read this first (owner, 2026-09-30)

> *No UI battle between existing and new. Build the prototype's design, then blend it where needed with existing design. Don't hijack the builders hall.*

Four consequences, applied in every row below:

1. **Genesis is a MODE the existing hall wears, never a second hall.**
   - It follows the social-mode precedent (`html[data-social]`): one attribute on the hall, off by default, and off whenever the founding state cannot be read.
   - It keeps today's v3 glass hall: the shell, the 64px rail, the navigation groups, the panels, the tokens and both modes.
2. **Founding mode adds exactly four things, and nothing else changes:**
   - the founding band;
   - the genesis home;
   - the asleep state on existing navigation items;
   - the founding mark.
   
   A test must pin that a hall that is not founding renders exactly as today.
3. **Where the canvas's hall chrome differs from the live hall, the live hall wins.**
   - The canvas drew a hall to show the idea: an expanded 232px rail, its own panel spacing, its own icons. Those are illustration, not instruction.
   - Build the four additions *into* the real hall's components (`OTBKit`, the archetype sheets, `shell.js` NAV, the widget registry). Never port the canvas's markup.
4. **The hub-side screens (front door, questions, look) are new surfaces in the apex world.**
   - They extend the existing create wizard (`projects.html ?view=new`) and follow `DESIGN.md` exactly.
   - Where the wizard already has a component, reuse it rather than the canvas's version: the lifecycle rail, hairline choice cells, one-hairline fields, doors and ledger rows.

## The screens

### Front door (hub, apex world)

| Canvas screen | What it is | Keep | Add |
|---|---|---|---|
| `Main.dc.html` · Before you begin | A terms acknowledgement before creation. | Sign-in stays where it is today, before this screen. The terms version stamp (the platform's existing acceptance machinery) records what was accepted. | A new first screen: display headline, two lede paragraphs, one checkbox, a "read the terms" link, one primary door. |
| `Fork.dc.html` · Demo or create | "You are now creating a digital planet." | The world's **door pill**, as specified in `DESIGN.md`: two equal doors joined into one glass object. | A full-bleed composition: the seed on the field plate, the headline, the door pill, and two route descriptions on a hairline band. |

### Route 1 · the demo

| Canvas screen | What it is | Keep | Add |
|---|---|---|---|
| `DemoSetup.dc.html` | People, hours each, an idea, and a fit check. | The wizard's steppers-as-fields grammar and hairline fields. | A fit-check panel in Bongos's voice, and a time-box ring on the planet. The copy says each person uses their own AI plan. |
| `DemoReady.dc.html` | Defaults picked, plus invites. | Ledger rows for the defaults; the existing invite step's shape. | The demo defaults (D-list below) and two invite fields. |
| `DemoKeep.dc.html` | "Keep your planet?" | — | Two cells: carry it over (pre-fills part 1) or keep it as a demo. |

**Demo decisions:**
- **D3 — the time box is soft.** A countdown shows; at zero the demo asks "keep your planet?". Work is never frozen.
- **D9 — an unkept demo is archived after 30 days.** It goes offline and can be restored, and the owner is warned first.

### Route 2 · part 1, planet physics (hub, apex world)

Every question screen shares one layout. On the left are the rail of seven steps, the question, the choices and the doors. On the right is the **stage**: the field plate, with the planet forming.

| Canvas screen | Question | Keep | Add |
|---|---|---|---|
| `Autofill.dc.html` | Start from your account, or from scratch? | Hairline cells. | The seven-step rail, shown up front. |
| `State.dc.html` / `StateExisting.dc.html` | 1 · New or existing, the idea text, and existing work types. | Cells, a hairline textarea, and check rows. | The planet begins as a **seed** (new) or **already formed** (existing). |
| `NotPossible.dc.html` | The screening stop. | — | A calm stop screen: nothing created, contact us, start over. No planet forms. |
| `Geography.dc.html` | 2 · Home country and state, and where builders are. | Hairline selects and option rows. | The planet's **coordinates** (a mono line on the stage). |
| `Ages.dc.html` | 3 · Anyone under 18? | Cells, and a ledger for the tiers. | A **protective ring**; the guardian tiers stated plainly. |
| `Entity.dc.html` / `EntityExisting.dc.html` | 4 · Intent (new) or legal type (existing). | Option rows with group heads. | The planet's **core material**: frost for an individual, chrome for a group, gold for an organization, obsidian for a nonprofit. This is placeholder art direction. |
| `Builders.dc.html` / `BuildersPro.dc.html` | 5 · One or many, how many, and a growth guess. | Cells and a stepper. | **Moons**, plus a dashed orbit for expected growth. Two voices (D5). |
| `Rewards.dc.html` | 6 · Reward intents (hidden when solo). | Check rows. | **Rings**: currents of value. |
| `Framing.dc.html` | 7 · A–D, plus the service checklist. | Option rows and a two-column check grid. | The planet's **orbit** around the Bongos pair: all managed is close, hybrid is middle, local is far, open source is its own system. |
| `Physics.dc.html` | The summary. | Ledger rows with change links. | The full planet, with every addition. |

**Decisions for part 1:**
- **D5 — the voice follows the entity answer automatically.** Planet voice for individuals and groups; professional voice for organizations. It can be switched later in settings.
- **D6 — soft limits only.** An option that does not apply is hidden or greyed, with a plain "why" line from one rule table that carries its reasons. Nothing claims to be enforced.

### Coordinates, a look, then birth (hub, apex world)

| Canvas screen | What it is | Keep | Add |
|---|---|---|---|
| `Coordinates.dc.html` | Name, handle and address; where the code lives; where the app runs. | **Today's wizard steps as they are.** This screen only shows them **pre-filled from part 1**, and skipped when they do not apply. | The planet named under the stage. |
| `Look.dc.html` | Pick a look for light and dark mode, plus a logo. | **A look is a branding pack**: the style library's real looks (Chrome World, Expedition, Grove, Blueprint), with no sixteenth token. | A look picker with two mini-hall previews. A night-tint switch, **on by default** (D2 — its ADR is PS06's first job). A logo upload. |
| `Birth.dc.html` | The planet forming while setup runs. | **Today's done panel**: the standup rail and the three owner-only steps. | The planet arriving on the stage. The primary door starts genesis while the machine setup finishes. |

**D8 — existing projects get the look and the logo only**, from project settings. They never get genesis.

### Part 2 · genesis, planet biology (the builders' hall, founding mode)

**Every row here is governed by the blend rule.** The canvas shows Kestrel's chosen look (Grove, with the night tint) on purpose, to show that halls differ. The real hall renders the project's own branding pack, whatever it is.

| Canvas screen | What it is | Keep (the live hall) | Add (founding mode only) |
|---|---|---|---|
| All four genesis screens | The frame. | The v3 glass hall: rail, topbar, panels, tokens, both modes, and the project's logo in the topbar. | **The founding band**: a 44px strip above the topbar reading "project founding mode", with the stage and day and a "what's this?" link. **Asleep navigation items**: today's items, dimmed, each naming the stage that wakes it. |
| `GenesisDecide.dc.html` | Decide: stage lengths, what counts as done, the starting government, passes, advisors. | The hall's panels, ledger rows and pills. | **The genesis home** as the founding-mode landing page, including a solo fast-track (D4, about ten minutes). |
| `GenesisHall.dc.html` | Mid-genesis. | The home widget registry and the roster rows. | A **life strip** (one rendered plate per stage; PS12 renders them), the stage list, and a founding builders panel. |
| `Charter.dc.html` | Pick a form of government. | The charter library's real forms and trajectories. | Forms under their **real academic names** with plain explanations (D10). The founding builders' reviews are shown. |
| `Legislation.dc.html` | Fine-tune the variables. | The Board Room constitution: franchise plus pass rule. | The variables under their academic names with plain explanations. The unbuilt variables are shown as coming later. "Limits from your answers" (D6). |
| `Alive.dc.html` | The planet comes alive. | The hub sky: the planet joins it. | A moment screen: the founding builders credited, then enter the full hall. **Founding mode switches off.** |
| `FoundingBuilders.dc.html` | The founding mark, after genesis. | The ranks page, profile and roster exactly as they are. | **The founding mark**: a numbered seed badge (D1 — badge only, it grants nothing), a column on ranks, and a founding wall on the home page. |

**How rooms wake.** Each finished stage wakes today's navigation items:

| Stage finished | Wakes |
|---|---|
| scope | goals & roadmap |
| strategize | tasks |
| charter | board room |
| legalize | economy |
| legislation | ranks |
| alive | community, and the public sky |

**D7 — a stage closes when the constitution in force decides it** (a Board Room item; PS04). Under a monarchy that is the founder's single confirmation.

## The planet as a system

The planet is built from the world's own rendered plates: `r2-*` and `r3-*`, the cutouts, and `r3-space-nebula` for the field. Nothing on the stage is drawn:

- orbits are hairline circles;
- moons are beads;
- the Bongos pair is the platform's mark.

Motion follows `DESIGN.md`: breathe (32s), sheen (40s), drift (90s), orbits of 160s or more, arrive (700ms). All of it is CSS on the objects only, and dead under the kill switch.

**The planet the flow forms is the planet that appears in the sky.** Its shape, material and style come from the hub's existing template fields, and the look's accent tints it.

## Copy

- **The screen text is user-facing copy, drawn from the owner's scope doc.** Italic text and footnotes in that doc were internal; they live in the canvas's notes and in the spec.
- **Voice:** the planet voice keeps the owner's energy (one ":)" on the fork). The professional voice drops the planet words but keeps the same flow.
- **The sample data is sample.** Kestrel, Avery, Jordan, Sam and Rae, the counts, and the "[n]" placeholders are not product copy.
