# De-monolith plan — no first-party file over 1,500 lines

**Date:** 2026-08-23 · **Task:** task 1003203 (spike, R03 of goal 1000079 "Code quality") · **Author:** example-owner
**Feeds:** task 1003204 (db.js), task 1003205 (ship.js), task 1003206 (the rest), task 1003207 (dead-code/baselines)
**Companion:** [`../audits/ai-dev-redteam-followup.md`](../audits/ai-dev-redteam-followup.md) §5

---

## The target

Goal 1000079's `monoliths-eliminated` criterion (aggressive scope): **`oversized_file_count` → 0.** The ratchet ([`fitness-ratchets.js`](../../scripts/gds/fitness-ratchets.js)) counts tracked first-party `.js` files over **1,500 lines** (`OVERSIZE_LINES`), after excluding `node_modules/`, `public-docs/`, `*.min.js`, `redoc.standalone.js`, and `vendor/`. Baseline today: **12 files, `excess_lines_total` ≈ 12.3k.** Shrink-only — lower the baseline in [`config/fitness-baselines.json`](../../config/fitness-baselines.json) as each file drops under; never raise it.

The 12 (current line counts on `main`):

| # | File | Lines | Module | Decision | R-task |
|---|---|---|---|---|---|
| 1 | `modules/lifecycle/db.js` | 5,748 | lifecycle | **SPLIT** (7 seams) | 1003204 |
| 2 | `scripts/gds/ship.js` | 4,613 | lifecycle | **SPLIT** (7 seams) | 1003205 |
| 3 | `modules/hall-ui/public/builders.js` | 2,558 | hall-ui | **SPLIT** (3 seams) | 1003206 |
| 4 | `scripts/gds/provision.js` | 2,498 | provisioning | **SPLIT** (4 seams) | 1003206 |
| 5 | `modules/grading/grader.js` | 2,083 | grading | **SPLIT** (5 seams) | 1003206 |
| 6 | `scripts/gds/fitness.js` | 1,990 | devsecops | **SPLIT** (checks→modules) | 1003206 |
| 7 | `modules/hall-ui/public/goals-page.js` | 1,988 | hall-ui | **SPLIT** (extend existing carve) | 1003206 |
| 8 | `scripts/gds/seed-v3-tasks.js` | 1,981 | (kernel) | **DELETE** (else allowlist) | 1003207 |
| 9 | `modules/lifecycle/routes/tasks.js` | 1,884 | lifecycle | **SPLIT** (sub-routers) | 1003206 |
| 10 | `src/bongos/auth.js` | 1,866 | kernel | **SPLIT** (4 seams) — highest risk | 1003206 |
| 11 | `modules/lifecycle/routes/goals.js` | 1,535 | lifecycle | **SPLIT** (extend existing carve) | 1003206 |
| 12 | `scripts/gds/box.js` | 1,519 | dev-box | **SPLIT** (2 seams — only 19 over) | 1003206 |

**One rule above all:** these are structural moves, not rewrites. Every split preserves behaviour, the module boundary (a module reaches core only via `src/module-api.js`, never a core internal or another module), and the public port surface. A split that changes a contract is out of scope — file it separately.

---

## Per-file seams

### 1. `db.js` → 7 seams (task 1003204) — highest coupling
The lifecycle data layer, ~97 functions sharing one `withTx`/`seams` doorway. Split by domain, keeping the **state machine whole** and the **transaction-participant seams intact** (the claim/confirm/ship/grade/credit functions open the tx and call `resolveOptional('reward'|'onboarding')` inside it — ADR 0093 §2; do not sever a function from its tx). Candidate modules (rough sizes):
- `db-rank-authz.js` (~450) — rank/permission/graduation: `claimPermissionsFor`, `rankAllowsTask`, `xenosClaimAllowed`, `_applyRankChangeTx`, `maybeAutoGraduateToThetes`, `syncGovernanceRankRole`, the grade-count SQL fragments.
- `db-versions.js` (~150) — `listVersions`, `getVersion`, `versionProgress`, `createVersion`.
- `db-goals.js` (~700) — goals + membership + criteria links + scope/visibility/successor/transfer.
- `db-claims.js` (~600) — the claim refusal ladder, `claimTask`, `resolveClaim`, active-claims, release requests.
- `db-tasks.js` (~700) — task CRUD, `createTask`, rescope, classifier hooks, dead-dep helpers.
- `db-ship.js` (~700) — `confirmTask`/`shipTask`/`applyGrade` + criterion auto-close cascade (the tx-participant core).
- `db-analytics.js` (~500) — estimation drift, grade trend, AI-dev curve, work-tracking reads; plus `tallyPeerVotes` + merge-lease (or a small `db-peer-votes.js`/`db-merge-lease.js`).
- `db.js` remains a thin re-export/facade so `lifecycle.js` and existing requires keep working unchanged.
**Risk: high.** Land behind the full lifecycle test suite (`coreB-carve-proof.sh` + the DB-integration tests named in the module CLAUDE.md); the boundary-forced duplications (`sealSessionLog`, `_applyRankChangeTx`, `gradePassCount`) must stay in lockstep with core.

### 2. `ship.js` → 7 seams (task 1003205)
Phases are the seams (its own doc says "search by phase keyword"):
- `ship-surprise.js` — surprise/learning capture.
- `ship-memory-sync.js` — memory sync-on-ship.
- `ship-session-upload.js` — session digest + transcript upload + the ADR-0022 scrubber.
- `ship-git.js` — git/shell/gh helpers, `buildMergeArgv`, `sanitizeGitHubRefs`.
- `ship-deploy-target.js` — deploy-mode/target resolution.
- `ship-grade.js` — the subagent-grader runner + baseline computation + grade formatting.
- `ship-land.js` — merge/land/deploy orchestration + the ship card.
- `ship.js` remains argv parsing + the phase orchestration (`main`). **Risk: medium** — pure CLI, no server tests, but it is the release path; smoke-test a real ship after.

### 3. `builders.js` → 3 seams (task 1003206) — client JS
IIFE attaching to `window.OTB`; extract to sibling `<script>` files that attach to the same namespace (no bundler): `ranks.js` (rank weight/normalize/badge — already mirrored per the source), `hall-widgets.js` (`ensureStandingGroups`/`widgetHost`/`mountHallWidgets`), leaving roster/table rendering in `builders.js`. **Risk: medium** (load-order in the page HTML).

### 4. `provision.js` → 4 seams (task 1003206)
`provision-db.js` (create/migrate/seed cmds), `provision-repo.js` (scaffold + repo auth + deploy keys + core-pin refresh), `provision-systemd.js` (service/backup/timer unit templates), `provision-env.js` (web.env body + federation). Keep `provision.js` as the intent-runner + `CONFIG`. **Risk: medium** (control-plane ops; unit-template tests exist).

### 5. `grader.js` → 5 seams (task 1003206)
`grader-prepass.js` (permission-path + route-rank deterministic pre-passes), `grader-model.js` (model selection), `grader-prompt.js` (prompt + context bundle), `grader-score.js` (validators, server-side guards, aggregation), `grader-subagent.js` (spawn/one-shot/cached). Keep `grader.js` as `gradeSubagent`/`gradeDeterministic` orchestration + the port surface. **Risk: medium.**

### 6. `fitness.js` → checks-as-modules (task 1003206) — cleanest
Already the pattern: `fitness-ratchets.js` and `control-manifest.js` are separate check modules registered here. Extend it — move check clusters to `fitness-checks-boundary.js`, `-docs.js`, `-migrations.js`, `-identity.js`; keep `fitness.js` as the `CHECKS` registry + runner. Each check is independent → low coupling. **Risk: low.**

### 7. `goals-page.js` → extend the existing carve (task 1003206)
Carve already begun (`goals-lib.js` per task 1003135, shared `hall-kit.js`). Finish it: move the remaining presentational helpers (`goalRenderFacts`, `goalRowHtml`, `goalCardHtml`, `statusBadge`, `goalStampHtml`) into `goals-lib.js`; keep the page as fetch/filter/render control flow. **Risk: low.**

### 8. `seed-v3-tasks.js` → DELETE, else allowlist (task 1003207)
81 task literals + 1 idempotent seeder function — pure historical data for GDS-V3, which has **shipped**. First choice: **delete** it (verify nothing requires it — it's an idempotent one-shot; `seed-gds-v4-tasks.js` is the sibling and also a candidate). If a reason to keep it surfaces, add a narrow, documented exclusion to `EXCLUDE_RE` for that specific file (not a blanket `seed-*.js` rule, which could hide a genuinely oversized seeder with logic). **Risk: low.**

### 9. `routes/tasks.js` → sub-routers (task 1003206)
~29 routes across clear resources. Split into `routes/tasks/{crud,dependencies,criteria,lifecycle,peer-votes,publish,overrides}.js`, each a function that registers its handlers on the shared router; `tasks.js` becomes the index that calls them. The two heavyweight handlers — `POST /tasks` (~220 lines) and `PATCH /tasks/:id` (~290 lines) — carry most of the bulk; their validation blocks can move to `task-write-validators.js`. **Risk: medium** (route tests exist; keep paths identical).

### 10. `auth.js` → 4 seams (task 1003206) — HIGHEST RISK (kernel/protected)
`auth-github.js` (OAuth creds/scopes, web + device flow, `fetchGithubUser`), `auth-idp.js` (federation hub assertion + logout token), `auth-discord.js` (Discord OAuth + guild membership), `auth-admission.js` (membership/admission/first-admin/rank-role sync). Keep `auth.js` as session-token mgmt + `extractTokens` + the middleware surface. **Risk: highest** — it is the identity path and a protected kernel file; land it last, behind the auth tests, with extra review. Sub-Metic builders may not touch it (behavioral rule).

### 11. `routes/goals.js` → extend the existing carve (task 1003206)
Already extracting (`goalSuggest.*`, `goalEdits.*` handlers imported). Continue: move the membership-request / invitation / members / conflicts / archive-reopen-scope-transfer handlers into `goal-*` helper modules the router wires up. **Risk: low–medium.**

### 12. `box.js` → 2 seams (task 1003206) — only 19 lines over
12 `cmd*` subcommands. Extract the two largest (`cmdProvision` ~300, `cmdReconcile*`) into `box-commands.js`; `box.js` stays the dispatcher. Trivial to get under 1,500. **Risk: low.**

---

## Ratchet exclusion-list update (for task 1003207)

- **Do not** broaden `EXCLUDE_RE` to hide real code. The only content-based exclusion warranted is a **single-file** exception for `seed-v3-tasks.js` *if* it is kept rather than deleted (prefer deletion).
- `redoc.standalone.js` / `public-docs/` / `*.min.js` / `vendor/` stay excluded (correct — vendored/generated).
- As each file lands under 1,500, **lower** `oversized_file_count` and `excess_lines_total` in one PR with the extraction, so CI proves the drop.

## Suggested sequencing (low-risk first, prove the loop)

1. **box.js, fitness.js, goals-page.js, routes/goals.js** — low risk, existing carve patterns → immediate baseline drops, validates the ratchet-lowering flow.
2. **seed-v3-tasks.js delete** — removes the largest single count with the least code risk.
3. **routes/tasks.js, provision.js, grader.js, builders.js** — medium risk, module-local.
4. **ship.js (1003205)** — medium risk, release path; smoke a real ship after.
5. **db.js (1003204)** and **auth.js** — highest risk, land last, each behind its full test suite and (for auth.js) extra review.

Every step is independently shippable and lowers the baseline — there is no big-bang cutover.
