# The builders' hall, direction v2: five archetypes of the chrome world (task 1003302)

**Date:** 2026-08-30 · **Goal:** 1000081 (Builders' hall in the world) · **Criterion:** `hall-archetypes-approved` ·
**World:** the chrome world, recorded in `DESIGN.md` at the repo root by task 1003298 ([ADR 0196](../adr/0196-chrome-world-token-contract-and-the-landing-sheets.md), [ADR 0204](../adr/0204-the-apex-is-dark-only.md)).

This document records the hall's composition round: five archetype pages, three versions each, built as real
HTML against the world the apex already lives in. It is the round that answers *how the hall should look*.
**It supersedes the LOOK described in [`vanilla-hall-ui-redesign-scope.md`](vanilla-hall-ui-redesign-scope.md)
and nothing else.** That document's information architecture, its component taxonomy and its sizing system are
givens this round did not reopen: the sidebar groups and their order, every href, every page gate, the topbar's
identity and sign-out affordances, the SSE behaviour and the hall-widget injection slots are all exactly as they
ship. This round changes how the hall looks, never where things are. **No build file was touched.**

---

## 1. What this round had to do

The hall is 27 pages and about 29,000 lines of vanilla HTML, CSS and JS, and it speaks a different visual
language from the front door: indigo `#4f63e7` on Inter, against the apex's salmon on Manrope. A builder who
walks from cloudbongos.com into their hall changes worlds mid-session. The goal is one world across the whole
frontend; this round is the half that decides what the hall's half of it looks like, before task 1003303 builds
the shell and tasks 1003304 to 1003308 re-skin the page families.

Five pages carry the whole hall, and every other page inherits from one of them:

| Archetype | Stands in for |
|---|---|
| **board** (`index.html` + `work.html`) | the home view and the work board: the densest surface in the hall |
| **task** (`task.html`) | one record read end to end; `idea` and `ideas` inherit |
| **reading** (`primer.html`) | long markdown with a table of contents; Ranks, Economy, Diagrams, Repo Atlas and Modules inherit |
| **goals** (`goals.html`) | the governance lists; Government, Modules, Watch, Gate, Sessions, People and the rest inherit |
| **settings** (`settings.html` + `profile.html`) | every form, switch, secret field and status line in the hall |

---

## 2. Method, as run

1. **The world was read first, not invented.** `DESIGN.md`, the two owner hall references from 2026-08-26
   (`hall-1-light-mono-label-dashboard.webp`, a light dashboard with mono uppercase labels over big-number stat
   tiles and a sidebar with a pinned identity card; `hall-2-dark-glass-dashboard-forest.webp`, dark glass over a
   photographic backdrop with a 64px icon rail), and the four candidate hall boards round 1 left in
   `mocks/world/*/hall.html`. The references contributed their **stat-tile, greeting and sidebar rhythm**; the
   palette is `DESIGN.md`'s throughout.
2. **One shared token tier was authored before any page**, at
   [`mocks/hall/_tokens.css`](mocks/hall/_tokens.css), following `DESIGN.md` §Reuse literally. All fifteen mocks
   link it, so a steer on the palette moves all fifteen at once, and it is what task 1003303 should adopt as
   `style.css`'s token block.
3. **Five builders ran in parallel**, one per archetype, against one written brief that froze the shell markup,
   the sidebar IA and the seven states, and supplied real ledger data so nothing was invented that could have
   been looked up.
4. **Every mock was gated mechanically** with `node modules/ui-design/kit/check-mock.js` (the platform's token
   discipline and state contract, plus the taste bans read from `DESIGN.md`'s "Don't" section), then rendered
   through the kit's stub at 1440 and 390 in both modes and looked at.
5. **A consistency pass reconciled the five** before the owner saw anything (§3.1).

Real figures throughout, read from the live public API on 2026-08-30: BONGOS-V1 at 1,176 of 1,612 tasks and 75
percent; CB-V1 at 58 of 155; the leaderboard (example-owner 44,562 credits, Percy Jackson 14,441, IAMMASTERQUA 3,316,
scootermack 2,646); total spend $49,708.47 against 71,040 credits of value; the five real ready tasks and the
real recently-shipped rows.

---

## 3. The five archetypes and their three versions

Every archetype builds the **same three theses**, so the owner can pick one language for the whole hall or mix
per archetype. They are three answers to one question: **how much container does an application surface get, and
does the hall get a ground?**

| # | Thesis | What it does | Signature | Honest risk |
|---|---|---|---|---|
| **v1** | **the ledger** | No panels anywhere. The page is hairline rules and rows straight on the page ground; figures sit bare under mono labels; the current nav item takes a 2px accent hairline on its left edge, the lifecycle rail's lit-step grammar. | Density. It is the closest reading of `DESIGN.md`'s "hairlines, not containers, no cards". | 27 pages of pure hairline can read undifferentiated. A claimable task loses the card affordance that makes it feel like an object you can pick up, and on a form the fields, notes and status lines can read as one column of grey. |
| **v2** | **the sheet** | Content sits on `bg-card` sheets with a `rule-soft` hairline edge and small corners, on the `bg` ground. **No shadow anywhere**: a sheet is separated by tone and a hairline, never by lift. Mono uppercase labels over big tabular figures, hall-1's rhythm exactly. | The owner's light reference, brought into the chrome world. | It bends `DESIGN.md`'s no-cards rule. Defensible for an application rather than a poster, but it is a real deviation, and on a long page the sheet edges add up to a lot of drawn structure. |
| **v3** | **the glass hall** | One rendered plate under the whole shell in dark beneath `--plate-veil`; sidebar and topbar as glass over it; content on `bg-card` at the full radius. The sidebar is the 64px rail **at every width**, expanding only on hover or focus. | The owner's dark reference. The loosest air of the three. | A photographic ground under 27 dense pages costs legibility and adds a per-page cost the other two do not have. The rail trades discoverability for calm: a newcomer sees unlabelled icons until they hover. **The hall's plate is not shot yet**, so what is on the sheet today is the honest fallback, the flat void. |

Two archetype-level findings worth the owner's eye:

- **The lifecycle rail earns its place** (task archetype). v1 and v3 carry it; **v2 deliberately does not**, so the
  round contains a real A/B. A status pill says *what* state a task is in; the rail says where in the pipeline it
  sits and what happens next, and on a shipped task the lit `credit` beat is what answers "did I get paid". It is
  also the only component on that page that spends the accent legitimately.
- **Rows beat cards for goals** (goals archetype). v1 shows rows, v2 shows cards, v3 argues for rows on the page.
  A goal carries seven facts plus a four-bucket roll-up; a 292px card drops two of them and still wraps the name.
  Task 1003307's real title is long enough to prove it, and it is on the sheet unshortened for exactly that reason.

### 3.1 What the review found, and what was fixed before the owner saw the sheet

Three findings are **the world's, not the mocks'**, and task 1003303 inherits all three. Each is recorded with its
evidence in `_tokens.css`.

1. **The hall's status colours fail AA on the chrome world's paper.** `style.css` tuned them against the hall's
   retired ground (`--bg #f5f6f8`, `--bg-card #ffffff`). The world's paper is darker (`--bg #edecee`), and measured
   against it the shipped values fail: `ok` 4.27:1, `warn` 4.13:1, `info` (raw `--sea`) 3.85:1 and 4.36:1, and
   4.19:1 on the dark card. Re-solved so all eight pairs clear 4.5:1 on **both** grounds in **both** modes with
   about nine percent of headroom, the margin `DESIGN.md` sets for its own thinnest pair: light `ok #187444`,
   `warn #895c00`, `danger #b42318` unchanged, `info` a `color-mix` of the contract's `--sea` at 86% over black;
   dark keeps `#4ade80` / `#fbbf24` / `#f87171` with `info` at 91% over white. **The build must carry these
   values, not `style.css`'s.**
2. **`--bg-deep` is invisible in dark.** `DESIGN.md` says "in dark, deep collapses back to black", so `--bg-deep`
   and `--bg` are the same value and a skeleton painted with it cannot be seen. The landing never noticed because
   it has no loading states; every hall page has them. Promoted to one shared token,
   `--skeleton: color-mix(in srgb, var(--ink) 10%, var(--bg-card))`, which reads in both modes and needs no twin.
3. **`ch` is not a character.** A `ch` is the width of the font's zero glyph, and Manrope's zero is much wider than
   its average lowercase, so `58ch` renders about 72 characters. `DESIGN.md` asks for "max 56 to 62ch"; read as
   CSS `ch` that is roughly 70 to 77 characters. The live primer is the worked example: `primer.css:138` sets
   `max-width: 72ch` under a comment reading "Roughly 60-72ch at 17px body", and it renders about **90
   characters**, the biggest reading defect on the page today. Promoted as `--measure: 48ch`, measured rather than
   calculated, which renders about 60 characters at the hall's body size.

Five things were reconciled **between** the archetypes, since the builders ran in parallel and diverged:

- **Nav links are lowercase**, per `DESIGN.md`'s Lowercase Display Rule, which names nav links explicitly. Three of
  five had them capitalised. The DOM text stays `Home`, so `tests/hall_nav.mjs` is unaffected by the change.
- **`aria-controls` on the collapsible group heads.** The shell markup as frozen carries `aria-expanded` with no
  target, which is an accessibility gap and fails the disclosure rule. Four archetypes added one under three
  different id schemes; `reading` added none and passed the gate only because its own table-of-contents disclosure
  satisfied the "at least one" rule. All five now point at `nav-items-<group>`. **This is a real addition the build
  inherits, not a mock artefact.**
- **The goal-detail data was made true.** An earlier pass inferred the titles of tasks 1003303 to 1003309 and
  showed one as shipped. Nothing in goal 1000081 has shipped; all eight rows now carry their real Bongos titles and
  statuses, and the Completed pane renders its honest empty state, which also gives the round an empty case inside
  an otherwise populated page.
- **An invented task id collided with a real one** on goal 1000064's card. All seven of that goal's tasks are
  backlog, so the card now says "Nothing claimable yet", which is both true and collision-free.
- **`--skeleton` and `--measure`** were each solved privately by every archetype before being promoted to the tier.

**A fixture rule the round had to learn, flagged by the grader's security worker.** The settings mocks compose the
CLI re-issue flow, which means they have to show a token in a `<pre>`, and they were seeded with a realistic
64-character hex string beside the real paste command, plus a hosted machine's actual `ssh <account>@<ip>` line.
Neither belonged in a committed artifact: the hex was invented (verified against this machine's real session files,
so nothing needed rotating) but a credential-shaped literal is treated as a secret regardless of intent and would
trip every future scanner, and the SSH host and account are real internal topology that no public API justifies.
Both were made unmistakable placeholders (the SSH line has since left the mocks with the retired dev-box settings group). **The rule for any mock that composes a secret or a connection string: the
fixture must be self-evidently fake at a glance while keeping the real string's LENGTH and SHAPE**, because the
length is the composition problem being solved. "Real data, invent nothing" governs ledger figures; it does not
extend to credentials or infrastructure.

---

## 4. Review

**The pick page:** <https://claude.ai/code/artifact/<redacted>> — self-contained, all
fifteen first-viewport plates embedded, click any screen for full size. It carries the five decisions, the three
theses, each version's cost, and the round's three findings. **If no pick lands there, the build takes v2 "the
sheet" for all five archetypes** (§5).

**The mocks themselves,** for the six states the plates cannot show (loading, empty, error, the 64px rail, the
mobile drawer, focus rings) and for light mode: serve the repo and open the contact sheet, which flips all fifteen
to the same state at once.

```
node modules/ui-design/kit/serve.js
http://127.0.0.1:3412/docs/design/mocks/hall/hall-sheet.html
```

Serving is not optional for the sheet: a page opened over `file://` cannot render the mocks inside it, which is
why the earlier apex rounds published artifacts instead (session log 2026-08-27). Opening a single mock straight
off disk works fine — [`mocks/hall/hall-sheet.html`](mocks/hall/hall-sheet.html) is the only file that needs the
server. Dark is the default; the toggle flips every tile to light.

Every mock carries the same seven states on `?state=`: `populated`, `loading` (skeletons in the shape of the final
content, not grey blobs), `empty`, `error`, `rail` (the sidebar at 64px), `drawer` (the mobile drawer open) and
`focus` (keyboard rings on real controls). Each one's head comment states its thesis, its composition, what light
does differently, and its honest risk.

---

## 5. The decisions this round asks of the owner

1. **One version per archetype.** Steers are allowed and a mix is allowed. The likeliest good answer is one
   language for all five; the likeliest good mix is the denser language for the working surfaces and a looser one
   for the reading room.
2. **Does the hall get containers at all?** v1 says no and follows the world's letter; v2 and v3 say yes. This is
   the single biggest thing the build inherits.
3. **Does the hall get its own rendered ground?** Only v3 spends one. `DESIGN.md` already reserves the hall's
   forest plate as the hall's own; this round is where that becomes real or is dropped. Note the plate is not shot
   yet, so v3 is being judged on its geometry, not its atmosphere.
4. **Two regions on the task page do not exist today.** This round's brief asked for a grade panel and a session
   log; grades live on Standing and session logs on `/sessions`. The task mocks show both marked `proposed`, with
   a dashed edge and a mono eyebrow. Say whether the build adds them or leaves them where they are.
5. **The light mode.** The apex went dark only ([ADR 0204](../adr/0204-the-apex-is-dark-only.md)), so the hall is now
   the only surface with a real light mode. Confirm it stays, since it doubles the build's contrast work.

**If no pick lands, the build takes v2 "the sheet" for all five archetypes**, as the version that reads the
owner's own two templates most directly and costs the least legibility on a dense 27-page surface.

---

## 6. The owner's pick

**2026-08-30: v3 "the glass hall", for all five archetypes.** Taken in session with the fifteen mocks open. Three
steers came with it, and together they change what v3 means for the build. This section overrides the rest of this
record and `DESIGN.md` where they conflict.

**What the pick settles.** The hall is built in v3's geometry: the sidebar is the **64px rail at every width**,
expanding only on hover or focus-within; the topbar and sidebar are glass; content sits on `bg-card` panels at the
full `--radius` with tone doing the separation and no hairline edge; the air is the loosest of the three. Section
headings are sentence-case Manrope rather than mono labels, which is v3's own divergence and is picked with it.

**The plate is deferred, and that is the load-bearing consequence.** Decision 3 was answered *"decide after the
shell lands"*, so **task 1003303 must not wait on an asset and must not block on one.** It builds v3 with
`--plate: none` and `--plate-veil: none`, which is precisely what v3's own light mode already does and what all
five mocks show today, since the hall's plate was never shot. The shell therefore has to be a complete composition
with no plate at all, judged on the real thing afterwards. Keep `--plate`, `--plate-veil` and `--plate-blend` in
the token tier as the declared seam so adding one later is a token change and not a re-layout. Whether the hall
ever gets a ground is re-opened once the shell is live, on the built surface rather than on a mock with a
placeholder void.

**Light mode stays** (decision 5). The hall keeps its `hall-theme` switch and full light parity, test-enforced in
both modes. This is now the only surface on the platform with a real light mode, and every re-skin task carries the
doubled contrast work; the criterion `hall-shell-in-world` already says "dark-first with light parity", and that
stands.

**The grade panel and the session log are approved for the task page** (decision 4, *"add both"*). They are
**net-new surface, not a re-skin**, so they do not ride task 1003305: grades live on Standing and session logs on
`/sessions` today, and moving or mirroring them is product work with its own API questions (the task API surfaces
only the most recent claim, and there is no grade or session-log shape on the task payload). Filed as its own task
under this goal, and the `proposed` eyebrow and dashed edge come off the mocks when it ships.

**What the unpicked two leave behind, regardless.** v2's stat-tile grid is the reference for any figure row the
hall renders; v1's bare-ledger treatment is the reference for the dense tables inside v3's panels, since v3's
panels hold rows and those rows are v1's; and the round's three world findings (§3.1) bind whichever version had
won.

---

## 7. What the build inherits

Beyond §3.1's three world findings and the five reconciliations, the round turned up defects in the shipped hall
that are **structural fixes, not paint**:

- **The hall fails two platform floors today.** `modules/hall-ui/public/ranks.states.json` already admits it: the
  hall predates the `controls-24px` and `one-header-main-h1` floors. `goals.html` has zero `<h1>`, no skip link,
  and a `<header>` that is an empty shell mount; `settings.html` and `profile.html` open on a paragraph with only
  `<h2>`s below. Every mock in this round fixes it, so the re-skin tasks should carry the fix.
- **Copy that fails the taste bans on port**, and therefore needs a copy change rather than a style port: the work
  board's copy glyph is an emoji and its touches chip uses a pen glyph; the pager reads `Showing {start}–{end} of
  {total}` with an en dash; the Home heading is literally `"Next up — ready to claim"`; the goals conflicts lede
  contains an em dash. The copy half belongs to `copy-desk`, so these route there rather than being rewritten in a
  style pass.
- **`md-reader.js` handles blockquotes and `primer.js` does not.** The reading mocks compose only the flat subset
  `md-reader.js` already emits, plus slugged h2 ids it already provides, which makes unifying the two parsers a
  natural part of task 1003306 rather than a separate job. The only parser-side work left is the diagram injection
  after a named h2.
- **A fixed sidebar silently eats the content column.** `.app` is a two-column grid; the moment the sidebar goes
  `position: fixed` it leaves the grid flow and the content falls into the sidebar's track. Any page that pins the
  rail or opens the drawer above 860px has this bug. A faded rail label also still occupies width: labels have to
  leave the layout, not just drop to `opacity: 0`, or a wide one pushes its own icon out of the 64px strip.
- **The soft acknowledge gate should use `aria-disabled`, not `disabled`.** A real `disabled` button leaves the tab
  order, so a keyboard reader can never land on it and never hears why it is locked. `primer.js` uses a hard
  `disabled` today.
- **A credential is rendered through an `innerHTML` string template** (`settings.js:979`). It is escaped, so it is
  not a live vulnerability, and the hall has 302 `innerHTML` sites because that is `hall-kit.js`'s documented
  contract, so this is deliberately *not* a call to rewrite the hall. Filed narrowly as idea 1000884: build the one
  node that renders a token with `createElement` and `textContent`.

Constraints the build must not break, all test-pinned: the sidebar group order and every item id
(`tests/hall_nav.mjs`); the palette's static shape (`hall_palette`); the inline-`<style>` ratchets, the frozen hash
namespaces, the first `:root` block's ten named vars, the deleted classes, and the exact 640px and 760px overflow
breakpoints (`hall_audit`); and the public pages `/`, `/ranks`, `/drachmae`, `/profile`, `/not-ready`, which render
for a signed-out stranger and need honest signed-out states (`hall_page_gate_map`).

---

## 8. Copy strings for the copy desk

| Where | String | Note |
|---|---|---|
| Work board, Home | `Next up, ready to claim` | replaces `Next up — ready to claim`; the em dash fails the taste ban |
| Work board, pager | `Showing 1 to 5 of 5` | replaces the en-dashed range |
| Goals, conflicts lede | `Open tasks whose declared files overlap: sequence these rather than running them together.` | replaces the em-dashed original |
| Task page, no action available | `This task has shipped and its credits have landed. Neither Ship nor Confirm is available.` | the honest note where a lifecycle button would be |
| Goals, nothing claimable | `Nothing claimable yet` | replaces a "claim next" door on a goal whose tasks are all backlog |
| Goals, empty Completed pane | `Nothing has shipped on this goal yet.` | |
| Profile, signed out | `Works, goals and idea trails are visible to signed-in builders. Sign in to read this builder's activity. Everything above stays public.` | names the permission boundary so a blank does not read as an empty record |

---

## 9. What carries forward

- The token tier at [`mocks/hall/_tokens.css`](mocks/hall/_tokens.css) is the round's most reusable artefact and is
  what task 1003303 should adopt, including the re-measured status vocabulary, `--skeleton` and `--measure`.
- The three theses are named so later rounds can refer to them: **the ledger**, **the sheet**, **the glass hall**.
- The status ledger's own round (goal 1000082, task 1003310) faces the same container question on a smaller
  surface, and should start from whichever thesis wins here rather than re-running the argument.
- The unpicked versions stay on disk as built and verified. What they leave behind regardless of the pick: the
  lifecycle rail on the task page, rows over cards for goals, the CLI re-issue ladder showing all three moments at
  once, and the signed-out profile's honest permission line.

---

*Round run under task 1003302, goal 1000081. Mocks: `docs/design/mocks/hall/<archetype>/v{1,2,3}.html`. Contact
sheet: `docs/design/mocks/hall/hall-sheet.html`. Token tier: `docs/design/mocks/hall/_tokens.css`. World:
`DESIGN.md`. IA, untouched: `docs/design/vanilla-hall-ui-redesign-scope.md` and `tests/hall_nav.mjs`. Prior rounds:
`docs/design/apex-pass-2-direction.md` (the world pick) and `docs/design/landing-page-direction-v2.md` (the
landing's composition pick).*
