# Projects Surfaces — Redesign Direction

> **Task 1002695** (goal 1000059 "Projects surface revamp", R06) · direction decided with the owner 2026-08-12.
> Feeds **task 1002696** (R07 — the implementation carrier) and the re-walk (task 1002697, with task 1002715 folded in).
> Findings feed: the QA/UAT checkpoint walk (task 1002702, [session log](../session-logs/<redacted>.md)) and the truthfulness cluster (task 1002720, findings F15–F23).

Scope: the three owner-facing project surfaces — the **create wizard** (`public-landing/create.html`), the **done panel** (`panel-done` in the same file), and the **manage view** (`public-landing/projects.html`, served at `/projects`). **All three live on the apex host — `cloudbongos.com` — and stay there.** Project creation and management are not builders-hall surfaces; the hall (builders subdomain) may link *out* to them, nothing more. The gate catalog stays with goal 1000031; the hall's federation my-projects page is a different surface and is out of scope.

---

## 0. Starting point — what exists today

- The flows **work end-to-end** (verified live on both venues by the checkpoint walk): create → address → GitHub sign-in → manage → teardown. What's broken is the *trust surface*, not the plumbing.
- Both pages are self-contained orphans: one inline `<style>` each, hand-rolled `:root`, no shared components, ~half the palette hardcoded past the branding contract's reach. The repo holds three unrelated design systems (sunrise landing, indigo hall kit, marble status page); these surfaces belong to the sunrise family but share no code with anything.
- Lifecycle truth lives in `provisioning_instances.status` — six runner-written states: `requested · provisioning · active · tearing_down · torn_down · error`. The UI maps them to chips (`queued / standing up / live / snagged / tearing down / torn down`).
- The three failure themes the walk proved (details in §§2–5): the platform asserts states it never verified, in both directions; the copy speaks operator; and the first-run paths (self-host, first admin, newborn instance) were never designed.

## 1. Decisions (owner, 2026-08-12)

1. **Truth model: heartbeat + honest chips.** The platform re-checks liveness on a background cadence and the UI shows verification recency. "Live" becomes a verified claim.
2. **Visual system: sunrise, tokenized — refined through design iterations.** Keep the sunrise landing brand; extract a shared token + component layer; the final look is nailed down through owner-review loops during implementation (§10), not invented in this doc.
   > **Amended in Loop 1 (owner, 2026-08-12, during task 1002696):** the iteration loops did their job and moved the look — these surfaces go **all-in on the space backdrop** (the gate's deep-space sky, stars, project orbs), with a **light/dark mode** governing the content cards (light = cream cards on space, dark = deep-navy cards; OS preference honored, manual toggle persisted). The token layer ships as `public-landing/assets/cosmos.css`. Everything else in this doc (truth model, vocabulary, copy rules, flows) is unchanged.
3. **First-run: designed now, delivered split.** This direction defines the shape-aware surfaces; task 1002696 implements the surface parts, and runner/infra hardening stays in its parallel lane (tasks 1002717–1002722).
4. **Deliverable: this direction doc.** Owner sign-off on this doc is the task's done condition.

Also folded in, decided earlier the same day: **task 1002704 — auto-assign `<slug>.cloudbongos.com` at creation, opt-out.** The address step collapses from a form into a confirmation (§6).

## 2. Principles

1. **The UI only asserts what the platform verified — and says when.** Every liveness claim carries recency. Unverified is stated as unverified, never dressed as fact.
2. **Copy speaks owner, not operator.** No raw tool output on a card. No wall-clock promises. No process jargon. What happened, what it means, what (if anything) the owner can do.
3. **Deliberate end-states are calm.** A teardown the owner asked for is not an error and is never styled as one.
4. **Every flow owns its vocabulary.** Stage labels are never reused across flows — a card being torn down must not render a stage named "Live".
5. **Surfaces are honest about hosting shape.** A step renders only if somebody real will actually perform it on this instance's shape. Dead copy is a broken promise.
6. **One themeable token layer.** Everything an instance can't re-theme through the branding contract is a bug.

## 3. Truth model — the verification overlay

Verification is an **overlay on lifecycle, not a new lifecycle state**. The runner's six statuses stay untouched; verification adds recorded observations about whether the instance actually answers.

**Server (small piece, ships inside task 1002696):**
- `provisioning_instances` gains `last_verified_at` (timestamptz) and `last_verified_up` (boolean); both nullable.
- A heartbeat sweep in the provisioning module (in-process interval on the control plane, ~5-minute cadence with jitter) probes every `active` instance: `GET https://<domain>/healthz` when addressed, the recorded local port otherwise, short timeout. It writes the two columns and never flips `status`.
- `GET /provisioning/instances` and `/:id` expose both fields.

**Display contract (chips on both surfaces):**

| Condition | Chip |
|---|---|
| `active`, last probe up, fresh (≤ 2 cadences) | **live** · checked 2m ago (green) |
| `active`, last probe failed | **unreachable** · since 14:02 (amber/red) |
| `active`, never probed or stale probe | **live?** · last seen 3h ago (amber) |

- The manage view refreshes settled cards on a slow interval (~60s) and on tab focus, so the overlay stays current while someone is looking. (Today an `active` card never polls again and can never self-correct.)
- Provision-time gating (walk finding F15 — the runner declared `active` after a failed probe) is **task 1002720's** server work; this direction sets its display contract: the runner either gates `active` on a passing probe or writes `last_verified_up=false` that the UI must render.
- The inverse direction (F23 — a *successful* GitHub-App setup recorded as failed after a restart race, then a single-use manifest code retried forever) is also task 1002720's; the display contract here is that the done panel's sign-in step **waits and re-verifies** before declaring failure, and never claims failure for a setup it hasn't conclusively observed failing.
- Address attach (F16): "answering at `<domain>`" is claimed only after a probe **against the domain** succeeds. If DNS wiring was skipped (no hook), the card says exactly what's left: "point your domain's A record at `<ip>` — we'll confirm once it answers."

## 4. Vocabulary — states, chips, strips

**Chips** (one set, both surfaces): `queued · standing up · live (·recency) · live? · unreachable · snagged · tearing down · torn down`. `torn down` renders neutral (faint ink, no color), never red.

**Progress strips are per-flow** — distinct labels, chosen by the open intent on the card (F22), not by lifecycle status alone:

| Flow | Stages |
|---|---|
| Standup | Request filed → Standing it up → Live |
| Teardown | Teardown queued → Winding down → Torn down |
| Revive | Revive queued → Standing it up → Back live |
| Address | Address queued → Wiring the address → Answering at `<domain>` |

- A torn-down card with a pending revive intent shows the **revive strip** — never "you can start another project below" (F22's actively-wrong guidance).
- A strip's final stage lights only when the truth model confirms it (probe answered), not when the runner finishes its script.

## 5. Copy rules — owner voice

1. **Errors are a plain sentence + a disclosure.** Map the failed runner step to an owner-facing category — "We couldn't reach the project's repository," "The server didn't come up," "The address didn't wire up." The raw `error_note` (git stderr, ssh noise) moves into a `<details>` labeled "Technical details" — present for whoever helps, never the headline.
2. **No wall-clock promises.** Kill "usually under a minute" and friends. Describe what's happening and what happens next; never how long.
3. **Retry honesty (F19).** Intents retire after 3 attempts and nothing auto-retries. The snagged card says so — "Stopped after 3 tries" — and gains an owner-facing **Try again** action that re-enqueues (the enqueue API already accepts re-provisioning; wire it). "The platform keeps retrying" copy dies.
4. **Teardown truth (F17) — decided: the database is not dropped.** (Owner, 2026-08-12: no database drop unless we find otherwise — retention is policy, not an accident.) The confirm and the torn-down card say so plainly: the server goes away, the repository stays the owner's, the database is kept and recoverable by the operator. Copy always states exactly what the runner does.
5. **Repo visibility is stated, always (task 1002721).** Every path that creates or adopts a repo says whether it will be public or private, before the owner commits — GitHub's own UI must never be the first place visibility appears. Private repos deploy via a per-project read-only deploy key the platform runner wires at standup (ADR 0176, task 1002735) — a **control-plane feature**: on the self-host venue there is no platform runner, so the `repo-auth` plan step is absent by design and repository access is the owner's own doing (they clone with their own credentials on their own box). A self-host surface must say that plainly rather than imply the platform will wire it.
6. **Newborn welcome (idea 1000701).** A freshly-provisioned instance greets its founding owner with a welcome moment, and account nags (billing, art-key coverage) are suppressed until first-run completes.

## 6. Surface · Create wizard

Beats stay **Name · Home · Address · Create** — the flow shape survives; the address beat changes meaning and everything gets the copy + token pass.

- **Gate panel:** unchanged in flow (GitHub sign-in, AGPL trust link); copy pass only.
- **Name panel:** unchanged in flow; the live slug hint becomes the seed of the address confirmation.
- **Home panel:** the three-way progressive branch (picker / manual / fresh) survives; the manual path and the fresh path both state repo visibility explicitly (§5.5).
- **Address panel — collapses to a confirmation (task 1002704):** headline shows the assigned address — "`<slug>.cloudbongos.com` — yours from the moment it stands up." The slug stays editable inline (revalidating availability). A disclosure "Use a domain I own" holds the custom-domain input. Starting without an address remains possible only inside that disclosure, with the honest consequence stated: "sign-in on your instance can't be set up until it has an address."
- **Review panel:** the Domain row becomes the Address row and always shows the resolved address.

## 7. Surface · Done panel

- **Keep** the canonical-plan rendering (task 1002694's work: checklist from `GET /provisioning/onboard-plan`, manifest-driven sign-in leg, live tick states).
- **Shape-awareness:** the plan endpoint tags each step with the hosting shapes it applies to; the panel renders only steps real for this instance's shape. On shapes with no control-plane runner, `auto` steps either disappear or convert to explicit owner-instructions — no promise a runner will do what no runner exists to do.
- **The progress strip obeys the truth model:** "Live" lights on a verified answer, not on script completion; a lost verification race shows "confirming…" rather than a false ✖ (F23 display contract).
- **A door out:** the panel ends with a link to `/projects` — "watch it any time from Your projects."

## 8. Surface · /projects (manage view)

- **Card anatomy stays** (name + chip → meta → address → strip → message → actions) with the §3 chip overlay, §4 per-flow strips, and §5 message rules.
- **New actions:**
  - **Bring it back** on `torn_down` cards — the enqueue API already revives a torn-down slug; the walk had to do it raw. Button + confirm, revive strip while it runs.
  - **Try again** on `snagged` cards (§5.3).
- **Address row** shows the auto-assigned domain post-1002704; attach/change stays for custom domains, claiming "answering" only per §3.
- **Navigation doors (the page is currently orphaned):** the gate gets a signed-in "Your projects" door; the done panel links out (§7); the hall gets a cross-host link out to `cloudbongos.com/projects` (a door only — the surface itself never moves to the hall host). At least the gate and done-panel doors ship with task 1002696.
- **Refresh model:** slow interval + on-focus refetch for settled cards (§3); active-intent cards keep today's 5s poll.

## 9. First-run — designed now, delivered split

| First-run gap (walk source) | Design (this direction) | Delivery |
|---|---|---|
| Done panel promises a runner self-hosts don't have (task 1002717) | Shape-aware plan rendering (§7) | **task 1002696** |
| `FIRST_ADMIN` invisible — first user bounced to a nonexistent Owner (task 1002717) | A virgin instance's sign-in surface says plainly: "No one is admitted yet — the instance operator names the first admin," and points at the one-line fix (env var / branding field) | copy surface with task 1002696 where it lives in core UI; self-host docs + recipe with the **1002717 lane** |
| Newborn instance greets its founder with "your art coverage has ended" (idea 1000701) | §5.6 welcome + nag suppression until first-run completes | **Spun out as task 1002739** (decided during task 1002696: it lives on the CHILD instance's hall + needs roster, not on the control-plane surfaces this task owns — the "otherwise" branch of the split below) |
| `/create` + `/projects` unreachable on single-origin self-hosts (task 1002717) | Out of this direction's hands — a mounting/architecture question | **1002717 lane** |
| Runner assumes the founder's box six ways; founder-identity hardcodes (tasks 1002718, 1002719) | Not a surface concern | **hardening lane** |
| Refuse-unknown dispatch + runner-drift gate (task 1002722) | Not a surface concern | **hardening lane** |

## 10. Visual system — sunrise, tokenized, iterated

**Base:** the sunrise landing brand stays — these surfaces are continuous with the gate, not the hall.

**Token + component layer** (new, shared by the three surfaces — e.g. `public-landing/assets/sunrise.css`):
- Tokens aligned to the branding contract's themeable set. The currently-hardcoded semantics (`--card`, `--line`, `--ok`, `--err`, chip fills, strip states, sky gradients) become tokens **derived from contract vars via `color-mix`** where that reads well; the contract's `COLOR_VARS` set is extended only where derivation fails aesthetically. End state: an instance pack re-themes the whole page, not half of it.
- Component set: page shell (sky header), card, chip, progress strip, step list, choice card, field row, disclosure, confirm dialog. Types and states defined once, used by all three surfaces.

**Iteration loops (owner-requested — the look is nailed by review, not by this doc):**
1. **Loop 1 — component sheet.** A static mock page showing the token palette and every component in every state (all chips, all strips, a card in each lifecycle). Owner reviews and directs before any surface is rebuilt.
2. **Loop 2 — applied surfaces.** The three rebuilt surfaces staged for an owner walk (stage preview or static) before task 1002696 ships.
3. **Final gate:** the re-walk (task 1002697, with the true-stranger pass task 1002715) is the acceptance test for the whole act.

## 11. Scope boundaries

**In (task 1002696 implements):** the three surfaces rebuilt on the shared token/component layer; heartbeat sweep + two columns + API exposure; chip overlay + per-flow strips; owner-voice copy pass incl. error categories + disclosures; address-step collapse (task 1002704); repo-visibility statements; Bring-it-back + Try-again actions; nav doors (gate, done panel); shape-aware done panel. **Not** the newborn welcome — that landed as task 1002739 (see §9).

**Parallel (hardening lane, already seeded):** provision-time healthz gating, no-hook attach honesty, teardown-vs-dropdb reality, manifest race + spent-code fix (task 1002720); self-host reachability + FIRST_ADMIN recipe (task 1002717); runner assumptions (task 1002718); founder-identity hardcodes (task 1002719); dispatch/drift gates (task 1002722).

**Out:** the gate catalog (goal 1000031); the hall's federation my-projects surface; unreachable-instance Discord alerts (owner wants them — captured as idea 1000703, a follow-up on top of the heartbeat, deliberately not in task 1002696).

## 12. Implementation seams — what task 1002696 must not break

- The canonical onboard-plan contract (`GET /provisioning/onboard-plan`) and its consumers — the done panel renders *from* it; shape-awareness extends the plan, it doesn't fork it.
- The GitHub-App manifest flow (`startManifest` → public status/callback routes) — the one-click sign-in leg keeps working mid-redesign.
- The `sessionStorage` create-draft resume behavior.
- Branding injection: `landingPage()` string tokens (`{{productName}}` etc.) and `themeMarkup()`'s `:root` override — the new token layer must sit *under* it, not fight it.
- Apex-host mounting (`isApexHost`) — moving these pages off the control plane is 1002717-lane work, not this task.
- The provisioning API surface consumed by other callers; additions only, no breaking changes.
- `tests/onboard.mjs` and the walk's verified legs — the re-walk (task 1002697) must pass everything the checkpoint walk passed.

## 13. Sign-off dispositions (owner, 2026-08-12)

No open questions remain — both were decided at sign-off:

1. **Teardown does not drop the database** — retention is deliberate policy unless we find otherwise (§5.4). Any future change starts with the runner, and the copy follows it.
2. **Unreachable-instance Discord alerts: yes** — captured as idea 1000703, a follow-up on top of the heartbeat, outside task 1002696's scope.
