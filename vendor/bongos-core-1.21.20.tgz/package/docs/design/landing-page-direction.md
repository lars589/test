# The Landing Page — Direction

> **Task 1002747** (goal 1000061 "Apex UI pass") · decided with the owner 2026-08-13.
> The mock this approves: [`mocks/landing-page-mock.html`](mocks/landing-page-mock.html).
> Palette comparison sheet: [`mocks/landing-palettes.html`](mocks/landing-palettes.html) ·
> candidate tokens: <redacted>

Scope: the **look and content spine** of the page that answers `cloudbongos.com/`. Structure was
already settled by [`front-door-and-hub-direction.md`](front-door-and-hub-direction.md), whose §7
deferred the visual design to this pass and told it to take the structure as given. This document
does not reopen structure. It also does **not** cover the hub — that is the next surface.

---

## 1. Decisions (owner, 2026-08-13)

1. **The hero is the bongo pair, not the buddha.** Animated, pulsing on a beat.
2. **The palette is `ember marigold`** — the existing sunrise with the milk taken out.
3. **One file, with a server-side apex conditional.** `public-landing/index.html` renders two
   shapes rather than the platform getting its own landing file.
4. **`landingPage()` gains server-side head injection** — `og:`/`twitter:`/`canonical` are stamped
   from the server-side `branding()`, in this pass. This closes idea 1000715.

## 2. The hero — why the drums beat the buddha

The mascot was the obvious hero and is not the right one.

- **The bongo pair is already the brand mark.** `config/branding.neutral.json`'s favicon is two
  circles, big and small, with lighter heads. The hero is that mark made dimensional, so the tab
  icon and the hero are the same object rather than two unrelated illustrations.
- **It re-themes.** It is inline SVG whose every fill is a token, so it follows the palette. The
  buddha is a fixed raster and would have pinned one instance's art onto every instance's landing
  page — the same portability problem as the social tags.
- **It is ~3KB against 1.3MB.** The buddha hero is 44 webp frames above the fold.
- **It animates the tagline.** "Building software is laying down a beat" is a claim about rhythm;
  a drum being played states it, a seated figure only implies it.

The beat is a 1.6s loop: the big drum on 0.0 and 0.8, the small one syncopating at 0.4, 1.0 and
1.25, with ripples crossing each head, a shell bob, and a matching pulse in the glow and shadow. It
holds a static pose under `prefers-reduced-motion`.

> **Gotcha worth keeping.** The drum head is *skin*, not a card. An early version had it inherit
> `--bg-card` and it turned black in dark mode. The head carries its own `--skin-hi/mid/lo` tokens
> that stay a light parchment in both modes.

The buddha is **not retired** — it stays the brand's character, and the interactive widget
(task 1001523, still gated on two unshipped art shoots) has a home in goal 1000031. It is simply
not what answers `/`.

## 3. The palette — `ember marigold`

Six palettes were designed against distinct moods and ranked by a brand critique; the sheet and all
six token sets are preserved in `mocks/`. Marigold won on the thing the light mode most needed:

- **A genuinely pigmented backdrop.** Today's light mode has page, sky and cards all within a few
  points of white, so nothing has a figure/ground relationship and the page reads as fog. Marigold
  keeps the backdrop golden all the way to the footer and makes the cards the only near-white
  surfaces, so every panel lifts.
- **A fired accent.** `#ce4806` instead of `#f97316` — unmistakably the same bongo orange, but with
  heat behind it, and it clears contrast (see §4) where the current one does not.
- **Dark mode is not an inversion.** Cards are `#2c1710`, a deep saturated umber, and the accent
  pair flips direction — the hover/link tone goes *brighter* (`#ffab63`), which is how warm schemes
  actually behave on a dark ground.

**Its risk, recorded so the build can watch for it:** the palette is almost entirely warm and
almost entirely orange. The ivory cards and the lagoon `--sea` (`#0f7a96`) are the only relief
valves. If either gets crowded out the page tips into a single amber wash. If that happens in the
build, the fix already identified is to borrow adobe clay's move and give the scheme a real second
hue rather than to desaturate the first.

## 4. The contrast defect this pass found — fix it in the build

Every candidate palette was checked with a WCAG contrast calculator across twelve pairs, and the
calculator was pointed at the **current** tokens too. The palette shipping today fails AA:

| Pair | Ratio | Required | |
|---|---|---|---|
| white on `--accent` `#f97316` | **2.80:1** | 4.5 | **fail** |
| white on `--accent-deep` `#ea580c` | **3.56:1** | 4.5 | **fail** |
| `--accent-deep` as link text on a card | **3.56:1** | 4.5 | **fail** |

This is **not** limited to the landing page — `--accent` is the fill of every primary `.btn` and
`--accent-deep` is the link color on `/create` and `/projects` right now. Marigold's `#ce4806`
(4.61:1) and `#9e3406` (6.86:1) clear it. Tracked as its own task so the fix is not buried inside a
landing-page commit.

**`--chrome-accent` must follow `--accent` in the same change.** It is hardcoded `#f97316`/`#fb923c`
in `cosmos.css`, so a re-themed instance gets an orange wordmark and orange glass borders beside its
own accent. Marigold is orange enough that this is subtle, but it is wrong for every other pack and
it is a one-line fix per mode.

## 5. The content spine

Ordered. **Portable** = true on every instance; **apex-only** = true of Cloud Bongos the platform.
Press `S` in the mock to outline the apex-only blocks, `C` to see the child-instance shape.

| | Section | Portable? |
|---|---|---|
| S0 | Head metadata — title, description, canonical, `og:`, `twitter:` | server-stamped |
| S1 | Header — wordmark, Projects, Hall, mode toggle, identity chip | portable |
| S2 | Hero — self-typing eyebrow, tagline, sub, two CTAs, the drums | portable (2nd CTA apex-only) |
| S3 | The mechanism — the ledger · the gates · the grade | portable |
| S4 | The lifecycle — claim → build → grade → ship → credit | portable |
| S5 | Living proof — the real project catalog | **apex-only**, self-hides on empty |
| S6 | What you own — AGPL, capture-resistant | **apex-only** |
| S7 | Two doors — build a project · join as a builder | portable |
| S8 | Footer | split (see below) |

Copy notes:
- The sub is verbatim from `space.js:34` and the §S6 paragraph verbatim from `create.html:391` —
  both already public-facing and owner-approved. Not newly invented.
- **The footer line splits.** `index.html:104` currently ships *"A non-profit, capture-resistant
  commons"* to every instance, including ones that are neither. That half is apex-only; *"Built by
  agents, on Cloud Bongos"* is the portable attribution.
- **S3 is the differentiator, not "AI writes code."** That claim is crowded. What is actually
  enforced — a complete ledger, a server-checked rank ladder, an adversarial grade — is not.
- **No CLI download block.** `/downloads/bongos/*` only mounts when `config/bongos-cli.json` exists.
  It does not, and the live URL 404s. Do not design copy around it.

## 6. The design system

The page **links `cosmos.css`** and adds a page-local sheet. It does not fork it and does not start
a fourth design system. The lifecycle rail is literally `.strip`, the catalog chips are the same
`.chip` verification vocabulary the hub uses — the marketing page and the working page share
components rather than resembling each other.

`cosmos.css` was built for `/create` and `/projects` and is missing things a marketing page needs.
The build should add these to the shared layer, not to the page: a `.wrap` container, a type scale
below `h1`, a spacing scale, one grid primitive, and a mid (~900px) breakpoint. The mock authors all
five page-locally; they are marked in its stylesheet.

## 7. Constraints the build must respect

- **C1 · One `:root`.** `injectBrandingGlobal` splices the pack's theme `<style>` at the end of
  `<head>`; a page-local `:root` block silently outranks it and defeats re-branding. Page-local
  custom properties stay scoped to their component.
- **C2 · Dark changes are made twice.** `:root[data-mode="dark"]` and the
  `prefers-color-scheme` twin are byte-identical duplicates in `cosmos.css`. Both, every time.
- **C3 · The page must ship a `.sky` element.** The pack's `theme.backdrop` emits a
  `body{background:…}` that overrides `--page-bg` in both modes; `.sky` is the opaque fixed layer
  that paints over it.
- **C4 · `id="who"` is required.** `tests/platform_boot.mjs:120` asserts `/id="who"/` on the apex
  landing, and that test must leave `KNOWN_FAILING` in the same change that makes it pass — the
  ratchet fails the suite otherwise (idea 1000716).
- **C5 · Nothing about cloudbongos.com is hardcoded.** `public-landing/` ships wholesale to every
  instance.
- **C6 · Outbound links cannot be client-filled.** `clientBranding()` does not project `domains`, so
  `[data-link-hall]` never re-points and every child instance currently sends visitors to
  `builders.cloudbongos.com`. The §1.4 server-side injection is the fix that respects the branding
  contract's decision to keep origins server-side.
- **C7 · Real markup, not JS-built.** The page must read correctly to a crawler and with JavaScript
  off — the failure the gate shipped with and task 1002746 had to repair.

## 8. Follow-on tasks this direction produced

| Task | Goal | What it does |
|---|---|---|
| **task 1002748** | 1000061 | **The build carrier.** Builds this direction into `public-landing/index.html`: the content spine, the bongo hero, the apex conditional, and the server-stamped head tags. This document plus the mock are its contract. |
| **task 1002749** | 1000059 | **The WCAG defect** found in §4. Filed separately from the build because it is a live fault on `/create` and `/projects`, not a landing-page issue, and should not be buried inside a landing-page commit. |

Both are promoted and claimable. Neither is started.

Already existing, and gated on the build: **task 1002743** part 3 is the apex flip — it does not run
until the landing page carries a door into the hub, which §5's header now does, *and* the hub itself
exists.

## 9. What is deliberately still open

- **The hub is not designed.** `/projects` is the next surface and gets its own mock and direction.
- **The apex flip does not happen here.** `/` keeps redirecting until the hub exists; the flip is
  task 1002743 part 3 and is paired with an operator Caddy edit.
- **Whether the catalog band survives at three projects.** It reads thin today. The band self-hides
  on an empty feed, so shipping it is safe, but if the catalog stays this small the honest options
  are a threshold or cutting S5 and letting the hub carry the showcase.
- **The proof band's effect is weaker in dark mode.** In light it reads as a window into the hub; in
  dark the whole page is already dark and it separates only by tint.
