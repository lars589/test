# The Front Door and the Project Hub — Direction

> **Task 1002746** (goal 1000059), promoted from idea 1000713 · decided with the owner 2026-08-13.
> Surfaced by the gate-navigation session (task 1002741) and **revises it** — see §6.
> Time-sensitive: whichever page answers `/` when the pre-launch lock comes off becomes the
> product's first impression.

Scope: what `cloudbongos.com/` serves at launch, what happens to the `index.html` placeholder, and
how the project surfaces are organised. Deliberately **not** in scope: the visual design of any of
it — the owner plans a whole-site UI pass once the projects work completes, and this direction
settles structure so that pass inherits a clean shape rather than a decision.

---

## 0. Starting point — what exists today

Verified live on core 1.19.85 and read from `origin/main`.

**Two landing pages, and the wrong one answers the domain.**

| Path | Live | Notes |
|---|---|---|
| `/` | **302 → `/gate/` → 401** | the orb sky, behind the pre-launch `basic_auth` |
| `/index.html` | 200, public | reachable only if you type the filename |
| `/create`, `/projects` | 200, public | link only to each other |

`public-landing/index.html` declares what it is in its own source: *"a deliberately MINIMAL
placeholder home — just the mascot + a way into the Hall. The full landing page is a separate
task."* It is a pre-gate stub, not a competing design.

**The metadata is inverted.** The placeholder nobody reaches has a real product title and a meta
description. The gate that actually answers `/` shipped with `<title>Cloud Bongos — landing gate</title>`,
**no** description, **no** `og:`/`twitter:` tags, and **no** `<noscript>` — and the sky is entirely
JS-built, so a non-executing crawler or a JS-off visitor got a blank page. None of it bit yet only
because `X-Robots-Tag: noindex, nofollow` covers the whole host pre-launch. All of it bites at once
when the lock comes off.

**`index.html` is shared, not platform-specific.** It is the default landing every instance serves
(a child instance like `spike-harbor.cloudbongos.com` has no gate, so it already answers `/` with
this page). `/projects` is apex-only. That asymmetry constrains what may be hardcoded into it (§4).

---

## 1. Decisions (owner, 2026-08-13)

1. **`/` serves a real landing page** — proper title, meta description, `og:`/social tags, and the
   rest of the landing information. Not a redirect into an interactive experience.
2. **`/projects` becomes the project hub.** One surface absorbs *all* project-related actions:
   viewing the map/grid of projects, managing the signed-in owner's own projects, and creating new
   ones. `/create` redirects into it. The orb sky stops being a front door and becomes a **view
   inside the hub**.
3. **Launch-safety is fixed now; the visual build is deferred** to the whole-site UI pass.
4. **The pre-launch `basic_auth` is temporary** (carried over from task 1002741 §1).

## 2. The hub model

`/projects` is the single place a person goes for anything project-shaped:

| Inside the hub | Comes from today's |
|---|---|
| the map / grid of projects (orb sky + the sortable table) | `/gate/` (`view-space`, `view-table`) |
| your own projects — status, address, teardown, revive | `/projects` |
| creating a project | `/create` (redirects in) |

- **No new vocabulary.** The hub keeps the `/projects` URL rather than inventing `/projects-hub`;
  every existing link and bookmark keeps working, and "projects" already means projects to anyone
  who has seen the surface. (An underscore form — `/projects_hub` — was considered and rejected:
  underscores are unconventional in URLs and read poorly in search results.)
- **The map and the manage list are two views of one truth.** Both must render the verification
  overlay the task 1002696 direction established (`live · checked Xm ago` / `live?` / `unreachable`).
  A project cannot look alive on the map and unreachable in the list.
- **Signed-out visitors get the map** as a showcase, plus a way in. Signed-in owners additionally get
  their own projects — which is where owner-orbs (§6) land.

## 3. Sequencing — why the flip is NOT in this task

The apex flip is deliberately **not** shipped here, for a reason worth recording:

- `/` today at least reaches the sky, which carries a (weak) corner door to `/projects`. The shared
  `index.html` has **no** door into the hub at all — its only outbound link is the builders' hall.
  Flipping `/` to that page before it has doors would leave navigation **worse** than today, not
  better.
- The flip also has an **infra half**: `/` is redirected in two places — the app
  (`src/platform-server.js:115-121`) and the live Caddyfile (`redir / /gate/ 302` inside the `@gate`
  block, which also carries the `basic_auth`). Changing code alone moves nothing on prod. The Caddy
  edit is an operator act on the live box tied to launch, not a surface task.

So the flip ships **with** the hub build, once the landing page has doors, and is paired with the
Caddy change. What ships now is the part that is safe and useful regardless (§4).

## 4. What ships in this task (the launch-safety fix)

Because the gate is what answers `/` **today**, the launch-safety fix is applied to the gate — not to
a page that does not yet hold the door:

- **`public-landing/gate/index.html`**: a real `<title>`, a meta description, `canonical`,
  `og:type/site_name/url/title/description/image`, and `twitter:` card tags. Absolute
  `cloudbongos.com` URLs, matching the domain `space.js` already pins.
- **A `<noscript>` block** stating plainly what Cloud Bongos is and linking to `/projects`,
  `/create`, and the hall. Inline-styled, because every rule in `space.css` is scoped to a body
  view-class this block must ignore. **No visual change for a JS visitor** — it renders only when
  scripting is off.

**Explicitly not done, and why:** `og:` tags were *not* added to `public-landing/index.html`. It ships
to every instance, and social tags are read before JS runs — so its `window.__BRANDING__` fill cannot
populate them, and hardcoding `cloudbongos.com` would make every child instance advertise the wrong
site. Per-instance social tags need server-side injection; filed as **idea 1000715** rather than
hacked in here.

## 5. Findings surfaced while deciding this

- **`tests/platform_boot.mjs` is parked in `KNOWN_FAILING` and has rotted.** Its apex test asserts
  `/` returns 200 with the landing page; the gate redirect (task 1002408) made it 302, and the test
  was never updated. It sits in `run-unit-tests.js`'s `KNOWN_FAILING` set (parked by task 1002617 so
  the `unit` check could be made required), which is why CI is green. A `known_failing_ratchet.mjs`
  pairs with it and fails the suite if a parked test starts passing — so **the hub flip must unpark
  this test in the same change that makes it pass**. Filed as **idea 1000716**.
  - Note the test also asserts an identity chip (`id="who"`, task 2094) that `index.html` does not
    contain — a second, independent rot in the same file.
- The assertion the repo already carries (`/` → 200, the landing page) is exactly the behaviour this
  direction decides. The test was right; the code drifted past it.

## 6. Revision of the gate-navigation direction (task 1002741)

That direction was written hours earlier on the premise that **the gate is the front door**. This
direction supersedes that premise. What survives and what changes:

| Decision there | Status now |
|---|---|
| The `basic_auth` wall is temporary | **stands** |
| The type-`bongos` entry ritual is removed; land on the sky | **stands** — the sky is now a hub view, and the ritual should not gate a view any more than it should gate a front door |
| A persistent door in every gate view | **becomes hub navigation** — the same requirement, relocated: the door is now the hub's own nav between map / your projects / create, not a link out of the gate |
| A signed-in owner's projects get a distinct identity in the sky | **stands** — and lands inside the hub's map view |
| The sky is the public front door | **superseded** — `/` is the landing page; the sky is a view of `/projects` |

Both carriers are re-scoped accordingly: **task 1002743** (ritual removal + hub navigation, plus the
apex flip and unparking `platform_boot`) and **task 1002744** (owner-scoped feed + owned-orb identity
inside the hub map).

## 7. Boundary with the coming UI pass

This direction settles **structure**: which URL serves what, what the hub contains, and what
redirects where. It settles **no** visual design — not the landing page's layout, not the hub's
chrome, not how the map and list views sit together. Those belong to the whole-site UI pass the owner
plans after the projects work completes, and that pass should be able to take this structure as given
and change only how it looks.

## 8. Sign-off dispositions (owner, 2026-08-13)

1. **`/` = a real landing page**; the map/project list is a separate surface.
2. **That surface is `/projects`**, absorbing map, manage, and create — chosen over a new
   `/projects-hub` URL so no vocabulary or bookmarks are lost.
3. **Amend task 1002741's direction and re-scope its two carriers** rather than letting them ship
   against a premise that changed (§6).
4. **Decide + do the launch-safety fix now** — hence §4, and hence the flip deferred to §3.
